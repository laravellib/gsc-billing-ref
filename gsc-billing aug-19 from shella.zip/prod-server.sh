#!/usr/bin/env bash

php artisan serve --host=192.168.1.250 --port=8000
