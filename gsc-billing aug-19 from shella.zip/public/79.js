(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[79],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Others/Ledger.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMain.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBMain.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======
/* harmony import */ var _PHBMenu_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBMenu.vue */ "./resources/js/components/PHBComponents/PHBMenu.vue");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
<<<<<<< HEAD
  components: {},
  data: function data() {
    return {
      rows: [],
      noDataFound: true,
      noDataFound2: true,
      loading: false,
      search: "",
      OverAllBalance: 0,
      detailRows: [],
      showTable1: true
    };
  },
  mounted: function mounted() {
    this.getData();
  },
  methods: {
    getData: function getData() {
      var _this = this;

      this.loading = true;
      this.$Progress.start();
      axios.get("api/others", {
        params: {
          getLedger: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          var Balance = 0;
          response.data.forEach(function (item) {
            item.bcolor = item.SOANo != '' ? "bcolor-blue" : "bcolor-red";
            Balance = Balance + item.Amount;
            item.Balance = Balance;
          });
          _this.OverAllBalance = _this.$root.formatNumberCommaRound(Balance);
          _this.rows = response.data;
          _this.noDataFound = false;
        } else {
          _this.noDataFound = true;
        }

        _this.$Progress.finish();

        _this.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    rowClick: function rowClick(row) {
      var _this2 = this;

      if (row.SOANo == "") {
        this.showTable1 = false;
        this.$Progress.start();
        axios.get("api/others", {
          params: {
            getLedgerPayment: true,
            id: row.PLID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this2.detailRows = response.data;
            _this2.noDataFound2 = false;
          } else {
            _this2.detailRows = [];
            _this2.noDataFound2 = true;
          }

          _this2.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
      } else {
        this.showTable1 = true;
        this.$Progress.start();
        axios.get("api/others", {
          params: {
            getLedgerPaymentSOA: true,
            SOANo: row.SOANo
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this2.detailRows = response.data;
            _this2.noDataFound2 = false;
          } else {
            _this2.detailRows = [];
            _this2.noDataFound2 = true;
          }

          _this2.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
      }
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toString().toLowerCase().includes(v) || item.check_no.toString().toLowerCase().includes(v) || item.orNumber.toString().toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.height-modified {\n    height:300px !important;\n}\n.height-modified2 {\n    height:100px !important;\n}\n.bcolor-red {\n    background-color: #5eff69 !important;\n}\n.bcolor-blue {\n    background-color: #e5e1fc !important;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;
=======
  components: {
    'phb-menu': _PHBMenu_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMain.vue?vue&type=template&id=cc16284e&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBMain.vue?vue&type=template&id=cc16284e& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container" },
    [
      _c("phb-menu"),
      _vm._v(" "),
      _vm._m(0),
      _vm._v(" "),
      _c("h1", [_c("center", [_vm._v("Welcome to PHB section :)")])], 1)
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-8" }, [
      _c("div", { staticClass: "card" })
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=template&id=535d4ada&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Others/Ledger.vue?vue&type=template&id=535d4ada& ***!
  \****************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f& ***!
  \************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c("div", { staticClass: "container dave-template" }, [
    _c("div", { staticClass: "col-xs-12" }, [
      _c("div", { staticClass: "card" }, [
        _vm._m(0),
        _vm._v(" "),
        _c("div", { staticClass: "card-body table-responsive" }, [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-12 table-height2" }, [
              _c(
                "table",
                { staticClass: "table table-hover table-striped dave-table" },
                [
                  _vm._m(1),
                  _vm._v(" "),
                  _c(
                    "tbody",
                    { staticClass: "dave-tbody height-modified" },
                    [
                      _c(
                        "tr",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: this.loading,
                              expression: "this.loading"
                            }
                          ]
                        },
                        [_vm._m(2)]
                      ),
                      _vm._v(" "),
                      _c(
                        "tr",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: this.noDataFound,
                              expression: "this.noDataFound"
                            }
                          ]
                        },
                        [_vm._m(3)]
                      ),
                      _vm._v(" "),
                      _vm._l(_vm.filteredBlogs, function(item) {
                        return _c(
                          "tr",
                          {
                            class: item.bcolor,
                            on: {
                              click: function($event) {
                                return _vm.rowClick(item)
                              }
                            }
                          },
                          [
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatDate")(item.paymentDate)
                                    ) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(item.SOANo ? item.SOANo : "PAYMENT")
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.check_no) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.orNumber) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.paymentMode) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-right",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.paymentType == "DEBIT"
                                          ? item.Amount
                                          : "0"
                                      )
                                    )
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-right",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.paymentType == "CREDIT"
                                          ? item.Amount
                                          : "0"
                                      )
                                    )
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-right",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.Balance ? item.Balance : "0"
                                      )
                                    )
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c("td", { attrs: { width: "20%" } }, [
                              _vm._v(_vm._s(item.remarks))
                            ])
                          ]
                        )
                      })
                    ],
                    2
                  )
                ]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-8" }, [
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.showTable1,
                      expression: "showTable1"
=======
  return _c("div", [
    _c("img", { attrs: { src: __webpack_require__(/*! ./PHB.png */ "./resources/js/components/PHBComponents/PHB.png") } }),
    _vm._v(" "),
    _c(
      "nav",
      {
        staticClass:
          "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
      },
      [
        _c(
          "div",
          {
            staticClass: "collapse navbar-collapse",
            attrs: { id: "navbarNavDropdown" }
          },
          [
            _c("ul", { staticClass: "navbar-nav" }, [
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#mlist"
                    }
                  },
                  [
                    _vm._v(
                      "\r\n                        Master File\r\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "mlist"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/phbdriverlist" }
                          },
                          [_c("a", [_vm._v("PHB Driver List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/phbvehiclelist" }
                          },
                          [_c("a", [_vm._v("PHB List & Rate")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/locationlist" }
                          },
                          [_c("a", [_vm._v("Location List")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#trans"
                    }
                  },
                  [
                    _vm._v(
                      "\r\n                        Transactions\r\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "trans"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                    }
                  ],
                  staticClass: "row"
                },
                [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
<<<<<<< HEAD
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(4),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody height-modified2" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: this.noDataFound2,
                                    expression: "this.noDataFound2"
                                  }
                                ]
                              },
                              [_vm._m(5)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.detailRows, function(item) {
                              return _c("tr", [
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.paymentMode))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatDate")(item.paymentDate)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.check_no))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.orNumber))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.billed_amount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.check_amount)
                                    )
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: !_vm.showTable1,
                      expression: "!showTable1"
                    }
                  ],
                  staticClass: "row"
                },
                [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(6),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody height-modified2" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: this.noDataFound2,
                                    expression: "this.noDataFound2"
                                  }
                                ]
                              },
                              [_vm._m(7)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.detailRows, function(item) {
                              return _c("tr", [
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.SOANo))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.billed_amount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.check_amount)
                                    )
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ]
              )
            ]),
            _vm._v(" "),
            _vm._m(8),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-2" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.OverAllBalance,
                    expression: "OverAllBalance"
                  }
                ],
                staticClass: "form-control text-right",
                attrs: {
                  type: "text",
                  name: "OverAllBalance",
                  placeholder: ""
                },
                domProps: { value: _vm.OverAllBalance },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.OverAllBalance = $event.target.value
                  }
                }
              })
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-footer" })
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("VIEW LEDGER")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        PDate\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        SOA #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Check #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        OR #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        PMode\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        DEBIT\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        CREDIT\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        BALANCE\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        REMARKS\n                                    "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center b", attrs: { colspan: "4" } }, [
      _c("i", [_vm._v("Loading...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "4" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Mode\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Date\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Check #\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                OR #\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Amount\n                                            "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "6" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                SOANo\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Amount\n                                            "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "3" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-2 text-right" }, [
      _c("b", [_vm._v("OVERALL BALANCE :")])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/Others/Ledger.vue":
/*!***************************************************!*\
  !*** ./resources/js/components/Others/Ledger.vue ***!
  \***************************************************/
=======
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/phbvehiclelogentry" }
                          },
                          [_c("a", [_vm._v("PHB Vehicle Log Entry")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#report"
                    }
                  },
                  [
                    _vm._v(
                      "\r\n                        PHB Reports\r\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "report"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistPHB" }
                          },
                          [_c("a", [_vm._v("Standard PHB Report")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistPHBPerJeep" }
                          },
                          [_c("a", [_vm._v("PHB Vehicle Log Billing Report")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/PHBComponents/PHB.png":
/*!*******************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHB.png ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/PHB.png?21890255ae24f079f0fea1c3de620084";

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBMain.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMain.vue ***!
  \***********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _Ledger_vue_vue_type_template_id_535d4ada___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Ledger.vue?vue&type=template&id=535d4ada& */ "./resources/js/components/Others/Ledger.vue?vue&type=template&id=535d4ada&");
/* harmony import */ var _Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ledger.vue?vue&type=script&lang=js& */ "./resources/js/components/Others/Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Ledger.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



=======
/* harmony import */ var _PHBMain_vue_vue_type_template_id_cc16284e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBMain.vue?vue&type=template&id=cc16284e& */ "./resources/js/components/PHBComponents/PHBMain.vue?vue&type=template&id=cc16284e&");
/* harmony import */ var _PHBMain_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PHBMain.vue?vue&type=script&lang=js& */ "./resources/js/components/PHBComponents/PHBMain.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");


>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Ledger_vue_vue_type_template_id_535d4ada___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Ledger_vue_vue_type_template_id_535d4ada___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PHBMain_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PHBMain_vue_vue_type_template_id_cc16284e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PHBMain_vue_vue_type_template_id_cc16284e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/Others/Ledger.vue"
=======
component.options.__file = "resources/js/components/PHBComponents/PHBMain.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/Others/Ledger.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/components/Others/Ledger.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
=======
/***/ "./resources/js/components/PHBComponents/PHBMain.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMain.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************/
/*! no static exports found */
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMain_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBMain.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMain.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMain_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBMain.vue?vue&type=template&id=cc16284e&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMain.vue?vue&type=template&id=cc16284e& ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/Others/Ledger.vue?vue&type=template&id=535d4ada&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/Others/Ledger.vue?vue&type=template&id=535d4ada& ***!
  \**********************************************************************************/
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMain_vue_vue_type_template_id_cc16284e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBMain.vue?vue&type=template&id=cc16284e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMain.vue?vue&type=template&id=cc16284e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMain_vue_vue_type_template_id_cc16284e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMain_vue_vue_type_template_id_cc16284e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBMenu.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMenu.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBMenu.vue?vue&type=template&id=7678b87f& */ "./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/PHBComponents/PHBMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_535d4ada___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=template&id=535d4ada& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/Ledger.vue?vue&type=template&id=535d4ada&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_535d4ada___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_535d4ada___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBMenu.vue?vue&type=template&id=7678b87f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);