(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/EntrySOA.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/EntrySOA.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _search_SearchAllowance_SearchAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchAllowance/SearchAllowanceHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue");
/* harmony import */ var _search_SearchAllowance_SearchSOAAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSOAAllowanceHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchSOAAllowanceHeader.vue");
/* harmony import */ var _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSignatories.vue */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue");
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _search_client_list_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/client-list.vue */ "./resources/js/components/search/client-list.vue");
/* harmony import */ var _search_signatory_req_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/signatory-req.vue */ "./resources/js/components/search/signatory-req.vue");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'client-list': _search_client_list_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'signatory-req': _search_signatory_req_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    rental: {
      type: [Object, Array]
    }
  },
  data: function data() {
    return {
      searching: '',
      golfcart: {},
      details_data: {},
      detail: {},
      filter: {},
      datas: [],
      signatory: {},
      form: new Form({
        id: '',
        series_no: '',
        billed_id: '',
        billed_name: '',
        billed_address: '',
        soa_date: '',
        charge_invoice_no: '',
        period_covered: '',
        total_amount: '',
        remarks: '',
        details: '',
        status: 'ACTIVE',
        rentals: {},
        grandtotals: {}
      })
    };
  },
  methods: {
    get_signatory: function get_signatory(data) {
      var _this = this;

      this.signatory = data;
      this.$Progress.start();
      axios.get('rental_liftruck_soa/details/' + this.form.id).then(function (_ref) {
        var data = _ref.data;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        data.data.forEach(function (item) {
          item.AmountNumeric = 'Php ' + numeral(item.amount).format('0,0.00');
        });
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_3___default.a();
        doc.setFont('courier');
        doc.setFontType('bold');
        doc.setFontSize(12);
        doc.addImage(Logo, 'PNG', 15, 5, 30, 30);
        doc.setFontSize(14);
        doc.text('GENERAL SERVICES MULTIPURPOSE COOPERATIVE', 50, 15);
        doc.setFontSize(11);
        doc.text('Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon', 50, 20);
        doc.text('CDA # 9520-10019987-1 / TIN: 411-478-949-000', 50, 25);
        doc.setFontType('normal');
        doc.text('STATEMENT OF ACCOUNT', 80, 45);
        doc.text('SOA#' + _this.form.series_no, 150, 40);
        doc.text('BILLED TO:           ' + _this.form.billed_name, 30, 57);
        doc.text('                     ' + _this.form.billed_address, 30, 65);
        doc.text('PERIOD COVERED:      FOR THE MONTH OF ' + _this.form.soa_date, 30, 75);
        doc.autoTable({
          theme: 'plain',
          headStyles: {
            lineWidth: 0.01,
            lineColor: '#000'
          },
          columnStyles: {
            0: {
              halign: 'center',
              lineWidth: 0.01,
              lineColor: '#000'
            },
            1: {
              halign: 'center',
              lineWidth: 0.01,
              lineColor: '#000'
            },
            2: {
              halign: 'center',
              lineWidth: 0.01,
              lineColor: '#000'
            }
          },
          // European countries centered
          body: data.data,
          columns: [{
            header: 'Date',
            dataKey: 'req_date'
          }, {
            header: 'Particulars',
            dataKey: 'particulars'
          }, {
            header: 'Amount',
            dataKey: 'AmountNumeric'
          }],
          margin: {
            top: 80
          }
        });
        doc.text('Prepared By:', 30, 150);
        doc.text(_this.signatory.preparedBy, 30, 155);
        doc.text('Approved By:', 110, 150);
        doc.text(_this.signatory.approvedBy, 110, 155);
        doc.text('Noted By:', 30, 165);
        doc.text(_this.signatory.notedBy, 30, 170);
        doc.save('liftruck_soa_' + _this.form.series_no + '.pdf');
      });
      this.$Progress.finish();
    },
    print_soa: function print_soa() {
      if (this.form.id == '') {
        swal.fire('No Data is Selected.', 'warning');
      } else {
        $('#signatory-req').modal('show');
      }
    },
    post_soa: function post_soa() {
      var _this2 = this;

      if (this.form.id == '') {
        swal.fire('No Data is Selected.', 'warning');
      } else {
        this.form.put('api/liftruck_soa_hdr/' + this.form.id).then(function () {
          toast.fire({
            icon: 'success',
            title: 'Update data successfully'
          });

          _this2.form.reset();
        })["catch"](function () {
          swal.fire('Error Found.', 'warning');
        });
      }
    },
    createData: function createData() {
      var _this3 = this;

      if (this.form.id == '') {
        this.form.rentals = this.rental;
        this.form.grandtotals = this.grandtotal;
        this.$Progress.start();
        this.form.post('api/liftruck_soa_hdr').then(function (data) {
          toast.fire({
            icon: 'success',
            title: 'Added Data in successfully'
          });
          _this3.form.id = data.data.id;
        })["catch"](function () {
          _this3.$Progress.fail();

          toast.fire({
            icon: 'error',
            title: 'Error Found'
          });
        });
        this.$Progress.finish();
      }
    },
    searchClient: function searchClient() {
      $('#searchGolfcart').modal('show');
    },
    getData: function getData(data) {
      this.form.billed_id = data.id;
      this.form.billed_name = data.FullName;
      this.form.billed_address = data.Address;
    },
    soa_data: function soa_data(data) {
      this.form.fill(data);
    },
    searchSoa: function searchSoa() {
      $('#searchSOA').modal('show');
    }
  },
  mounted: function mounted() {},
  created: function created() {
    this.form.series_no = 'LSOA-' + moment__WEBPACK_IMPORTED_MODULE_0___default()().format('HHMMSS');
    this.form.soa_date = moment__WEBPACK_IMPORTED_MODULE_0___default()().format('YYYY-MM-DD');
    this.form.period_covered = moment__WEBPACK_IMPORTED_MODULE_0___default()().format('YYYY-MM-DD');
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _search_signatory_review_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/signatory-review.vue */ "./resources/js/components/search/signatory-review.vue");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'signatory-review': _search_signatory_review_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      id: 0,
      soa_no: '',
      searching: '',
      billed_name: '',
      billed_address: '',
      soa_date: '',
      golfcart: {},
      filter: {},
      detail: {},
      datas: [],
      showButton: false,
      showDetail: false,
      signatory: {}
    };
  },
  methods: {
    get_signatory: function get_signatory(data) {
      var _this = this;

      this.signatory = data;
      this.$Progress.start();

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      axios.get('rental_liftruck_soa/details/' + this.id).then(function (_ref) {
        var data = _ref.data;
        data.data.forEach(function (item) {
          item.AmountNumeral = 'Php ' + numeral(item.amount).format('0,0.00');
        });
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_1___default.a();
        doc.setFont('courier');
        doc.setFontType('bold');
        doc.setFontSize(12);
        doc.addImage(Logo, 'PNG', 15, 5, 30, 30);
        doc.setFontSize(14);
        doc.text('GENERAL SERVICES MULTIPURPOSE COOPERATIVE', 50, 15);
        doc.setFontSize(11);
        doc.text('Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon', 50, 20);
        doc.text('CDA # 9520-10019987-1 / TIN: 411-478-949-000', 50, 25);
        doc.setFontType('normal');
        doc.text('STATEMENT OF ACCOUNT', 80, 45);
        doc.text('SOA#' + _this.soa_no, 150, 40);
        doc.text('BILLED TO:           ' + _this.billed_name, 30, 57);
        doc.text('                     ' + _this.billed_address, 30, 65);
        doc.text('PERIOD COVERED:      FOR THE MONTH OF ' + _this.soa_date, 30, 75);
        doc.autoTable({
          theme: 'plain',
          headStyles: {
            lineWidth: 0.01,
            lineColor: '#000'
          },
          columnStyles: {
            0: {
              halign: 'center',
              lineWidth: 0.01,
              lineColor: '#000'
            },
            1: {
              halign: 'center',
              lineWidth: 0.01,
              lineColor: '#000'
            },
            2: {
              halign: 'center',
              lineWidth: 0.01,
              lineColor: '#000'
            }
          },
          // European countries centered
          body: data.data,
          columns: [{
            header: 'Date',
            dataKey: 'req_date'
          }, {
            header: 'Particulars',
            dataKey: 'particulars'
          }, {
            header: 'Amount',
            dataKey: 'AmountNumeric'
          }],
          margin: {
            top: 80
          }
        });
        doc.text('Prepared By:', 30, 150);
        doc.text(_this.signatory.preparedBy, 30, 155);
        doc.text('Approved By:', 110, 150);
        doc.text(_this.signatory.approvedBy, 110, 155);
        doc.text('Noted By:', 30, 165);
        doc.text(_this.signatory.notedBy, 30, 170);
        doc.save('liftruck_soa_' + _this.soa_no + '.pdf');
      });
      this.$Progress.finish();
    },
    soa_detail: function soa_detail() {
      var _this2 = this;

      axios.get('rental_liftruck_soa/details/' + this.id).then(function (_ref2) {
        var data = _ref2.data;
        _this2.detail = data.data;
      });
      this.showDetail = true;
    },
    paid_soa: function paid_soa() {
      var _this3 = this;

      if (this.id == '') {
        swal.fire('No Data is Selected.', 'warning');
      } else {
        swal.fire({
          title: 'Are you sure you want to set this as PAID/COLLECTED?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, Cancel it!'
        }).then(function (result) {
          if (result.value) {
            axios.get('rental_liftruck_soa/collected/' + _this3.id).then(function (_ref3) {
              var data = _ref3.data;

              _this3.review();
            });
          }
        });
      }
    },
    view_soa: function view_soa() {
      if (this.id == '') {
        swal.fire('No Data is Selected.', 'warning');
      } else {
        $('#signatory-review').modal('show');
      }
    },
    cancel_soa: function cancel_soa(id) {
      var _this4 = this;

      if (this.id == '') {
        swal.fire('No Data is Selected.', 'warning');
      } else {
        swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, Cancel it!'
        }).then(function (result) {
          if (result.value) {
            console.log(id);
            axios.get('rental_liftruck_soa/cancel/' + _this4.id).then(function (_ref4) {
              var data = _ref4.data;

              _this4.review();
            });
          }
        });
      }
    },
    review: function review() {
      var _this5 = this;

      axios.get('rental_liftruck_soa/review/' + this.datefrom + '/' + this.dateto).then(function (_ref5) {
        var data = _ref5.data;
        _this5.rental = data.data;
        _this5.filter = _this5.rental;
        console.log(data);
      });
    },
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      console.log(dataItem);
      this.id = dataItem.id;
      this.soa_no = dataItem.series_no;
      this.billed_name = dataItem.billed_name;
      this.billed_address = dataItem.billed_address;
      this.soa_date = dataItem.soa_date;
      this.showButton = true;
      this.showDetail = false;
    }
  },
  mounted: function mounted() {},
  created: function created() {
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_0___default()().format('YYYY-MM-DD');
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_0___default()().format('YYYY-MM-DD');
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Liftruck_SOA_Req_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA-Req.vue */ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue");
/* harmony import */ var _Liftruck_SOA_Review_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA-Review.vue */ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue");
/* harmony import */ var _Liftruck_Menu_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Liftruck-Menu.vue */ "./resources/js/components/liftruck/Liftruck-Menu.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_5__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======



>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
<<<<<<< HEAD
    "search-allowanceHeader": _search_SearchAllowance_SearchAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-allowanceSOAHeader": _search_SearchAllowance_SearchSOAAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "search-signatory": _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      header: {
        ASHID: "",
        SOANo: "",
        hdr_idLink: "",
        Period: "",
        Location: "",
        Date: "",
        billedTo: "",
        TIN: "",
        Address: "",
        Status: ""
      },
      formHeader: {
        ASHID: "",
        SOANo: "",
        hdr_idLink: "",
        Period: "",
        Location: "",
        Date: this.$root.formatDate(new Date()),
        billedTo: "Del Monte Philippines, Inc.",
        TIN: "000-291-799-000",
        Address: "Camp Phillips, Bukidnon",
        Prepared_by: "",
        Prepared_by_desig: "",
        Noted_by: "",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        Approved_by2: "",
        Approved_by2_desig: ""
      },
      detail: _defineProperty({
        ADID: "",
        hdr_idLink: "",
        EmpID: "",
        Chapa: "",
        FName: "",
        MName: "",
        LName: "",
        ExtName: "",
        manDays: "",
        GL: "",
        CostCenter: "",
        Gasoline: "0.00",
        Communication: "0.00",
        RentalMaintenance: "0.00",
        Others: "0.00",
        AdminFee: "0.00",
        SubTotal: "0.00"
      }, "SubTotal", "0.00"),
      updateMeHeader: false,
      detailList: [],
      dataInDetail: false,
      Total: "0.00",
      reportData: {
        to: "",
        thru: "",
        body: "",
        body2: "",
        Prepared_by: "",
        Prepared_by_desig: "",
        Checked_by: "",
        Checked_by_desig: "",
        Noted_by: "",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        department: "",
        url1: "",
        url2: ""
      },
      modalPage: 1,
      depList: []
    };
  },
  mounted: function mounted() {},
  methods: {
    newModal: function newModal() {
      this.clearHeader("formHeader");
      this.updateMeHeader = false;
      $("#addNew").modal("show");
    },
    updateAllowanceSOAHeaderButton: function updateAllowanceSOAHeaderButton() {
      if (!this.header.ASHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select/save Allowance SOA Header to continue."
        });
      }

      this.formHeader = Object.assign({}, this.header);
      this.updateMeHeader = true;
      $("#addNew").modal("show");
    },
    deleteAllowanceHeaderButton: function deleteAllowanceHeaderButton() {
      var _this = this;

      if (!this.header.ASHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select Allowance SOA Header to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(function (result) {
        if (result.value) {
          _this.$Progress.start();

          axios["delete"]("api/allowanceSOA/".concat(_this.header.ASHID)).then(function (response) {
            if (response.data.success) {
              _this.clearAll();

              swal.fire("Deleted!", response.data.message, "success");
            } else {
              swal.fire("Warning!", response.data.message, "warning");
            }

            _this.$Progress.finish();
          })["catch"](function (err) {
            console.log(err);
          });
        } else {
          swal.fire("Information!", "Deletion is cancelled.", "warning");
        }
      });
    },
    searchAllowanceHeaderButton: function searchAllowanceHeaderButton() {
      Fire.$emit("searchAllowanceHeader");
    },
    allowanceHeaderClose: function allowanceHeaderClose(row) {
      this.formHeader.Period = row.Period;
      this.formHeader.Location = row.Location;
      this.formHeader.hdr_idLink = row.AHID;
    },
    searchAllowanceSOAHeaderButton: function searchAllowanceSOAHeaderButton() {
      Fire.$emit("searchSOAAllowanceHeader");
    },
    allowanceSOAHeaderClose: function allowanceSOAHeaderClose(row) {
      this.header = Object.assign({}, row);
      this.getTotalAmount();
      this.getAllowanceDetail();
    },
    searchSearchSignatoryButton: function searchSearchSignatoryButton(number) {
      Fire.$emit("searchSignatory", number);
    },
    signatoryClose: function signatoryClose(row) {
      if (row.number == 1) {
        this.formHeader.Prepared_by = row.SignatoryName;
        this.formHeader.Prepared_by_desig = row.Designation;
      } else if (row.number == 2) {
        this.formHeader.Noted_by = row.SignatoryName;
        this.formHeader.Noted_by_desig = row.Designation;
      } else if (row.number == 3) {
        this.formHeader.Approved_by = row.SignatoryName;
        this.formHeader.Approved_by_desig = row.Designation;
      } else if (row.number == 4) {
        this.formHeader.Approved_by2 = row.SignatoryName;
        this.formHeader.Approved_by2_desig = row.Designation;
      } else if (row.number == 5) {
        this.reportData.Prepared_by = row.SignatoryName;
        this.reportData.Prepared_by_desig = row.Designation;
      } else if (row.number == 6) {
        this.reportData.Checked_by = row.SignatoryName;
        this.reportData.Checked_by_desig = row.Designation;
      } else if (row.number == 7) {
        this.reportData.Noted_by = row.SignatoryName;
        this.reportData.Noted_by_desig = row.Designation;
      } else if (row.number == 8) {
        this.reportData.Approved_by = row.SignatoryName;
        this.reportData.Approved_by_desig = row.Designation;
      }
    },
    saveSOAHeader: function saveSOAHeader() {
      var _this2 = this;

      var data = Object.assign({}, this.formHeader);
      this.$Progress.start();
      axios.post("api/allowanceSOAHeader", data).then(function (response) {
        if (response.data.success) {
          _this2.header = Object.assign({}, _this2.formHeader);
          console.log(_this2.formHeader);

          if (response.data.id) {
            _this2.header.ASHID = response.data.id;
            _this2.header.SOANo = response.data.SOANo;
          }

          toast.fire({
            icon: "success",
            title: response.data.message
          });
          _this2.header.Status = "ACTIVE";
          $("#addNew").modal("hide");
          _this2.formHeader = {};
        } else {
          toast.fire({
            icon: "warning",
            title: response.data.message
          });
        }

        _this2.getTotalAmount();

        _this2.getAllowanceDetail();

        _this2.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getTotalAmount: function getTotalAmount() {
      var _this3 = this;

      if (this.header.hdr_idLink) {
        axios.get("api/allowance", {
          params: {
            total: true,
            id: this.header.hdr_idLink
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this3.Total = _this3.$root.formatNumberCommaRound(response.data[0].TotalAmount);
          } else {
            _this3.Total = "0.00";
          }
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    getAllowanceDetail: function getAllowanceDetail() {
      var _this4 = this;

      axios.get("api/allowance", {
        params: {
          detail: true,
          id: this.header.hdr_idLink
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          _this4.dataInDetail = true;
          response.data.forEach(function (item) {
            item.FullName = item.LName + " " + item.ExtName + ", " + item.FName + " " + item.MName;
          });
          _this4.detailList = response.data;
        } else {
          _this4.detailList = [];
          _this4.dataInDetail = false;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    },
    printSOA: function printSOA() {
      var _this5 = this;

      this.$Progress.start();
      axios.get("api/reportAllowance", {
        params: {
          SOANo: this.header.SOANo,
          department: this.reportData["department"],
          type: 'ALLOWANCE'
        }
      }).then(function (response) {
        console.log(response.data);

        if (response.data.success) {
          _this5.reportData.url2 = "api/reportAllowance?report=true&SOANo=" + _this5.header.SOANo + "&department=" + _this5.reportData.department + "&type=ALLOWANCE";
        } else {
          swal.fire("Warning!", response.data.message, "warning");
        }

        _this5.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    postLedger: function postLedger() {
      var _this6 = this;

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Post it!"
      }).then(function (result) {
        if (result.value) {
          console.log(_this6.$root.formatNumber(_this6.Total));

          _this6.$Progress.start();

          var data = {
            SOANo: _this6.header.SOANo,
            amount: _this6.$root.formatNumber(_this6.Total)
          };
          axios.post("api/allowancePostLedger", data).then(function (response) {
            if (response.data.success) {
              _this6.header.Status = "POSTED TO LEDGER";
              toast.fire({
                icon: "success",
                title: response.data.message
              });
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this6.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    clearHeader: function clearHeader(type) {
      if (type == "header") {
        this.header = {};
      } else if (type == "reportData") {
        this.reportData = {
          to: "",
          thru: "",
          body: "",
          body2: "",
          Prepared_by: "",
          Prepared_by_desig: "",
          Checked_by: "",
          Checked_by_desig: "",
          Noted_by: "",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          department: "",
          url1: "",
          url2: ""
        };
      } else {
        this.formHeader = {
          ASHID: "",
          SOANo: "",
          hdr_idLink: "",
          Period: "",
          Location: "",
          Date: this.$root.formatDate(new Date()),
          billedTo: "Del Monte Philippines, Inc.",
          TIN: "000-291-799-000",
          Address: "Camp Phillips, Bukidnon",
          Prepared_by: "",
          Prepared_by_desig: "",
          Noted_by: "",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          Approved_by2: "",
          Approved_by2_desig: ""
        };
      }
    },
    clearAll: function clearAll() {
      this.clearHeader("header");
      this.clearHeader("formHeader");
      this.detailList = [];
    },
    // modal for print
    viewReport: function viewReport() {
      var _this7 = this;

      if (this.modalPage == 1) {
        this.modalPage = 2;
        axios.post("api/reportAllowanceSOASave", {
          to: this.reportData.to,
          thru: this.reportData.thru,
          body: this.reportData.body,
          body2: this.reportData.body2
        }).then(function (response) {
          if (response.data.success) {
            _this7.reportData.url1 = "api/reportSOA?report=true&SOANo=" + _this7.header.SOANo + "&Prepared_by=" + _this7.reportData.Prepared_by + "&Checked_by=" + _this7.reportData.Checked_by + "&Noted_by=" + _this7.reportData.Noted_by + "&Approved_by=" + _this7.reportData.Approved_by + "&reportID=" + response.data.id + "&type=ALLOWANCE";
          }

          _this7.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
        this.printSOA();
      } else {
        this.modalPage = 1;
      }
    },
    getDepartment: function getDepartment() {
      var _this8 = this;

      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getDepartment: true
        }
      }).then(function (response) {
        _this8.depList = response.data;

        _this8.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    reportModal: function reportModal() {
      this.getDepartment();
      var dec = this.$root.formatNumber(this.Total).toString().split(".");

      if (dec.length == 1) {
        var decimal = "00";
      } else {
        var decimal = dec[1].toString().padEnd(2, "0");
      }

      var numberToWord = this.$root.number2word(this.$root.formatNumber(this.Total)).toString().toUpperCase();
      this.reportData.to = "TO: MS.LORNA SEVILLEJO\n\xa0\xa0\xa0\xa0Accounting Supervisor\n\xa0\xa0\xa0\xa0Del Monte, Inc\n\xa0\xa0\xa0\xa0Camp Philips, Manolo Fortich, Bukidnon";
      this.reportData.thru = "THRU:\n\xa0\xa0\xa0\xa0MS.KAREN I. DOMINGUEZ\n\xa0\xa0\xa0\xa0HR Plantation Supervisor\n\xa0\xa0\xa0\xa0Del Monte, Inc\n\xa0\xa0\xa0\xa0Camp Philips, Manolo Fortich, Bukidnon";
      this.reportData.body = "Dear Ms. Sevillejo,\n\n\nThis is to bill Del Monte, Inc. the amount of " + numberToWord + " PESOS & " + decimal + "/100 ONLY (Php " + this.Total + ") for PPE issuance of Philpack Freezing Plant production employees. Please see attached file for your perusal.";
      this.reportData.body2 = "Please issue check in the name of GENERAL SERVICES MULTIPURPOSE COOPERATIVE.";
      this.reportData.Prepared_by = this.header.Prepared_by;
      this.reportData.Prepared_by_desig = this.header.Prepared_by_desig;
      this.reportData.Noted_by = this.header.Noted_by;
      this.reportData.Noted_by_desig = this.header.Noted_by_desig;
      this.reportData.Approved_by = this.header.Approved_by;
      this.reportData.Approved_by_desig = this.header.Approved_by_desig;
      $("#reportModal").modal("show");
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this9 = this;

      return this.detailList.filter(function (item) {
        return _this9.search.toLowerCase().split(" ").every(function (v) {
          return item.Chapa.toString().toLowerCase().includes(v) || item.FullName.toString().toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      type: ""
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("searchAllowanceHeader", function (data) {
      _this.type = data;

      _this.getAllowanceHeaderModal();

      $("#SearchAllowanceHeader").modal("show");
    });
  },
  methods: {
    rowClick: function rowClick(row) {
      this.$emit("rowClick", row);
      $("#SearchAllowanceHeader").modal("hide");
    },
    getAllowanceHeaderModal: function getAllowanceHeaderModal() {
      var _this2 = this;

      if (this.type == "soa") {
        axios.get("api/allowance", {
          params: {
            SOAOnly: true
          }
        }).then(function (response) {
          _this2.rows = response.data;
        })["catch"](function (error) {
          console.log(error);
        });
      } else {
        axios.get("api/allowance", {
          params: {
            header: true
          }
        }).then(function (response) {
          _this2.rows = response.data;
        })["catch"](function (error) {
          console.log(error);
        });
      }
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.Period.toLowerCase().includes(v) || item.Location.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      number: 0
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("searchSignatory", function (data) {
      _this.number = data;

      _this.getData();

      $("#SearchSignatory").modal("show");
    });
  },
  methods: {
    rowClick: function rowClick(row) {
      row.number = this.number;
      this.$emit("rowClick", row);
      $("#SearchSignatory").modal("hide");
    },
    getData: function getData() {
      var _this2 = this;

      axios.get("api/signatoryList").then(function (response) {
        response.data.forEach(function (item) {
          var extname = item.ename ? " " + item.ename : "";
          var mname = item.mname ? " " + item.mname[0] + "." : "";
          item.SignatoryName = item.fname + mname + " " + item.lname + extname;
          item.Designation = item.position;
        });
        _this2.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.SignatoryName.toLowerCase().includes(v);
        });
      });
    }
=======
    'create-soa': _Liftruck_SOA_Req_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'review-soa': _Liftruck_SOA_Review_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'liftruck-menu': _Liftruck_Menu_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
      datefrom: '',
      dateto: '',
      filter: {},
      selected: [],
      rental: {},
      clients: {},
      client: [],
      columnDefs: null,
      gridApi: null,
      columnApi: null,
      form: new Form({
        billed_id: '',
        billed_name: '',
        billed_address: '',
        series_no: '',
        soa_date: '',
        charge_invoice_no: '',
        remarks: '',
        amount: 0,
        id: 0
      })
    };
  },
  methods: {
    print_soa: function print_soa() {
      var _this = this;

      if (this.form.id == 0) {
        swal.fire('No Data is Selected.', 'warning');
      } else {
        this.$Progress.start();
        axios.get('rental_liftruck_soa/details/' + this.form.id).then(function (_ref) {
          var data = _ref.data;
          var doc = new jspdf__WEBPACK_IMPORTED_MODULE_4___default.a();
          doc.setFont('courier');
          doc.setFontType('bold');
          doc.setFontSize(12);
          doc.addImage(Logo, 'PNG', 15, 5, 30, 30);
          doc.setFontSize(14);
          doc.text('GENERAL SERVICES MULTIPURPOSE COOPERATIVE', 50, 15);
          doc.setFontSize(11);
          doc.text('Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon', 50, 20);
          doc.text('CDA # 9520-10019987-1 / TIN: 411-478-949-000', 50, 25);
          doc.setFontType('normal');
          doc.text('STATEMENT OF ACCOUNT', 80, 45);
          doc.text('SOA#' + _this.form.series_no, 150, 40);
          doc.text('BILLED TO:           ' + _this.form.billed_name, 30, 57);
          doc.text('                     ' + _this.form.billed_address, 30, 65);
          doc.text('PERIOD COVERED:      FOR THE MONTH OF ' + _this.form.soa_date, 30, 75);
          doc.autoTable({
            columnStyles: {
              0: {
                halign: 'center',
                fillColor: [0, 255, 0]
              },
              1: {
                halign: 'center',
                fillColor: [255, 255, 0]
              },
              2: {
                halign: 'center',
                fillColor: [0, 255, 255]
              }
            },
            // European countries centered
            body: data.data,
            columns: [{
              header: 'Date',
              dataKey: 'req_date'
            }, {
              header: 'Particulars',
              dataKey: 'particulars'
            }, {
              header: 'Amount',
              dataKey: 'amount'
            }],
            margin: {
              top: 80
            }
          });
          doc.text('Prepared By:', 30, 150);
          doc.text('Approved By:', 85, 150);
          doc.text('Noted By:', 150, 150);
          doc.save('liftruck_soa_' + _this.form.id + '.pdf');
        });
        this.$Progress.finish();
      }
    },
    preview: function preview() {
      var _this2 = this;

      axios.get('rental_liftruck_soa/search/' + this.datefrom + '/' + this.dateto).then(function (_ref2) {
        var data = _ref2.data;
        _this2.selected = [];
        _this2.rental = data.data;
        _this2.filter = _this2.rental;
      });
    },
    create_soa: function create_soa() {
      if (this.selected.length == 0) {
        swal.fire('No Rental Data Found.', 'warning');
      } else {
        $('#createSOA').modal('show');
      }
    },
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    onChange: function onChange(e) {
      var _this3 = this;

      this.form.applied_amount = 0;
      this.selected = [];
      var selectedRows = this.gridApi.getSelectedNodes();
      var selectedData = selectedRows.map(function (node) {
        return node.data;
      });
      var push = selectedData.map(function (node) {
        return _this3.selected.push(node);
      });
    },
    review_soa: function review_soa() {
      $('#reviewSOA').modal('show');
    },
    get_client: function get_client() {
      var _this4 = this;

      axios.get('search/client').then(function (_ref3) {
        var data = _ref3.data;
        _this4.clients = data.data;
      });
    }
  },
  created: function created() {
    this.columnDefs = [{
      headerName: 'Date',
      field: 'date',
      resizable: true,
      width: 170,
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true
    }, {
      headerName: 'Type',
      field: 'type',
      resizable: true,
      width: 170
    }, {
      headerName: 'Activity',
      field: 'po_activity',
      resizable: true,
      width: 170
    }, {
      headerName: 'Gross Amount',
      field: 'gross_amount',
      resizable: true,
      width: 170
    }, {
      headerName: '# Trips',
      field: 'no_trips',
      resizable: true,
      width: 170
    }, {
      headerName: 'Amount',
      field: 'amount',
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: 'center'
      },
      valueFormatter: this.$root.currencyFormatter
    }];
    this.filter = [];
    this.get_client();
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_3___default()().format('YYYY-MM-DD');
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_3___default()().format('YYYY-MM-DD');
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/EntrySOA.vue?vue&type=template&id=be13e716&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/EntrySOA.vue?vue&type=template&id=be13e716& ***!
  \*********************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-Menu.vue?vue&type=template&id=89804ff0&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-Menu.vue?vue&type=template&id=89804ff0& ***!
  \*************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
<<<<<<< HEAD
    "div",
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-2" }, [
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", [_vm._v("Control#")]),
                    _vm._v(" "),
                    _c(
                      "b-input-group",
                      [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.header.ASHID,
                              expression: "header.ASHID"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "control_no",
                            placeholder: "",
                            disabled: ""
                          },
                          domProps: { value: _vm.header.ASHID },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.header, "ASHID", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c(
                          "b-input-group-append",
                          [
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  variant: "outline-primary",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.searchAllowanceSOAHeaderButton()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-search",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  disabled: _vm.header.Status != "ACTIVE",
                                  variant: "outline-success",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.updateAllowanceSOAHeaderButton()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-edit",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  disabled: _vm.header.Status != "ACTIVE",
                                  variant: "outline-danger",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.deleteAllowanceHeaderButton()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-trash",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("SOA No.")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.SOANo,
                        expression: "header.SOANo"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "SOANo",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.SOANo },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "SOANo", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Date")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Date,
                        expression: "header.Date"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "date",
                      name: "Date",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Date },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Date", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Billed To")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.billedTo,
                        expression: "header.billedTo"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "billedTo",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.billedTo },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "billedTo", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3 text-center" }, [
                _c("label", { staticClass: "text-danger" }, [
                  _c("b", [_vm._v(_vm._s(_vm.header.Status))])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "form-group text-right" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { bold: "" },
                      on: { click: _vm.newModal }
                    },
                    [
                      _vm._v(
                        "\n                                New SOA Header\n                                "
                      ),
                      _c("i", { staticClass: "fa fa-user-plus fa fw" })
                    ]
                  )
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("TIN")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.TIN,
                        expression: "header.TIN"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "TIN",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.TIN },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "TIN", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Address")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Address,
                        expression: "header.Address"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Address",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Address },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Address", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Period")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Period,
                        expression: "header.Period"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Period",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Period },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Period", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Location")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Location,
                        expression: "header.Location"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Location",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Location },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Location", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Total")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.Total,
                        expression: "Total"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Total",
                      placeholder: "",
                      disabled: "",
                      "text-right": "",
                      bold: ""
                    },
                    domProps: { value: _vm.Total },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.Total = $event.target.value
                      }
                    }
                  })
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _vm._m(1),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody" },
                      [
                        _c(
                          "tr",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: !this.dataInDetail,
                                expression: "!this.dataInDetail"
                              }
                            ]
                          },
                          [_vm._m(2)]
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.detailList, function(item) {
                          return _c(
                            "tr",
                            {
                              key: item.ADID,
                              on: {
                                click: function($event) {
                                  return _vm.rowClick(item)
                                }
                              }
                            },
                            [
                              _c("td", { attrs: { bold: "" } }, [
                                _vm._v(_vm._s(item.Chapa))
                              ]),
                              _vm._v(" "),
                              _c("td", { attrs: { width: "20%" } }, [
                                _vm._v(_vm._s(item.FullName))
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.Gasoline)
                                    ) +
                                    "\n                                    "
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.Communication)
                                    ) +
                                    "\n                                    "
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.RentalMaintenance
                                      )
                                    ) +
                                    "\n                                    "
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.Others)
                                    ) +
                                    "\n                                    "
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.AdminFee)
                                    ) +
                                    "\n                                    "
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.SubTotal)
                                    ) +
                                    "\n                                    "
                                )
                              ])
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Prepared By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Prepared_by,
                        expression: "header.Prepared_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Prepared_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Prepared_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Prepared_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Noted By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Noted_by,
                        expression: "header.Noted_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Noted_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Noted_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Noted_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Approved By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Approved_by,
                        expression: "header.Approved_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Approved_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Approved_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Approved_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-3" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Approved By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Approved_by2,
                        expression: "header.Approved_by2"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Approved_by2",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Approved_by2 },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(
                          _vm.header,
                          "Approved_by2",
                          $event.target.value
                        )
                      }
                    }
                  })
                ])
              ])
            ]),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12 text-right" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-default",
                    attrs: { type: "button", bold: "" },
                    on: {
                      click: function($event) {
                        return _vm.clearAll()
                      }
                    }
                  },
                  [
                    _c("i", {
                      staticClass: "fa fa-eraser",
                      attrs: { "aria-hidden": "true" }
                    }),
                    _vm._v(
                      "\n                            Clear\n                        "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-primary",
                    attrs: {
                      disabled: !this.header.ASHID,
                      type: "button",
                      bold: ""
                    },
                    on: {
                      click: function($event) {
                        return _vm.reportModal()
                      }
                    }
                  },
                  [
                    _c("i", {
                      staticClass: "fa fa-print",
                      attrs: { "aria-hidden": "true" }
                    }),
                    _vm._v(
                      "\n                            Print\n                        "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-warning",
                    attrs: {
                      disabled: this.header.Status != "TRANSMITTED",
                      type: "button",
                      bold: ""
                    },
                    on: {
                      click: function($event) {
                        return _vm.postLedger()
                      }
                    }
                  },
                  [
                    _c("i", {
                      staticClass: "fa fa-calculator",
                      attrs: { "aria-hidden": "true" }
                    }),
                    _vm._v(
                      "\n                            POST to Ledger\n                        "
                    )
                  ]
                )
              ])
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" })
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-dialog-centered modal-lg",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header-cus" }, [
                  _c("div", { staticClass: "row container-fluid" }, [
                    _c("div", { staticClass: "col-md-11" }, [
                      _c("h5", [
                        _c(
                          "b",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: !this.updateMeHeader,
                                expression: "!this.updateMeHeader"
                              }
                            ]
                          },
                          [_vm._v("Create Allowance SOA Header")]
                        ),
                        _vm._v(" "),
                        _c(
                          "b",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: this.updateMeHeader,
                                expression: "this.updateMeHeader"
                              }
                            ]
                          },
                          [_vm._v("Update Allowance SOA Header")]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _vm._m(3)
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.saveSOAHeader()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body-cus" }, [
                      _c("div", { staticClass: "container-fluid" }, [
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col-md-3" }, [
                            _c("div", { staticClass: "form-group" }, [
                              _c("label", [_vm._v("Date")]),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.formHeader.Date,
                                    expression: "formHeader.Date"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "date",
                                  name: "Date",
                                  placeholder: "",
                                  required: ""
                                },
                                domProps: { value: _vm.formHeader.Date },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.formHeader,
                                      "Date",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-md-5" }, [
                            _c("div", { staticClass: "form-group" }, [
                              _c("label", [_vm._v("Billed To")]),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.formHeader.billedTo,
                                    expression: "formHeader.billedTo"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "billedTo",
                                  placeholder: "",
                                  required: ""
                                },
                                domProps: { value: _vm.formHeader.billedTo },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.formHeader,
                                      "billedTo",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-md-4" }, [
                            _c("div", { staticClass: "form-group" }, [
                              _c("label", [_vm._v("TIN")]),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.formHeader.TIN,
                                    expression: "formHeader.TIN"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "TIN",
                                  placeholder: "",
                                  required: ""
                                },
                                domProps: { value: _vm.formHeader.TIN },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.formHeader,
                                      "TIN",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col-md-5" }, [
                            _c("div", { staticClass: "form-group" }, [
                              _c("label", [_vm._v("Address")]),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.formHeader.Address,
                                    expression: "formHeader.Address"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "Address",
                                  placeholder: "",
                                  required: ""
                                },
                                domProps: { value: _vm.formHeader.Address },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.formHeader,
                                      "Address",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ])
                          ]),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "col-md-5" },
                            [
                              _c("label", [_vm._v("Location")]),
                              _vm._v(" "),
                              _c(
                                "b-input-group",
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.formHeader.Location,
                                        expression: "formHeader.Location"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "Location",
                                      placeholder: "",
                                      required: "",
                                      disabled: ""
                                    },
                                    domProps: {
                                      value: _vm.formHeader.Location
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.formHeader,
                                          "Location",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchAllowanceHeaderButton()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-md-2" }, [
                            _c("label", [_vm._v("Period")]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.formHeader.Period,
                                  expression: "formHeader.Period"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "Period",
                                placeholder: "",
                                required: "",
                                disabled: ""
                              },
                              domProps: { value: _vm.formHeader.Period },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.formHeader,
                                    "Period",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c(
                            "div",
                            { staticClass: "col-md-6" },
                            [
                              _c("label", [_vm._v("Prepared By")]),
                              _vm._v(" "),
                              _c(
                                "b-input-group",
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.formHeader.Prepared_by,
                                        expression: "formHeader.Prepared_by"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "Prepared_by",
                                      placeholder: "",
                                      required: "",
                                      disabled: ""
                                    },
                                    domProps: {
                                      value: _vm.formHeader.Prepared_by
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.formHeader,
                                          "Prepared_by",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchSearchSignatoryButton(
                                                1
                                              )
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "col-md-6" },
                            [
                              _c("label", [_vm._v("Noted By")]),
                              _vm._v(" "),
                              _c(
                                "b-input-group",
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.formHeader.Noted_by,
                                        expression: "formHeader.Noted_by"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "Noted_by",
                                      placeholder: "",
                                      required: "",
                                      disabled: ""
                                    },
                                    domProps: {
                                      value: _vm.formHeader.Noted_by
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.formHeader,
                                          "Noted_by",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchSearchSignatoryButton(
                                                2
                                              )
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "col-md-6" },
                            [
                              _c("label", [_vm._v("Approved By")]),
                              _vm._v(" "),
                              _c(
                                "b-input-group",
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.formHeader.Approved_by,
                                        expression: "formHeader.Approved_by"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "Approved_by",
                                      placeholder: "",
                                      required: "",
                                      disabled: ""
                                    },
                                    domProps: {
                                      value: _vm.formHeader.Approved_by
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.formHeader,
                                          "Approved_by",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchSearchSignatoryButton(
                                                3
                                              )
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "col-md-6" },
                            [
                              _c("label", [_vm._v("Approved By")]),
                              _vm._v(" "),
                              _c(
                                "b-input-group",
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.formHeader.Approved_by2,
                                        expression:
                                          "\n                                                formHeader.Approved_by2\n                                            "
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "Approved_by2",
                                      placeholder: "",
                                      required: "",
                                      disabled: ""
                                    },
                                    domProps: {
                                      value: _vm.formHeader.Approved_by2
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.formHeader,
                                          "Approved_by2",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchSearchSignatoryButton(
                                                4
                                              )
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ]),
                        _vm._v(" "),
                        _c("br"),
                        _vm._v(" "),
                        _vm._m(4)
                      ])
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "reportModal",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-dialog-centered modal-xl",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _vm._m(5),
                _vm._v(" "),
                _c("div", { staticClass: "modal-body-cus" }, [
                  _c("div", { staticClass: "container-fluid" }, [
                    _c(
                      "div",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.modalPage == 1,
                            expression: "modalPage == 1"
                          }
                        ],
                        staticClass: "row"
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass: "col-md-6",
                            staticStyle: { "border-right": "2px solid black" }
                          },
                          [
                            _c("div", { staticClass: "row" }, [
                              _c("div", { staticClass: "col-md-6" }, [
                                _c(
                                  "button",
                                  {
                                    staticClass: "btn btn-primary btn-xs",
                                    attrs: { type: "button", bold: "" },
                                    on: {
                                      click: function($event) {
                                        return _vm.viewReport()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-eye",
                                      attrs: { "aria-hidden": "true" }
                                    }),
                                    _vm._v(
                                      "\n                                            View Report\n                                        "
                                    )
                                  ]
                                )
                              ]),
                              _vm._v(" "),
                              _vm._m(6)
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "row" }, [
                              _c("div", { staticClass: "col-md-12" }, [
                                _c("label", [_vm._v("TO:")]),
                                _vm._v(" "),
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.reportData.to,
                                      expression: "reportData.to"
                                    }
                                  ],
                                  staticStyle: {
                                    width: "100%",
                                    height: "100px"
                                  },
                                  domProps: { value: _vm.reportData.to },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.reportData,
                                        "to",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "col-md-12" }, [
                                _c("label", [_vm._v("THRU:")]),
                                _vm._v(" "),
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.reportData.thru,
                                      expression: "reportData.thru"
                                    }
                                  ],
                                  staticStyle: {
                                    width: "100%",
                                    height: "100px"
                                  },
                                  domProps: { value: _vm.reportData.thru },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.reportData,
                                        "thru",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "col-md-12" }, [
                                _c("label", [_vm._v("BODY:")]),
                                _vm._v(" "),
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.reportData.body,
                                      expression: "reportData.body"
                                    }
                                  ],
                                  staticStyle: {
                                    width: "100%",
                                    height: "130px"
                                  },
                                  domProps: { value: _vm.reportData.body },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.reportData,
                                        "body",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "col-md-12" }, [
                                _c("label", [_vm._v("BODY2:")]),
                                _vm._v(" "),
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.reportData.body2,
                                      expression: "reportData.body2"
                                    }
                                  ],
                                  staticStyle: {
                                    width: "100%",
                                    height: "100px"
                                  },
                                  domProps: { value: _vm.reportData.body2 },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.reportData,
                                        "body2",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ])
                            ])
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "col-md-6",
                            staticStyle: { "border-right": "2px solid black" }
                          },
                          [
                            _vm._m(7),
                            _vm._v(" "),
                            _c("div", { staticClass: "row" }, [
                              _c("div", { staticClass: "col-md-12" }, [
                                _c("label", [_vm._v("Department:")]),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.reportData.department,
                                      expression: "reportData.department"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "department",
                                    placeholder: "",
                                    list: "department"
                                  },
                                  domProps: {
                                    value: _vm.reportData.department
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.reportData,
                                        "department",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "datalist",
                                  { attrs: { id: "department" } },
                                  _vm._l(_vm.depList, function(item) {
                                    return _c("option", { key: item.id }, [
                                      _vm._v(_vm._s(item.Department))
                                    ])
                                  }),
                                  0
                                )
                              ])
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "row" }, [
                              _c(
                                "div",
                                { staticClass: "col-md-6" },
                                [
                                  _c("label", [_vm._v("Prepared By:")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.reportData.Prepared_by,
                                            expression:
                                              "\n                                                    reportData.Prepared_by\n                                                "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Prepared_by",
                                          placeholder: "",
                                          required: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.reportData.Prepared_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.reportData,
                                              "Prepared_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    5
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "col-md-6" },
                                [
                                  _c("label", [_vm._v("Checked By:")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.reportData.Checked_by,
                                            expression:
                                              "\n                                                    reportData.Checked_by\n                                                "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Checked_by",
                                          placeholder: "",
                                          required: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.reportData.Checked_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.reportData,
                                              "Checked_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    6
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "row" }, [
                              _c(
                                "div",
                                { staticClass: "col-md-6" },
                                [
                                  _c("label", [_vm._v("Noted By:")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.reportData.Noted_by,
                                            expression:
                                              "\n                                                    reportData.Noted_by\n                                                "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Noted_by",
                                          placeholder: "",
                                          required: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.reportData.Noted_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.reportData,
                                              "Noted_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    7
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "col-md-6" },
                                [
                                  _c("label", [_vm._v("Approved By:")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.reportData.Approved_by,
                                            expression:
                                              "\n                                                    reportData.Approved_by\n                                                "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Approved_by",
                                          placeholder: "",
                                          required: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.reportData.Approved_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.reportData,
                                              "Approved_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    8
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ]
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.modalPage == 2,
                            expression: "modalPage == 2"
                          }
                        ],
                        staticClass: "row"
                      },
                      [
                        _c("div", { staticClass: "col-md-6" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col-md-6" }, [
                              _c(
                                "button",
                                {
                                  staticClass: "btn btn-primary btn-xs",
                                  attrs: { type: "button", bold: "" },
                                  on: {
                                    click: function($event) {
                                      return _vm.viewReport()
                                    }
                                  }
                                },
                                [
                                  _c("i", {
                                    staticClass: "fa fa-arrow-left",
                                    attrs: { "aria-hidden": "true" }
                                  }),
                                  _vm._v(
                                    "\n                                            Back to Setting\n                                        "
                                  )
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _vm._m(8)
                          ]),
                          _vm._v(" "),
                          _c("iframe", {
                            attrs: {
                              width: "100%",
                              height: "550px",
                              src: _vm.reportData.url1
                            }
                          })
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-md-6" }, [
                          _vm._m(9),
                          _vm._v(" "),
                          _c("iframe", {
                            attrs: {
                              width: "100%",
                              height: "550px",
                              src: _vm.reportData.url2
                            }
                          })
                        ])
                      ]
                    )
                  ])
                ])
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-allowanceHeader", {
        on: {
          rowClick: function($event) {
            return _vm.allowanceHeaderClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-allowanceSOAHeader", {
        on: {
          rowClick: function($event) {
            return _vm.allowanceSOAHeaderClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-signatory", {
        on: {
          rowClick: function($event) {
            return _vm.signatoryClose($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("ALLOWANCE SOA ENTRY")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [_vm._v("Chapa")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Fullname\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("Gasoline")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("Comm")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("Rent&Maint")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("Others")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("Admin Fee")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("Sub Total")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "8" } }, [
      _c("i", [_vm._v("No Data Found...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-1" }, [
      _c(
        "button",
        {
          staticClass: "close close-modal",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12 text-right" }, [
        _c(
          "button",
          {
            staticClass: "btn btn-success",
            attrs: { type: "submit", bold: "" }
          },
          [
            _c("i", {
              staticClass: "fa fa-save",
              attrs: { "aria-hidden": "true" }
            }),
            _vm._v(
              "\n                                        SAVE\n                                    "
            )
          ]
        )
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Generate SOA Report")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-6 text-right" }, [
      _c("h6", [_c("i", [_vm._v("Page 1")])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-6" }),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-6 text-right" }, [
        _c("h6", [_c("i", [_vm._v("Page 2 (Attachment)")])])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-6 text-right" }, [
      _c("h6", [_c("i", [_vm._v("Page 1")])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-6" }),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-6 text-right" }, [
        _c("h6", [_c("i", [_vm._v("Page 2 (Attachment)")])])
      ])
    ])
  }
]
=======
    "nav",
    { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
    [
      _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
        _vm._v("LIFT TRUCK SECTION")
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "collapse navbar-collapse", attrs: { id: "navbarNav" } },
        [
          _c("ul", { staticClass: "navbar-nav" }, [
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-list"
                    }
                  },
                  [_vm._v("Lift Truck List")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-location"
                    }
                  },
                  [_vm._v("Route")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-driver"
                    }
                  },
                  [_vm._v("Drivers")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-po"
                    }
                  },
                  [_vm._v("Purchase Order")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-rental"
                    }
                  },
                  [_vm._v("Rental")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-soa"
                    }
                  },
                  [_vm._v("Create SOA")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-payment"
                    }
                  },
                  [_vm._v("Payment Collection")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-ledger"
                    }
                  },
                  [_vm._v("Ledger")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/liftruck-reports"
                    }
                  },
                  [_vm._v("Reports")]
                )
              ],
              1
            )
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = []
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& ***!
  \****************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c(
    "div",
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "SearchAllowanceHeader",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-md",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.search,
                          expression: "search"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "search",
                        placeholder: "Search here..."
                      },
                      domProps: { value: _vm.search },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.search = $event.target.value
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          _vm._l(_vm.filteredBlogs, function(item) {
                            return _c(
                              "tr",
                              {
                                on: {
                                  click: function($event) {
                                    return _vm.rowClick(item)
                                  }
                                }
                              },
                              [
                                _c("td", { attrs: { width: "20%" } }, [
                                  _vm._v(
                                    "\n                                            " +
                                      _vm._s(item.Period) +
                                      "\n                                        "
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Location))]),
                                _vm._v(" "),
                                _c("td", { attrs: { width: "25%" } }, [
                                  _vm._v(
                                    "\n                                            " +
                                      _vm._s(
                                        _vm._f("formatDate")(item.date_created)
                                      ) +
                                      "\n                                        "
                                  )
                                ])
                              ]
                            )
                          }),
                          0
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Allowance Header List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
=======
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "createSOA",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body" }, [
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.createData()
                    }
                  }
                },
                [
                  _c("div", { staticClass: "modal-body" }, [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "golfcart" } }, [
                          _vm._v("SOA No")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.series_no,
                              expression: "form.series_no"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "series_no" },
                          domProps: { value: _vm.form.series_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "series_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Date")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.soa_date,
                              expression: "form.soa_date"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date", name: "soa_date" },
                          domProps: { value: _vm.form.soa_date },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "soa_date",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Status")
                        ]),
                        _vm._v(" "),
                        _c("p", [_vm._v(_vm._s(_vm.form.status))])
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "col",
                          staticStyle: { "text-align": "center" }
                        },
                        [
                          _c("label", { attrs: { for: "refence" } }, [
                            _vm._v("Amount")
                          ]),
                          _vm._v(" "),
                          _c("p", [_vm._v(_vm._s(_vm.form.total_amount))])
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "golfcart" } }, [
                          _vm._v("Billed to")
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "input-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.billed_name,
                                expression: "form.billed_name"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: {
                              type: "text",
                              disabled: "",
                              name: "billed_name"
                            },
                            domProps: { value: _vm.form.billed_name },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "billed_name",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "span",
                            { staticClass: "input-group-btn" },
                            [
                              _c(
                                "button",
                                {
                                  staticClass: "btn btn-outline-primary btn-sm",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      return _vm.searchClient()
                                    }
                                  }
                                },
                                [_vm._v("Search")]
                              ),
                              _vm._v(" "),
                              _c("client-list", {
                                on: { golfcart_data: _vm.getData }
                              }),
                              _vm._v(" "),
                              _c("signatory-req", {
                                on: { signatory: _vm.get_signatory }
                              })
                            ],
                            1
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Period Covered")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.period_covered,
                              expression: "form.period_covered"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date", name: "period_convered" },
                          domProps: { value: _vm.form.period_covered },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "period_covered",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Address")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.billed_address,
                              expression: "form.billed_address"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: {
                            type: "text",
                            name: "billed_address",
                            disabled: ""
                          },
                          domProps: { value: _vm.form.billed_address },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "billed_address",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Charge Invoice")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.charge_invoice_no,
                              expression: "form.charge_invoice_no"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "charge_invoice_no" },
                          domProps: { value: _vm.form.charge_invoice_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "charge_invoice_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Remarks")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.remarks,
                              expression: "form.remarks"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "remarks" },
                          domProps: { value: _vm.form.remarks },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "remarks", $event.target.value)
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Details")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.details,
                              expression: "form.details"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "details" },
                          domProps: { value: _vm.form.details },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "details", $event.target.value)
                            }
                          }
                        })
                      ])
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-footer" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-primary",
                        attrs: { type: "submit" }
                      },
                      [_vm._v("Create")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-secondary",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            return _vm.print_soa()
                          }
                        }
                      },
                      [_vm._v("PRINT")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-danger",
                        attrs: { type: "button", "data-dismiss": "modal" }
                      },
                      [_vm._v("Close")]
                    )
                  ])
                ]
              )
            ])
          ])
        ])
      ]
    )
  ])
}
var staticRenderFns = [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { attrs: { width: "20%" } }, [_vm._v("Period")]),
        _vm._v(" "),
        _c("th", [_vm._v("Location")]),
        _vm._v(" "),
        _c("th", { attrs: { width: "25%" } }, [_vm._v("Date Created")])
      ])
=======
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Create Liftruck SOA")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& ***!
  \*******************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c(
    "div",
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "SearchSignatory",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-md",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.search,
                          expression: "search"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "search",
                        placeholder: "Search Signatory here..."
                      },
                      domProps: { value: _vm.search },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.search = $event.target.value
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          _vm._l(_vm.filteredBlogs, function(item) {
                            return _c(
                              "tr",
                              {
                                key: item.SID,
                                on: {
                                  click: function($event) {
                                    return _vm.rowClick(item)
                                  }
                                }
                              },
                              [
                                _c("td", [_vm._v(_vm._s(item.SignatoryName))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Designation))])
                              ]
                            )
                          }),
                          0
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
  )
=======
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "reviewSOA",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c(
            "div",
            { staticClass: "modal-content" },
            [
              _vm._m(0),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c(
                  "div",
                  { staticClass: "container" },
                  [
                    _c("div", { staticClass: "row mt-3" }, [
                      _vm._v(
                        "\n              Search by SOA Date\n              "
                      ),
                      _c("div", { staticClass: "col" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.datefrom,
                              expression: "datefrom"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.datefrom },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.datefrom = $event.target.value
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.dateto,
                              expression: "dateto"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.dateto },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.dateto = $event.target.value
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-secondary",
                            on: {
                              click: function($event) {
                                return _vm.review()
                              }
                            }
                          },
                          [_vm._v("Review")]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "kendo-grid",
                      {
                        attrs: {
                          height: 200,
                          "data-source": _vm.filter,
                          selectable: true,
                          sortable: true
                        },
                        on: { change: _vm.onChange }
                      },
                      [
                        _c("kendo-grid-column", {
                          attrs: { field: "soa_date", title: "SOA Date" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "series_no", title: "SOA No" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "billed_name", title: "Billed To" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: {
                            field: "charge_invoice_no",
                            title: "Charge Invoice No"
                          }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "status", title: "Status" }
                        })
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _vm.showButton
                ? _c("div", { staticClass: "container" }, [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("p", [_vm._v("SOA: " + _vm._s(_vm.soa_no))]),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.soa_detail()
                              }
                            }
                          },
                          [_vm._v("View Detail")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.cancel_soa(_vm.id)
                              }
                            }
                          },
                          [_vm._v("Cancel SOA")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.view_soa()
                              }
                            }
                          },
                          [_vm._v("Preview SOA Form")]
                        )
                      ])
                    ])
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.showDetail
                ? _c("div", { staticClass: "container" }, [
                    _c(
                      "div",
                      { staticClass: "row" },
                      [
                        _c(
                          "kendo-grid",
                          {
                            attrs: {
                              height: 150,
                              "data-source": _vm.detail,
                              selectable: true,
                              sortable: true
                            }
                          },
                          [
                            _c("kendo-grid-column", {
                              attrs: { field: "req_date", title: "Date" }
                            }),
                            _vm._v(" "),
                            _c("kendo-grid-column", {
                              attrs: {
                                field: "particulars",
                                title: "Particulars"
                              }
                            }),
                            _vm._v(" "),
                            _c("kendo-grid-column", {
                              attrs: { field: "amount", title: "Amount" }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c("signatory-review", { on: { signatory: _vm.get_signatory } }),
              _vm._v(" "),
              _vm._m(1)
            ],
            1
          )
        ])
      ]
    )
  ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Signatory List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
=======
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("SOA Review")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Signatory Name")]),
        _vm._v(" "),
        _c("th", [_vm._v("Designation")])
      ])
=======
    return _c("div", { staticClass: "modal-footer" }, [
      _c(
        "button",
        {
          staticClass: "btn btn-danger",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [
          _c("i", { staticClass: "far fa-window-close" }),
          _vm._v(" Close\n          ")
        ]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/allowance/EntrySOA.vue":
/*!********************************************************!*\
  !*** ./resources/js/components/allowance/EntrySOA.vue ***!
  \********************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      { staticClass: "row" },
      [
        _c("img", { attrs: { src: __webpack_require__(/*! ./LiftTruck.png */ "./resources/js/components/liftruck/LiftTruck.png") } }),
        _vm._v(" "),
        _c("liftruck-menu"),
        _vm._v(" "),
        _c("div", { attrs: { id: "dmpi" } }, [
          _c("div", { staticClass: "row mt-3" }, [
            _vm._v("\n        Search by Trans Date\n        "),
            _c("div", { staticClass: "col" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.datefrom,
                    expression: "datefrom"
                  }
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "date", placeholder: "Search Rental..." },
                domProps: { value: _vm.datefrom },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.datefrom = $event.target.value
                  }
                }
              })
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.dateto,
                    expression: "dateto"
                  }
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "date", placeholder: "Search Rental..." },
                domProps: { value: _vm.dateto },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.dateto = $event.target.value
                  }
                }
              })
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-secondary",
                  on: {
                    click: function($event) {
                      return _vm.preview()
                    }
                  }
                },
                [_vm._v("Preview")]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mt-3" }, [
            _c(
              "div",
              { staticClass: "col-sm" },
              [
                _c("ag-grid-vue", {
                  staticClass: "ag-theme-balham",
                  staticStyle: { width: "1050px", height: "200px" },
                  attrs: {
                    columnDefs: _vm.columnDefs,
                    rowData: _vm.filter,
                    rowSelection: "multiple"
                  },
                  on: {
                    "grid-ready": _vm.onGridReady,
                    selectionChanged: _vm.onChange
                  }
                }),
                _vm._v(" "),
                _c("create-soa", { attrs: { rental: _vm.selected } }),
                _vm._v(" "),
                _c("review-soa")
              ],
              1
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "modal-footer" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-primary",
                  attrs: { type: "submit" },
                  on: {
                    click: function($event) {
                      return _vm.create_soa()
                    }
                  }
                },
                [_vm._v("Create SOA")]
              ),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-success",
                  attrs: { type: "submit" },
                  on: {
                    click: function($event) {
                      return _vm.review_soa()
                    }
                  }
                },
                [_vm._v("Manage SOA")]
              ),
              _vm._v(" "),
              _c(
                "button",
                { staticClass: "btn btn-success", attrs: { type: "submit" } },
                [_vm._v("Print Charge Invoice")]
              ),
              _vm._v(" "),
              _c(
                "button",
                { staticClass: "btn btn-success", attrs: { type: "submit" } },
                [_vm._v("Print Delivery")]
              )
            ])
          ])
        ])
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/liftruck/LiftTruck.png":
/*!********************************************************!*\
  !*** ./resources/js/components/liftruck/LiftTruck.png ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/LiftTruck.png?da61557599ebb8f7b52916f82b5bfeb9";

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-Menu.vue":
/*!************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-Menu.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Liftruck_Menu_vue_vue_type_template_id_89804ff0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-Menu.vue?vue&type=template&id=89804ff0& */ "./resources/js/components/liftruck/Liftruck-Menu.vue?vue&type=template&id=89804ff0&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _Liftruck_Menu_vue_vue_type_template_id_89804ff0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_Menu_vue_vue_type_template_id_89804ff0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/liftruck/Liftruck-Menu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-Menu.vue?vue&type=template&id=89804ff0&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-Menu.vue?vue&type=template&id=89804ff0& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_Menu_vue_vue_type_template_id_89804ff0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-Menu.vue?vue&type=template&id=89804ff0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-Menu.vue?vue&type=template&id=89804ff0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_Menu_vue_vue_type_template_id_89804ff0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_Menu_vue_vue_type_template_id_89804ff0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue":
/*!***************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Req.vue ***!
  \***************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _EntrySOA_vue_vue_type_template_id_be13e716___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EntrySOA.vue?vue&type=template&id=be13e716& */ "./resources/js/components/allowance/EntrySOA.vue?vue&type=template&id=be13e716&");
/* harmony import */ var _EntrySOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EntrySOA.vue?vue&type=script&lang=js& */ "./resources/js/components/allowance/EntrySOA.vue?vue&type=script&lang=js&");
=======
/* harmony import */ var _Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& */ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&");
/* harmony import */ var _Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA-Req.vue?vue&type=script&lang=js& */ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _EntrySOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _EntrySOA_vue_vue_type_template_id_be13e716___WEBPACK_IMPORTED_MODULE_0__["render"],
  _EntrySOA_vue_vue_type_template_id_be13e716___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/allowance/EntrySOA.vue"
=======
component.options.__file = "resources/js/components/liftruck/Liftruck-SOA-Req.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/allowance/EntrySOA.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/allowance/EntrySOA.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
=======
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EntrySOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./EntrySOA.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/EntrySOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EntrySOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/allowance/EntrySOA.vue?vue&type=template&id=be13e716&":
/*!***************************************************************************************!*\
  !*** ./resources/js/components/allowance/EntrySOA.vue?vue&type=template&id=be13e716& ***!
  \***************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Req.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& ***!
  \**********************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EntrySOA_vue_vue_type_template_id_be13e716___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./EntrySOA.vue?vue&type=template&id=be13e716& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/EntrySOA.vue?vue&type=template&id=be13e716&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EntrySOA_vue_vue_type_template_id_be13e716___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EntrySOA_vue_vue_type_template_id_be13e716___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue ***!
  \**********************************************************************************/
=======
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue":
/*!******************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Review.vue ***!
  \******************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _SearchAllowanceHeader_vue_vue_type_template_id_5395bd3c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c& */ "./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c&");
/* harmony import */ var _SearchAllowanceHeader_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchAllowanceHeader.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& */ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&");
/* harmony import */ var _Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA-Review.vue?vue&type=script&lang=js& */ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _SearchAllowanceHeader_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchAllowanceHeader_vue_vue_type_template_id_5395bd3c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchAllowanceHeader_vue_vue_type_template_id_5395bd3c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue"
=======
component.options.__file = "resources/js/components/liftruck/Liftruck-SOA-Review.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************/
=======
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchAllowanceHeader_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchAllowanceHeader.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchAllowanceHeader_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c& ***!
  \*****************************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Review.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& ***!
  \*************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchAllowanceHeader_vue_vue_type_template_id_5395bd3c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchAllowanceHeader.vue?vue&type=template&id=5395bd3c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchAllowanceHeader_vue_vue_type_template_id_5395bd3c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchAllowanceHeader_vue_vue_type_template_id_5395bd3c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue ***!
  \******************************************************************************/
=======
/***/ "./resources/js/components/liftruck/Liftruck-SOA.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA.vue ***!
  \***********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchSignatories.vue?vue&type=template&id=93faadfe& */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&");
/* harmony import */ var _SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchSignatories.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA.vue?vue&type=template&id=f2b2d828& */ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&");
/* harmony import */ var _Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA.vue?vue&type=script&lang=js& */ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/search/SearchAllowance/SearchSignatories.vue"
=======
component.options.__file = "resources/js/components/liftruck/Liftruck-SOA.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
=======
/***/ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchSignatories.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe& ***!
  \*************************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchSignatories.vue?vue&type=template&id=93faadfe& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA.vue?vue&type=template&id=f2b2d828& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);