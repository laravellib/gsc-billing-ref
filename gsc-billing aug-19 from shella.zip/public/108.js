(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[108],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/RateMaster.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/RateMaster.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {},
  data: function data() {
    return {
<<<<<<< HEAD
      rates: {},
      isSubmit: false,
      validationError: [],
      isEdit: 0,
      // 1 = preview, 1 = edit, 3 = add
      locationData: {},
      glData: {},
      ccData: {},
      activityData: {},
      selectedRate: [],
      form: new Form({
        id: '',
        activity: ' ',
        dayType: ' ',
        rd_st: '',
        rd_ot: '',
        rd_nd: '',
        rd_ndot: '',
        shol_st: '',
        shol_ot: '',
        shol_nd: '',
        shol_ndot: '',
        shrd_st: '',
        shrd_ot: '',
        shrd_nd: '',
        shrd_ndot: '',
        rhol_st: '',
        rhol_ot: '',
        rhol_nd: '',
        rhol_ndot: '',
        rhrd_st: '',
        rhrd_ot: '',
        rhrd_nd: '',
        rhrd_ndot: '',
        status: 'active',
        selectedLocationID: '',
        selectedActivityID: '',
        selectedGlID: '',
        selectedCcID: ''
      }),
      selectedLocationID: '',
      selectedActivityID: '',
      selectedGlID: '',
      selectedCcID: ''
    };
  },
  mounted: function mounted() {
    this.selectedLocationID = '17';
    this.getResults();
    this.getLocation();
    this.getCc();
    this.getActivity();
    this.getGl();
  },
  methods: {
    // Our method to GET results from a Laravel endpoint
    getResults: function getResults() {
      var _this = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('/api/ratemaster?page=' + page, {
        params: {
          id: this.selectedLocationID,
          ccId: this.selectedCcID,
          glId: this.selectedGlID,
          activityId: this.selectedActivityID
        }
      }).then(function (response) {
        _this.rates = response.data;
        console.log(_this.rates);
      });
    },
    onFileChange: function onFileChange(e) {
      console.log(e.target.files[0]);
      this.file = e.target.files[0];
    },
    createJob: function createJob() {
      console.log("test");
    },
    getTasks: function getTasks() {
      var _this2 = this;

      axios({
        method: 'GET',
        url: '/api/ratemaster'
      }).then(function (_ref) {
        var data = _ref.data;
        return _this2.rates = data;
      });
    },
    toUpper: function toUpper() {
      this.form.activity = this.$parent.toCapitalizeFirstLetter(this.form.activity);
    },
    addNewRate: function addNewRate(e) {
      var _this3 = this;

      this.$Progress.start();
      this.toUpper();
      this.form.selectedLocationID = this.selectedLocationID;
      this.form.selectedActivityID = this.selectedActivityID;
      this.form.selectedGlID = this.selectedGlID;
      this.form.selectedCcID = this.selectedCcID;
      this.form.post('api/ratemaster').then(function (res) {
        console.log(res.data);

        if (res.data == true) {
          $('#addNewRate').modal('hide');

          _this3.$Progress.finish();

          _this3.getResults();

          toast.fire({
            icon: 'success',
            title: 'Created successfully'
          });
        } else {
          _this3.getResults();

          _this3.$Progress.fail();

          toast.fire({
            icon: 'warning',
            title: 'Data already exist'
          });
=======
      rows: [],
      noDataFound: true,
      noDataFound2: true,
      loading: false,
      search: "",
      OverAllBalance: 0,
      OverAllBalance2: 0,
      detailRows: [],
      showTable1: true,
      date_from: this.$root.formatDate(new Date()),
      date_to: this.$root.formatDate(new Date()),
      rows2: [],
      showMe: false
    };
  },
  mounted: function mounted() {
    this.getData();
    this.getData2();
  },
  methods: {
    getData2: function getData2() {
      var _this = this;

      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getLedgerOne: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          var Balance = 0;
          response.data.forEach(function (item) {
            Balance = Balance + item.Balance;
          });
          _this.OverAllBalance2 = _this.$root.formatNumberCommaRound(Balance);
          _this.rows2 = response.data;
          _this.noDataFound = false;
        } else {
          _this.noDataFound = true;
        }

        _this.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getData: function getData() {
      var _this2 = this;

      this.loading = true;
      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getLedger: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          var Balance = 0;
          response.data.forEach(function (item) {
            item.bcolor = item.SOANo != '' ? "bcolor-blue" : "bcolor-red";
            Balance = Balance + item.Amount;
            item.Balance = Balance;
            item.paymentDate = _this2.$root.formatDate(item.paymentDate);
          });
          _this2.OverAllBalance = _this2.$root.formatNumberCommaRound(Balance);
          _this2.rows = response.data;
          _this2.noDataFound = false;
        } else {
          _this2.noDataFound = true;
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
        }
      })["catch"](function (err) {
        _this3.$Progress.fail();

<<<<<<< HEAD
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });
      });
    },
    updateRate: function updateRate() {
      var _this4 = this;

      this.$Progress.start();
      this.toUpper();
      this.form.selectedLocationID = this.selectedRate['locationID'];
      this.form.selectedActivityID = this.selectedRate['activityID'];
      this.form.selectedGlID = this.selectedRate['glID'];
      this.form.selectedCcID = this.selectedRate['costCenterID'];
      this.form.put('api/ratemaster/' + this.form.id).then(function (res) {
        console.log(res);

        if (res.data == true) {
          $('#addNewRate').modal('hide');

          _this4.$Progress.finish();

          _this4.getResults();

          toast.fire({
            icon: 'success',
            title: 'Rate successfully updated'
          });
        } else {
          _this4.getResults();

          _this4.$Progress.fail();

          toast.fire({
            icon: 'warning',
            title: 'Rate already exist'
          });
        }
      })["catch"](function () {
        _this4.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'rate not updated successfully'
=======
        _this2.$Progress.finish();

        _this2.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    rowClick: function rowClick(row) {
      var _this3 = this;

      if (row.SOANo == "") {
        this.showTable1 = false;
        this.$Progress.start();
        axios.get("api/allowance", {
          params: {
            getLedgerPayment: true,
            id: row.ALID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this3.detailRows = response.data;
            _this3.noDataFound2 = false;
          } else {
            _this3.detailRows = [];
            _this3.noDataFound2 = true;
          }

          _this3.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
      } else {
        this.showTable1 = true;
        this.$Progress.start();
        axios.get("api/allowance", {
          params: {
            getLedgerPaymentSOA: true,
            SOANo: row.SOANo
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this3.detailRows = response.data;
            _this3.noDataFound2 = false;
          } else {
            _this3.detailRows = [];
            _this3.noDataFound2 = true;
          }

          _this3.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    generateReport: function generateReport() {
      var _this4 = this;

      if (!this.date_from && !this.date_to) {
        return toast.fire({
          icon: "warning",
          title: "Please select Date From and Date To to continue."
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
        });
      });
    },
    editMode: function editMode(rate) {
      this.isEdit = 2;
      this.form.reset();
      $('#addNewRate').modal('show');
      this.form.fill(rate);
      this.selectedRate = rate;
    },
    createMode: function createMode() {
      this.isEdit = 3;
      this.form.reset();
      $('#addNewRate').modal('show');
    },
    deleteRate: function deleteRate(id) {
      var _this5 = this;

<<<<<<< HEAD
      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this5.form["delete"]('api/ratemaster/' + id).then(function () {
            swal.fire('Deleted!', 'Your file has been deleted.', 'success');

            _this5.getResults();
          })["catch"](function () {
            swal.fire('Failed!', 'Something went wrong.', 'error');
          });
        }
      });
    },
    getLocation: function getLocation() {
      var _this6 = this;

      axios.get('/api/getLocation').then(function (_ref2) {
        var data = _ref2.data;
        _this6.locationData = data;
      })["catch"](function (err) {
        console.log(err);
      });
    },
    getCc: function getCc() {
      var _this7 = this;

      axios.get('/api/getCc').then(function (_ref3) {
        var data = _ref3.data;
        _this7.ccData = data;
      })["catch"](function (err) {
        console.log(err);
      });
    },
    getGl: function getGl() {
      var _this8 = this;

      axios.post("api/getSelectedGl", {
        type: 'DAR'
      }).then(function (_ref4) {
        var data = _ref4.data;
        _this8.glData = data;
        console.log('data', data);
      })["catch"](function (err) {
        console.log(err);
      });
    },
    getActivity: function getActivity() {
      var _this9 = this;

      axios.get('/api/getActivity').then(function (_ref5) {
        var data = _ref5.data;
        _this9.activityData = data;
      })["catch"](function (err) {
        console.log(err);
      });
    },
    viewMode: function viewMode(rate) {
      this.isEdit = 1;
      this.form.reset();
      $('#addNewRate').modal('show');
      this.form.fill(rate);
    }
  },
  created: function created() {
    var _this10 = this;

    Fire.$on('searching', function () {
      var query = _this10.$parent.search;
      axios.get('api/ratemasterSearch?q=' + query).then(function (_ref6) {
        var data = _ref6.data;
        _this10.rates = data;
=======
      this.$Progress.start();
      axios.get("api/paidUnpaidReport", {
        params: {
          date_from: this.date_from,
          date_to: this.date_to,
          type: "ppe"
        }
      }).then(function (response) {
        if (response.data.success) {
          window.open("api/paidUnpaidReport?report=true&date_from=" + _this4.date_from + "&date_to=" + _this4.date_to + "&type=allowance");
        } else {
          toast.fire({
            icon: "warning",
            title: response.data.message
          });
        }

        _this4.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    exportExcel: function exportExcel() {
      var element = document.getElementById("remove1");
      element.parentNode.removeChild(element);
      var element2 = document.getElementById("remove2");
      element2.parentNode.removeChild(element2);
      var tab_text = "<table border='2px'><tr bgcolor='#87AFC6'>";
      var textRange;
      var j = 0;
      var tab = document.getElementById('tableExport'); // id of table

      var sa = "";

      for (j = 0; j < tab.rows.length; j++) {
        tab_text = tab_text + tab.rows[j].innerHTML + "</tr>"; //tab_text=tab_text+"</tr>";
      }

      tab_text = tab_text + "</table>";
      tab_text = tab_text.replace(/<A[^>]*>|<\/A>/g, ""); //remove if u want links in your table

      tab_text = tab_text.replace(/<img[^>]*>/gi, ""); // remove if u want images in your table

      tab_text = tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

      var ua = window.navigator.userAgent;
      var msie = ua.indexOf("MSIE ");

      if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer
        {
          txtArea1.document.open("txt/html", "replace");
          txtArea1.document.write(tab_text);
          txtArea1.document.close();
          txtArea1.focus();
          sa = txtArea1.document.execCommand("SaveAs", true, "Say Thanks to Sumit.xls");
        } else {
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));
      } //other browser not tested on IE 11


      this.$router.go();
      return sa;
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this5 = this;

      return this.rows.filter(function (item) {
        return _this5.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toString().toLowerCase().includes(v) || item.check_no.toString().toLowerCase().includes(v) || item.orNumber.toString().toLowerCase().includes(v);
        });
      });
    },
    filteredBlogs2: function filteredBlogs2() {
      var _this6 = this;

      return this.rows2.filter(function (item) {
        return _this6.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toString().toLowerCase().includes(v);
        });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      });
    });
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/RateMaster.vue?vue&type=template&id=8fe931e6&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/RateMaster.vue?vue&type=template&id=8fe931e6& ***!
  \*************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.height-modified {\n    height:300px !important;\n}\n.height-modified2 {\n    height:100px !important;\n}\n.bcolor-red {\n    background-color: #5eff69 !important;\n}\n.bcolor-blue {\n    background-color: #e5e1fc !important;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa& ***!
  \*******************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c("div", { staticClass: "card full-width container" }, [
    _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [_vm._v("Rate Master File")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "btn btn-secondary float-right",
          on: { click: _vm.createMode }
        },
        [
          _c("i", { staticClass: "fas fa-plus-circle" }),
          _vm._v(" Add rate\n    ")
        ]
      )
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "row margin-top-10" }, [
      _c("div", { staticClass: "col-3" }, [
        _c(
          "select",
          {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.selectedLocationID,
                expression: "selectedLocationID"
              }
            ],
            staticClass: "form-control form-control-sm",
            on: {
              change: [
                function($event) {
                  var $$selectedVal = Array.prototype.filter
                    .call($event.target.options, function(o) {
                      return o.selected
                    })
                    .map(function(o) {
                      var val = "_value" in o ? o._value : o.value
                      return val
                    })
                  _vm.selectedLocationID = $event.target.multiple
                    ? $$selectedVal
                    : $$selectedVal[0]
                },
                function($event) {
                  return _vm.getResults()
                }
              ]
            }
          },
          [
            _c("option", { attrs: { disabled: "", selected: "", value: "" } }, [
              _vm._v(" -- select a location -- ")
            ]),
            _vm._v(" "),
            _vm._l(_vm.locationData, function(location) {
              return _c(
                "option",
                { key: location.id, domProps: { value: location.id } },
                [_vm._v(_vm._s(location.location))]
              )
            })
          ],
          2
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-3" }, [
        _c(
          "select",
          {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.selectedActivityID,
                expression: "selectedActivityID"
              }
            ],
            staticClass: "form-control form-control-sm",
            on: {
              change: [
                function($event) {
                  var $$selectedVal = Array.prototype.filter
                    .call($event.target.options, function(o) {
                      return o.selected
                    })
                    .map(function(o) {
                      var val = "_value" in o ? o._value : o.value
                      return val
                    })
                  _vm.selectedActivityID = $event.target.multiple
                    ? $$selectedVal
                    : $$selectedVal[0]
                },
                function($event) {
                  return _vm.getResults()
                }
              ]
            }
          },
          [
            _c("option", { attrs: { selected: "", value: "" } }, [
              _vm._v(" -- select an activity -- ")
            ]),
            _vm._v(" "),
            _vm._l(_vm.activityData, function(activity) {
              return _c(
                "option",
                { key: activity.id, domProps: { value: activity.id } },
                [_vm._v(_vm._s(activity.activity))]
              )
            })
          ],
          2
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-3" }, [
        _c(
          "select",
          {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.selectedGlID,
                expression: "selectedGlID"
              }
            ],
            staticClass: "form-control form-control-sm",
            on: {
              change: [
                function($event) {
                  var $$selectedVal = Array.prototype.filter
                    .call($event.target.options, function(o) {
                      return o.selected
                    })
                    .map(function(o) {
                      var val = "_value" in o ? o._value : o.value
                      return val
                    })
                  _vm.selectedGlID = $event.target.multiple
                    ? $$selectedVal
                    : $$selectedVal[0]
                },
                function($event) {
                  return _vm.getResults()
                }
              ]
            }
          },
          [
            _c("option", { attrs: { selected: "", value: "" } }, [
              _vm._v(" -- select a gl -- ")
            ]),
            _vm._v(" "),
            _vm._l(_vm.glData, function(gl) {
              return _c("option", { key: gl.id, domProps: { value: gl.id } }, [
                _vm._v(_vm._s(gl.gl))
              ])
            })
          ],
          2
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-3" }, [
        _c(
          "select",
          {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.selectedCcID,
                expression: "selectedCcID"
              }
            ],
            staticClass: "form-control form-control-sm",
            on: {
              change: [
                function($event) {
                  var $$selectedVal = Array.prototype.filter
                    .call($event.target.options, function(o) {
                      return o.selected
                    })
                    .map(function(o) {
                      var val = "_value" in o ? o._value : o.value
                      return val
                    })
                  _vm.selectedCcID = $event.target.multiple
                    ? $$selectedVal
                    : $$selectedVal[0]
                },
                function($event) {
                  return _vm.getResults()
                }
              ]
            }
          },
          [
            _c("option", { attrs: { selected: "", value: "" } }, [
              _vm._v(" -- select a costcenter -- ")
            ]),
            _vm._v(" "),
            _vm._l(_vm.ccData, function(cc) {
              return _c("option", { key: cc.id, domProps: { value: cc.id } }, [
                _vm._v(_vm._s(cc.costcenter))
              ])
            })
          ],
          2
        )
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "table-responsive custom-shell-table" }, [
      _c(
        "table",
        { staticClass: "table table-rate table-sm table-bordered table-hover" },
        [
          _vm._m(0),
          _vm._v(" "),
          _c(
            "tbody",
            _vm._l(_vm.rates.data, function(rate) {
              return _c("tr", { key: rate.id }, [
                _c(
                  "td",
                  { staticClass: "bgg-gray" },
                  [
                    _vm._v(
                      _vm._s(rate.activity) + " \n                        "
                    ),
                    _c(
                      "b-button-group",
                      { staticClass: "fl-right", attrs: { size: "sm" } },
                      [
                        _c(
                          "b-button",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: rate.status == "active",
                                expression: "rate.status=='active'"
                              }
                            ],
                            on: {
                              click: function($event) {
                                return _vm.editMode(rate)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-edit" })]
                        ),
                        _vm._v(" "),
                        _c(
                          "b-button",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: rate.status == "previous",
                                expression: "rate.status=='previous'"
                              }
                            ],
                            on: {
                              click: function($event) {
                                return _vm.viewMode(rate)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-eye" })]
                        )
                      ],
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.gl))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.costcenter))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.status))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rd_st))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rd_ot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rd_nd))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rd_ndot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shol_st))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shol_ot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shol_nd))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shol_ndot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shrd_st))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shrd_ot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shrd_nd))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.shrd_ndot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhol_st))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhol_ot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhol_nd))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhol_ndot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhrd_st))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhrd_ot))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhrd_nd))]),
                _vm._v(" "),
                _c("td", [_vm._v(_vm._s(rate.rhrd_ndot))])
              ])
            }),
            0
          )
        ]
      )
    ]),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "card-footer clearfix pagination" },
      [
        _c("pagination", {
          attrs: { data: _vm.rates, limit: 2 },
          on: { "pagination-change-page": _vm.getResults }
        })
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "addNewRate",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(1),
            _vm._v(" "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                  }
                }
              },
              [
                _c("div", { staticClass: "modal-body" }, [
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.form.id,
                        expression: "form.id"
                      }
                    ],
                    staticClass: "form-control form-control-sm",
                    attrs: { hidden: "true", type: "text", name: "id" },
                    domProps: { value: _vm.form.id },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.form, "id", $event.target.value)
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c("div", { staticClass: "row margin-top-10" }, [
                    _c(
                      "div",
                      { staticClass: "col-3" },
                      [
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.selectedLocationID,
                                expression: "selectedLocationID"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            on: {
                              change: [
                                function($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function(o) {
                                      return o.selected
                                    })
                                    .map(function(o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.selectedLocationID = $event.target
                                    .multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                },
                                function($event) {
                                  return _vm.getResults()
                                }
                              ]
                            }
                          },
                          [
                            _c(
                              "option",
                              {
                                attrs: { disabled: "", selected: "", value: "" }
                              },
                              [_vm._v(" -- select a location -- ")]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.locationData, function(location) {
                              return _c(
                                "option",
                                {
                                  key: location.id,
                                  domProps: { value: location.id }
                                },
                                [_vm._v(_vm._s(location.location))]
                              )
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "selectedLocationID" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-3" },
                      [
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.selectedActivityID,
                                expression: "selectedActivityID"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            on: {
                              change: [
                                function($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function(o) {
                                      return o.selected
                                    })
                                    .map(function(o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.selectedActivityID = $event.target
                                    .multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                },
                                function($event) {
                                  return _vm.getResults()
                                }
                              ]
                            }
                          },
                          [
                            _c(
                              "option",
                              { attrs: { selected: "", value: "" } },
                              [_vm._v(" -- select an activity -- ")]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.activityData, function(activity) {
                              return _c(
                                "option",
                                {
                                  key: activity.id,
                                  domProps: { value: activity.id }
                                },
                                [_vm._v(_vm._s(activity.activity))]
                              )
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "selectedActivityID" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-3" },
                      [
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.selectedGlID,
                                expression: "selectedGlID"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            on: {
                              change: [
                                function($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function(o) {
                                      return o.selected
                                    })
                                    .map(function(o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.selectedGlID = $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                },
                                function($event) {
                                  return _vm.getResults()
                                }
                              ]
                            }
                          },
                          [
                            _c(
                              "option",
                              { attrs: { selected: "", value: "" } },
                              [_vm._v(" -- select a gl -- ")]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.glData, function(gl) {
                              return _c(
                                "option",
                                { key: gl.id, domProps: { value: gl.id } },
                                [_vm._v(_vm._s(gl.gl))]
                              )
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "selectedGlID" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-3" },
                      [
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.selectedCcID,
                                expression: "selectedCcID"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            on: {
                              change: [
                                function($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function(o) {
                                      return o.selected
                                    })
                                    .map(function(o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.selectedCcID = $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                },
                                function($event) {
                                  return _vm.getResults()
                                }
                              ]
                            }
                          },
                          [
                            _c(
                              "option",
                              { attrs: { selected: "", value: "" } },
                              [_vm._v(" -- select a costcenter -- ")]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.ccData, function(cc) {
                              return _c(
                                "option",
                                { key: cc.id, domProps: { value: cc.id } },
                                [_vm._v(_vm._s(cc.costcenter))]
                              )
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "selectedCcID" }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-sm-3" },
                      [
                        _c(
                          "b-badge",
                          { attrs: { pill: "", variant: "info" } },
                          [_vm._v("Regular Day")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "fname" } }, [
                          _vm._v("ST")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rd_st,
                              expression: "form.rd_st"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: { "is-invalid": _vm.form.errors.has("rd_st") },
                          attrs: { type: "text", name: "rd_st" },
                          domProps: { value: _vm.form.rd_st },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rd_st", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rd_st" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "mname" } }, [
                          _vm._v("OT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rd_ot,
                              expression: "form.rd_ot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: { "is-invalid": _vm.form.errors.has("rd_ot") },
                          attrs: { type: "text", name: "rd_ot" },
                          domProps: { value: _vm.form.rd_ot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rd_ot", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rd_ot" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("ND")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rd_nd,
                              expression: "form.rd_nd"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: { "is-invalid": _vm.form.errors.has("rd_nd") },
                          attrs: { type: "text", name: "rd_nd" },
                          domProps: { value: _vm.form.rd_nd },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rd_nd", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rd_nd" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("NDOT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rd_ndot,
                              expression: "form.rd_ndot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rd_ndot")
                          },
                          attrs: { type: "text", name: "rd_ndot" },
                          domProps: { value: _vm.form.rd_ndot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rd_ndot", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rd_ndot" }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-sm-3" },
                      [
                        _c(
                          "b-badge",
                          { attrs: { pill: "", variant: "info" } },
                          [_vm._v("Special Holiday")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "fname" } }, [
                          _vm._v("ST")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shol_st,
                              expression: "form.shol_st"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shol_st")
                          },
                          attrs: { type: "text", name: "shol_st" },
                          domProps: { value: _vm.form.shol_st },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "shol_st", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shol_st" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "mname" } }, [
                          _vm._v("OT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shol_ot,
                              expression: "form.shol_ot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shol_ot")
                          },
                          attrs: { type: "text", name: "shol_ot" },
                          domProps: { value: _vm.form.shol_ot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "shol_ot", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shol_ot" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("ND")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shol_nd,
                              expression: "form.shol_nd"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shol_nd")
                          },
                          attrs: { type: "text", name: "shol_nd" },
                          domProps: { value: _vm.form.shol_nd },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "shol_nd", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shol_nd" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("NDOT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shol_ndot,
                              expression: "form.shol_ndot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shol_ndot")
                          },
                          attrs: { type: "text", name: "shol_ndot" },
                          domProps: { value: _vm.form.shol_ndot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "shol_ndot",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shol_ndot" }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-sm-3" },
                      [
                        _c(
                          "b-badge",
                          { attrs: { pill: "", variant: "info" } },
                          [_vm._v("Special Holiday on Rest Day")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "fname" } }, [
                          _vm._v("ST")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shrd_st,
                              expression: "form.shrd_st"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shrd_st")
                          },
                          attrs: { type: "text", name: "shrd_st" },
                          domProps: { value: _vm.form.shrd_st },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "shrd_st", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shrd_st" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "mname" } }, [
                          _vm._v("OT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shrd_ot,
                              expression: "form.shrd_ot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shrd_ot")
                          },
                          attrs: { type: "text", name: "shrd_ot" },
                          domProps: { value: _vm.form.shrd_ot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "shrd_ot", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shrd_ot" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("ND")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shrd_nd,
                              expression: "form.shrd_nd"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shrd_nd")
                          },
                          attrs: { type: "text", name: "shrd_nd" },
                          domProps: { value: _vm.form.shrd_nd },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "shrd_nd", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shrd_nd" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("NDOT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.shrd_ndot,
                              expression: "form.shrd_ndot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("shrd_ndot")
                          },
                          attrs: { type: "text", name: "shrd_ndot" },
                          domProps: { value: _vm.form.shrd_ndot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "shrd_ndot",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "shrd_ndot" }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-sm-3" },
                      [
                        _c(
                          "b-badge",
                          { attrs: { pill: "", variant: "info" } },
                          [_vm._v("Regular Holiday")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "fname" } }, [
                          _vm._v("ST")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhol_st,
                              expression: "form.rhol_st"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhol_st")
                          },
                          attrs: { type: "text", name: "rhol_st" },
                          domProps: { value: _vm.form.rhol_st },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rhol_st", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhol_st" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "mname" } }, [
                          _vm._v("OT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhol_ot,
                              expression: "form.rhol_ot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhol_ot")
                          },
                          attrs: { type: "text", name: "rhol_ot" },
                          domProps: { value: _vm.form.rhol_ot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rhol_ot", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhol_ot" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("ND")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhol_nd,
                              expression: "form.rhol_nd"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhol_nd")
                          },
                          attrs: { type: "text", name: "rhol_nd" },
                          domProps: { value: _vm.form.rhol_nd },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rhol_nd", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhol_nd" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("NDOT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhol_ndot,
                              expression: "form.rhol_ndot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhol_ndot")
                          },
                          attrs: { type: "text", name: "rhol_ndot" },
                          domProps: { value: _vm.form.rhol_ndot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "rhol_ndot",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhol_ndot" }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-sm-3" },
                      [
                        _c(
                          "b-badge",
                          { attrs: { pill: "", variant: "info" } },
                          [_vm._v("Reglar Holiday on Rest Day")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "fname" } }, [
                          _vm._v("ST")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhrd_st,
                              expression: "form.rhrd_st"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhrd_st")
                          },
                          attrs: { type: "text", name: "rhrd_st" },
                          domProps: { value: _vm.form.rhrd_st },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rhrd_st", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhrd_st" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "mname" } }, [
                          _vm._v("OT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhrd_ot,
                              expression: "form.rhrd_ot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhrd_ot")
                          },
                          attrs: { type: "text", name: "rhrd_ot" },
                          domProps: { value: _vm.form.rhrd_ot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rhrd_ot", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhrd_ot" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("ND")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhrd_nd,
                              expression: "form.rhrd_nd"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhrd_nd")
                          },
                          attrs: { type: "text", name: "rhrd_nd" },
                          domProps: { value: _vm.form.rhrd_nd },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "rhrd_nd", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhrd_nd" }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-2" },
                      [
                        _c("label", { attrs: { for: "position" } }, [
                          _vm._v("NDOT")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.rhrd_ndot,
                              expression: "form.rhrd_ndot"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("rhrd_ndot")
                          },
                          attrs: { type: "text", name: "rhrd_ndot" },
                          domProps: { value: _vm.form.rhrd_ndot },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "rhrd_ndot",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "rhrd_ndot" }
                        })
                      ],
                      1
                    )
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "modal-footer justify-content-between" },
                  [
                    _vm._m(2),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.isEdit == 2,
                            expression: "isEdit==2"
                          }
                        ],
                        staticClass: "btn btn-success",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            return _vm.updateRate()
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "far fa-save" }),
                        _vm._v(" Update")
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.isEdit == 3,
                            expression: "isEdit==3"
                          }
                        ],
                        staticClass: "btn btn-primary",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            return _vm.addNewRate()
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "far fa-save" }),
                        _vm._v(" Create")
                      ]
                    )
                  ]
                )
              ]
            )
          ])
        ])
      ]
    )
=======
  return _c("div", { staticClass: "container dave-template" }, [
    _c("iframe", {
      staticStyle: { display: "none" },
      attrs: { id: "txtArea1" }
    }),
    _vm._v(" "),
    _c("div", { staticClass: "col-xs-12" }, [
      _c("div", { staticClass: "card" }, [
        _vm._m(0),
        _vm._v(" "),
        _c("div", { staticClass: "card-body table-responsive" }, [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-2" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.date_from,
                    expression: "date_from"
                  }
                ],
                staticClass: "form-control",
                attrs: { type: "date", name: "date_from", placeholder: "" },
                domProps: { value: _vm.date_from },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.date_from = $event.target.value
                  }
                }
              })
            ]),
            _vm._v(" "),
            _vm._m(1),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-2" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.date_to,
                    expression: "date_to"
                  }
                ],
                staticClass: "form-control",
                attrs: { type: "date", name: "date_from", placeholder: "" },
                domProps: { value: _vm.date_to },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.date_to = $event.target.value
                  }
                }
              })
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-2 text-left" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-primary",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      return _vm.generateReport()
                    }
                  }
                },
                [
                  _vm._v(
                    "\n                            Paid/Unpaid Report\n                        "
                  )
                ]
              )
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-2 text-right" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-success",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      return _vm.exportExcel()
                    }
                  }
                },
                [
                  _vm._v(
                    "\n                            Export Excel\n                        "
                  )
                ]
              )
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-12 table-height2" }, [
              _c(
                "table",
                {
                  staticClass: "table table-hover table-striped dave-table",
                  attrs: { id: "tableExport" }
                },
                [
                  _vm._m(2),
                  _vm._v(" "),
                  _c(
                    "tbody",
                    { staticClass: "dave-tbody height-modified" },
                    _vm._l(_vm.filteredBlogs2, function(item) {
                      return _c(
                        "tr",
                        {
                          on: {
                            click: function($event) {
                              return _vm.rowClick(item)
                            }
                          }
                        },
                        [
                          _c(
                            "td",
                            {
                              staticClass: "text-center",
                              attrs: { width: "20%" }
                            },
                            [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatDate")(item.Date_Transmitted)
                                  ) +
                                  "\n                                    "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-center",
                              attrs: { width: "20%" }
                            },
                            [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.SOANo) +
                                  "\n                                    "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-right",
                              attrs: { width: "20%" }
                            },
                            [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatNumber")(
                                      item.TotalAmount == 0
                                        ? "0"
                                        : item.TotalAmount
                                    )
                                  ) +
                                  "\n                                    "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-right",
                              attrs: { width: "20%" }
                            },
                            [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatNumber")(
                                      item.TotalAmount - item.Balance == 0
                                        ? "0"
                                        : item.TotalAmount - item.Balance
                                    )
                                  ) +
                                  "\n                                    "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-right",
                              attrs: { width: "20%" }
                            },
                            [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatNumber")(
                                      item.Balance == 0 ? "0" : item.Balance
                                    )
                                  ) +
                                  "\n                                    "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-center",
                              attrs: { width: "20%" }
                            },
                            [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.P_Status) +
                                  "\n                                    "
                              )
                            ]
                          )
                        ]
                      )
                    }),
                    0
                  )
                ]
              )
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.showMe,
                    expression: "showMe"
                  }
                ],
                staticClass: "col-md-12 table-height2"
              },
              [
                _c(
                  "table",
                  {
                    staticClass: "table table-hover table-striped dave-table",
                    attrs: { id: "tableExport2" }
                  },
                  [
                    _vm._m(3),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody height-modified" },
                      [
                        _c(
                          "tr",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: this.loading,
                                expression: "this.loading"
                              }
                            ],
                            attrs: { id: "remove1" }
                          },
                          [_vm._m(4)]
                        ),
                        _vm._v(" "),
                        _c(
                          "tr",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: this.noDataFound,
                                expression: "this.noDataFound"
                              }
                            ],
                            attrs: { id: "remove2" }
                          },
                          [_vm._m(5)]
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.filteredBlogs, function(item) {
                          return _c(
                            "tr",
                            {
                              class: item.bcolor,
                              on: {
                                click: function($event) {
                                  return _vm.rowClick(item)
                                }
                              }
                            },
                            [
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(
                                        _vm._f("formatDate")(
                                          item.Date_Transmitted
                                        )
                                      ) +
                                      "\n                                    "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _c("b", [
                                    _vm._v(
                                      _vm._s(
                                        item.SOANo ? item.SOANo : "PAYMENT"
                                      )
                                    )
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(item.check_no) +
                                      "\n                                    "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(
                                        !item.SOANo ? item.paymentDate : ""
                                      ) +
                                      "\n                                    "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(item.orNumber) +
                                      "\n                                    "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(item.paymentMode) +
                                      "\n                                    "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-right",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _c("b", [
                                    _vm._v(
                                      _vm._s(
                                        _vm._f("formatNumber")(
                                          item.paymentType == "DEBIT"
                                            ? item.Amount
                                            : "0"
                                        )
                                      )
                                    )
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-right",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _c("b", [
                                    _vm._v(
                                      _vm._s(
                                        _vm._f("formatNumber")(
                                          item.paymentType == "CREDIT"
                                            ? Math.abs(item.Amount)
                                            : "0"
                                        )
                                      )
                                    )
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-right",
                                  attrs: { width: "20%" }
                                },
                                [
                                  _c("b", [
                                    _vm._v(
                                      _vm._s(
                                        _vm._f("formatNumber")(
                                          item.Balance ? item.Balance : "0"
                                        )
                                      )
                                    )
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                {
                                  staticClass: "text-center",
                                  attrs: { width: "20%" }
                                },
                                [_c("b", [_vm._v(_vm._s(item.P_Status))])]
                              )
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]
                )
              ]
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-8" }, [
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.showTable1,
                      expression: "showTable1"
                    }
                  ],
                  staticClass: "row"
                },
                [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(6),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody height-modified2" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: this.noDataFound2,
                                    expression: "this.noDataFound2"
                                  }
                                ]
                              },
                              [_vm._m(7)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.detailRows, function(item) {
                              return _c("tr", [
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.paymentMode))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatDate")(item.paymentDate)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.check_no))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.orNumber))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.billed_amount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.paidAmount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.check_amount)
                                    )
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: !_vm.showTable1,
                      expression: "!showTable1"
                    }
                  ],
                  staticClass: "row"
                },
                [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(8),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody height-modified2" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: this.noDataFound2,
                                    expression: "this.noDataFound2"
                                  }
                                ]
                              },
                              [_vm._m(9)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.detailRows, function(item) {
                              return _c("tr", [
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.SOANo))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.billed_amount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.paidAmount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.check_amount)
                                    )
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ]
              )
            ]),
            _vm._v(" "),
            _vm._m(10),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-2" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.OverAllBalance2,
                    expression: "OverAllBalance2"
                  }
                ],
                staticClass: "form-control text-right",
                attrs: {
                  type: "text",
                  name: "OverAllBalance2",
                  placeholder: "",
                  disabled: ""
                },
                domProps: { value: _vm.OverAllBalance2 },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.OverAllBalance2 = $event.target.value
                  }
                }
              })
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-footer" })
      ])
    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("activity")]),
        _vm._v(" "),
        _c("th", [_vm._v("gl")]),
        _vm._v(" "),
        _c("th", [_vm._v("costcenter")]),
        _vm._v(" "),
        _c("th", [_vm._v("status")]),
        _vm._v(" "),
        _c("th", [_vm._v("rd-st")]),
        _vm._v(" "),
        _c("th", [_vm._v("rd-ot")]),
        _vm._v(" "),
        _c("th", [_vm._v("rd-nd")]),
        _vm._v(" "),
        _c("th", [_vm._v("rd-ndot")]),
        _vm._v(" "),
        _c("th", [_vm._v("shol-st")]),
        _vm._v(" "),
        _c("th", [_vm._v("shol-ot")]),
        _vm._v(" "),
        _c("th", [_vm._v("shol-nd")]),
        _vm._v(" "),
        _c("th", [_vm._v("shol-ndot")]),
        _vm._v(" "),
        _c("th", [_vm._v("shrd-st")]),
        _vm._v(" "),
        _c("th", [_vm._v("shrd-ot")]),
        _vm._v(" "),
        _c("th", [_vm._v("shrd-nd")]),
        _vm._v(" "),
        _c("th", [_vm._v("shrd-ndot")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhol-st")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhol-ot")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhol-nd")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhol-ndot")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhrd-st")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhrd-ot")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhrd-nd")]),
        _vm._v(" "),
        _c("th", [_vm._v("rhrd-ndot")])
      ])
=======
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("VIEW LEDGER")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [
        _vm._v("Change active rate for selected activity")
      ]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
=======
    return _c("div", { staticClass: "col-md-1 text-center" }, [
      _c("h4", [_vm._v("To")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Date Transmitted\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        SOA #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Billed Amount\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Collection\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Balance\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Status\n                                    "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Date Transmitted\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        SOA #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Check #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Payment/ Check Date\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        OR #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        PMode\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Billed Amount\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Collection\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Running Balance\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Status\n                                    "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center b", attrs: { colspan: "4" } }, [
      _c("i", [_vm._v("Loading...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "4" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Mode\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment/ Check Date\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Check #\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                OR #\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Billed Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Paid Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment/ Check Amount\n                                            "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "6" } }, [
      _c("b", [_vm._v("No Data Found")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c(
      "button",
      {
        staticClass: "btn btn-default",
        attrs: { type: "button", "data-dismiss": "modal" }
      },
      [_c("i", { staticClass: "far fa-window-close" }), _vm._v(" Close")]
    )
=======
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                SOANo\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Billed Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Paid Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment/ Check Amount\n                                            "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "3" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-2 text-right" }, [
      _c("b", [_vm._v("OVERALL BALANCE :")])
    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/RateMaster.vue":
/*!************************************************!*\
  !*** ./resources/js/components/RateMaster.vue ***!
  \************************************************/
=======
/***/ "./resources/js/components/allowance/Ledger.vue":
/*!******************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue ***!
  \******************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _RateMaster_vue_vue_type_template_id_8fe931e6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RateMaster.vue?vue&type=template&id=8fe931e6& */ "./resources/js/components/RateMaster.vue?vue&type=template&id=8fe931e6&");
/* harmony import */ var _RateMaster_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RateMaster.vue?vue&type=script&lang=js& */ "./resources/js/components/RateMaster.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Ledger.vue?vue&type=template&id=6e4274aa& */ "./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&");
/* harmony import */ var _Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ledger.vue?vue&type=script&lang=js& */ "./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Ledger.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RateMaster_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _RateMaster_vue_vue_type_template_id_8fe931e6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _RateMaster_vue_vue_type_template_id_8fe931e6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/RateMaster.vue"
=======
component.options.__file = "resources/js/components/allowance/Ledger.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/RateMaster.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/components/RateMaster.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
=======
/***/ "./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RateMaster_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib??ref--4-0!../../../node_modules/vue-loader/lib??vue-loader-options!./RateMaster.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/RateMaster.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RateMaster_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/RateMaster.vue?vue&type=template&id=8fe931e6&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/RateMaster.vue?vue&type=template&id=8fe931e6& ***!
  \*******************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa& ***!
  \*************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RateMaster_vue_vue_type_template_id_8fe931e6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./RateMaster.vue?vue&type=template&id=8fe931e6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/RateMaster.vue?vue&type=template&id=8fe931e6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RateMaster_vue_vue_type_template_id_8fe931e6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RateMaster_vue_vue_type_template_id_8fe931e6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=template&id=6e4274aa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);