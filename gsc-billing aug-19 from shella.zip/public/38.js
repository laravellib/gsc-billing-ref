(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[38],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _search_client_list_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/client-list.vue */ "./resources/js/components/search/client-list.vue");
/* harmony import */ var _search_signatory_req_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/signatory-req.vue */ "./resources/js/components/search/signatory-req.vue");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

=======
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
/* harmony import */ var _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchOperator.vue */ "./resources/js/components/search/SearchJeep/SearchOperator.vue");
/* harmony import */ var _search_SearchPHB_SearchPHBVehicle_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchPHB/SearchPHBVehicle.vue */ "./resources/js/components/search/SearchPHB/SearchPHBVehicle.vue");
/* harmony import */ var _search_SearchPHB_SearchLocation_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/SearchPHB/SearchLocation.vue */ "./resources/js/components/search/SearchPHB/SearchLocation.vue");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _PHBMenu_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PHBMenu.vue */ "./resources/js/components/PHBComponents/PHBMenu.vue");
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "client-list": _search_client_list_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "signatory-req": _search_signatory_req_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    rental: {
      type: [Object, Array]
    }
  },
  data: function data() {
    var _ref;

    return {
      searching: "",
      golfcart: {},
      details_data: {},
      detail: {},
      filter: {},
      datas: [],
      signatory: {},
      form: new Form((_ref = {
        id: "",
        series_no: "",
        billed_id: "",
        billed_name: "",
        billed_address: "",
        soa_date: "",
        charge_invoice_no: "",
        period_covered: "",
        total_amount: "",
        remarks: "",
        details: "",
        status: "ACTIVE"
      }, _defineProperty(_ref, "total_amount", 0), _defineProperty(_ref, "rentals", {}), _defineProperty(_ref, "grandtotals", {}), _ref))
    };
  },
  methods: {
    get_signatory: function get_signatory(data) {
      var _this = this;

      this.signatory = data;
      console.log(this.signatory);
      this.$Progress.start();
      axios.get("wreq_soa/details/" + this.form.id).then(function (_ref2) {
        var data = _ref2.data;
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_3___default.a();
        doc.setFont("courier");
        doc.setFontType("bold");
        doc.setFontSize(11);
        doc.addImage(Logo, "PNG", 15, 5, 30, 30);
        doc.setFontSize(12);
        doc.text("GENERAL SERVICES MULTIPURPOSE COOPERATIVE", 50, 15);
        doc.setFontSize(10);
        doc.setFontType("normal");
        doc.text("Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon", 50, 20);
        doc.text("CDA # 9520-10019987-1 / TIN: 411-478-949-000", 50, 25);
        doc.setFontType("normal");
        doc.text("STATEMENT OF ACCOUNT", 80, 45);
        doc.text("SOA#" + _this.form.series_no, 150, 40);
        doc.text("BILLED TO:           " + _this.form.billed_name, 30, 57);
        doc.text("                     " + _this.form.billed_address, 30, 65);
        doc.text("PERIOD COVERED:      FOR THE MONTH OF " + _this.form.soa_date, 30, 75);
        doc.autoTable({
          columnStyles: {
            0: {
              halign: "center",
              fillColor: [0, 255, 0],
              fontSize: 9
            },
            1: {
              halign: "center",
              fillColor: [255, 255, 0],
              fontSize: 9
            },
            2: {
              halign: "center",
              fillColor: [0, 255, 255],
              fontSize: 9
            }
          },
          // European countries centered
          body: data.data,
          columns: [{
            header: "Date",
            dataKey: "req_date"
          }, {
            header: "Particulars",
            dataKey: "particulars"
          }, {
            header: "Amount",
            dataKey: "amount"
          }],
          margin: {
            top: 80
          }
        });
        doc.text("Prepared By:", 30, 150);
        doc.text(_this.signatory.preparedBy, 30, 155);
        doc.text("Approved By:", 110, 150);
        doc.text(_this.signatory.approvedBy, 110, 155);
        doc.text("Noted By:", 30, 165);
        doc.text(_this.signatory.notedBy, 30, 170);
        doc.save("wingvan_soa_" + _this.form.series_no + ".pdf");
      });
      this.$Progress.finish();
    },
    print_soa: function print_soa() {
      if (this.form.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        $("#signatory-req").modal("show");
      }
    },
    post_soa: function post_soa() {
      var _this2 = this;

      if (this.form.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        this.form.put("api/wingvan_soa_hdr/" + this.form.id).then(function () {
          toast.fire({
            icon: "success",
            title: "Update data successfully"
          });

          _this2.form.reset();
        })["catch"](function () {
          swal.fire("Error Found.", "warning");
        });
      }
    },
    createData: function createData() {
      var _this3 = this;

      if (this.form.id == "") {
        this.form.rentals = this.rental;
        this.form.grandtotals = this.grandtotal;
        this.$Progress.start();
        this.form.post("api/wingvan_soa_hdr").then(function (data) {
          toast.fire({
            icon: "success",
            title: "Added Data in successfully"
          });
          _this3.form.id = data.data.id;
        })["catch"](function () {
          _this3.$Progress.fail();

          toast.fire({
            icon: "error",
            title: "Error Found"
          });
        });
        this.$Progress.finish();
      }
    },
    searchClient: function searchClient() {
      $("#searchGolfcart").modal("show");
    },
    getData: function getData(data) {
      this.form.billed_id = data.id;
      this.form.billed_name = data.FirstName;
      this.form.billed_address = data.Address;
    },
    soa_data: function soa_data(data) {
      this.form.fill(data);
    },
    searchSoa: function searchSoa() {
      $("#searchSOA").modal("show");
    }
  },
  mounted: function mounted() {},
  created: function created() {
    this.form.series_no = "WSOA-" + moment__WEBPACK_IMPORTED_MODULE_0___default()().format("HHMMSS");
    this.form.soa_date = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
    this.form.period_covered = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _search_signatory_review_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/signatory-review.vue */ "./resources/js/components/search/signatory-review.vue");
//
//
=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "signatory-review": _search_signatory_review_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      id: 0,
      soa_no: "",
      searching: "",
      billed_name: "",
      billed_address: "",
      soa_date: "",
      golfcart: {},
      filter: {},
      detail: {},
      datas: [],
      showButton: false,
      showDetail: false,
      signatory: {}
    };
  },
  methods: {
    get_signatory: function get_signatory(data) {
      var _this = this;

      this.signatory = data;
      console.log(this.signatory);
      this.$Progress.start();
      axios.get("wreq_soa/details/" + this.id).then(function (_ref) {
        var data = _ref.data;
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_1___default.a();
        doc.setFont("courier");
        doc.setFontType("bold");
        doc.setFontSize(11);
        doc.addImage(Logo, "PNG", 15, 5, 30, 30);
        doc.setFontSize(12);
        doc.text("GENERAL SERVICES MULTIPURPOSE COOPERATIVE", 50, 15);
        doc.setFontSize(10);
        doc.setFontType("normal");
        doc.text("Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon", 50, 20);
        doc.text("CDA # 9520-10019987-1 / TIN: 411-478-949-000", 50, 25);
        doc.setFontType("normal");
        doc.text("STATEMENT OF ACCOUNT", 80, 45);
        doc.text("SOA#" + _this.soa_no, 150, 40);
        doc.text("BILLED TO:           " + _this.billed_name, 30, 57);
        doc.text("                     " + _this.billed_address, 30, 65);
        doc.text("PERIOD COVERED:      FOR THE MONTH OF " + _this.soa_date, 30, 75);
        doc.autoTable({
          columnStyles: {
            0: {
              halign: "center",
              fillColor: [0, 255, 0],
              fontSize: 9
            },
            1: {
              halign: "center",
              fillColor: [255, 255, 0],
              fontSize: 9
            },
            2: {
              halign: "center",
              fillColor: [0, 255, 255],
              fontSize: 9
            }
          },
          // European countries centered
          body: data.data,
          columns: [{
            header: "Date",
            dataKey: "req_date"
          }, {
            header: "Particulars",
            dataKey: "particulars"
          }, {
            header: "Amount",
            dataKey: "amount"
          }],
          margin: {
            top: 80
          }
        });
        doc.text("Prepared By:", 30, 150);
        doc.text(_this.signatory.preparedBy, 30, 155);
        doc.text("Approved By:", 110, 150);
        doc.text(_this.signatory.approvedBy, 110, 155);
        doc.text("Noted By:", 30, 165);
        doc.text(_this.signatory.notedBy, 30, 170);
        doc.save("wingvan_soa_" + _this.soa_no + ".pdf");
      });
      this.$Progress.finish();
    },
    soa_detail: function soa_detail() {
      var _this2 = this;

      axios.get("wreq_soa/details/" + this.id).then(function (_ref2) {
        var data = _ref2.data;
        _this2.detail = data.data;
      });
      this.showDetail = true;
    },
    paid_soa: function paid_soa() {
      var _this3 = this;

      if (this.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        swal.fire({
          title: "Are you sure you want to set this as PAID/COLLECTED?",
          text: "You won't be able to revert this!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Yes, Cancel it!"
        }).then(function (result) {
          if (result.value) {
            axios.get("wreq_soa/collected/" + _this3.id).then(function (_ref3) {
              var data = _ref3.data;

              _this3.review();
            });
          }
        });
      }
    },
    view_soa: function view_soa() {
      if (this.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        $("#signatory-review").modal("show");
      }
    },
    cancel_soa: function cancel_soa(id) {
      var _this4 = this;

      if (this.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        swal.fire({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Yes, Cancel it!"
        }).then(function (result) {
          if (result.value) {
            console.log(id);
            axios.get("wreq_soa/cancel/" + _this4.id).then(function (_ref4) {
              var data = _ref4.data;

              _this4.review();
            });
          }
        });
      }
    },
    review: function review() {
      var _this5 = this;

      axios.get("wreq_soa/review/" + this.datefrom + "/" + this.dateto).then(function (_ref5) {
        var data = _ref5.data;
        _this5.rental = data.data;
        _this5.filter = _this5.rental;
        console.log(data);
      });
    },
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      console.log(dataItem);
      this.id = dataItem.id;
      this.soa_no = dataItem.series_no;
      this.billed_name = dataItem.billed_name;
      this.billed_address = dataItem.billed_address;
      this.soa_date = dataItem.soa_date;
      this.showButton = true;
      this.showDetail = false;
    }
  },
  mounted: function mounted() {},
  created: function created() {
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WingVan_SOA_Req_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-SOA-Req.vue */ "./resources/js/components/wingvan/WingVan-SOA-Req.vue");
/* harmony import */ var _WingVan_SOA_Review_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-SOA-Review.vue */ "./resources/js/components/wingvan/WingVan-SOA-Review.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//








/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
<<<<<<< HEAD
    "create-soa": _WingVan_SOA_Req_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "review-soa": _WingVan_SOA_Review_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    AgGridVue: AgGridVue
=======
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-operator': _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-phbvehicle': _search_SearchPHB_SearchPHBVehicle_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    'search-location': _search_SearchPHB_SearchLocation_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    'phb-menu': _PHBMenu_vue__WEBPACK_IMPORTED_MODULE_5__["default"]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  },
  data: function data() {
    var _ref;

    return {
<<<<<<< HEAD
      datefrom: "",
      dateto: "",
      filter: {},
      rental: {},
      clients: {},
      client: [],
      columnDefs: null,
      gridApi: null,
      columnApi: null,
      selected: [],
      form: new Form({
        billed_id: "",
        billed_name: "",
        billed_address: "",
        series_no: "",
        soa_date: "",
        charge_invoice_no: "",
        remarks: "",
        amount: 0,
        id: 0
      })
    };
  },
  methods: {
    print_soa: function print_soa() {
      var _this = this;

      if (this.form.id == 0) {
        swal.fire("No Data is Selected.", "warning");
      } else {
        this.$Progress.start();
        axios.get("wreq_soa/details/" + this.form.id).then(function (_ref) {
          var data = _ref.data;
          var doc = new jspdf__WEBPACK_IMPORTED_MODULE_3___default.a();
          doc.setFont("courier");
          doc.setFontType("bold");
          doc.setFontSize(12);
          doc.addImage(Logo, "PNG", 15, 5, 30, 30);
          doc.setFontSize(14);
          doc.text("GENERAL SERVICES MULTIPURPOSE COOPERATIVE", 50, 15);
          doc.setFontSize(11);
          doc.text("Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon", 50, 20);
          doc.text("CDA # 9520-10019987-1 / TIN: 411-478-949-000", 50, 25);
          doc.setFontType("normal");
          doc.text("STATEMENT OF ACCOUNT", 80, 45);
          doc.text("SOA#" + _this.form.series_no, 150, 40);
          doc.text("BILLED TO:           " + _this.form.billed_name, 30, 57);
          doc.text("                     " + _this.form.billed_address, 30, 65);
          doc.text("PERIOD COVERED:      FOR THE MONTH OF " + _this.form.soa_date, 30, 75);
          doc.autoTable({
            columnStyles: {
              0: {
                halign: "center",
                fillColor: [0, 255, 0]
              },
              1: {
                halign: "center",
                fillColor: [255, 255, 0]
              },
              2: {
                halign: "center",
                fillColor: [0, 255, 255]
              }
            },
            // European countries centered
            body: data.data,
            columns: [{
              header: "Date",
              dataKey: "req_date"
            }, {
              header: "Particulars",
              dataKey: "particulars"
            }, {
              header: "Amount",
              dataKey: "amount"
            }],
            margin: {
              top: 80
            }
          });
          doc.text("Prepared By:", 30, 150);
          doc.text("Approved By:", 85, 150);
          doc.text("Noted By:", 150, 150);
          doc.save("vanrental_soa_" + _this.form.id + ".pdf");
        });
        this.$Progress.finish();
      }
    },
    preview: function preview() {
      var _this2 = this;

      axios.get("wreq_soa/search/" + this.datefrom + "/" + this.dateto).then(function (_ref2) {
        var data = _ref2.data;
        _this2.selected = [];
        _this2.rental = data.data;
        _this2.filter = _this2.rental;
=======
      PHBDetails: [],
      loc: '',
      checkedNames: [],
      filteredblogs: [],
      checkedNamesFilter: [],
      editmode: false,
      equalequal: false,
      allSelected: false,
      editCollection: false,
      jvls: [],
      jvlsobject: {},
      search: '',
      jvcps: {},
      drivers: [],
      vehicles: {},
      rates: {},
      operators: {},
      batch: [],
      jvlfilter: [],
      jvlbalamt: [],
      var1: '',
      var2: '',
      first: '',
      second: '',
      eq: 'true',
      truevalue: '',
      falsevalue: '',
      SearchPHBPlateNo: '',
      DateFrom: '',
      DateTo: '',
      JeepVehicleCollectionPayments: {},
      form: new Form((_ref = {
        PHBVLHDRID: '',
        PHBVLDate: '',
        OVLNo: '',
        PHBIDLink: '',
        PHBPlateNo: '',
        DriverIDLink: '',
        DriverLastName: '',
        DriverFirstName: '',
        DriverMiddleName: '',
        DriverExtName: '',
        BillAmount: '',
        LessAdmin: '',
        FuelAmount: '',
        FuelRate: '',
        NetTrucker: '',
        Status: '',
        ChargeInvoiceNumber: '',
        GLCode: '',
        CostCenter: '',
        PerKilometerRate: '120',
        ExtraRun: '',
        NumberofDays: '',
        DriverName: '',
        TruckerName: '',
        CollectedAmount: '',
        ORCRNumber: '',
        ORCRDate: '',
        Remarks: '',
        TotalAmount: '',
        startreading: '',
        endreading: '',
        totalrun: '',
        totalactualrun: '',
        LocationName: '',
        LocationID: '',
        Assignment: '',
        TimeIn: '',
        TimeOut: '',
        FuelLiters: '',
        MaintenanceCost: '',
        Helper: '',
        Labor: '400',
        OVLType: 'TRIP',
        PONo: '',
        ModeOfPayment: 'CASH',
        ServiceEntrySheet: '',
        RefNo: '',
        DocHeaderText: ''
      }, _defineProperty(_ref, "ServiceEntrySheet", ''), _defineProperty(_ref, "Amount", ''), _defineProperty(_ref, "CheckNumber", ''), _defineProperty(_ref, "CheckDate", new Date().toISOString().slice(0, 10)), _defineProperty(_ref, "CheckBank", ''), _defineProperty(_ref, "PaymentMode", ''), _defineProperty(_ref, "PaymentRemarks", ''), _ref)),
      paymentModes: []
    };
  },
  methods: {
    calculateReading: function calculateReading() {
      if (this.form.endreading && this.form.startreading) {
        this.form.totalrun = parseFloat(this.form.endreading - this.form.startreading);
      } else {
        this.form.totalrun = 0;
      }
    },
    calculateExtraRun: function calculateExtraRun() {
      if (!this.form.totalactualrun) {
        this.form.ExtraRun = 0;
      } else {
        var extra = parseFloat(this.form.totalactualrun) - parseFloat(this.form.PerKilometerRate);

        if (extra > 0) {
          this.form.ExtraRun = extra;
          this.form.ExtraRunAmount = extra * 2;
        } else {
          this.form.ExtraRun = 0;
        }
      }
    },
    signalChangeLessFuel: function signalChangeLessFuel() {
      var semitotalss = 0 + this.form.LessFuel; //this.form.LessAdmin + this.form.LessFuel;

      this.form.NetTrucker = this.form.BillAmount - this.form.LessFuel; //this.form.BillAmount - this.form.LessAdmin - this.form.LessFuel;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
    },
    signalChangeCollectedAmount: function signalChangeCollectedAmount() {
      this.collection.BalanceAmount = this.form.BalanceAmountHDR - this.form.CollectedAmount;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');

      if (this.form.BalanceAmount == 0) {
        this.form.Status = 'PAID';
      }
    },
    changeFuelAmount: function changeFuelAmount() {
      if (this.form.FuelRate && this.form.FuelLiters) {
        this.form.FuelAmount = parseFloat(this.form.FuelRate) * parseFloat(this.form.FuelLiters);
        this.form.LessAdmin = this.form.FuelAmount * 0.1;
      } else {
        this.form.FuelAmount = 0;
        this.form.LessAdmin = 0;
      }
    },
    calculateMaintenance: function calculateMaintenance() {
      this.form.MaintenanceCost = this.form.BillAmount * 0.1;
    },
    addPayment: function addPayment(jvl) {
      this.form.reset();

      if (!jvl.CollectedAmount) {
        jvl.ModeOfPayment = 'CASH';
        jvl.CheckDate = new Date().toISOString().slice(0, 10);
      }

      this.form.fill(jvl);

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      $('#addNewMultiple').modal('show');
    },
    updateTitleLocation: function updateTitleLocation(updatedTitleLocation) {
      if (this.loc == 'MAIN') {
        this.form.LocationName = updatedTitleLocation.LocationName;
      } else if (this.loc == 'LOADING') {
        this.detail.LoadingLocationName = updatedTitleLocation.LocationName;
      } else if (this.loc == 'UNLOADING') {
        this.detail.UnLoadingLocationName = updatedTitleLocation.LocationName;
      } // console.log(updatedTitle);

    },
    updateTitle: function updateTitle(updatedTitle) {
      this.form.DriverName = updatedTitle.LastName + ',' + updatedTitle.FirstName + ' ' + updatedTitle.MiddleName + ' ' + updatedTitle.ExtName;
      this.form.DriverIDLink = updatedTitle.id;
      this.form.DriverLastName = updatedTitle.LastName;
      this.form.DriverFirstName = updatedTitle.FirstName;
      this.form.DriverMiddleName = updatedTitle.MiddleName;
      this.form.DriverExtName = updatedTitle.ExtName; // console.log(updatedTitle);
    },
    updateTitleOperator: function updateTitleOperator(updatedTitleOperator) {
      this.form.TruckerName = updatedTitleOperator.LastName + ',' + updatedTitleOperator.FirstName + ' ' + updatedTitleOperator.MiddleName + ' ' + updatedTitleOperator.ExtName;
      this.form.TruckerIDLink = updatedTitleOperator.id;
      this.form.TruckerLastName = updatedTitleOperator.LastName;
      this.form.TruckerFirstName = updatedTitleOperator.FirstName;
      this.form.TruckerMiddleName = updatedTitleOperator.MiddleName;
      this.form.TruckerExtName = updatedTitleOperator.ExtName; // console.log(updatedTitle);
    },
    updateTitleVehicle: function updateTitleVehicle(updatedTitleVehicle) {
      if (this.eq == 'true') {
        this.form.PHBPlateNo = updatedTitleVehicle.PlateNumber;
        this.form.PHBIDLink = updatedTitleVehicle.MVID;
        this.form.TruckerName = updatedTitleVehicle.TruckerName;
        this.form.TruckerIDLink = updatedTitleVehicle.TruckerID;
        this.form.TruckerLastName = updatedTitleVehicle.TruckerLastName;
        this.form.TruckerFirstName = updatedTitleVehicle.TruckerFirstName;
        this.form.TruckerMiddleName = updatedTitleVehicle.TruckerMiddleName;
        this.form.TruckerExtName = updatedTitleVehicle.TruckerExtName;
        this.form.DriverName = updatedTitleVehicle.DriverName;
        this.form.DriverIDLink = updatedTitleVehicle.DriverID;
        this.form.DriverLastName = updatedTitleVehicle.DriverLastName;
        this.form.DriverFirstName = updatedTitleVehicle.DriverFirstName;
        this.form.DriverMiddleName = updatedTitleVehicle.DriverMiddleName;
        this.form.DriverExtName = updatedTitleVehicle.DriverExtName; // console.log(updatedTitle);

        this.getVehicleRate();
      } else {
        this.form.SearchPHBPlateNo = updatedTitleVehicle.PlateNumber;
      }
    },
    getVehicleRate: function getVehicleRate() {
      var _this = this;

      axios.get('/api/getphbvehiclerate', {
        params: {
          PHBIDLink: this.form.PHBIDLink
        }
      }).then(function (response) {
        _this.batch = response.data;
      })["catch"](function (err) {});
    },
    getJVLFilter: function getJVLFilter() {
      var _this2 = this;

      axios.get('/api/getphbfilter', {
        params: {
          PHBIDLink: this.form.PHBIDLink
        }
      }).then(function (response) {
        _this2.jvlfilter = response.data;
      })["catch"](function (err) {});
    },
    searchsearchVehicleFunction: function searchsearchVehicleFunction() {
      this.eq = 'false';
      $('#searchVehicle').modal('show');
    },
    searchVehicleFunction: function searchVehicleFunction() {
      $('#searchVehicle').modal('show');
    },
    getVehicleIsReal: function getVehicleIsReal() {
      var _this3 = this;

      axios.get('api/vehicle').then(function (_ref2) {
        var data = _ref2.data;
        return _this3.vehicles = data;
      });
    },
    searchOperatorFunction: function searchOperatorFunction() {
      $('#searchOperator').modal('show');
    },
    getOperatorIsReal: function getOperatorIsReal() {
      var _this4 = this;

      axios.get('api/operator').then(function (_ref3) {
        var data = _ref3.data;
        return _this4.operators = data;
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      });
    },
    create_soa: function create_soa() {
      if (this.selected.length == 0) {
        swal.fire("No Rental Data Found.", "warning");
      } else {
        $("#createSOA").modal("show");
      }
    },
    review_soa: function review_soa() {
      $("#reviewSOA").modal("show");
    },
<<<<<<< HEAD
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    onChange: function onChange(e) {
      var _this3 = this;

      this.form.applied_amount = 0;
      this.selected = [];
      var selectedRows = this.gridApi.getSelectedNodes();
      var selectedData = selectedRows.map(function (node) {
        return node.data;
      });
      var push = selectedData.map(function (node) {
        return _this3.selected.push(node);
      });
      console.log(this.selected);
    },
    get_client: function get_client() {
      var _this4 = this;

      axios.get("search/client").then(function (_ref3) {
        var data = _ref3.data;
        _this4.clients = data.data;
        console.log(_this4.filter);
      });
    },
    select_client: function select_client() {
      this.form.billed_id = this.client.id;
      this.form.billed_name = this.client.FirstName;
      this.form.billed_address = this.client.Address;
    }
  },
  created: function created() {
    this.columnDefs = [{
      headerName: "Activity",
      field: "date",
      resizable: true,
      width: 170,
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true
    }, {
      headerName: "Route",
      field: "type",
      resizable: true,
      width: 170
    }, {
      headerName: "Mat. Code",
      field: "po_activity",
      resizable: true,
      width: 170
    }, {
      headerName: "No Bags",
      field: "gross_amount",
      resizable: true,
      width: 170
    }, {
      headerName: "U Price",
      field: "no_trips",
      resizable: true,
      width: 170
    }, {
      headerName: "Amount",
      field: "amount",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }];
    this.filter = [];
    this.get_client();
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_2___default()().format("YYYY-MM-DD");
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_2___default()().format("YYYY-MM-DD");
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef& ***!
  \**************************************************************************************************************************************************************************************************************************/
=======
    searchLocationFunction: function searchLocationFunction() {
      this.loc = 'MAIN';
      $('#searchLocation').modal('show');
    },
    searchLoadingLocationFunction: function searchLoadingLocationFunction() {
      this.loc = 'LOADING';
      $('#searchLocation').modal('show');
    },
    searchUnLoadingLocationFunction: function searchUnLoadingLocationFunction() {
      this.loc = 'UNLOADING';
      $('#searchLocation').modal('show');
    },
    getDriverIsReal: function getDriverIsReal() {
      var _this5 = this;

      axios.get('api/driver').then(function (_ref4) {
        var data = _ref4.data;
        return _this5.drivers = data;
      });
    },
    getResults: function getResults() {
      var _this6 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/jvl?page=' + page).then(function (response) {
        _this6.jeepvehiclelog = response.data;
      });
    },
    updateJVL: function updateJVL(PHBVLHDRID) {
      console.log(this.form.ExtraRun);
      this.$Progress.start();

      if (this.addPayment) {
        this.form.Status = 'COLLECTED';
      }

      this.form.put('api/phbvl/' + this.form.PHBVLHDRID); //$('#addNew').modal('hide');

      toast.fire({
        icon: 'success',
        title: 'PHB Vehicle Log successfully updated'
      });
      this.$Progress.finish();
      this.loadJVL();
    },
    deleteModal: function deleteModal(PHBVLHDRID) {
      var _this7 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this7.$Progress.start();

          _this7.form["delete"]('api/phbvl/' + PHBVLHDRID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');
          _this7.form.PHBVLHDRID_Link = PHBVLHDRID;
          axios.get('/api/deletephbvcpdtl', {
            params: {
              PHBVLHDRID_Link: _this7.form.PHBVLHDRID_Link
            }
          }).then(function (_ref5) {
            var data = _ref5.data;
          })["catch"](function (err) {});
          axios.get('/api/deleteallphbdtl', {
            params: {
              PHBVLHDRID_Link: _this7.form.PHBVLHDRID_Link
            }
          }).then(function (_ref6) {
            var data = _ref6.data;
          })["catch"](function (err) {});

          _this7.$Progress.finish();

          _this7.loadJVL();
        }
      });
    },
    editModal: function editModal(jvl) {
      this.form.PHBVLHDRID_Link = jvl.PHBVLHDRID;
      this.editmode = true;
      this.form.reset();
      $('#addNew').modal('show');
      this.form.fill(jvl);

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      $('#addNew').modal('show');
      var today = new Date().toISOString().slice(0, 10);
      this.form.PHBVLDate = today;
      this.form.LessFuel = 0;
      this.form.FuelLiters = 0;
    },
    loadJVL: function loadJVL() {
      var _this8 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getphbvl').then(function (response) {
        _this8.jvls = response.data;
        response.data.forEach(function (item) {
          if (item.CollectedAmount > 0) {
            item.Status = 'COLLECTED';
          } else {
            item.Status = 'TO COLLECT';
          }
        });
      })["catch"](function (error) {
        console.log(error);
      });
    },
    createJVL: function createJVL() {
      var _this9 = this;

      this.$Progress.start();
      this.form.post('api/phbvl').then(function () {
        //$('#addNew').modal('hide');
        //$('.modal-backdrop').remove();
        _this9.form.reset();

        var today = new Date().toISOString().slice(0, 10);
        _this9.form.PHBVLDate = today;
        toast.fire({
          icon: 'success',
          title: 'PHB Vehicle Log successfully created'
        });

        _this9.$Progress.finish();

        _this9.loadJVL();

        _this9.form.LessFuel = 0;
        _this9.form.FuelLiters = 0;
      })["catch"](function () {
        _this9.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'PHB Vehicle Log not added successfully'
        });
      });
    },
    loadPaymentModes: function loadPaymentModes() {
      var _this10 = this;

      axios.get('api/mode').then(function (_ref7) {
        var data = _ref7.data;
        _this10.paymentModes = data.data;
      });
    }
  },
  created: function created() {
    this.loadJVL();
    this.loadPaymentModes(); //setInterval(() => this.loadDriver(),3000);
  },
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this11 = this;

      if (this.DateFrom !== '' || this.DateTo !== '' && this.SearchPHBPlateNo !== '') {
        this.SearchPHBPlateNo = '';
        var vm = this;
        var startdate = vm.DateFrom;
        var enddate = vm.DateTo;
        return _.filter(vm.jvls, function (data) {
          if (_.isNull(startdate) && _.isNull(enddate)) {
            return true;
          } else {
            var date = data.PHBVLDate;
            return date >= startdate && date <= enddate;
          }
        });
      } else {
        this.DateFrom = '';
        this.DateTo = ''; //return this.jvls.filter(jvl =>{
        //return jvl.PHBPlateNo.includes(this.form.PHBPlateNo)
        //});

        return this.jvls.filter(function (samsung) {
          return _this11.SearchPHBPlateNo.toLowerCase().split(' ').every(function (v) {
            return samsung.PHBPlateNo.toLowerCase().includes(v);
          });
        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      locations: [],
      swegets: [],
      searchClientVar: "",
      form: new Form({
        search: ""
      })
    };
  },
  mounted: function mounted() {
    this.loadLocation();
  },
  methods: {
    changeTitleLocation: function changeTitleLocation(location) {
      // console.log(driver);
      this.$emit('changeTitleLocation', location); // this.$emit('kuhaDriverID',driver.id);

      $('#searchLocation').modal('hide');
    },
    loadLocation: function loadLocation() {
      var _this = this;

      axios.get('api/getlocation').then(function (response) {
        _this.locations = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this2 = this;

      //return this.drivers.filter(driver =>{
      //return driver.LastName.includes(this.form.search)
      //});
      return this.locations.filter(function (samsung) {
        return _this2.form.search.toLowerCase().split(' ').every(function (v) {
          return samsung.LocationName.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n\tpointer-events: none;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("img", { attrs: { src: __webpack_require__(/*! ./PHB.png */ "./resources/js/components/PHBComponents/PHB.png") } }),
    _vm._v(" "),
    _c(
      "nav",
      {
        staticClass:
          "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
      },
      [
        _c(
          "div",
          {
            staticClass: "collapse navbar-collapse",
            attrs: { id: "navbarNavDropdown" }
          },
          [
            _c("ul", { staticClass: "navbar-nav" }, [
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#mlist"
                    }
                  },
                  [
                    _vm._v(
                      "\r\n                        Master File\r\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "mlist"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/phbdriverlist" }
                          },
                          [_c("a", [_vm._v("PHB Driver List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/phbvehiclelist" }
                          },
                          [_c("a", [_vm._v("PHB List & Rate")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/locationlist" }
                          },
                          [_c("a", [_vm._v("Location List")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#trans"
                    }
                  },
                  [
                    _vm._v(
                      "\r\n                        Transactions\r\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "trans"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/phbvehiclelogentry" }
                          },
                          [_c("a", [_vm._v("PHB Vehicle Log Entry")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#report"
                    }
                  },
                  [
                    _vm._v(
                      "\r\n                        PHB Reports\r\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "report"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistPHB" }
                          },
                          [_c("a", [_vm._v("Standard PHB Report")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistPHBPerJeep" }
                          },
                          [_c("a", [_vm._v("PHB Vehicle Log Billing Report")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& ***!
  \***************************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "createSOA",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body" }, [
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.createData()
                    }
                  }
                },
                [
                  _c("div", { staticClass: "modal-body" }, [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "golfcart" } }, [
                          _vm._v("SOA No")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.series_no,
                              expression: "form.series_no"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "series_no" },
                          domProps: { value: _vm.form.series_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "series_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Date")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.soa_date,
                              expression: "form.soa_date"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date", name: "soa_date" },
                          domProps: { value: _vm.form.soa_date },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "soa_date",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Status")
                        ]),
                        _vm._v(" "),
                        _c("p", [_vm._v(_vm._s(_vm.form.status))])
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "golfcart" } }, [
                          _vm._v("Billed to")
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "input-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.billed_name,
                                expression: "form.billed_name"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: {
                              type: "text",
                              disabled: "",
                              name: "billed_name"
                            },
                            domProps: { value: _vm.form.billed_name },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "billed_name",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "span",
                            { staticClass: "input-group-btn" },
                            [
                              _c(
                                "button",
                                {
                                  staticClass: "btn btn-outline-primary btn-sm",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      return _vm.searchClient()
                                    }
                                  }
                                },
                                [_vm._v("Search")]
                              ),
                              _vm._v(" "),
                              _c("client-list", {
                                on: { golfcart_data: _vm.getData }
                              }),
                              _vm._v(" "),
                              _c("signatory-req", {
                                on: { signatory: _vm.get_signatory }
                              })
                            ],
                            1
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Period Covered")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.period_covered,
                              expression: "form.period_covered"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date", name: "period_convered" },
                          domProps: { value: _vm.form.period_covered },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "period_covered",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Address")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.billed_address,
                              expression: "form.billed_address"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: {
                            type: "text",
                            name: "billed_address",
                            disabled: ""
                          },
                          domProps: { value: _vm.form.billed_address },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "billed_address",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Charge Invoice")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.charge_invoice_no,
                              expression: "form.charge_invoice_no"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "charge_invoice_no" },
                          domProps: { value: _vm.form.charge_invoice_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "charge_invoice_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Remarks")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.remarks,
                              expression: "form.remarks"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "remarks" },
                          domProps: { value: _vm.form.remarks },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "remarks", $event.target.value)
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Details")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.details,
                              expression: "form.details"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "details" },
                          domProps: { value: _vm.form.details },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "details", $event.target.value)
                            }
                          }
                        })
                      ])
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-footer" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-primary",
                        attrs: { type: "submit" }
                      },
                      [_vm._v("Create")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-secondary",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            return _vm.print_soa()
                          }
                        }
                      },
                      [_vm._v("PRINT")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-danger",
                        attrs: { type: "button", "data-dismiss": "modal" }
                      },
                      [_vm._v("Close")]
                    )
                  ])
                ]
              )
            ])
          ])
        ])
      ]
    )
  ])
}
var staticRenderFns = [
=======
  return _c(
    "div",
    { staticClass: "container", attrs: { id: "sweget" } },
    [
      _c("phb-menu"),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c(
              "form",
              {
                staticStyle: {
                  "border-style": "solid",
                  "border-color": "coral"
                }
              },
              [
                _c("div", { staticClass: "form-inline" }, [
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(1),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateFrom,
                            expression: "DateFrom"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateFrom" },
                        domProps: { value: _vm.DateFrom },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateFrom = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(2),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateTo,
                            expression: "DateTo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateTo" },
                        domProps: { value: _vm.DateTo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateTo = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              _vm.filterKey = "all"
                            }
                          }
                        },
                        [_vm._v("Search")]
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-left": "5px",
                        "margin-top": "10px"
                      }
                    },
                    [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.SearchPHBPlateNo,
                            expression: "SearchPHBPlateNo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "SearchPHBPlateNo",
                          placeholder: "PHB Plate Number"
                        },
                        domProps: { value: _vm.SearchPHBPlateNo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.SearchPHBPlateNo = $event.target.value
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-primary", size: "sm" },
                              on: {
                                click: function($event) {
                                  return _vm.searchsearchVehicleFunction()
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-search",
                                attrs: { "aria-hidden": "true" }
                              })
                            ]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }),
            _vm._v(" "),
            _c("br")
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _vm._m(3),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.filteredBlogs, function(jvl) {
                    return _c("tr", { key: jvl.PHBVLHDRID }, [
                      _c("td", [_vm._v(_vm._s(jvl.PHBVLDate))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.PHBPlateNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.DriverName))]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          _vm._s(
                            "Php " +
                              jvl.BillAmount.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          _vm._s(
                            "Php " +
                              jvl.CollectedAmount.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.Status))]),
                      _vm._v(" "),
                      _c("td", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#", title: "Add Payment" },
                            on: {
                              click: function($event) {
                                return _vm.addPayment(jvl)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-coins text-warning" })]
                        ),
                        _vm._v("\n                  /\n                  "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.editModal(jvl)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-edit" })]
                        ),
                        _vm._v("\n                  /\n                  "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.deleteModal(jvl.PHBVLHDRID)
                              }
                            }
                          },
                          [
                            _c("i", {
                              staticClass: "fa fa-trash",
                              staticStyle: { color: "red" }
                            })
                          ]
                        )
                      ])
                    ])
                  }),
                  0
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer text-right" }, [
            _c(
              "button",
              { staticClass: "btn btn-success", on: { click: _vm.newModal } },
              [
                _vm._v(
                  "\n              Add New PHB Vehicle Log\n              "
                ),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New PHB Vehicle Log")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update PHB Vehicle Log's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(4)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode ? _vm.updateJVL() : _vm.createJVL()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(5),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBVLDate,
                                        expression: "form.PHBVLDate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      id: "PHBVLDate",
                                      type: "date",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.PHBVLDate },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBVLDate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBVLHDRID,
                                        expression: "form.PHBVLHDRID"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "hidden" },
                                    domProps: { value: _vm.form.PHBVLHDRID },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBVLHDRID",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(6),
                                  _vm._v(" "),
                                  _c(
                                    "select",
                                    {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: _vm.form.OVLType,
                                          expression: "form.OVLType"
                                        }
                                      ],
                                      staticClass: "form-control",
                                      attrs: { name: "OVLType", required: "" },
                                      on: {
                                        change: function($event) {
                                          var $$selectedVal = Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function(o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function(o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                          _vm.$set(
                                            _vm.form,
                                            "OVLType",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        }
                                      }
                                    },
                                    [
                                      _c("option"),
                                      _vm._v(" "),
                                      _c("option", [_vm._v("TRIP")]),
                                      _vm._v(" "),
                                      _c("option", [_vm._v("ADMIN CHARGE")])
                                    ]
                                  )
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(7),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLNo,
                                        expression: "form.OVLNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "OVLNo" },
                                    domProps: { value: _vm.form.OVLNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LocationName,
                                        expression: "form.LocationName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "LocationName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "LocationName",
                                      placeholder: "Location Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.LocationName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LocationName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchLocationFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBPlateNo,
                                        expression: "form.PHBPlateNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PHBPlateNo",
                                      placeholder: "PHB Plate Number",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.PHBPlateNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBPlateNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBIDLink,
                                        expression: "form.PHBIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "PHBIDLink",
                                      placeholder: "PHBIDLink"
                                    },
                                    domProps: { value: _vm.form.PHBIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchVehicleFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverName,
                                        expression: "form.DriverName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "DriverName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "DriverName",
                                      placeholder: "Driver Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.DriverName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchDriverFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(8),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.GLCode,
                                        expression: "form.GLCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "GLCode" },
                                    domProps: { value: _vm.form.GLCode },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "GLCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(9),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CostCenter,
                                        expression: "form.CostCenter"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "CostCenter" },
                                    domProps: { value: _vm.form.CostCenter },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "CostCenter",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(10),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PerKilometerRate,
                                        expression: "form.PerKilometerRate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PerKilometerRate"
                                    },
                                    domProps: {
                                      value: _vm.form.PerKilometerRate
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PerKilometerRate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(11),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Assignment,
                                        expression: "form.Assignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "Assignment" },
                                    domProps: { value: _vm.form.Assignment },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Assignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(12),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.TimeIn,
                                        expression: "form.TimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "time", name: "TimeIn" },
                                    domProps: { value: _vm.form.TimeIn },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "TimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(13),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.TimeOut,
                                        expression: "form.TimeOut"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "time", name: "TimeOut" },
                                    domProps: { value: _vm.form.TimeOut },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "TimeOut",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _vm._m(14),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(15),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.startreading,
                                        expression: "form.startreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85C1E9" },
                                    attrs: {
                                      type: "number",
                                      name: "endreading",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.startreading },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "startreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.calculateReading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(16),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.endreading,
                                        expression: "form.endreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85C1E9" },
                                    attrs: {
                                      type: "number",
                                      name: "endreading",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.endreading },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "endreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.calculateReading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(17),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.totalrun,
                                        expression: "form.totalrun"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85C1E9" },
                                    attrs: {
                                      type: "number",
                                      name: "totalactualrun",
                                      "data-readonly": ""
                                    },
                                    domProps: { value: _vm.form.totalrun },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "totalrun",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _vm._m(18),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(19),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.MaintenanceCost,
                                        expression: "form.MaintenanceCost"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "MaintenanceCost",
                                      disabled: ""
                                    },
                                    domProps: {
                                      value: _vm.form.MaintenanceCost
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "MaintenanceCost",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(20),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LessAdmin,
                                        expression: "form.LessAdmin"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "LessAdmin",
                                      disabled: ""
                                    },
                                    domProps: { value: _vm.form.LessAdmin },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LessAdmin",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(21),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Helper,
                                        expression: "form.Helper"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "Helper" },
                                    domProps: { value: _vm.form.Helper },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Helper",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(22),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Labor,
                                        expression: "form.Labor"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "Labor" },
                                    domProps: { value: _vm.form.Labor },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Labor",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(23),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.FuelLiters,
                                        expression: "form.FuelLiters"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "number",
                                      name: "FuelLiters"
                                    },
                                    domProps: { value: _vm.form.FuelLiters },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "FuelLiters",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.changeFuelAmount()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(24),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.FuelRate,
                                        expression: "form.FuelRate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "FuelRate" },
                                    domProps: { value: _vm.form.FuelRate },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "FuelRate",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.changeFuelAmount()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(25),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.FuelAmount,
                                        expression: "form.FuelAmount"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "number",
                                      name: "LessFuel",
                                      disabled: ""
                                    },
                                    domProps: { value: _vm.form.FuelAmount },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "FuelAmount",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(26),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.BillAmount,
                                        expression: "form.BillAmount"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "BillAmount" },
                                    domProps: { value: _vm.form.BillAmount },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "BillAmount",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.calculateMaintenance()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNewMultiple",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-md",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _vm._m(27),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.updateJVL()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body" }, [
                      _c("div", { staticClass: "col-xs-12" }, [
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(28),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.totalactualrun,
                                      expression: "form.totalactualrun"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "totalactualrun"
                                  },
                                  domProps: { value: _vm.form.totalactualrun },
                                  on: {
                                    input: [
                                      function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "totalactualrun",
                                          $event.target.value
                                        )
                                      },
                                      function($event) {
                                        return _vm.calculateExtraRun()
                                      }
                                    ]
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(29),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.ExtraRun,
                                      expression: "form.ExtraRun"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "ExtraRun" },
                                  domProps: { value: _vm.form.ExtraRun },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "ExtraRun",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(30),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.PONo,
                                      expression: "form.PONo"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "PONo" },
                                  domProps: { value: _vm.form.PONo },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "PONo",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(31),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.RefNo,
                                      expression: "form.RefNo"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "ORCRNumber" },
                                  domProps: { value: _vm.form.RefNo },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "RefNo",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(32),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.ServiceEntrySheet,
                                      expression: "form.ServiceEntrySheet"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "ServiceEntrySheet"
                                  },
                                  domProps: {
                                    value: _vm.form.ServiceEntrySheet
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "ServiceEntrySheet",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(33),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DocHeaderText,
                                      expression: "form.DocHeaderText"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "DocHeaderText"
                                  },
                                  domProps: { value: _vm.form.DocHeaderText },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DocHeaderText",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col-7" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(34),
                                _vm._v(" "),
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ModeOfPayment,
                                        expression: "form.ModeOfPayment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { required: "" },
                                    on: {
                                      change: function($event) {
                                        var $$selectedVal = Array.prototype.filter
                                          .call($event.target.options, function(
                                            o
                                          ) {
                                            return o.selected
                                          })
                                          .map(function(o) {
                                            var val =
                                              "_value" in o ? o._value : o.value
                                            return val
                                          })
                                        _vm.$set(
                                          _vm.form,
                                          "ModeOfPayment",
                                          $event.target.multiple
                                            ? $$selectedVal
                                            : $$selectedVal[0]
                                        )
                                      }
                                    }
                                  },
                                  [
                                    _c("option"),
                                    _vm._v(" "),
                                    _vm._l(_vm.paymentModes, function(item) {
                                      return _c("option", { key: item.name }, [
                                        _vm._v(_vm._s(item.name))
                                      ])
                                    })
                                  ],
                                  2
                                )
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-5" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(35),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.CollectedAmount,
                                      expression: "form.CollectedAmount"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "CollectedAmount"
                                  },
                                  domProps: { value: _vm.form.CollectedAmount },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "CollectedAmount",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col-5" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(36),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.CheckNumber,
                                      expression: "form.CheckNumber"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "CheckNumber" },
                                  domProps: { value: _vm.form.CheckNumber },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "CheckNumber",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-7" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(37),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.CheckDate,
                                      expression: "form.CheckDate"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    id: "date",
                                    type: "date",
                                    name: "CheckDate"
                                  },
                                  domProps: { value: _vm.form.CheckDate },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "CheckDate",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(38),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.CheckBank,
                                      expression: "form.CheckBank"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "CheckBank" },
                                  domProps: { value: _vm.form.CheckBank },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "CheckBank",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(39),
                                _vm._v(" "),
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.PaymentRemarks,
                                      expression: "form.PaymentRemarks"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "PaymentRemarks"
                                  },
                                  domProps: { value: _vm.form.PaymentRemarks },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "PaymentRemarks",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ])
                      ])
                    ]),
                    _vm._v(" "),
                    _vm._m(40)
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-driver", {
        on: {
          changeTitle: function($event) {
            return _vm.updateTitle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-operator", {
        on: {
          changeTitleOperator: function($event) {
            return _vm.updateTitleOperator($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-phbvehicle", {
        on: {
          changeTitleVehicle: function($event) {
            return _vm.updateTitleVehicle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-location", {
        on: {
          changeTitleLocation: function($event) {
            return _vm.updateTitleLocation($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("PHB Vehicle Log Entry")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("VL No")]),
        _vm._v(" "),
        _c("th", [_vm._v("Plate No")]),
        _vm._v(" "),
        _c("th", [_vm._v("Driver")]),
        _vm._v(" "),
        _c("th", [_vm._v("Est. Bill Amt.")]),
        _vm._v(" "),
        _c("th", [_vm._v("Actual Bill Amt.")]),
        _vm._v(" "),
        _c("th", [_vm._v("Status")]),
        _vm._v(" "),
        _c("th", [_vm._v("Modify")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("VL Type")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("VL No")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("GL Code")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Cost Center")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Standard km rate (60-120km)")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Assignment")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time In")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time Out")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col" }, [
        _c("h3", [_vm._v("ACTUAL RUN - GSC")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85C1E9",
            "border-color": "#85C1E9"
          }
        },
        [_vm._v("Actual Start Reading")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85C1E9",
            "border-color": "#85C1E9"
          }
        },
        [_vm._v("Actual End Reading")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85C1E9",
            "border-color": "#85C1E9"
          }
        },
        [_vm._v("Total Actual Run")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col" }, [
        _c("h3", [_vm._v("EXPENSES & BILL AMOUNT")])
      ])
    ])
  },
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Create Wing Van SOA")]),
=======
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Maintenance Cost")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Admin Cost")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Helper")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Labor")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("No. Of Liters")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Fuel Rate")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Fuel Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Estimated Bill Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header" }, [
      _c("h5", { staticClass: "modal-title", attrs: { id: "addNewLabel" } }, [
        _vm._v("PHB Payment")
      ]),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
<<<<<<< HEAD
=======
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("DMPI Run")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Extra Run")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("PO No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Ref No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Service Entry Sheet")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Doc Header Text")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Mode of Payment")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check Bank")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Remarks")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-footer" }, [
      _c(
        "button",
        { staticClass: "btn btn-primary", attrs: { type: "submit" } },
        [_vm._v("Save")]
      ),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "btn btn-secondary",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [_vm._v("Close")]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=template&id=12a440d2&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=template&id=12a440d2& ***!
  \*****************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156& ***!
  \**********************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
<<<<<<< HEAD
          id: "reviewSOA",
=======
          id: "searchLocation",
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c(
            "div",
            { staticClass: "modal-content" },
            [
              _vm._m(0),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c(
                  "div",
                  { staticClass: "container" },
                  [
                    _c("div", { staticClass: "row mt-3" }, [
                      _vm._v(
                        "\n              Search by SOA Date\n              "
                      ),
                      _c("div", { staticClass: "col" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.datefrom,
                              expression: "datefrom"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.datefrom },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.datefrom = $event.target.value
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.dateto,
                              expression: "dateto"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.dateto },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.dateto = $event.target.value
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-secondary",
                            on: {
                              click: function($event) {
                                return _vm.review()
                              }
                            }
                          },
                          [_vm._v("Review")]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "kendo-grid",
                      {
                        attrs: {
                          height: 200,
                          "data-source": _vm.filter,
                          selectable: true,
                          sortable: true
                        },
                        on: { change: _vm.onChange }
                      },
                      [
                        _c("kendo-grid-column", {
                          attrs: { field: "soa_date", title: "SOA Date" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "series_no", title: "SOA No" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "billed_name", title: "Billed To" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: {
                            field: "charge_invoice_no",
                            title: "Charge Invoice No"
                          }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "status", title: "Status" }
                        })
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _vm.showButton
                ? _c("div", { staticClass: "container" }, [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("p", [_vm._v("SOA: " + _vm._s(_vm.soa_no))]),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.soa_detail()
                              }
                            }
                          },
                          [_vm._v("View Detail")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.cancel_soa(_vm.id)
                              }
                            }
                          },
                          [_vm._v("Cancel SOA")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.view_soa()
                              }
                            }
                          },
                          [_vm._v("Preview SOA Form")]
                        )
                      ])
                    ])
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.showDetail
                ? _c("div", { staticClass: "container" }, [
                    _c(
                      "div",
                      { staticClass: "row" },
                      [
                        _c(
                          "kendo-grid",
                          {
                            attrs: {
                              height: 150,
                              "data-source": _vm.detail,
                              selectable: true,
                              sortable: true
                            }
                          },
                          [
<<<<<<< HEAD
                            _c("kendo-grid-column", {
                              attrs: { field: "req_date", title: "Date" }
                            }),
                            _vm._v(" "),
                            _c("kendo-grid-column", {
                              attrs: {
                                field: "particulars",
                                title: "particulars"
=======
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.form.search,
                                  expression: "form.search"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "search",
                                placeholder: "Search for..."
                              },
                              domProps: { value: _vm.form.search },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.form,
                                    "search",
                                    $event.target.value
                                  )
                                }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                              }
                            }),
                            _vm._v(" "),
                            _c("kendo-grid-column", {
                              attrs: { field: "amount", title: "Amount" }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
<<<<<<< HEAD
                  ])
                : _vm._e(),
=======
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "card-body table-responsive pre-scrollable"
                    },
                    [
                      _c("table", { staticClass: "table table-hover" }, [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.filteredBlogs, function(location) {
                            return _c(
                              "tr",
                              {
                                key: location.LocationID,
                                staticStyle: { cursor: "pointer" },
                                attrs: { id: "element" },
                                on: {
                                  click: function($event) {
                                    return _vm.changeTitleLocation(location)
                                  }
                                }
                              },
                              [
                                _c("td", [
                                  _vm._v(_vm._s(location.LocationCode))
                                ]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(_vm._s(location.LocationName))
                                ])
                              ]
                            )
                          }),
                          0
                        )
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  !_vm.locations
                    ? _c(
                        "div",
                        {
                          staticClass: "alert alert-default",
                          attrs: { role: "alert" }
                        },
                        [
                          _vm._v(
                            "\n                        No Data\n                    "
                          )
                        ]
                      )
                    : _vm._e()
                ])
              ]),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
              _vm._v(" "),
              _c("signatory-review", { on: { signatory: _vm.get_signatory } }),
              _vm._v(" "),
              _vm._m(1)
            ],
            1
          )
        ])
      ]
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header" }, [
<<<<<<< HEAD
      _c("h4", { staticClass: "modal-title" }, [_vm._v("SOA Review")]),
=======
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Search Location")]),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "modal-footer" }, [
=======
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("Location Code")]),
        _vm._v(" "),
        _c("th", [_vm._v("Location Name")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-footer " }, [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _c(
        "button",
        {
          staticClass: "btn btn-danger",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [
          _c("i", { staticClass: "far fa-window-close" }),
          _vm._v(" Close\n          ")
        ]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=template&id=3d12923e&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=template&id=3d12923e& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
=======
/***/ "./resources/js/components/PHBComponents/PHB.png":
/*!*******************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHB.png ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/PHB.png?21890255ae24f079f0fea1c3de620084";

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBMenu.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMenu.vue ***!
  \***********************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c("div", { staticClass: "row" }, [
      _c(
        "nav",
        { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
        [
          _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
            _vm._v("WING VAN SECTION")
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNav" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-list"
                        }
                      },
                      [_vm._v("Wing Van List")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-location"
                        }
                      },
                      [_vm._v("Route")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-po"
                        }
                      },
                      [_vm._v("Purchase Order")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-rental"
                        }
                      },
                      [_vm._v("Rental")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-soa"
                        }
                      },
                      [_vm._v("Create SOA")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-payment"
                        }
                      },
                      [_vm._v("Payment Collection")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-ledger"
                        }
                      },
                      [_vm._v("Ledger")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-reports"
                        }
                      },
                      [_vm._v("Reports")]
                    )
                  ],
                  1
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { attrs: { id: "dmpi" } }, [
        _c("div", { staticClass: "row mt-3" }, [
          _vm._v("\n        Search by Trans Date\n        "),
          _c("div", { staticClass: "col" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.datefrom,
                  expression: "datefrom"
                }
              ],
              staticClass: "form-control form-control-sm mb-2",
              attrs: { type: "date", placeholder: "Search Rental..." },
              domProps: { value: _vm.datefrom },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.datefrom = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.dateto,
                  expression: "dateto"
                }
              ],
              staticClass: "form-control form-control-sm mb-2",
              attrs: { type: "date", placeholder: "Search Rental..." },
              domProps: { value: _vm.dateto },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.dateto = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                on: {
                  click: function($event) {
                    return _vm.preview()
                  }
                }
              },
              [_vm._v("Preview")]
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row mt-3" }, [
          _c(
            "div",
            { staticClass: "col-sm" },
            [
              _c("ag-grid-vue", {
                staticClass: "ag-theme-balham",
                staticStyle: { width: "1050px", height: "300px" },
                attrs: {
                  columnDefs: _vm.columnDefs,
                  rowData: _vm.filter,
                  rowSelection: "multiple"
                },
                on: {
                  "grid-ready": _vm.onGridReady,
                  selectionChanged: _vm.onChange
                }
              }),
              _vm._v(" "),
              _c("create-soa", { attrs: { rental: _vm.selected } }),
              _vm._v(" "),
              _c("review-soa")
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: { type: "submit" },
                on: {
                  click: function($event) {
                    return _vm.create_soa()
                  }
                }
              },
              [_vm._v("Create SOA")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-success",
                attrs: { type: "submit" },
                on: {
                  click: function($event) {
                    return _vm.review_soa()
                  }
                }
              },
              [_vm._v("Manage SOA")]
            ),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "btn btn-success", attrs: { type: "submit" } },
              [_vm._v("PRINT CHARGE INVOICE")]
            ),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "btn btn-success", attrs: { type: "submit" } },
              [_vm._v("PRINT DELIVERY")]
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-SOA-Req.vue":
/*!*************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA-Req.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WingVan_SOA_Req_vue_vue_type_template_id_7e1403ef___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef& */ "./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef&");
/* harmony import */ var _WingVan_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-SOA-Req.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");


=======
/* harmony import */ var _PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBMenu.vue?vue&type=template&id=7678b87f& */ "./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

var script = {}


/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_SOA_Req_vue_vue_type_template_id_7e1403ef___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_SOA_Req_vue_vue_type_template_id_7e1403ef___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/wingvan/WingVan-SOA-Req.vue"
=======
component.options.__file = "resources/js/components/PHBComponents/PHBMenu.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
=======
/***/ "./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f& ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-SOA-Req.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef&":
/*!********************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Req_vue_vue_type_template_id_7e1403ef___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Req.vue?vue&type=template&id=7e1403ef&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Req_vue_vue_type_template_id_7e1403ef___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Req_vue_vue_type_template_id_7e1403ef___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBMenu.vue?vue&type=template&id=7678b87f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBMenu.vue?vue&type=template&id=7678b87f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBMenu_vue_vue_type_template_id_7678b87f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-SOA-Review.vue":
/*!****************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA-Review.vue ***!
  \****************************************************************/
=======
/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue ***!
  \**************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _WingVan_SOA_Review_vue_vue_type_template_id_12a440d2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-SOA-Review.vue?vue&type=template&id=12a440d2& */ "./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=template&id=12a440d2&");
/* harmony import */ var _WingVan_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-SOA-Review.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");


=======
/* harmony import */ var _PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& */ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&");
/* harmony import */ var _PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PHBVehicleLogComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/PHBComponents/PHBVehicleLogComponent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc


<<<<<<< HEAD

/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_SOA_Review_vue_vue_type_template_id_12a440d2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_SOA_Review_vue_vue_type_template_id_12a440d2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/wingvan/WingVan-SOA-Review.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
/*! exports provided: default */
=======
/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************/
/*! no static exports found */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-SOA-Review.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=template&id=12a440d2&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=template&id=12a440d2& ***!
  \***********************************************************************************************/
=======
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& ***!
  \*********************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Review_vue_vue_type_template_id_12a440d2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-SOA-Review.vue?vue&type=template&id=12a440d2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA-Review.vue?vue&type=template&id=12a440d2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Review_vue_vue_type_template_id_12a440d2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_Review_vue_vue_type_template_id_12a440d2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-SOA.vue":
/*!*********************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA.vue ***!
  \*********************************************************/
=======
/***/ "./resources/js/components/search/SearchPHB/SearchLocation.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/components/search/SearchPHB/SearchLocation.vue ***!
  \*********************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _WingVan_SOA_vue_vue_type_template_id_3d12923e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-SOA.vue?vue&type=template&id=3d12923e& */ "./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=template&id=3d12923e&");
/* harmony import */ var _WingVan_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-SOA.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchLocation.vue?vue&type=template&id=5581f156& */ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&");
/* harmony import */ var _SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchLocation.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _WingVan_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_SOA_vue_vue_type_template_id_3d12923e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_SOA_vue_vue_type_template_id_3d12923e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/wingvan/WingVan-SOA.vue"
=======
component.options.__file = "resources/js/components/search/SearchPHB/SearchLocation.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
=======
/***/ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-SOA.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=template&id=3d12923e&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=template&id=3d12923e& ***!
  \****************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchLocation.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156& ***!
  \****************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_vue_vue_type_template_id_3d12923e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-SOA.vue?vue&type=template&id=3d12923e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-SOA.vue?vue&type=template&id=3d12923e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_vue_vue_type_template_id_3d12923e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_SOA_vue_vue_type_template_id_3d12923e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchLocation.vue?vue&type=template&id=5581f156& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);