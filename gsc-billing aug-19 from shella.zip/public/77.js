(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[77],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
/* harmony import */ var _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchOperator.vue */ "./resources/js/components/search/SearchJeep/SearchOperator.vue");
/* harmony import */ var _search_SearchOVL_SearchOVLVehicle_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchOVL/SearchOVLVehicle.vue */ "./resources/js/components/search/SearchOVL/SearchOVLVehicle.vue");
/* harmony import */ var _search_SearchJeep_SearchClient_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/SearchJeep/SearchClient.vue */ "./resources/js/components/search/SearchJeep/SearchClient.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_5__);
=======
/* harmony import */ var _OVLMenu_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLMenu.vue */ "./resources/js/components/OVLComponents/OVLMenu.vue");
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





 // import {AgGridVue} from "@ag-grid-community/vue";
// import {AllCommunityModules} from '@ag-grid-community/all-modules';
// import "ag-grid-community/dist/styles/ag-grid.css";
// import "ag-grid-community/dist/styles/ag-theme-balham.css";

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-operator': _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-ovlvehicle': _search_SearchOVL_SearchOVLVehicle_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    'search-client': _search_SearchJeep_SearchClient_vue__WEBPACK_IMPORTED_MODULE_3__["default"] // AgGridVue

  },
  data: function data() {
    return {
      // columnDefs: null,
      // rowData: null,
      // gridApi: null,
      // columnApi: null,
      // modules: AllCommunityModules,
      OVLDTLDetails: [],
      checkedNames: [],
      filteredblogs: [],
      csoatotals: [],
      checkedNamesFilter: [],
      editmode: false,
      equalequal: false,
      allSelected: false,
      jvls: [],
      jvlsobject: {},
      search: "",
      jvcps: {},
      drivers: [],
      vehicles: {},
      rates: {},
      operators: {},
      batch: [],
      jvlfilter: [],
      jvlbalamt: [],
      var1: "",
      var2: "",
      first: "",
      second: "",
      eq: "true",
      truevalue: "",
      falsevalue: "",
      SearchOVLPlateNo: "",
      DateFrom: "",
      DateTo: "",
      JeepVehicleCollectionPayments: {},
      form: new Form({
        OVLVLHDRID: "",
        OVLVLHDRIDFilter: "",
        OVLVLDate: "",
        OVLNo: "",
        OVLIDLink: "",
        OVLPlateNo: "",
        DriverIDLink: "",
        DriverLastName: "",
        DriverFirstName: "",
        DriverMiddleName: "",
        DriverExtName: "",
        TruckerIDLink: "",
        TruckerLastName: "",
        TruckerFirstName: "",
        TruckerMiddleName: "",
        TruckerExtName: "",
        BillAmount: "",
        LessAdmin: "",
        LessFuel: "",
        NetTrucker: "",
        Status: "",
        SOANumber: "",
        SOADate: "",
        ChargeInvoiceNumber: "",
        GLCode: "",
        CostCenter: "",
        PerHourRate: "",
        NumberofDays: "",
        NumberOfHours: "",
        DriverName: "",
        TruckerName: "",
        CollectedAmount: "",
        CollectedAmountHDR: "",
        BalanceAmountHDR: "",
        BalanceAmount: "",
        ORCRNumber: "",
        ORCRDate: "",
        Remarks: "",
        OVLVLHDRID_Link: "",
        TotalAmount: "",
        startreading: "",
        endreading: "",
        ClientName: "",
        ClientFirstName: "",
        ClientMiddleName: "",
        ClientLastName: "",
        ClientExtName: "",
        ClientIDLink: "",
        ModeOfPayment: "",
        MaintenanceCost: "",
        AmountExpense: "",
        Helper: "",
        Labor: "",
        TotalExpense: "",
        SubTotalExpense: "",
        FuelLiters: ""
      }),
      view: new Form({
        ViewLessFuel: "",
        ViewBillAmount: "",
        ViewNetTrucker: "",
        ViewPerHourRate: "",
        ViewBalanceAmount: "",
        ViewMaintenanceCost: "",
        ViewTotalExpense: "",
        ViewSubTotalExpense: ""
      }),
      detail: new Form({
        LoadingAssignment: "",
        PHBVLHDRID_Link: "",
        // LoadingLocationName:"",
        LoadingFLDLOG: "",
        LoadingTimeIn: "",
        LoadingTimeStart: "",
        LoadingTimeEnd: "",
        LoadingRemarks: "",
        LoadingLoadFill: "",
        LoadingHiredOperatorHour: "",
        LoadingJobCode: "",
        LoadingNoOfLoad: "",
        // UnLoadingLocationName:"",
        UnLoadingAssignment: "",
        UnLoadingFLDLOG: "",
        UnLoadingTimeIn: "",
        UnLoadingTimeStart: "",
        UnLoadingTimeEnd: "",
        UnLoadingRemarks: "",
        UnLoadingLoadFill: "",
        UnLoadingHiredOperatorHour: "",
        UnLoadingJobCode: "",
        UnLoadingNoOfLoad: "",
        OVLVLHDRID_Link: "",
        OVLVLDTLID: ""
      })
    };
  },
  mounted: function mounted() {//this.$parent.getSearchDriver();
    //this.$parent.getSearchOperator();
  },
  methods: {
    refreshtotalsoa: function refreshtotalsoa() {
      var _this = this;

      this.form.TotalAmount = "";
      this.form.OVLVLHDRID = this.checkedNames.join();
      axios.get('/api/getcsoasum', {
        params: {
          OVLVLHDRID: this.form.OVLVLHDRID
        }
      }).then(function (_ref) {
        var data = _ref.data;
        _this.csoatotals = data;
        _this.form.TotalAmount = _this.csoatotals[0].BillAmount;
        console.log(_this.form.TotalAmount);
      })["catch"](function (err) {});
    },
    selectAll: function selectAll() {
      this.checkedNames = [];

      if (this.allSelected == false) {
        for (var user in this.filteredBlogs) {
          this.checkedNames.push(this.filteredBlogs[user].OVLVLHDRID);
        } // this.form.OVLVLHDRID = this.checkedNames.join();
        // // axios.get('/api/getphbcsoasum', {params: {OVLVLHDRID: this.form.OVLVLHDRID}})
        // // .then(({ data }) => {
        // //     this.csoatotals = data;
        // //     this.form.TotalAmount = this.csoatotals[0].BillAmount;
        // //     console.log(this.form.TotalAmount);
        // // })
        // // .catch((err)=>{
        // // })

      } else {
        this.form.TotalAmount = "";
      }
    },
    select: function select() {
      this.allSelected = false;
    },
    SearchDateFromTo: function SearchDateFromTo() {//return this.jvls.filter(jvl =>{
      //       return jvl.OVLVLDate.includes(this.form.DateFrom)
      //    });

      /*var vm = this;
            var startdate = vm.form.DateFrom;
            var enddate = vm.form.DateTo;
            return _.filter(vm.jvls,(function(data){
              if ((_.isNull(startdate) && _.isNull(enddate))){
                return true
              }
              else{
                var date = data.OVLVLDate;
                return date.includes(date >= startdate && date <= enddate);
                
              }
            }))*/
    },
    InsertDetails: function InsertDetails() {
      this.detail.reset();
      this.detail.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      this.loadOVLDTL();
      $('#addOVLDetails').modal('show');
    },
    SetToUnpaid: function SetToUnpaid() {
      if (this.form.Status == "POSTED") {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Can not Set to Unpaid. The Status is still POSTED.'
        });
      } else {
        this.form.Status = "POSTED";
        this.form.BalanceAmount = this.form.BillAmount;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
        this.form.CollectedAmount = 0;
        this.$Progress.start();
        this.form.put('api/ovlpaidtoposted/' + this.form.OVLVLHDRID); //$('#addNew').modal('hide');

        toast.fire({
          icon: "success",
          title: "Outsider Vehicle Log is back to Unpaid"
        });
        this.deleteEntirePaymentDetail();
        this.loadJVL();
        this.getJVLBalanceAmount();
        this.$Progress.finish();
        this.form.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      }
    },
    signalChangestartreading: function signalChangestartreading() {
      var totalreading = 0;

      if (this.form.endreading !== "") {
        var startTime = moment__WEBPACK_IMPORTED_MODULE_4___default()(this.form.startreading, "HH:mm:ss a");
        var endTime = moment__WEBPACK_IMPORTED_MODULE_4___default()(this.form.endreading, "HH:mm:ss a");
        totalreading = endTime.diff(startTime, 'hours');
        this.form.BillAmount = parseFloat(totalreading * this.form.PerHourRate).toFixed(2);
        this.form.MaintenanceCost = parseFloat(this.form.BillAmount * 0.1).toFixed(2);
        var semitotal = this.form.MaintenanceCost + this.form.LessFuel;
        this.form.NetTrucker = parseFloat(this.form.BillAmount - semitotal).toFixed(2);

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        this.view.ViewBillAmount = numeral(this.form.BillAmount).format('0,0.00');
        this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
        this.view.ViewMaintenanceCost = numeral(this.form.MaintenanceCost).format('0,0.00');
        this.form.NumberOfHours = totalreading;
        var tots = 0;
        tots = parseFloat(this.form.LessFuel) + parseFloat(this.form.MaintenanceCost) + parseFloat(this.form.LessAdmin) + parseFloat(this.form.Helper) + parseFloat(this.form.Labor);
        this.form.TotalExpense = tots;
        this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
        this.form.TotalExpense = tots;
        this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
        this.form.SubTotalExpense = parseFloat(this.form.BillAmount) - parseFloat(this.form.LessFuel) - parseFloat(this.form.MaintenanceCost) - parseFloat(this.form.LessAdmin);
        this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');

        if (this.eq == "true") {
          this.form.BalanceAmount = this.form.BillAmount;
        }
      }
    },
    signalChangeendreading: function signalChangeendreading() {
      var totalreading = 0;
      var startTime = moment__WEBPACK_IMPORTED_MODULE_4___default()(this.form.startreading, "HH:mm:ss a");
      var endTime = moment__WEBPACK_IMPORTED_MODULE_4___default()(this.form.endreading, "HH:mm:ss a");
      totalreading = endTime.diff(startTime, 'hours');
      this.form.BillAmount = parseFloat(totalreading * this.form.PerHourRate).toFixed(2);
      this.form.MaintenanceCost = parseFloat(this.form.BillAmount * 0.1).toFixed(2);
      var semitotal = this.form.MaintenanceCost + this.form.LessFuel;
      this.form.NetTrucker = parseFloat(this.form.BillAmount - semitotal).toFixed(2);

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBillAmount = numeral(this.form.BillAmount).format('0,0.00');
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.view.ViewMaintenanceCost = numeral(this.form.MaintenanceCost).format('0,0.00');
      this.form.NumberOfHours = totalreading;
      var tots = 0;
      tots = parseFloat(this.form.LessFuel) + parseFloat(this.form.MaintenanceCost) + parseFloat(this.form.LessAdmin) + parseFloat(this.form.Helper) + parseFloat(this.form.Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(this.form.BillAmount) - parseFloat(this.form.LessFuel) - parseFloat(this.form.MaintenanceCost) - parseFloat(this.form.LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');

      if (this.eq == "true") {
        this.form.BalanceAmount = this.form.BillAmount;
        this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
      }
    },
    signalChangeLessFuel: function signalChangeLessFuel() {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      var tots = 0;
      this.form.LessAdmin = parseFloat(this.form.LessFuel * 0.1).toFixed(2);
      var tots = 0;
      tots = parseFloat(this.form.LessFuel) + parseFloat(this.form.MaintenanceCost) + parseFloat(this.form.LessAdmin) + parseFloat(this.form.Helper) + parseFloat(this.form.Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.NetTrucker = parseFloat(this.form.BillAmount) - parseFloat(tots);
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(this.form.BillAmount) - parseFloat(this.form.LessFuel) - parseFloat(this.form.MaintenanceCost) - parseFloat(this.form.LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');
    },
    signalChangeHelper: function signalChangeHelper() {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      var tots = 0;
      var tots = 0;
      tots = parseFloat(this.form.LessFuel) + parseFloat(this.form.MaintenanceCost) + parseFloat(this.form.LessAdmin) + parseFloat(this.form.Helper) + parseFloat(this.form.Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.NetTrucker = parseFloat(this.form.BillAmount) - parseFloat(tots);
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(this.form.BillAmount) - parseFloat(this.form.LessFuel) - parseFloat(this.form.MaintenanceCost) - parseFloat(this.form.LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');
    },
    signalChangeLabor: function signalChangeLabor() {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      var tots = 0;
      var tots = 0;
      tots = parseFloat(this.form.LessFuel) + parseFloat(this.form.MaintenanceCost) + parseFloat(this.form.LessAdmin) + parseFloat(this.form.Helper) + parseFloat(this.form.Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.NetTrucker = parseFloat(this.form.BillAmount) - parseFloat(tots);
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(this.form.BillAmount) - parseFloat(this.form.LessFuel) - parseFloat(this.form.MaintenanceCost) - parseFloat(this.form.LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');
    },
    signalChangeCollectedAmount: function signalChangeCollectedAmount() {
      this.form.BalanceAmount = this.form.BalanceAmountHDR - this.form.CollectedAmount;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');

      if (this.form.BalanceAmount == 0) {
        this.form.Status = "PAID";
      } //this.form.CollectedAmount = this.form.CollectedAmountHDR;

    },
    updateTitleClient: function updateTitleClient(updatedTitleClient) {
      this.form.ClientName = updatedTitleClient.LastName + ', ' + updatedTitleClient.FirstName + ' ' + updatedTitleClient.MiddleName + ' ' + updatedTitleClient.ExtName;
      this.form.ClientIDLink = updatedTitleClient.id;
      this.form.ClientLastName = updatedTitleClient.LastName;
      this.form.ClientFirstName = updatedTitleClient.FirstName;
      this.form.ClientMiddleName = updatedTitleClient.MiddleName;
      this.form.ClientExtName = updatedTitleClient.ExtName;
    },
    updateTitle: function updateTitle(updatedTitle) {
      this.form.DriverName = updatedTitle.LastName + ',' + updatedTitle.FirstName + ' ' + updatedTitle.MiddleName + ' ' + updatedTitle.ExtName;
      this.form.DriverIDLink = updatedTitle.id;
      this.form.DriverLastName = updatedTitle.LastName;
      this.form.DriverFirstName = updatedTitle.FirstName;
      this.form.DriverMiddleName = updatedTitle.MiddleName;
      this.form.DriverExtName = updatedTitle.ExtName; // console.log(updatedTitle);
    },
    updateTitleOperator: function updateTitleOperator(updatedTitleOperator) {
      this.form.TruckerName = updatedTitleOperator.LastName + ',' + updatedTitleOperator.FirstName + ' ' + updatedTitleOperator.MiddleName + ' ' + updatedTitleOperator.ExtName;
      this.form.TruckerIDLink = updatedTitleOperator.id;
      this.form.TruckerLastName = updatedTitleOperator.LastName;
      this.form.TruckerFirstName = updatedTitleOperator.FirstName;
      this.form.TruckerMiddleName = updatedTitleOperator.MiddleName;
      this.form.TruckerExtName = updatedTitleOperator.ExtName; // console.log(updatedTitle);
    },
    updateTitleVehicle: function updateTitleVehicle(updatedTitleVehicle) {
      if (this.eq == "true") {
        this.form.OVLPlateNo = updatedTitleVehicle.PlateNumber;
        this.form.OVLIDLink = updatedTitleVehicle.MVID;
        this.form.TruckerName = updatedTitleVehicle.TruckerName;
        this.form.TruckerIDLink = updatedTitleVehicle.TruckerID;
        this.form.TruckerLastName = updatedTitleVehicle.TruckerLastName;
        this.form.TruckerFirstName = updatedTitleVehicle.TruckerFirstName;
        this.form.TruckerMiddleName = updatedTitleVehicle.TruckerMiddleName;
        this.form.TruckerExtName = updatedTitleVehicle.TruckerExtName;
        this.form.DriverName = updatedTitleVehicle.DriverName;
        this.form.DriverIDLink = updatedTitleVehicle.DriverID;
        this.form.DriverLastName = updatedTitleVehicle.DriverLastName;
        this.form.DriverFirstName = updatedTitleVehicle.DriverFirstName;
        this.form.DriverMiddleName = updatedTitleVehicle.DriverMiddleName;
        this.form.DriverExtName = updatedTitleVehicle.DriverExtName; // console.log(updatedTitle);

        this.getVehicleRate();
      } else {
        this.form.SearchOVLPlateNo = updatedTitleVehicle.PlateNumber;
      }
    },
    getVehicleRate: function getVehicleRate() {
      var _this2 = this;

      axios.get('/api/getovlvehiclerate', {
        params: {
          OVLIDLink: this.form.OVLIDLink
        }
      }).then(function (response) {
        _this2.batch = response.data;
        _this2.form.PerHourRate = _this2.batch[0].PerHourRate;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        _this2.view.ViewPerHourRate = numeral(_this2.form.PerHourRate).format('0,0.00');
      })["catch"](function (err) {});
    },
    getJVLFilter: function getJVLFilter() {
      var _this3 = this;

      axios.get('/api/getjvlfilter', {
        params: {
          OVLIDLink: this.form.OVLIDLink
        }
      }).then(function (response) {
        _this3.jvlfilter = response.data; //this.form.PerHourRate=this.jvlfilter[0].BillAmount;
      })["catch"](function (err) {});
    },
    getJVCP: function getJVCP() {
      var _this4 = this;

      axios.get('/api/getovcp', {
        params: {
          OVLVLHDRID_Link: this.form.OVLVLHDRID_Link
        }
      }).then(function (_ref2) {
        var data = _ref2.data;
        _this4.JeepVehicleCollectionPayments = data;
        console.log(JeepVehicleCollectionPayments);
      })["catch"](function (err) {
        ;
      });
    },
    searchsearchVehicleFunction: function searchsearchVehicleFunction() {
      this.eq = "false";
      $('#searchVehicle').modal('show');
    },
    searchVehicleFunction: function searchVehicleFunction() {
      $('#searchVehicle').modal('show');
    },
    getVehicleIsReal: function getVehicleIsReal() {
      var _this5 = this;

      axios.get("api/vehicle").then(function (_ref3) {
        var data = _ref3.data;
        return _this5.vehicles = data;
      });
      console.log(this.vehicles);
    },
    searchOperatorFunction: function searchOperatorFunction() {
      $('#searchOperator').modal('show');
    },
    getOperatorIsReal: function getOperatorIsReal() {
      var _this6 = this;

      axios.get("api/operator").then(function (_ref4) {
        var data = _ref4.data;
        return _this6.operators = data;
      });
      console.log(this.operators);
    },
    searchDriverFunction: function searchDriverFunction() {
      $('#searchDriver').modal('show');
    },
    getDriverIsReal: function getDriverIsReal() {
      var _this7 = this;

      axios.get("api/driver").then(function (_ref5) {
        var data = _ref5.data;
        return _this7.drivers = data;
      });
      console.log(this.drivers);
    },
    searchClientFunction: function searchClientFunction() {
      $('#searchClient').modal('show');
    },
    getResults: function getResults() {
      var _this8 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/jvl?page=' + page).then(function (response) {
        _this8.jeepvehiclelog = response.data;
      });
    },
    updateJVL: function updateJVL(OVLVLHDRID) {
      console.log(this.form.Status);
      console.log(this.form.BalanceAmount);
      this.$Progress.start();
      this.form.put('api/ovl/' + this.form.OVLVLHDRID); //$('#addNew').modal('hide');

      toast.fire({
        icon: "success",
        title: "Outsider Vehicle Log successfully updated"
      });
      this.$Progress.finish();

      if (this.form.CollectedAmount !== "") {
        //KUNG HEADER RA ANG GI UPDATE
        this.form.OVLVLHDRID_Link = this.form.OVLVLHDRID;
        this.createJVCP();
      }

      this.loadJVL();
    },
    deleteModal: function deleteModal(OVLVLHDRID) {
      var _this9 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this9.$Progress.start();

          _this9.form["delete"]('api/phbvl/' + OVLVLHDRID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');
          _this9.form.OVLVLHDRID_Link = OVLVLHDRID;
          axios.get('/api/deletephbvcpdtl', {
            params: {
              OVLVLHDRID_Link: _this9.form.OVLVLHDRID_Link
            }
          }).then(function (_ref6) {
            var data = _ref6.data;
          })["catch"](function (err) {});

          _this9.$Progress.finish();

          _this9.loadJVL();
        }
      });
    },
    deleteModalJVCP: function deleteModalJVCP(jvcp) {
      var _this10 = this;

      if (this.form.BalanceAmount == 0 && this.form.Status == "PAID") {
        swal.fire({
          title: 'Ooopsie Doopsieee',
          text: "The transaction is already PAID.",
          icon: 'error',
          showCancelButton: true,
          showConfirmButton: false,
          cancelButtonColor: '#d33'
        }).then(function (result) {
          if (result.value) {}
        });
      } else {
        swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then(function (result) {
          if (result.value) {
            _this10.form.Status = "PAID";
            _this10.form.BalanceAmount = _this10.form.BalanceAmount + jvcp.CollectedAmount;

            var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

            _this10.view.ViewBalanceAmount = numeral(_this10.form.BalanceAmount).format('0,0.00');
            var collectedamount = _this10.form.BillAmount - _this10.form.BalanceAmount;
            _this10.form.CollectedAmount = collectedamount;
            console.log("Bill Amount Before Delete:" + _this10.form.BillAmount);
            console.log("Balance Amount Before Delete:" + _this10.form.BalanceAmount);
            console.log("Selected Payment Detail Collected Amount Before Delete:" + jvcp.CollectedAmount);
            console.log("Value of Collected Amount Variable" + _this10.form.CollectedAmount);
            _this10.form.ORCRNumber = jvcp.ORCRNumber;
            _this10.form.ORCRDate = jvcp.ORCRDate;
            _this10.form.Remarks = jvcp.Remarks;

            _this10.$Progress.start(); //UPDATE FIRST


            _this10.form.put('api/ovl/' + _this10.form.OVLVLHDRID); //$('#addNew').modal('hide');


            _this10.loadJVL();

            _this10.form.OVLVLHDRID_Link = _this10.form.OVLVLHDRID; //END UPDATE

            _this10.form["delete"]('api/ovcp/' + jvcp.OVLVCDTLID);

            swal.fire('Deleted!', 'Your file has been deleted.', 'success');

            _this10.getJVCP();

            _this10.getJVLBalanceAmount();

            _this10.$Progress.finish();

            _this10.form.OVLVLHDRID_Link = jvcp.OVLVLHDRID_Link;
            _this10.form.CollectedAmount = "";
            _this10.form.ORCRNumber = "";
            _this10.form.ORCRDate = "";
            _this10.form.Remarks = "";
          }
        });
      }
    },
    editModal: function editModal(jvl) {
      this.form.OVLVLHDRID_Link = jvl.OVLVLHDRID;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBillAmount = numeral(jvl.BillAmount).format('0,0.00');
      this.view.ViewNetTrucker = numeral(jvl.NetTrucker).format('0,0.00');
      this.view.ViewLessAdmin = numeral(jvl.LessAdmin).format('0,0.00');
      this.view.ViewPerHourRate = numeral(jvl.PerHourRate).format('0,0.00');
      this.view.ViewMaintenanceCost = numeral(jvl.MaintenanceCost).format('0,0.00');
      this.view.ViewSubTotalExpense = numeral(jvl.SubTotalExpense).format('0,0.00');
      this.view.ViewTotalExpense = numeral(jvl.TotalExpense).format('0,0.00');
      this.getJVCP(); //console.log(this.form.OVLVLHDRID_Link);

      this.editmode = true;
      this.form.reset();
      this.form.fill(jvl);
      $('#addNew').modal('show');
      this.form.CollectedAmount = "";
      this.form.BalanceAmount = jvl.BalanceAmount;
      this.form.BalanceAmountHDR = jvl.BalanceAmount;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
      this.form.ORCRNumber = "";
      this.form.ORCRDate = "";
      this.form.Remarks = "";
      this.form.ModeOfPayment = "";
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      this.view.reset();
      $('#addNew').modal('show');
      var today = new Date().toISOString().slice(0, 10);
      this.form.OVLVLDate = today;
      this.form.LessFuel = 0;
      this.form.LessAdmin = 0;
      this.form.MaintenanceCost = 0;
      this.form.Helper = 0;
      this.form.Labor = 0;
      this.form.FuelLiters = 0;
    },
    closeModalMultiple: function closeModalMultiple() {
      location.reload();
      $('#addNewMultiple').modal('hide');
    },
    newModalMultiple: function newModalMultiple() {
      var _this11 = this;

      this.var1 = 0;
      this.first = 0;
      var i = 0;
      this.form.OVLVLHDRID = this.checkedNames;
      this.$Progress.start();

      if (this.checkedNames == "") {
        this.$Progress.fail();
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'No Transaction Selected.'
        });
      } else {
        axios.get('/api/getovlvlfilter', {
          params: {
            OVLVLHDRID: this.checkedNames
          }
        }).then(function (response) {
          _this11.jvlfilter = response.data;

          for (i = 0; i < _this11.jvlfilter.length; i++) {
            if (_this11.jvlfilter[i].BillAmount != _this11.jvlfilter[0].BillAmount) {
              _this11.$Progress.fail();

              swal.fire({
                title: 'Ooopsie Doopsieee',
                text: "The transactions that you have selected are not uniform in Bill Amount. Please review.",
                icon: 'error',
                showCancelButton: true,
                showConfirmButton: false,
                cancelButtonColor: '#d33'
              }).then(function (result) {
                if (result.value) {} else {
                  $('#addNewMultiple').modal('hide');
                }
              });
              break;
            } else {
              _this11.editmode = false;

              _this11.form.reset();

              _this11.form.BillAmount = _this11.jvlfilter[0].BillAmount;
              _this11.form.BalanceAmount = _this11.jvlfilter[0].BalanceAmount;
              _this11.form.BalanceAmountHDR = _this11.jvlfilter[0].BalanceAmount;

              var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

              _this11.view.ViewBalanceAmount = numeral(_this11.form.BalanceAmount).format('0,0.00'); //this.form.CollectedAmount = this.jvlfilter[0].CollectedAmount;
              //this.form.BalanceAmount = this.form.BillAmount - this.form.CollectedAmount;

              $('#addNewMultiple').modal('show');
            }
          }
        }); //END AXIOS

        this.$Progress.finish();
      }
    },
    doSomething: function doSomething(data) {
      console.log(data);
    },
    loadJVL: function loadJVL() {
      var _this12 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getovl').then(function (response) {
        _this12.jvls = response.data;
        _this12.rowData = response.data;
        console.log(_this12.jvls);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    loadOVLDTL: function loadOVLDTL() {
      var _this13 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getovldtl', {
        params: {
          OVLVLHDRID_Link: this.detail.OVLVLHDRID_Link
        }
      }).then(function (response) {
        _this13.OVLDTLDetails = response.data;
        console.log(_this13.OVLDTLDetails);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    loadJVCP: function loadJVCP() {
      var _this14 = this;

      axios.get("api/jvcp").then(function (_ref7) {
        var data = _ref7.data;
        return _this14.jvcps = data;
      });
    },
    createJVL: function createJVL() {
      var _this15 = this;

      this.$Progress.start();
      this.form.post("api/ovl").then(function () {
        //$('#addNew').modal('hide');
        //$('.modal-backdrop').remove();
        _this15.form.reset();

        _this15.view.reset();

        var today = new Date().toISOString().slice(0, 10);
        _this15.form.OVLVLDate = today;
        toast.fire({
          icon: "success",
          title: "Outsider Vehicle Log successfully created"
        });

        _this15.$Progress.finish();

        _this15.loadJVL();

        _this15.form.LessFuel = 0;
        _this15.form.FuelLiters = 0;
        _this15.form.MaintenanceCost = 0;
        _this15.form.LessAdmin = 0;
        _this15.form.Helper = 0;
        _this15.form.Labor = 0;
      })["catch"](function () {
        _this15.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Outsider Vehicle Log not added successfully'
        });
      });
    },
    createOVLDetails: function createOVLDetails() {
      var _this16 = this;

      this.$Progress.start();
      axios.get('api/insertovldtl', {
        params: {
          OVLVLHDRID_Link: this.detail.OVLVLHDRID_Link,
          LoadingAssignment: this.detail.LoadingAssignment,
          LoadingFLDLOG: this.detail.LoadingFLDLOG,
          LoadingTimeIn: this.detail.LoadingTimeIn,
          LoadingTimeStart: this.detail.LoadingTimeStart,
          LoadingTimeEnd: this.detail.LoadingTimeEnd,
          LoadingRemarks: this.detail.LoadingRemarks,
          LoadingLoadFill: this.detail.LoadingLoadFill,
          LoadingHiredOperatorHour: this.detail.LoadingHiredOperatorHour,
          LoadingJobCode: this.detail.LoadingJobCode,
          LoadingNoOfLoad: this.detail.LoadingNoOfLoad,
          UnLoadingAssignment: this.detail.UnLoadingAssignment,
          UnLoadingFLDLOG: this.detail.UnLoadingFLDLOG,
          UnLoadingTimeIn: this.detail.UnLoadingTimeIn,
          UnLoadingTimeStart: this.detail.UnLoadingTimeStart,
          UnLoadingTimeEnd: this.detail.UnLoadingTimeEnd,
          UnLoadingRemarks: this.detail.UnLoadingRemarks,
          UnLoadingLoadFill: this.detail.UnLoadingLoadFill,
          UnLoadingHiredOperatorHour: this.detail.UnLoadingHiredOperatorHour,
          UnLoadingJobCode: this.detail.UnLoadingJobCode,
          UnLoadingNoOfLoad: this.detail.UnLoadingNoOfLoad
        }
      }).then(function (response) {
        toast.fire({
          icon: "success",
          title: "OVL Detail successfully created"
        });

        _this16.$Progress.finish();

        _this16.loadOVLDTL();
      })["catch"](function (error) {
        this.$Progress.fail();
        toast.fire({
          icon: 'error',
          title: 'OVL Detail not added successfully'
        });
      });
    },
    createJVCP: function createJVCP() {
      var _this17 = this;

      this.form.post("api/ovcp").then(function () {
        toast.fire({
          icon: "success",
          title: "Outsider Vehicle Log successfully created"
        });

        _this17.getJVCP();

        _this17.form.CollectedAmount = ""; //this.form.BalanceAmount=0;

        _this17.form.ORCRNumber = "";
        _this17.form.ORCRDate = "";
        _this17.form.Remarks = "";

        _this17.getJVLBalanceAmount();
      })["catch"](function () {
        _this17.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Outsider Vehicle Collection Payment not added successfully'
        });
      });
    },
    getJVLBalanceAmount: function getJVLBalanceAmount() {
      var _this18 = this;

      axios.get('/api/getovlvlbalanceamount', {
        params: {
          OVLVLHDRID: this.form.OVLVLHDRID
        }
      }).then(function (response) {
        _this18.jvlbalamt = response.data;
        _this18.form.BalanceAmountHDR = _this18.jvlbalamt[0].BalanceAmount;
        console.log(_this18.jvlbalamt[0].BalanceAmount);
      })["catch"](function (err) {});
    },
    deleteEntirePaymentDetail: function deleteEntirePaymentDetail() {
      this.form["delete"]('api/ovldeleteentirepaymentdetail/' + this.form.OVLVLHDRID);
      swal.fire('Deleted!', 'Your file has been deleted.', 'success');
      this.form.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      this.JeepVehicleCollectionPayments = [];
      this.getJVCP();
    },
    deleteModalOVLDTL: function deleteModalOVLDTL(OVLDTL) {
      this.detail.OVLVLDTLID = OVLDTL.OVLVLDTLID;
      axios.get('/api/deleteovldtl', {
        params: {
          OVLVLDTLID: this.detail.OVLVLDTLID
        }
      }).then(function (_ref8) {
        var data = _ref8.data;
        swal.fire('Deleted!', 'Your file has been deleted.', 'success');
      })["catch"](function (err) {});
      this.loadOVLDTL();
    },
    createJVCPMultiple: function createJVCPMultiple() {
      var _this19 = this;

      if (this.form.BalanceAmount == 0) {
        this.form.Status = "PAID";
      } else {
        this.form.Status = "POSTED";
      }

      this.editmode = false;
      swal.fire({
        title: 'Are you sure you watn to save?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, save it!'
      }).then(function (result) {
        if (result.value) {
          _this19.$Progress.start(); ////console.log(this.checkedNames);


          var arr = 0;

          for (var i = 0; i < _this19.checkedNames.length; i++) {
            arr = i;
            console.log(_this19.checkedNames.length);
            _this19.form.OVLVLHDRID_Link = _this19.checkedNames[i]; //console.log(this.form.OVLVLHDRID_Link);
            //UPDATE VEHICLE LOG HDR

            _this19.form.put('api/ovlvlovlvcp/' + _this19.checkedNames[i]);

            $('#addNewMultiple').modal('hide'); //END UPDATE
            //CREATE INSERT TO JEEP VEHICLE COLLECTION PAYMENT

            _this19.form.post("api/ovcp").then(function () {
              //toast.fire({
              //   icon: "success",
              //  title: "Transaction done."
              //}); 
              swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 1500
              });
            }); //END CREATE 

          }

          _this19.$Progress.finish(); //location.reload();


          _this19.loadJVL();

          _this19.checkedNames = [];
          _this19.allSelected = false;
        }
      });
    } // getSelectedRows(){
    //   const selectedNodes = this.gridApi.getSelectedNodes();
    //   const selectedData = selectedNodes.map(node => node.data);
    //   this.checkedNames= selectedData.map(node => node.OVLVLHDRID).join();
    // },
    // onGridReady(params){
    //   this.gridApi = params.api;
    //   this.columnApi = params.columnApi;
    // },
    // onRowSelected(event) {
    //         const selectedNodes = this.gridApi.getSelectedNodes();
    //   const selectedData = selectedNodes.map(node => node.data);
    //   this.checkedNames= selectedData.map(node => node.OVLVLHDRID).join();
    //     },

  },
  created: function created() {
    this.loadJVL(); //setInterval(() => this.loadDriver(),3000);
  },
  // beforeMount() {
  //     this.columnDefs = [
  //         {headerName: 'ID', field: 'OVLVLHDRID',checkboxSelection: true},
  //         {headerName: 'Date', field: 'OVLVLDate'},
  //         {headerName: 'VL No.', field: 'OVLNo'},
  //         {headerName: 'Plate No.', field: 'OVLPlateNo',filter:true},
  //         {headerName: 'Driver', field: 'DriverName',filter:true},
  //         {headerName: 'Billable Amt.', field: 'BillAmount'},
  //         {headerName: 'Less Admin', field: 'LessAdmin'},
  //         {headerName: 'Less Fuel', field: 'LessFuel'},
  //         {headerName: 'Net Operator', field: 'NetTrucker'},
  //         {headerName: 'Status', field: 'Status'},
  //         {headerName: 'SOA No.', field: 'SOANumber'},
  //         {headerName: 'SOA Date', field: 'SOADate'}
  //     ];
  //     // fetch('https://api.myjson.com/bins/15psn9')
  //     //   .then(result => result.json())
  //     //   .then(rowData => this.rowData = rowData);
  //     // this.rowData = this.jvls;
  //     // this.rowData = [
  //     //      {OVLVLDate: this.jvls.OVLVLDate, OVLNo: this.jvls.OVLNo, OVLPlateNo: this.jvls.OVLNo,DriverName: this.jvls.DriverName,BillAmount: this.jvls.BillAmount,LessAdmin: this.jvls.LessAdmin,LessFuel: this.jvls.LessFuel,NetTrucker: this.jvls.NetTrucker,Status: this.jvls.Status,SOANumber: this.jvls.SOANumber,SOADate: this.jvls.SOADate}
  //     // ];
  // },
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this20 = this;

      if (this.DateFrom !== "" || this.DateTo !== "" && this.SearchOVLPlateNo !== "") {
        this.SearchOVLPlateNo = "";
        var vm = this;
        var startdate = vm.DateFrom;
        var enddate = vm.DateTo;
        return _.filter(vm.jvls, function (data) {
          if (_.isNull(startdate) && _.isNull(enddate)) {
            return true;
          } else {
            var date = data.OVLVLDate;
            return date >= startdate && date <= enddate;
          }
        });
      } else {
        this.DateFrom = "";
        this.DateTo = ""; //return this.jvls.filter(jvl =>{
        //return jvl.OVLPlateNo.includes(this.form.OVLPlateNo)
        //});

        return this.jvls.filter(function (samsung) {
          return _this20.SearchOVLPlateNo.toLowerCase().split(' ').every(function (v) {
            return samsung.OVLPlateNo.toLowerCase().includes(v);
          });
        });
      }
=======


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'ovl-menu': _OVLMenu_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      form: new Form({
        DateFrom: new Date().toISOString().slice(0, 10),
        DateTo: new Date().toISOString().slice(0, 10),
        DriverName: '',
        DriverID: ''
      }),
      list: []
    };
  },
  methods: {
    updateDriver: function updateDriver(updatedTitle) {
      var LastName = updatedTitle.LastName ? updatedTitle.LastName + ' ' : '';
      var FirstName = updatedTitle.FirstName ? updatedTitle.FirstName + ' ' : '';
      var MiddleName = updatedTitle.MiddleName ? updatedTitle.MiddleName + ' ' : '';
      var ExtName = updatedTitle.ExtName ? updatedTitle.ExtName : '';
      this.form.DriverName = LastName + FirstName + MiddleName + ExtName;
      this.form.DriverID = updatedTitle.id;
    },
    searchDriverFunction: function searchDriverFunction() {
      Fire.$emit('searchDriver', 'OVL');
    },
    getPayroll: function getPayroll() {
      var _this = this;

      if (!this.form.DriverName) {
        return toast.fire({
          icon: 'warning',
          title: 'Select Driver'
        });
      }

      this.form.post('api/getOVLPayroll').then(function (response) {
        _this.list = response.data;
      });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    }
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n  pointer-events: none;\n}\r\n\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& ***!
  \***************************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=template&id=92a30524&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=template&id=92a30524& ***!
  \******************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container", attrs: { id: "sweget" } },
    [
      _c(
        "div",
        { staticClass: "col-xs-12" },
        [
<<<<<<< HEAD
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNavDropdown" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#mlist"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Master File\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "mlist"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/driverlist" }
                            },
                            [_c("a", [_vm._v("Driver List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/ovlvehiclelist" }
                            },
                            [_c("a", [_vm._v("OVL Vehicle List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehicletype" }
                            },
                            [_c("a", [_vm._v("Vehicle Type List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/ovlvehiclerate" }
                            },
                            [_c("a", [_vm._v("OVL Rate List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/clientlist" }
                            },
                            [_c("a", [_vm._v("Client List")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#trans"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Transactions\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "trans"
                      }
                    },
                    [
=======
          _c("ovl-menu"),
          _vm._v(" "),
          _c("div", { staticClass: "card" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.getPayroll()
                    }
                  }
                },
                [
                  _c("div", { staticClass: "row" }, [
                    _c("div", { staticClass: "col" }, [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                      _c(
                        "div",
                        { staticClass: "input-group mb-3 input-group-sm" },
                        [
<<<<<<< HEAD
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/ovlvehiclelogentry" }
                            },
                            [_c("a", [_vm._v("OVL Vehicle Log Entry")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/createovlsoa" }
                            },
                            [_c("a", [_vm._v("OVL Create SOA")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/soaovltransactions" }
                            },
                            [_c("a", [_vm._v("OVL SOA Transactions")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#report"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              OVL Reports\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "report"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistovl" }
                            },
                            [_c("a", [_vm._v("Standard OVL Report")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ])
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c(
              "form",
              {
                staticStyle: {
                  "border-style": "solid",
                  "border-color": "coral"
                }
              },
              [
                _c("div", { staticClass: "form-inline" }, [
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(1),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateFrom,
                            expression: "DateFrom"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateFrom" },
                        domProps: { value: _vm.DateFrom },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateFrom = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(2),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateTo,
                            expression: "DateTo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateTo" },
                        domProps: { value: _vm.DateTo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateTo = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              _vm.filterKey = "all"
                            }
                          }
                        },
                        [_vm._v("Search")]
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-left": "5px",
                        "margin-top": "10px"
                      }
                    },
                    [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.SearchOVLPlateNo,
                            expression: "SearchOVLPlateNo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "SearchOVLPlateNo",
                          placeholder: "OVL Plate Number"
                        },
                        domProps: { value: _vm.SearchOVLPlateNo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.SearchOVLPlateNo = $event.target.value
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-primary", size: "sm" },
                              on: {
                                click: function($event) {
                                  return _vm.searchsearchVehicleFunction()
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-search",
                                attrs: { "aria-hidden": "true" }
                              })
                            ]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }),
            _vm._v(" "),
            _c("br")
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _c("thead", [
                  _c("tr", [
                    _c("th", [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.allSelected,
                            expression: "allSelected"
                          }
                        ],
                        attrs: { type: "checkbox" },
                        domProps: {
                          checked: Array.isArray(_vm.allSelected)
                            ? _vm._i(_vm.allSelected, null) > -1
                            : _vm.allSelected
                        },
                        on: {
                          click: _vm.selectAll,
                          change: function($event) {
                            var $$a = _vm.allSelected,
                              $$el = $event.target,
                              $$c = $$el.checked ? true : false
                            if (Array.isArray($$a)) {
                              var $$v = null,
                                $$i = _vm._i($$a, $$v)
                              if ($$el.checked) {
                                $$i < 0 && (_vm.allSelected = $$a.concat([$$v]))
                              } else {
                                $$i > -1 &&
                                  (_vm.allSelected = $$a
                                    .slice(0, $$i)
                                    .concat($$a.slice($$i + 1)))
                              }
                            } else {
                              _vm.allSelected = $$c
                            }
                          }
                        }
                      })
                    ]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Date")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("VL No")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Plate No")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Driver")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Billable Amt")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Less Admin")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Less Fuel")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Net Operator")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Status")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("SOA No")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("SOA Date")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Charge Invoice No")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Modify")])
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.filteredBlogs, function(jvl) {
                    return _c("tr", { key: jvl.OVLVLHDRID }, [
                      _c("td", [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.checkedNames,
                              expression: "checkedNames"
                            }
                          ],
                          attrs: { type: "checkbox" },
                          domProps: {
                            value: jvl.OVLVLHDRID,
                            checked: Array.isArray(_vm.checkedNames)
                              ? _vm._i(_vm.checkedNames, jvl.OVLVLHDRID) > -1
                              : _vm.checkedNames
                          },
                          on: {
                            change: function($event) {
                              var $$a = _vm.checkedNames,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = jvl.OVLVLHDRID,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    (_vm.checkedNames = $$a.concat([$$v]))
                                } else {
                                  $$i > -1 &&
                                    (_vm.checkedNames = $$a
                                      .slice(0, $$i)
                                      .concat($$a.slice($$i + 1)))
                                }
                              } else {
                                _vm.checkedNames = $$c
                              }
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLVLDate))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLPlateNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.DriverName))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(
                            "Php" +
                              jvl.BillAmount.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.LessAdmin))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.LessFuel))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(
                            "Php" +
                              jvl.NetTrucker.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.Status))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.SOANumber))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.SOADate))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.ChargeInvoiceNumber))]),
                      _vm._v(" "),
                      _c("td", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.editModal(jvl)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-edit" })]
                        ),
                        _vm._v("\n                /\n                "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.deleteModal(jvl.OVLVLHDRID)
                              }
                            }
                          },
                          [
                            _c("i", {
                              staticClass: "fa fa-trash",
                              staticStyle: { color: "red" }
                            })
                          ]
                        )
                      ])
                    ])
                  }),
                  0
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-warning",
                on: { click: _vm.newModalMultiple }
              },
              [
                _vm._v(
                  "\n            Add New Multiple OVL Collection Payment\n            "
                ),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            ),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "btn btn-success", on: { click: _vm.newModal } },
              [
                _vm._v("\n            Add New OVL\n            "),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            ),
            _vm._v(" "),
            _c("div", { staticStyle: { float: "right" } }, [
              _vm._v("Total SOA Amount : " + _vm._s(_vm.form.TotalAmount))
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Outsider Vehicle Log")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Outsider Vehicle Log's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(3)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode ? _vm.updateJVL() : _vm.createJVL()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(4),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLVLDate,
                                        expression: "form.OVLVLDate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      id: "OVLVLDate",
                                      type: "date",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.OVLVLDate },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLVLDate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLVLHDRID,
                                        expression: "form.OVLVLHDRID"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "hidden" },
                                    domProps: { value: _vm.form.OVLVLHDRID },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLVLHDRID",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(5),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLNo,
                                        expression: "form.OVLNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "OVLNo" },
                                    domProps: { value: _vm.form.OVLNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLPlateNo,
                                        expression: "form.OVLPlateNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "OVLPlateNo",
                                      placeholder: "Vehicle Plate Number",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.OVLPlateNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLPlateNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLIDLink,
                                        expression: "form.OVLIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "OVLIDLink",
                                      placeholder: "OVLIDLink"
                                    },
                                    domProps: { value: _vm.form.OVLIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchVehicleFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverName,
                                        expression: "form.DriverName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "DriverName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "DriverName",
                                      placeholder: "Driver Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.DriverName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverLastName,
                                        expression: "form.DriverLastName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverLastName",
                                      placeholder: "DriverLastName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverLastName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverLastName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverFirstName,
                                        expression: "form.DriverFirstName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverFirstName",
                                      placeholder: "DriverFirstName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverFirstName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverFirstName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverMiddleName,
                                        expression: "form.DriverMiddleName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverMiddleName",
                                      placeholder: "DriverMiddleName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverMiddleName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverMiddleName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverExtName,
                                        expression: "form.DriverExtName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverExtName",
                                      placeholder: "DriverExtName"
                                    },
                                    domProps: { value: _vm.form.DriverExtName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverExtName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverIDLink,
                                        expression: "form.DriverIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverIDLink",
                                      placeholder: "DriverIDLink"
                                    },
                                    domProps: { value: _vm.form.DriverIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchDriverFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientName,
                                        expression: "form.ClientName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "DriverName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "ClientName",
                                      placeholder: "Client Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.ClientName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientLastName,
                                        expression: "form.ClientLastName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientLastName",
                                      placeholder: "ClientLastName"
                                    },
                                    domProps: {
                                      value: _vm.form.ClientLastName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientLastName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientFirstName,
                                        expression: "form.ClientFirstName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientFirstName",
                                      placeholder: "ClientFirstName"
                                    },
                                    domProps: {
                                      value: _vm.form.ClientFirstName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientFirstName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientMiddleName,
                                        expression: "form.ClientMiddleName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientMiddleName",
                                      placeholder: "ClientMiddleName"
                                    },
                                    domProps: {
                                      value: _vm.form.ClientMiddleName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientMiddleName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientExtName,
                                        expression: "form.ClientExtName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientExtName",
                                      placeholder: "ClientExtName"
                                    },
                                    domProps: { value: _vm.form.ClientExtName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientExtName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientIDLink,
                                        expression: "form.ClientIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientIDLink",
                                      placeholder: "ClientIDLink"
                                    },
                                    domProps: { value: _vm.form.ClientIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchClientFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(6),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.GLCode,
                                        expression: "form.GLCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "GLCode" },
                                    domProps: { value: _vm.form.GLCode },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "GLCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(7),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CostCenter,
                                        expression: "form.CostCenter"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "CostCenter" },
                                    domProps: { value: _vm.form.CostCenter },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "CostCenter",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(8),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewPerHourRate,
                                        expression: "view.ViewPerHourRate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PerHourRate"
                                    },
                                    domProps: {
                                      value: _vm.view.ViewPerHourRate
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewPerHourRate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(9),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.startreading,
                                        expression: "form.startreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "time",
                                      name: "startreading",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.startreading },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "startreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangestartreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(10),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.endreading,
                                        expression: "form.endreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "time",
                                      name: "endreading",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.endreading },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "endreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeendreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(11),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.NumberOfHours,
                                        expression: "form.NumberOfHours"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "number",
                                      name: "NumberOfHours",
                                      "data-readonly": ""
                                    },
                                    domProps: { value: _vm.form.NumberOfHours },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "NumberOfHours",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(12),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewBillAmount,
                                        expression: "view.ViewBillAmount"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "ViewBillAmount",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewBillAmount
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewBillAmount",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("EXPENSES")])])],
                              1
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(13),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.FuelLiters,
                                        expression: "form.FuelLiters"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A5" },
                                    attrs: { type: "text", name: "FuelLiters" },
                                    domProps: { value: _vm.form.FuelLiters },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "FuelLiters",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(14),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LessFuel,
                                        expression: "form.LessFuel"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A5" },
                                    attrs: {
                                      step: "0.01",
                                      type: "number",
                                      name: "LessFuel"
                                    },
                                    domProps: { value: _vm.form.LessFuel },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "LessFuel",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeLessFuel()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(15),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewMaintenanceCost,
                                        expression: "view.ViewMaintenanceCost"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A5" },
                                    attrs: {
                                      type: "text",
                                      name: "ViewLessAdmin",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewMaintenanceCost
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewMaintenanceCost",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(16),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LessAdmin,
                                        expression: "form.LessAdmin"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A5" },
                                    attrs: {
                                      type: "text",
                                      name: "ViewLessAdmin",
                                      "data-readonly": ""
                                    },
                                    domProps: { value: _vm.form.LessAdmin },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LessAdmin",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(17),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Helper,
                                        expression: "form.Helper"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A5" },
                                    attrs: {
                                      step: "0.01",
                                      type: "number",
                                      name: "Helper"
                                    },
                                    domProps: { value: _vm.form.Helper },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "Helper",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeHelper()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(18),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Labor,
                                        expression: "form.Labor"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A5" },
                                    attrs: {
                                      step: "0.01",
                                      type: "number",
                                      name: "Labor"
                                    },
                                    domProps: { value: _vm.form.Labor },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "Labor",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeLabor()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("TOTAL")])])],
                              1
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(19),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewSubTotalExpense,
                                        expression: "view.ViewSubTotalExpense"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C9" },
                                    attrs: {
                                      type: "text",
                                      name: "TotalExpense",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewSubTotalExpense
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewSubTotalExpense",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(20),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewTotalExpense,
                                        expression: "view.ViewTotalExpense"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C9" },
                                    attrs: {
                                      type: "text",
                                      name: "TotalExpense",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewTotalExpense
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewTotalExpense",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(21),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewNetTrucker,
                                        expression: "view.ViewNetTrucker"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C9" },
                                    attrs: {
                                      type: "text",
                                      name: "ViewNetTrucker",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewNetTrucker
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewNetTrucker",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: _vm.editmode,
                                expression: "editmode"
                              }
                            ],
                            staticClass: "col-xs-12",
                            staticStyle: {
                              "border-style": "solid",
                              "border-color": "coral"
                            }
                          },
                          [
                            _c("div", { staticClass: "row" }, [
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(22),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.CollectedAmount,
                                            expression: "form.CollectedAmount"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "CollectedAmount"
                                        },
                                        domProps: {
                                          value: _vm.form.CollectedAmount
                                        },
                                        on: {
                                          input: [
                                            function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.form,
                                                "CollectedAmount",
                                                $event.target.value
                                              )
                                            },
                                            function($event) {
                                              return _vm.signalChangeCollectedAmount()
                                            }
                                          ]
                                        }
                                      })
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(23),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.view.ViewBalanceAmount,
                                            expression: "view.ViewBalanceAmount"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "BalanceAmount",
                                          "data-readonly": ""
                                        },
                                        domProps: {
                                          value: _vm.view.ViewBalanceAmount
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.view,
                                              "ViewBalanceAmount",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(24),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.ORCRNumber,
                                            expression: "form.ORCRNumber"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "ORCRNumber"
                                        },
                                        domProps: {
                                          value: _vm.form.ORCRNumber
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.form,
                                              "ORCRNumber",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(25),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.ORCRDate,
                                            expression: "form.ORCRDate"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          id: "date",
                                          type: "date",
                                          name: "ORCRDate"
                                        },
                                        domProps: { value: _vm.form.ORCRDate },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.form,
                                              "ORCRDate",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "row" }, [
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(26),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.ModeOfPayment,
                                            expression: "form.ModeOfPayment"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        staticStyle: {
                                          "text-transform": "uppercase"
                                        },
                                        attrs: {
                                          type: "text",
                                          name: "ModeOfPayment"
                                        },
                                        domProps: {
                                          value: _vm.form.ModeOfPayment
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.form,
                                              "ModeOfPayment",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(27),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.CheckNumber,
                                            expression: "form.CheckNumber"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "CheckNumber"
                                        },
                                        domProps: {
                                          value: _vm.form.CheckNumber
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.form,
                                              "CheckNumber",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(28),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.CheckDate,
                                            expression: "form.CheckDate"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          id: "date",
                                          type: "date",
                                          name: "CheckDate"
                                        },
                                        domProps: { value: _vm.form.CheckDate },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.form,
                                              "CheckDate",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.editmode,
                                      expression: "editmode"
                                    }
                                  ],
                                  staticClass: "col"
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "input-group mb-3 input-group-sm"
                                    },
                                    [
                                      _vm._m(29),
                                      _vm._v(" "),
                                      _c("textarea", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.form.Remarks,
                                            expression: "form.Remarks"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Remarks"
                                        },
                                        domProps: { value: _vm.form.Remarks },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.form,
                                              "Remarks",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ]
                                  )
                                ]
                              )
                            ])
                          ]
                        ),
                        _vm._v(" "),
                        _c("div", { staticClass: "pre-scrollable" }, [
                          _c(
                            "table",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.editmode,
                                  expression: "editmode"
                                }
                              ],
                              staticClass: "table table-hover"
                            },
                            [
                              _c(
                                "tbody",
                                [
                                  _vm._m(30),
                                  _vm._v(" "),
                                  _vm._l(
                                    _vm.JeepVehicleCollectionPayments,
                                    function(jvcp) {
                                      return _c(
                                        "tr",
                                        { key: jvcp.OVLVCDTLID },
                                        [
                                          _c("td", [
                                            _vm._v(
                                              _vm._s(
                                                "Php" +
                                                  jvcp.CollectedAmount.toLocaleString(
                                                    undefined,
                                                    {
                                                      maximumFractionDigits: 2,
                                                      minimumFractionDigits: 2
                                                    }
                                                  )
                                              )
                                            )
                                          ]),
                                          _vm._v(" "),
                                          _c("td", [
                                            _vm._v(
                                              _vm._s(
                                                _vm._f("formatDate")(
                                                  jvcp.ORCRDate
                                                )
                                              )
                                            )
                                          ]),
                                          _vm._v(" "),
                                          _c("td", [
                                            _vm._v(_vm._s(jvcp.ORCRNumber))
                                          ]),
                                          _vm._v(" "),
                                          _c("td", [
                                            _c(
                                              "a",
                                              {
                                                attrs: { href: "#" },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.deleteModalJVCP(
                                                      jvcp
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-trash",
                                                  staticStyle: { color: "red" }
                                                })
                                              ]
                                            )
                                          ])
                                        ]
                                      )
                                    }
                                  )
                                ],
                                2
                              )
                            ]
                          )
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: { click: _vm.InsertDetails }
                        },
                        [_vm._v("Add PHB Details")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-warning",
                          attrs: { type: "button" },
                          on: { click: _vm.SetToUnpaid }
                        },
                        [_vm._v("Set to Unpaid")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNewMultiple",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Multiple Oustider Vehicle Log")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Multiple Outsider Vehicle Log's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(31)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode
                          ? _vm.updateJVL()
                          : _vm.createJVCPMultiple()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body" }, [
                      _c(
                        "div",
                        {
                          staticClass: "col-xs-12",
                          staticStyle: {
                            "border-style": "solid",
                            "border-color": "coral"
                          }
                        },
                        [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(32),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CollectedAmount,
                                        expression: "form.CollectedAmount"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "CollectedAmount"
                                    },
                                    domProps: {
                                      value: _vm.form.CollectedAmount
                                    },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "CollectedAmount",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeCollectedAmount()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: _vm.editmode,
                                    expression: "editmode"
                                  }
                                ],
                                staticClass: "col"
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "input-group mb-3 input-group-sm"
                                  },
                                  [
                                    _vm._m(33),
                                    _vm._v(" "),
                                    _c("input", {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: _vm.view.ViewBalanceAmount,
                                          expression: "view.ViewBalanceAmount"
                                        }
                                      ],
                                      staticClass: "form-control",
                                      attrs: {
                                        type: "text",
                                        name: "BalanceAmount",
                                        "data-readonly": ""
                                      },
                                      domProps: {
                                        value: _vm.view.ViewBalanceAmount
                                      },
                                      on: {
                                        input: function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.view,
                                            "ViewBalanceAmount",
                                            $event.target.value
                                          )
                                        }
                                      }
                                    })
                                  ]
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(34),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ORCRNumber,
                                        expression: "form.ORCRNumber"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "ORCRNumber" },
                                    domProps: { value: _vm.form.ORCRNumber },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ORCRNumber",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(35),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ORCRDate,
                                        expression: "form.ORCRDate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      id: "date",
                                      type: "date",
                                      name: "ORCRDate"
                                    },
                                    domProps: { value: _vm.form.ORCRDate },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ORCRDate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(36),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ModeOfPayment,
                                        expression: "form.ModeOfPayment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: {
                                      "text-transform": "uppercase"
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "ModeOfPayment"
                                    },
                                    domProps: { value: _vm.form.ModeOfPayment },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ModeOfPayment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(37),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CheckNumber,
                                        expression: "form.CheckNumber"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "CheckNumber"
                                    },
                                    domProps: { value: _vm.form.CheckNumber },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "CheckNumber",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(38),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CheckDate,
                                        expression: "form.CheckDate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      id: "date",
                                      type: "date",
                                      name: "CheckDate"
                                    },
                                    domProps: { value: _vm.form.CheckDate },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "CheckDate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(39),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Remarks,
                                        expression: "form.Remarks"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "Remarks" },
                                    domProps: { value: _vm.form.Remarks },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Remarks",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addOVLDetails",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add OVL Details")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update OVL Details")]
                  ),
                  _vm._v(" "),
                  _vm._m(40)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        !_vm.editmode ? _vm.updateJVL() : _vm.createOVLDetails()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "pre-scrollable",
                                  staticStyle: { height: "200px" }
                                },
                                [
                                  _c(
                                    "table",
                                    {
                                      directives: [
                                        {
                                          name: "show",
                                          rawName: "v-show",
                                          value: _vm.editmode,
                                          expression: "editmode"
                                        }
                                      ],
                                      staticClass: "table table-hover"
                                    },
                                    [
                                      _c("thead", [
                                        _c("tr", [
                                          _c(
                                            "th",
                                            {
                                              staticStyle: {
                                                "border-color": "#E985A9"
                                              },
                                              attrs: { colspan: "10" }
                                            },
                                            [_c("center", [_vm._v("LOADING")])],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "th",
                                            {
                                              staticStyle: {
                                                "border-color": "#85E9C5"
                                              },
                                              attrs: { colspan: "10" }
                                            },
                                            [
                                              _c("center", [
                                                _vm._v("UNLOADING")
                                              ])
                                            ],
                                            1
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _vm._m(41)
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "tbody",
                                        _vm._l(_vm.OVLDTLDetails, function(
                                          OVLDTL
                                        ) {
                                          return _c(
                                            "tr",
                                            { key: OVLDTL.OVLVLDTLID },
                                            [
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingAssignment
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(OVLDTL.LoadingFLDLOG)
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(OVLDTL.LoadingTimeIn)
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingTimeStart
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingTimeEnd
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingRemarks
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingLoadFill
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingHiredOperatorHour
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingJobCode
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingNoOfLoad
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingAssignment
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingFLDLOG
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingTimeIn
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingTimeStart
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingTimeEnd
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingRemarks
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingLoadFill
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingHiredOperatorHour
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingJobCode
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingNoOfLoad
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c("td", [
                                                _c(
                                                  "a",
                                                  {
                                                    attrs: { href: "#" },
                                                    on: {
                                                      click: function($event) {
                                                        return _vm.deleteModalOVLDTL(
                                                          OVLDTL
                                                        )
                                                      }
                                                    }
                                                  },
                                                  [
                                                    _c("i", {
                                                      staticClass:
                                                        "fa fa-trash",
                                                      staticStyle: {
                                                        color: "red"
                                                      }
                                                    })
                                                  ]
                                                )
                                              ])
                                            ]
                                          )
                                        }),
                                        0
                                      )
                                    ]
                                  )
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(42),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.PHBVLHDRID_Link,
                                        expression: "detail.PHBVLHDRID_Link"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "PHBVLHDRID_Link"
                                    },
                                    domProps: {
                                      value: _vm.detail.PHBVLHDRID_Link
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "PHBVLHDRID_Link",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("LOADING")])])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("UNLOADING")])])],
                              1
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(43),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingAssignment,
                                        expression: "detail.LoadingAssignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingAssignment"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingAssignment
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingAssignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(44),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingAssignment,
                                        expression: "detail.UnLoadingAssignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingAssignment"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingAssignment
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingAssignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(45),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingFLDLOG,
                                        expression: "detail.LoadingFLDLOG"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingFLDLOG"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingFLDLOG
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingFLDLOG",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(46),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingFLDLOG,
                                        expression: "detail.UnLoadingFLDLOG"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingFLDLOG"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingFLDLOG
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingFLDLOG",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(47),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeIn,
                                        expression: "detail.LoadingTimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingLocationName"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeIn
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(48),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeIn,
                                        expression: "detail.UnLoadingTimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeIn"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeIn
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(49),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeStart,
                                        expression: "detail.LoadingTimeStart"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingTimeStart"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeStart
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeStart",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(50),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeStart,
                                        expression: "detail.UnLoadingTimeStart"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeStart"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeStart
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeStart",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(51),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeEnd,
                                        expression: "detail.LoadingTimeEnd"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingTimeEnd"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeEnd
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeEnd",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(52),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeEnd,
                                        expression: "detail.UnLoadingTimeEnd"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeEnd"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeEnd
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeEnd",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(53),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingRemarks,
                                        expression: "detail.LoadingRemarks"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingRemarks"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingRemarks
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingRemarks",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(54),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingRemarks,
                                        expression: "detail.UnLoadingRemarks"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingRemarks"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingRemarks
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingRemarks",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(55),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingLoadFill,
                                        expression: "detail.LoadingLoadFill"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingLoadFill"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingLoadFill
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingLoadFill",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(56),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingLoadFill,
                                        expression: "detail.UnLoadingLoadFill"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingLoadFill"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingLoadFill
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingLoadFill",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(57),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value:
                                          _vm.detail.LoadingHiredOperatorHour,
                                        expression:
                                          "detail.LoadingHiredOperatorHour"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingHiredOperatorHour"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingHiredOperatorHour
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingHiredOperatorHour",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(58),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value:
                                          _vm.detail.UnLoadingHiredOperatorHour,
                                        expression:
                                          "detail.UnLoadingHiredOperatorHour"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingHiredOperatorHour"
                                    },
                                    domProps: {
                                      value:
                                        _vm.detail.UnLoadingHiredOperatorHour
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingHiredOperatorHour",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(59),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingJobCode,
                                        expression: "detail.LoadingJobCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingJobCode"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingJobCode
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingJobCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(60),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingJobCode,
                                        expression: "detail.UnLoadingJobCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingJobCode"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingJobCode
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingJobCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(61),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingNoOfLoad,
                                        expression: "detail.LoadingNoOfLoad"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingNoOfLoad"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingNoOfLoad
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingNoOfLoad",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(62),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingNoOfLoad,
                                        expression: "detail.UnLoadingNoOfLoad"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingNoOfLoad"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingNoOfLoad
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingNoOfLoad",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
=======
                          _vm._m(1),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.DateFrom,
                                expression: "form.DateFrom"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              id: "DateFrom",
                              required: "",
                              type: "date",
                              name: "DateFrom"
                            },
                            domProps: { value: _vm.form.DateFrom },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "DateFrom",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col" }, [
                      _c(
                        "div",
                        { staticClass: "input-group mb-3 input-group-sm" },
                        [
                          _vm._m(2),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.DateTo,
                                expression: "form.DateTo"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              id: "DateTo",
                              required: "",
                              type: "date",
                              name: "DateTo"
                            },
                            domProps: { value: _vm.form.DateTo },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "DateTo",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col" }, [
                      _c(
                        "div",
                        { staticClass: "input-group mb-3 input-group-sm" },
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.DriverName,
                                expression: "form.DriverName"
                              }
                            ],
                            staticClass: "form-control",
                            class: {
                              "is-invalid": _vm.form.errors.has("DriverName")
                            },
                            attrs: {
                              type: "text",
                              name: "DriverName",
                              placeholder: "Driver Name",
                              readonly: ""
                            },
                            domProps: { value: _vm.form.DriverName },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "DriverName",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "b-input-group-append",
                            [
                              _c(
                                "b-button",
                                {
                                  attrs: {
                                    variant: "outline-primary",
                                    size: "sm"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.searchDriverFunction()
                                    }
                                  }
                                },
                                [
                                  _c("i", {
                                    staticClass: "fa fa-search",
                                    attrs: { "aria-hidden": "true" }
                                  })
                                ]
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    ]),
                    _vm._v(" "),
                    _vm._m(3)
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "col-xs-12" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col" }, [
                    _c("table", { staticClass: "table table-hover" }, [
                      _vm._m(4),
                      _vm._v(" "),
                      _c(
                        "tbody",
                        _vm._l(_vm.list, function(jvl) {
                          return _c("tr", { key: jvl.OVLVLHDRID }, [
                            _c("td", [_vm._v(_vm._s(jvl.OVLVLDate))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(jvl.OVLNo))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(jvl.OVLPlateNo))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(jvl.DriverName))]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(
                                  "Php " +
                                    jvl.BillAmount.toLocaleString(undefined, {
                                      maximumFractionDigits: 2,
                                      minimumFractionDigits: 2
                                    })
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(jvl.LessAdmin))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(jvl.LessFuel))]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(
                                  "Php " +
                                    jvl.NetTrucker.toLocaleString(undefined, {
                                      maximumFractionDigits: 2,
                                      minimumFractionDigits: 2
                                    })
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(jvl.Status))])
                          ])
                        }),
                        0
                      )
                    ])
                  ])
                ])
              ])
            ])
          ])
        ],
        1
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      ),
      _vm._v(" "),
      _c("search-driver", {
        on: {
          changeTitle: function($event) {
<<<<<<< HEAD
            return _vm.updateTitle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-operator", {
        on: {
          changeTitleOperator: function($event) {
            return _vm.updateTitleOperator($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-ovlvehicle", {
        on: {
          changeTitleVehicle: function($event) {
            return _vm.updateTitleVehicle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-client", {
        on: {
          changeTitleClient: function($event) {
            return _vm.updateTitleClient($event)
=======
            return _vm.updateDriver($event)
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
<<<<<<< HEAD
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("Outsider Vehicle Log Entry")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("VL No")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("GL Code")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Cost Center")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Per Hour Rate")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time Start")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time End")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("No. of Hours")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Bill Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Fuel Liters")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Fuel Amount")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Maintenance Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Admin Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Helper")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Labor")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C9",
            "border-color": "#85E9C9"
          }
        },
        [_vm._v("Sub-Total Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C9",
            "border-color": "#85E9C9"
          }
        },
        [_vm._v("Total Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C9",
            "border-color": "#85E9C9"
          }
        },
        [_vm._v("Net From Rent")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Collected Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Balance Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR No./CR No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR/CR Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Mode of Payment")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Remarks")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", [_vm._v("Amount Collected")]),
      _vm._v(" "),
      _c("th", [_vm._v("OR/CR Date")]),
      _vm._v(" "),
      _c("th", [_vm._v("OR/CR No")]),
      _vm._v(" "),
      _c("th", [_vm._v("Modify")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Collected Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Balance Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR No./CR No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR/CR Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Mode of Payment")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Remarks")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Assignment")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("FLD/LOG")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Time In")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Time Start")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Time End")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Remarks")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Load Fill")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Hired Operator Hour")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Job Code")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("No. Of Load")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Assignment")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("FLD/LOG")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Time In")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Time Start")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Time End")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Remarks")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Load Fill")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Hired Operator Hour")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Job Code")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("No. Of Load")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        { staticClass: "input-group-text", staticStyle: { display: "none" } },
        [_vm._v("Header ID")]
      )
    ])
  },
=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Assignment")]
      )
=======
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("OVL Driver Payroll List")])
      ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
<<<<<<< HEAD
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Assignment")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading FLD/LOG")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading FLD/LOG")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time In")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time In")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time Start")]
      )
=======
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
      ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
<<<<<<< HEAD
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time Start")]
      )
=======
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time End")]
=======
    return _c("div", { staticClass: "col" }, [
      _c(
        "button",
        { staticClass: "btn btn-primary btn-sm", attrs: { type: "submit" } },
        [_c("i", { staticClass: "fa fa-search fa-fw" }), _vm._v("Search")]
      ),
      _vm._v(" "),
      _c(
        "button",
        { staticClass: "btn btn-success btn-sm", attrs: { type: "button" } },
        [_c("i", { staticClass: "fa fa-print fa-fw" }), _vm._v("Print")]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time End")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Remraks")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Remraks")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Load Fill")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Load Fill")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Hired Operator Hour")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Hired Operator Hour")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Job Code")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Job Code")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading No. Of Load")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading No. Of Load")]
      )
    ])
  }
]
=======
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("DR No")]),
        _vm._v(" "),
        _c("th", [_vm._v("Remarks")]),
        _vm._v(" "),
        _c("th", [_vm._v("No. of Hrs")]),
        _vm._v(" "),
        _c("th", [_vm._v("Rate/Hr")]),
        _vm._v(" "),
        _c("th", [_vm._v("SubTotal")]),
        _vm._v(" "),
        _c("th", [_vm._v("Fuel Cost")]),
        _vm._v(" "),
        _c("th", [_vm._v("Loaders")]),
        _vm._v(" "),
        _c("th", [_vm._v("Helper")]),
        _vm._v(" "),
        _c("th", [_vm._v("Admin Cost")]),
        _vm._v(" "),
        _c("th", [_vm._v("Maintenance Cost")]),
        _vm._v(" "),
        _c("th", [_vm._v("Sub Total")]),
        _vm._v(" "),
        _c("th", [_vm._v("Net From Deduction")]),
        _vm._v(" "),
        _c("th", [_vm._v("Total")]),
        _vm._v(" "),
        _c("th", [_vm._v("GSC Shop Hrs")]),
        _vm._v(" "),
        _c("th", [_vm._v("GSC Shop Rate")]),
        _vm._v(" "),
        _c("th", [_vm._v("Total")]),
        _vm._v(" "),
        _c("th", [_vm._v("Gross Income")])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("img", { attrs: { src: __webpack_require__(/*! ./OVL.png */ "./resources/js/components/OVLComponents/OVL.png") } }),
    _vm._v(" "),
    _c(
      "nav",
      {
        staticClass:
          "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
      },
      [
        _c(
          "div",
          {
            staticClass: "collapse navbar-collapse",
            attrs: { id: "navbarNavDropdown" }
          },
          [
            _c("ul", { staticClass: "navbar-nav" }, [
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#mlist"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        Master File\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "mlist"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovldriverlist" }
                          },
                          [_c("a", [_vm._v("OVL Driver List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovlvehiclelist" }
                          },
                          [_c("a", [_vm._v("OVL Vehicle List & Rate")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#trans"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        Transactions\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "trans"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovlvehiclelogentry" }
                          },
                          [_c("a", [_vm._v("OVL Vehicle Log Entry")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovldriverpayroll" }
                          },
                          [_c("a", [_vm._v("Driver Payroll List")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#report"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        OVL Reports\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "report"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistovl" }
                          },
                          [_c("a", [_vm._v("Standard OVL Report")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  ])
}
var staticRenderFns = []
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue ***!
  \**************************************************************************/
=======
/***/ "./resources/js/components/OVLComponents/DriverPayroll.vue":
/*!*****************************************************************!*\
  !*** ./resources/js/components/OVLComponents/DriverPayroll.vue ***!
  \*****************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& */ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&");
/* harmony import */ var _OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OVLVehicleLogComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

=======
/* harmony import */ var _DriverPayroll_vue_vue_type_template_id_92a30524___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DriverPayroll.vue?vue&type=template&id=92a30524& */ "./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=template&id=92a30524&");
/* harmony import */ var _DriverPayroll_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DriverPayroll.vue?vue&type=script&lang=js& */ "./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DriverPayroll_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DriverPayroll_vue_vue_type_template_id_92a30524___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DriverPayroll_vue_vue_type_template_id_92a30524___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/OVLComponents/OVLVehicleLogComponent.vue"
=======
component.options.__file = "resources/js/components/OVLComponents/DriverPayroll.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
=======
/***/ "./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DriverPayroll_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./DriverPayroll.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DriverPayroll_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=template&id=92a30524&":
/*!************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=template&id=92a30524& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DriverPayroll_vue_vue_type_template_id_92a30524___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./DriverPayroll.vue?vue&type=template&id=92a30524& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/DriverPayroll.vue?vue&type=template&id=92a30524&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DriverPayroll_vue_vue_type_template_id_92a30524___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DriverPayroll_vue_vue_type_template_id_92a30524___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/OVLComponents/OVL.png":
/*!*******************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVL.png ***!
  \*******************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/OVL.png?70ca35f6f16b7d8ea732077eeaa11d02";

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLMenu.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLMenu.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 
=======
/* harmony import */ var _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLMenu.vue?vue&type=template&id=321a0b35& */ "./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}

>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

<<<<<<< HEAD
/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& ***!
  \*********************************************************************************************************/
=======
/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/OVLComponents/OVLMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLMenu.vue?vue&type=template&id=321a0b35& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);