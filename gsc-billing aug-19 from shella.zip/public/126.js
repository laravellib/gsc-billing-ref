(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[126],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
=======
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
<<<<<<< HEAD
      general: new Form({
        url: ""
      })
    };
  },
  mounted: function mounted() {},
  methods: {},
  //method end
  created: function created() {},
  computed: {}
=======
      DateFrom: '',
      DateTo: '',
      rentals: []
    };
  },
  methods: {
    loadAllReports: function loadAllReports() {
      var _this = this;

      axios.get('api/vehicleAllReports?from=' + this.DateFrom + '&to=' + this.DateTo).then(function (response) {
        var sum = 0;
        response.data.forEach(function (item) {
          sum = sum + parseFloat(item.NetTrucker);
        });
        _this.rentals = response.data;
      })["catch"](function (error) {});
    },
    exportExcel: function exportExcel() {}
  },
  created: function created() {
    var today = new Date().toISOString().slice(0, 10);
    this.DateFrom = today;
    this.DateTo = today;
  }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=template&id=26833aca&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=template&id=26833aca& ***!
  \*******************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=template&id=5b65707c&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=template&id=5b65707c& ***!
  \************************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
<<<<<<< HEAD
    _c("div", { staticClass: "justify-content-center" }, [
=======
    _c("div", { staticClass: "col-xs-12" }, [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _c("div", { staticClass: "card" }, [
        _vm._m(0),
        _vm._v(" "),
        _c("div", { staticClass: "card-body" }, [
<<<<<<< HEAD
          _c("div", { staticClass: "col report-nav" }, [
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c(
                  "b-button",
                  { attrs: { variant: "primary" } },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          to: "/dailyBillingTransmittal",
                          target: "_blank"
                        }
                      },
                      [
                        _c("i", { staticClass: "fa fa-caret-square-right" }, [
                          _vm._v("   Billing Transmittal")
                        ])
                      ]
                    )
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c(
                  "b-button",
                  { attrs: { variant: "primary" } },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: { to: "/SoaReactivatereport", target: "_blank" }
                      },
                      [
                        _c("i", { staticClass: "fa fa-caret-square-right" }, [
                          _vm._v("   Reactivated SOA Report")
                        ])
                      ]
                    )
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c("b-button", { attrs: { variant: "primary" } }, [
                  _c("i", { staticClass: "fa fa-caret-square-right" }, [
                    _vm._v("   Year to Date Collection Report")
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c("b-button", { attrs: { variant: "primary" } }, [
                  _c("i", { staticClass: "fa fa-caret-square-right" }, [
                    _vm._v("   Year to Date Aging Report")
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c("b-button", { attrs: { variant: "primary" } }, [
                  _c("i", { staticClass: "fa fa-caret-square-right" }, [
                    _vm._v("   Billing Report Per Client")
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c("b-button", { attrs: { variant: "primary" } }, [
                  _c("i", { staticClass: "fa fa-caret-square-right" }, [
                    _vm._v("   Payroll Billing Annual Report")
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "row padding-top" },
              [
                _c(
                  "b-button",
                  { attrs: { variant: "primary" } },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: { to: "/SoaStatusMonitoring", target: "_blank" }
                      },
                      [
                        _c("i", { staticClass: "fa fa-caret-square-right" }, [
                          _vm._v("   SOA Status Monitoring")
                        ])
                      ]
                    )
                  ],
                  1
                )
              ],
              1
=======
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-3" }, [
              _c("div", { staticClass: "input-group mb-3 input-group-sm" }, [
                _vm._m(1),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.DateFrom,
                      expression: "DateFrom"
                    }
                  ],
                  staticClass: "form-control",
                  attrs: { id: "DateFrom", type: "date", name: "DateFrom" },
                  domProps: { value: _vm.DateFrom },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.DateFrom = $event.target.value
                    }
                  }
                })
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-3" }, [
              _c("div", { staticClass: "input-group mb-3 input-group-sm" }, [
                _vm._m(2),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.DateTo,
                      expression: "DateTo"
                    }
                  ],
                  staticClass: "form-control",
                  attrs: { id: "DateTo", type: "date", name: "DateTo" },
                  domProps: { value: _vm.DateTo },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.DateTo = $event.target.value
                    }
                  }
                })
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-1" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-primary btn-sm",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      return _vm.loadAllReports()
                    }
                  }
                },
                [
                  _c("i", { staticClass: "fa fa-search fa-fw" }),
                  _vm._v("Search")
                ]
              )
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-primary btn-sm",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      return _vm.exportExcel()
                    }
                  }
                },
                [
                  _c("i", { staticClass: "fa fa-search fa-fw" }),
                  _vm._v("Export to Excel")
                ]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c(
              "table",
              { staticClass: "table table-hover", attrs: { id: "my-table" } },
              [
                _vm._m(3),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.rentals, function(rental) {
                    return _c("tr", { key: rental.rentalHDRID }, [
                      _c("td", [_vm._v(_vm._s(rental.rentalDate))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.OVLNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.DriverName))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.JeepPlateNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.TruckerName))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.BillAmount.toFixed(2)))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.LessFuel.toFixed(2)))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.LessAdmin.toFixed(2)))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.NetTrucker.toFixed(2)))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.NetTrucker.toFixed(2)))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.NetTrucker.toFixed(2)))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(rental.NetTrucker.toFixed(2)))])
                    ])
                  }),
                  0
                )
              ]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
<<<<<<< HEAD
        _vm._v("Other Client & Dmpi Reports")
=======
        _c("b", [_vm._v("Vehicle All Reports")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("DATE")]),
        _vm._v(" "),
        _c("th", [_vm._v("DR NO")]),
        _vm._v(" "),
        _c("th", [_vm._v("Date Received")]),
        _vm._v(" "),
        _c("th", [_vm._v("Invoice No")]),
        _vm._v(" "),
        _c("th", [_vm._v("Admin Cost")]),
        _vm._v(" "),
        _c("th", [_vm._v("Loaders/Unloaders")]),
        _vm._v(" "),
        _c("th", [_vm._v("Helper")]),
        _vm._v(" "),
        _c("th", [_vm._v("Subtotal")]),
        _vm._v(" "),
        _c("th", [_vm._v("Labor")]),
        _vm._v(" "),
        _c("th", [_vm._v("Total Cost")]),
        _vm._v(" "),
        _c("th", [_vm._v("Net From Rental")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/reports/DmpiReportsComponent.vue":
/*!******************************************************************!*\
  !*** ./resources/js/components/reports/DmpiReportsComponent.vue ***!
  \******************************************************************/
=======
/***/ "./resources/js/components/VehicleReports/Vehicle-All-Report.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/components/VehicleReports/Vehicle-All-Report.vue ***!
  \***********************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _DmpiReportsComponent_vue_vue_type_template_id_26833aca___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DmpiReportsComponent.vue?vue&type=template&id=26833aca& */ "./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=template&id=26833aca&");
/* harmony import */ var _DmpiReportsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DmpiReportsComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=script&lang=js&");
=======
/* harmony import */ var _Vehicle_All_Report_vue_vue_type_template_id_5b65707c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Vehicle-All-Report.vue?vue&type=template&id=5b65707c& */ "./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=template&id=5b65707c&");
/* harmony import */ var _Vehicle_All_Report_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Vehicle-All-Report.vue?vue&type=script&lang=js& */ "./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=script&lang=js&");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _DmpiReportsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DmpiReportsComponent_vue_vue_type_template_id_26833aca___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DmpiReportsComponent_vue_vue_type_template_id_26833aca___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _Vehicle_All_Report_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Vehicle_All_Report_vue_vue_type_template_id_5b65707c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Vehicle_All_Report_vue_vue_type_template_id_5b65707c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/reports/DmpiReportsComponent.vue"
=======
component.options.__file = "resources/js/components/VehicleReports/Vehicle-All-Report.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
=======
/***/ "./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiReportsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./DmpiReportsComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiReportsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=template&id=26833aca&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=template&id=26833aca& ***!
  \*************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Vehicle_All_Report_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Vehicle-All-Report.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Vehicle_All_Report_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=template&id=5b65707c&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=template&id=5b65707c& ***!
  \******************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiReportsComponent_vue_vue_type_template_id_26833aca___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./DmpiReportsComponent.vue?vue&type=template&id=26833aca& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/reports/DmpiReportsComponent.vue?vue&type=template&id=26833aca&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiReportsComponent_vue_vue_type_template_id_26833aca___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiReportsComponent_vue_vue_type_template_id_26833aca___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Vehicle_All_Report_vue_vue_type_template_id_5b65707c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Vehicle-All-Report.vue?vue&type=template&id=5b65707c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/VehicleReports/Vehicle-All-Report.vue?vue&type=template&id=5b65707c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Vehicle_All_Report_vue_vue_type_template_id_5b65707c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Vehicle_All_Report_vue_vue_type_template_id_5b65707c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);