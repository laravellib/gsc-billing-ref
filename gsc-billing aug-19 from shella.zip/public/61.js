(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[61],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/Payment.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/FUEL/Payment.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var vue_spinner_dist_vue_spinner_min_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-spinner/dist/vue-spinner.min.js */ "./node_modules/vue-spinner/dist/vue-spinner.min.js");
/* harmony import */ var vue_spinner_dist_vue_spinner_min_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_spinner_dist_vue_spinner_min_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _AdminComponents_BarChart_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../AdminComponents/BarChart.js */ "./resources/js/components/AdminComponents/BarChart.js");
=======
/* harmony import */ var _FUEL_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../FUEL/ShowDetailModal.vue */ "./resources/js/components/FUEL/ShowDetailModal.vue");
/* harmony import */ var _search_SearchAllowance_SearchFUELHeader_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchAllowance/SearchFUELHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchFUELHeader.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
<<<<<<< HEAD
    LineChart: _AdminComponents_BarChart_js__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      PayStation: "",
      Month: "",
      Year: "",
      Phase: "",
      datacollection: {},
      datacollection2: {},
      selectedMonth: "",
      selectedYear: "",
      selectedPhase: "",
      selectedPayStation: "",
      Paystations: "",
      Totals: "",
      Dates: "",
      TotalsAmount: "",
      darreportsresult: [],
      tangtanglastcomma: "",
      tangtanglastcommadates: "",
      tangtanglastcommatotal: "",
      tangtanglastcommatotalamount: "",
      stringtoarrayna: [],
      stringtoarraynadates: [],
      stringtoarraynatotal: [],
      stringtoarraynatotalamount: [],
      color: "",
      tangtanglastcommacolor: "",
      stringtoarraynacolor: [],
      min: 1,
      max: 255,
      TotalAverageHeadCount: 0,
      FinalViewTotalAverageHeadCount: 0,
      TotalNetAmount: 0,
      index: 0
    };
  },
  mounted: function mounted() {
    this.LoadPayrollPeriodMonth();
    this.LoadPayrollPeriodYear();
    this.LoadPayrollPeriodPayStation();
  },
  methods: {
    getPhoto: function getPhoto() {
      return "img/source (1).gif";
    },
    doMath: function doMath(index) {
      return index + 1;
    },
    generateDarReport: function generateDarReport() {
      var _this = this;

      //   this.fillData();
      // $('#addNew').modal('show');
      document.getElementById('overlay').style.display = "block"; // axios.get('/api/getDARReportPayStation', {params: {selectedMonth: this.selectedMonth, selectedYear: this.selectedYear, selectedPhase: this.selectedPhase,selectedPayStation: this.selectedPayStation}})

      axios.get('/api/getDARReportPayStation', {
        params: {
          selectedMonth: this.selectedMonth,
          selectedYear: this.selectedYear,
          selectedPhase: this.selectedPhase,
          selectedPayStation: this.selectedPayStation
        }
      }).then(function (_ref) {
        var data = _ref.data;
        _this.darreportsresult = data;
        _this.Paystations = "";
        _this.Totals = "";
        _this.TotalsAmount = "";
        _this.Dates = "";
        _this.color = "";
        _this.TotalAverageHeadCount = 0;
        _this.TotalNetAmount = 0; //   this.Paystations = this.darreportsresult.PayStation;
        //   this.Totals = this.darreportsresult.Total;
        //  this.fillData();

        console.log(_this.darreportsresult);

        for (var i = 0; i < _this.darreportsresult.length; i++) {
          // this.Paystations = this.darreportsresult[i].PayStation;
          _this.Paystations = _this.darreportsresult[i].PayStation + ',' + _this.Paystations;
          _this.Totals = _this.darreportsresult[i].Total + ',' + _this.Totals;
          _this.TotalsAmount = _this.darreportsresult[i].TotalAmount + ',' + _this.TotalsAmount;
          _this.Dates = _this.darreportsresult[i].PeriodDate + ' ,' + _this.Dates;
          var r = Math.floor(Math.random() * (_this.max - _this.min + 1) + _this.min);
          var g = Math.floor(Math.random() * (_this.max - _this.min + 1) + _this.min);
          var b = Math.floor(Math.random() * (_this.max - _this.min + 1) + _this.min);
          _this.color = 'rgb(' + r + ',' + g + ',' + b + ') ,' + _this.color;
          _this.TotalAverageHeadCount = _this.darreportsresult[i].Total + _this.TotalAverageHeadCount;
          _this.TotalNetAmount = _this.darreportsresult[i].TotalAmount + _this.TotalNetAmount;
        } //    $('#addNew').modal('hide');
        // $('.modal-backdrop').remove();


        swal.fire({
          icon: 'success',
          title: 'Finished!',
          text: 'Done Generating Report!'
        });
        document.getElementById('overlay').style.display = "none";

        _this.fillData();
      })["catch"](function (err) {});
    },
    fillData: function fillData() {
      this.FinalViewTotalAverageHeadCount = this.TotalAverageHeadCount / this.darreportsresult.length;
      this.tangtanglastcomma = this.Paystations.replace(/,\s*$/, "");
      this.tangtanglastcommatotal = this.Totals.replace(/,\s*$/, "");
      this.tangtanglastcommatotalamount = this.TotalsAmount.replace(/,\s*$/, "");
      this.tangtanglastcommacolor = this.color.replace(/,\s*$/, "");
      this.tangtanglastcommadates = this.Dates.replace(/,\s*$/, "");
      this.stringtoarrayna = this.tangtanglastcomma.split(",");
      this.stringtoarraynatotal = this.tangtanglastcommatotal.split(",");
      this.stringtoarraynatotalamount = this.tangtanglastcommatotalamount.split(",");
      this.stringtoarraynacolor = this.tangtanglastcommacolor.split(" ,");
      this.stringtoarraynadates = this.tangtanglastcommadates.split(" ,");
      console.log('Dates: ' + this.stringtoarraynadates);
      console.log('Amount: ' + this.stringtoarraynatotal); //var data =this.Paystations.split(",");

      this.datacollection = {
        labels: this.stringtoarraynadates,
        datasets: [{
          label: 'Data One',
          backgroundColor: this.stringtoarraynacolor,
          data: this.stringtoarraynatotal
        }],
        options: {
          scaleShowValues: true,
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }],
            xAxes: [{
              ticks: {
                autoSkip: false
              }
            }]
          }
        }
      };
      this.datacollection2 = {
        labels: this.stringtoarraynadates,
        datasets: [{
          label: 'Data Two',
          backgroundColor: this.stringtoarraynacolor,
          data: this.stringtoarraynatotalamount
        }],
        options: {
          scaleShowValues: true,
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }],
            xAxes: [{
              ticks: {
                autoSkip: false,
                labelString: 'hehefeefefefe'
              }
            }]
          }
=======
    "search-fuelDetail": _FUEL_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-fuelHeader": _search_SearchAllowance_SearchFUELHeader_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      search: "",
      headerList: [],
      dataInHeader: false,
      header: {
        FHID: "",
        SOANo: "",
        billing: "0.00",
        balance: "0.00",
        totalPayment: "0.00"
      },
      detailList: [],
      dataInDetail: false,
      detail: {
        FPID: "",
        hdr_idLink: "",
        paymentMode: "",
        check_no: "",
        check_date: this.$root.formatDate(new Date()),
        check_amount: "0.00",
        orNumber: "",
        remarks: ""
      },
      check_amount: 0,
      SOANo: ""
    };
  },
  mounted: function mounted() {// this.getData();
  },
  methods: {
    appendSOANo: function appendSOANo() {
      var _this = this;

      if (!this.SOANo) {
        return toast.fire({
          icon: "warning",
          title: "Please select SOA Number to continue."
        });
      }

      this.$Progress.start();
      axios.get("api/fuel", {
        params: {
          getViewFUEL: true,
          SOANo: this.SOANo
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          var exist = false;

          if (_this.headerList.length > 0) {
            _this.headerList.forEach(function (item) {
              if (item.SOANo == response.data[0].SOANo) {
                exist = true;
                return toast.fire({
                  icon: "warning",
                  title: "SOA Number already in the list."
                });
              }
            });
          }

          if (!exist) {
            _this.headerList.push(response.data[0]);

            _this.dataInHeader = true;

            _this.totalBilling();
          }
        } else {
          return toast.fire({
            icon: "warning",
            title: "SOA Number has no details."
          });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
        }
      };
    },
    LoadPayrollPeriodMonth: function LoadPayrollPeriodMonth() {
      var _this2 = this;

<<<<<<< HEAD
      axios.get('api/getPPMonth').then(function (response) {
        _this2.Month = response.data;
        console.log(_this2.Month);
=======
        _this.$Progress.finish();
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      })["catch"](function (error) {
        console.log(error);
      });
    },
<<<<<<< HEAD
    LoadPayrollPeriodYear: function LoadPayrollPeriodYear() {
      var _this3 = this;

      axios.get('api/getPPYear').then(function (response) {
        _this3.Year = response.data;
        console.log(_this3.Year);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    LoadPayrollPeriodPayStation: function LoadPayrollPeriodPayStation() {
      var _this4 = this;

      axios.get('api/getPPPayStation').then(function (response) {
        _this4.PayStation = response.data;
        console.log(_this4.PayStation);
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {
    this.fillData();
  },
  computed: {
    totals: function totals() {
      return this.darreportsresult;
    }
  }
});
=======
    totalBilling: function totalBilling() {
      var total = 0;
      this.headerList.forEach(function (item) {
        total = total + item.Balance;
      });
      this.header.billing = this.$root.formatNumberCommaRound(total);
      this.detail.check_amount = this.$root.formatNumberCommaRound(total);
    },
    removeSOANo: function removeSOANo(item) {
      this.headerList.splice(this.headerList.indexOf(item), 1);
      this.totalBilling();
    },
    getDetail: function getDetail() {
      var _this2 = this;

      if (this.header.FHID) {
        axios.get("api/fuel", {
          params: {
            getPaymentDetail: true,
            id: this.header.FHID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this2.detailList = response.data;
            _this2.dataInDetail = true;
          } else {
            _this2.dataInDetail = false;
            _this2.detailList = [];
          }

          _this2.getTotalPayment();

          _this2.check_amount = 0;
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    rowClick: function rowClick(row) {
      this.header.FHID = row.FHID;
      this.header.SOANo = row.SOANo;
      this.header.billing = this.$root.formatNumberCommaRound(row.TotalAmount);
      this.header.balance = this.$root.formatNumberCommaRound(row.Balance);
      this.clearFunction("detail");
      this.getDetail();
    },
    clickDetails: function clickDetails(id) {
      Fire.$emit("searchFUELDetail", id);
    },
    searchFUELHeader: function searchFUELHeader() {
      Fire.$emit("searchFUELHeader", "payment");
    },
    fuelHeaderClose: function fuelHeaderClose(row) {
      this.SOANo = row.SOANo;
    },
    savePayment: function savePayment() {
      var _this3 = this;

      if (this.$root.formatNumber(this.detail.check_amount) == 0 || this.$root.formatNumber(this.detail.check_amount) < 0) {
        return toast.fire({
          icon: "warning",
          title: "Check Amount is invalid."
        });
      }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Post it!"
      }).then(function (result) {
        if (result.value) {
          _this3.$Progress.start();

<<<<<<< HEAD
/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.small {\n  max-width: 600px;\n  margin:  150px auto;\n}\n", ""]);

// exports
=======
          var data = Object.assign({}, _this3.detail);
          data.check_amount = _this3.$root.formatNumber(_this3.detail.check_amount);
          data.hdr_idLink = _this3.header.FHID;
          var soaList = [];
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

          _this3.headerList.forEach(function (item) {
            soaList.push(item.SOANo);
          });

          data.soaList = soaList;
          axios.post("api/fuelPayment", data).then(function (response) {
            if (response.data.success) {
              if (response.data.id) {
                _this3.header.FPID = response.data.id;
              }

<<<<<<< HEAD
/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css&");
=======
              toast.fire({
                icon: "success",
                title: response.data.message
              });

              _this3.$Progress.finish();
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this3.check_amount = 0;

            _this3.getDetail();

            _this3.clearFunction("detail");

            _this3.clearFunction("header");

            _this3.SOANo = "";
            _this3.headerList = [];
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    deletePaymentDetail: function deletePaymentDetail() {
      var _this4 = this;

      if (!this.detail.FPID) {
        return toast.fire({
          icon: "warning",
          title: "Please select payment record to continue."
        });
      }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(function (result) {
        if (result.value) {
          _this4.$Progress.start();

          axios["delete"]("api/fuelPaymentDelete/".concat(_this4.detail.FPID)).then(function (response) {
            if (response.data.success) {
              _this4.clearFunction("detail");

              _this4.check_amount = 0;

              _this4.getDetail();

              swal.fire("Deleted!", response.data.message, "success");
            } else {
              swal.fire("Warning!", response.data.message, "warning");
            }

            _this4.$Progress.finish();
          })["catch"](function (err) {
            console.log(err);
          });
        } else {
          swal.fire("Information!", "Deletion is cancelled.", "warning");
        }
      });
    },
    rowClickDetail: function rowClickDetail(row) {
      this.detail = Object.assign({}, row);
      this.detail.check_amount = this.$root.formatNumberCommaRound(row.check_amount);
      this.check_amount = row.check_amount;
    },
    getTotalPayment: function getTotalPayment() {
      if (this.detailList.length == 0) {
        this.header.totalPayment = "0.00";
        this.header.balance = this.header.billing;
        return;
      }

      var total = 0;
      this.detailList.forEach(function (item) {
        total = total + item.check_amount;
      });
      this.header.balance = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.header.billing) - total);
      this.header.totalPayment = this.$root.formatNumberCommaRound(total);
    },
    clearFunction: function clearFunction(type) {
      if (type == "detail") {
        this.detail = {
          FPID: "",
          hdr_idLink: "",
          paymentMode: "",
          check_no: "",
          check_date: this.$root.formatDate(new Date()),
          check_amount: "",
          orNumber: "",
          remarks: ""
        };
        this.check_amount = 0;
      } else if (type == "detailList") {
        this.detailList = [];
      } else {
        this.header = {
          FHID: "",
          SOANo: "",
          billing: "0.00",
          balance: "0.00",
          totalPayment: "0.00"
        };
      }
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this5 = this;

      return this.headerList.filter(function (item) {
        return _this5.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toString().toLowerCase().includes(v) || item.Location.toString().toLowerCase().includes(v);
        });
      });
    },
    filteredBlogs2: function filteredBlogs2() {
      var _this6 = this;

      return this.detailList.filter(function (item) {
        return _this6.search.toLowerCase().split(" ").every(function (v) {
          return item.check_no.toString().toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33&":
/*!***************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33& ***!
  \***************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      type: "",
      detailList: [],
      dataInDetail: false
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("searchFUELDetail", function (data) {
      _this.getData(data);

      $("#SearchFUELDetail").modal("show");
    });
  },
  methods: {
    getData: function getData(id) {
      var _this2 = this;

      axios.get("api/fuel", {
        params: {
          getDtl: true,
          id: id
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          _this2.dataInDetail = true;
          _this2.detailList = response.data;
        } else {
          _this2.detailList = [];
          _this2.dataInDetail = false;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.detailList.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.Description.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/Payment.vue?vue&type=template&id=41a82bd8&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/FUEL/Payment.vue?vue&type=template&id=41a82bd8& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c("div", { staticClass: "col-xs-12" }, [
    _c(
      "div",
      { attrs: { id: "overlay" } },
      [
        _c(
          "center",
          [
            _c("b-spinner", {
              staticStyle: {
                width: "6rem",
                height: "6rem",
                "margin-top": "300px",
                color: "#82E0AA"
              },
              attrs: { label: "Large Spinner", type: "grow" }
            }),
            _vm._v(" "),
            _c("b-spinner", {
              staticStyle: {
                width: "6rem",
                height: "6rem",
                "margin-top": "300px",
                color: "#82E0AA"
              },
              attrs: { label: "Large Spinner", type: "grow" }
            }),
            _vm._v(" "),
            _c("b-spinner", {
              staticStyle: {
                width: "6rem",
                height: "6rem",
                "margin-top": "300px",
                color: "#82E0AA"
              },
              attrs: { label: "Large Spinner", type: "grow" }
            })
          ],
          1
        )
      ],
      1
    ),
    _vm._v(" "),
    _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col" }, [
        _c("div", { staticClass: "card" }, [
          _c(
            "div",
            { staticClass: "card-body" },
            [
              _vm._m(0),
              _vm._v(" "),
              _c("div", { staticClass: "col-xs-12" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col" }, [
                    _c("label", { staticClass: "mr-sm-2" }, [
                      _vm._v("Select Month")
                    ]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.selectedMonth,
                            expression: "selectedMonth"
                          }
                        ],
                        attrs: { required: "" },
                        on: {
                          change: function($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function(o) {
                                return o.selected
                              })
                              .map(function(o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.selectedMonth = $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          }
                        }
                      },
                      [
                        _c("option", { attrs: { value: "", selected: "" } }, [
                          _vm._v("Choose Month...")
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.Month, function(momonth) {
                          return _c(
                            "option",
                            {
                              key: momonth.id,
                              domProps: { value: momonth.xMonth }
                            },
                            [
                              _vm._v(
                                "\r\n                    " +
                                  _vm._s(momonth.xMonth) +
                                  "\r\n                  "
                              )
                            ]
                          )
=======
  return _c(
    "div",
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-4" }, [
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", [_vm._v("Search SOA")]),
                    _vm._v(" "),
                    _c(
                      "b-input-group",
                      [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.SOANo,
                              expression: "SOANo"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "SOANo",
                            placeholder: "",
                            disabled: ""
                          },
                          domProps: { value: _vm.SOANo },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.SOANo = $event.target.value
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c(
                          "b-input-group-append",
                          [
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  variant: "outline-primary",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.searchFUELHeader()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-search",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-4" }, [
                _c("label", [_vm._v(" ")]),
                _vm._v(" "),
                _c("div", { staticClass: "form-group" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { type: "button", bold: "" },
                      on: {
                        click: function($event) {
                          return _vm.appendSOANo()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-plus",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                APPEND\n                            "
                      )
                    ]
                  )
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _vm._m(1),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody" },
                      [
                        _c(
                          "tr",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: !this.dataInHeader,
                                expression: "!this.dataInHeader"
                              }
                            ]
                          },
                          [_vm._m(2)]
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.filteredBlogs, function(item) {
                          return _c("tr", [
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { bold: "" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.SOANo) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.Period) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(item.Location))]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatDate")(item.date_created)
                                  ) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-right" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatNumber")(item.TotalAmount)
                                  ) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-right" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(_vm._f("formatNumber")(item.Balance)) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                staticStyle: { width: "10%" }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-eye text-primary",
                                  staticStyle: { "font-size": "120%" },
                                  on: {
                                    click: function($event) {
                                      return _vm.clickDetails(item.FHID)
                                    }
                                  }
                                }),
                                _vm._v(
                                  "\n                                           \n                                        "
                                ),
                                _c("i", {
                                  staticClass: "fa fa-minus-circle text-danger",
                                  staticStyle: { "font-size": "120%" },
                                  on: {
                                    click: function($event) {
                                      return _vm.removeSOANo(item)
                                    }
                                  }
                                })
                              ]
                            )
                          ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        })
                      ],
                      2
                    )
<<<<<<< HEAD
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c("label", { staticClass: "mr-sm-2" }, [
                      _vm._v("Select Year")
                    ]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.selectedYear,
                            expression: "selectedYear"
                          }
                        ],
                        attrs: { required: "" },
                        on: {
                          change: function($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function(o) {
                                return o.selected
                              })
                              .map(function(o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.selectedYear = $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          }
                        }
                      },
                      [
                        _c("option", { attrs: { value: "", selected: "" } }, [
                          _vm._v("Choose Year...")
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.Year, function(yeyear) {
                          return _c(
                            "option",
                            {
                              key: yeyear.id,
                              domProps: { value: yeyear.xYear }
                            },
                            [
                              _vm._v(
                                "\r\n                    " +
                                  _vm._s(yeyear.xYear) +
                                  "\r\n                  "
                              )
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c(
                      "div",
                      { staticClass: "input-group mb-3 input-group-sm" },
                      [
                        _c("label", { staticClass: "mr-sm-2" }, [
                          _vm._v("Select Phase")
                        ]),
                        _vm._v(" "),
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.selectedPhase,
                                expression: "selectedPhase"
                              }
                            ],
                            attrs: { required: "" },
                            on: {
                              change: function($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function(o) {
                                    return o.selected
                                  })
                                  .map(function(o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.selectedPhase = $event.target.multiple
                                  ? $$selectedVal
                                  : $$selectedVal[0]
                              }
                            }
                          },
                          [
                            _c(
                              "option",
                              { attrs: { value: "", selected: "" } },
                              [_vm._v("Choose Phase...")]
                            ),
                            _vm._v(" "),
                            _c("option", { attrs: { value: "1" } }, [
                              _vm._v("1")
                            ]),
                            _vm._v(" "),
                            _c("option", { attrs: { value: "2" } }, [
                              _vm._v("2")
                            ])
                          ]
                        )
                      ]
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c("label", { staticClass: "mr-sm-2" }, [
                      _vm._v("Select Pay Station")
                    ]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.selectedPayStation,
                            expression: "selectedPayStation"
                          }
                        ],
                        attrs: { required: "" },
                        on: {
                          change: function($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function(o) {
                                return o.selected
                              })
                              .map(function(o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.selectedPayStation = $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          }
                        }
                      },
                      [
                        _c("option", { attrs: { value: "", selected: "" } }, [
                          _vm._v("Choose Pay Station...")
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.PayStation, function(ps) {
                          return _c(
                            "option",
                            { key: ps.id, domProps: { value: ps.PayStation } },
                            [
                              _vm._v(
                                "\r\n                    " +
                                  _vm._s(ps.PayStation) +
                                  "\r\n                  "
                              )
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c(
                      "div",
                      { staticClass: "input-group mb-3 input-group-sm" },
                      [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: { click: _vm.generateDarReport }
                          },
                          [_vm._v("Generate")]
                        )
                      ]
                    )
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("line-chart", {
                attrs: { width: 300, "chart-data": _vm.datacollection }
              })
            ],
            1
          )
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col" }, [
            _c("div", { staticClass: "card" }, [
              _c(
                "div",
                { staticClass: "card-body" },
                [
                  _vm._m(1),
                  _vm._v(" "),
                  _c("line-chart", {
                    attrs: {
                      width: 300,
                      height: 428,
                      "chart-data": _vm.datacollection2
                    }
                  })
                ],
                1
              )
            ])
          ])
        ])
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "card" }, [
      _c("div", { staticClass: "card-body table-responsive pre-scrollables" }, [
        _c("table", { staticClass: "table table-hover" }, [
          _vm._m(2),
          _vm._v(" "),
          _c(
            "tbody",
            _vm._l(_vm.darreportsresult, function(dar, index) {
              return _c("tr", { key: dar.id }, [
                _c("td", { staticStyle: { "text-align": "right" } }, [
                  _vm._v(_vm._s(_vm.doMath(index)))
                ]),
                _vm._v(" "),
                _c("td", { staticStyle: { "text-align": "right" } }, [
                  _vm._v(_vm._s(dar.PeriodDate))
                ]),
                _vm._v(" "),
                _c("td", { staticStyle: { "text-align": "right" } }, [
                  _vm._v(_vm._s(dar.Total))
                ]),
                _vm._v(" "),
                _c("td", { staticStyle: { "text-align": "right" } }, [
                  _vm._v(
                    _vm._s(
                      "Php" +
                        dar.TotalAmount.toLocaleString(undefined, {
                          maximumFractionDigits: 2,
                          minimumFractionDigits: 2
                        })
                    )
                  )
                ])
              ])
            }),
            0
          )
        ])
      ])
    ]),
    _vm._v(" "),
    _c("table", { staticClass: "table" }, [
      _c("thead", { staticClass: "thead-dark" }, [
        _c("tr", [
          _c("th", { staticStyle: { "text-align": "right" } }, [
            _vm._v(_vm._s("GRAND TOTAL"))
          ]),
          _vm._v(" "),
          _c("th", { staticStyle: { "text-align": "right" } }, [
            _vm._v(
              _vm._s(
                "Total Average Head Count: " +
                  this.FinalViewTotalAverageHeadCount.toLocaleString(
                    undefined,
                    { maximumFractionDigits: 0, minimumFractionDigits: 0 }
                  )
              )
            )
          ]),
          _vm._v(" "),
          _c("th", { staticStyle: { "text-align": "right" } }, [
            _vm._v(
              _vm._s(
                "Total Amount: Php" +
                  this.TotalNetAmount.toLocaleString(undefined, {
                    maximumFractionDigits: 2,
                    minimumFractionDigits: 2
                  })
              )
            )
          ])
        ])
      ])
    ])
  ])
=======
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12" }, [
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.savePayment()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-4" }, [
                        _c("label", [_vm._v("Mode of Payment")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.detail.paymentMode,
                              expression: "detail.paymentMode"
                            }
                          ],
                          staticClass: "form-control text-center bold",
                          attrs: {
                            type: "text",
                            name: "paymentMode",
                            placeholder: "",
                            required: "",
                            list: "modePayment"
                          },
                          domProps: { value: _vm.detail.paymentMode },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.detail,
                                "paymentMode",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _vm._m(3)
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4 offset-4" }, [
                        _c("label", [_vm._v("Total Payable")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.header.billing,
                              expression: "header.billing"
                            }
                          ],
                          staticClass: "form-control text-right",
                          attrs: {
                            type: "text",
                            name: "billing",
                            placeholder: "",
                            disabled: ""
                          },
                          domProps: { value: _vm.header.billing },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.header,
                                "billing",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-4" }, [
                        _c("label", [_vm._v("Check No")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.detail.check_no,
                              expression: "detail.check_no"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "check_no",
                            placeholder: ""
                          },
                          domProps: { value: _vm.detail.check_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.detail,
                                "check_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4" }, [
                        _c("label", [_vm._v("OR/ Ref Number")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.detail.orNumber,
                              expression: "detail.orNumber"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "orNumber",
                            placeholder: ""
                          },
                          domProps: { value: _vm.detail.orNumber },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.detail,
                                "orNumber",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4" }, [
                        _c("label", [_vm._v("Check/ Payment Date")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.detail.check_date,
                              expression: "detail.check_date"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "date",
                            name: "check_date",
                            placeholder: "",
                            required: ""
                          },
                          domProps: { value: _vm.detail.check_date },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.detail,
                                "check_date",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-8" }, [
                        _c("label", [_vm._v("Remarks")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.detail.remarks,
                              expression: "detail.remarks"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "remarks",
                            placeholder: ""
                          },
                          domProps: { value: _vm.detail.remarks },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.detail,
                                "remarks",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4" }, [
                        _c("label", [_vm._v("Payment/ Check Amount")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.detail.check_amount,
                              expression: "detail.check_amount"
                            }
                          ],
                          staticClass: "form-control text-right",
                          attrs: {
                            type: "text",
                            name: "check_amount",
                            placeholder: "",
                            required: ""
                          },
                          domProps: { value: _vm.detail.check_amount },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.detail,
                                "check_amount",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-12 text-right" }, [
                        _c("label", [_vm._v(" ")]),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-group" }, [
                          _c(
                            "button",
                            {
                              staticClass: "btn btn-primary",
                              attrs: { type: "button", bold: "" },
                              on: {
                                click: function($event) {
                                  return _vm.clearFunction("detail")
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-eraser",
                                attrs: { "aria-hidden": "true" }
                              }),
                              _vm._v(
                                "\n                                            CLEAR\n                                        "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _vm._m(4)
                        ])
                      ])
                    ])
                  ]
                )
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("search-fuelHeader", {
        on: {
          rowClick: function($event) {
            return _vm.fuelHeaderClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-fuelDetail")
    ],
    1
  )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "col-xs-12" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col" }, [
          _c("h2", { staticClass: "card-title" }, [
            _c("b", [
              _vm._v("DAR Statistics Per Pay Station(AVERAGE HEAD COUNT)")
            ])
          ])
        ])
=======
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("FUEL PAYMENT FORM")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [_vm._v("SOA No")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                        PERIOD\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("LOCATION")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [_vm._v("DATE")]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                        Total Billing\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                        Balance\n                                    "
          )
        ]),
        _vm._v(" "),
        _c(
          "th",
          { staticClass: "text-center", staticStyle: { width: "10%" } },
          [
            _vm._v(
              "\n                                        ACTION\n                                    "
            )
          ]
        )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "col-xs-12" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col" }, [
          _c("h2", { staticClass: "card-title" }, [
            _c("b", [_vm._v("DAR Statistics Per Pay Station(TOTAL AMOUNT)")])
          ])
=======
    return _c("td", { staticClass: "text-center", attrs: { colspan: "5" } }, [
      _c("i", [_vm._v("No Data Found...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("datalist", { attrs: { id: "modePayment" } }, [
      _c("option", [_vm._v("CHECK")]),
      _vm._v(" "),
      _c("option", [_vm._v("CASH")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      { staticClass: "btn btn-success", attrs: { type: "submit", bold: "" } },
      [
        _c("i", {
          staticClass: "fa fa-save",
          attrs: { "aria-hidden": "true" }
        }),
        _vm._v(
          "\n                                            SAVE\n                                        "
        )
      ]
    )
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=template&id=79ea24f1&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=template&id=79ea24f1& ***!
  \***********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "SearchFUELDetail",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-lg",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: !_vm.dataInDetail,
                                    expression: "!dataInDetail"
                                  }
                                ]
                              },
                              [_vm._m(2)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.filteredBlogs, function(item) {
                              return _c("tr", { key: item.PEDID }, [
                                _c("td", [
                                  _vm._v(
                                    _vm._s(_vm._f("formatDate")(item.Date))
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.InvoiceNo))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Description))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Qty))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Unit))]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(
                                    _vm._s(_vm._f("formatNumber")(item.Price))
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(
                                        _vm._f("formatNumber")(item.Amount)
                                      ) +
                                      "\n                                    "
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("FUEL Detail List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("thead", [
      _c("tr", [
        _c("th", { staticStyle: { "text-align": "right" } }, [_vm._v("#")]),
        _vm._v(" "),
        _c("th", { staticStyle: { "text-align": "right" } }, [
          _vm._v("Pay Station")
        ]),
        _vm._v(" "),
        _c("th", { staticStyle: { "text-align": "right" } }, [
          _vm._v("Average Head Count")
        ]),
        _vm._v(" "),
        _c("th", { staticStyle: { "text-align": "right" } }, [_vm._v("Amount")])
      ])
    ])
=======
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("Invoice No.")]),
        _vm._v(" "),
        _c("th", [_vm._v("Description")]),
        _vm._v(" "),
        _c("th", [_vm._v("Qty")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit Price")]),
        _vm._v(" "),
        _c("th", [_vm._v("Amount")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "7" } }, [
      _c("i", [_vm._v("No Data Found...")])
    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/AdminComponents/BarChart.js":
/*!*************************************************************!*\
  !*** ./resources/js/components/AdminComponents/BarChart.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_chartjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-chartjs */ "./node_modules/vue-chartjs/es/index.js");

var reactiveProp = vue_chartjs__WEBPACK_IMPORTED_MODULE_0__["mixins"].reactiveProp;
/* harmony default export */ __webpack_exports__["default"] = ({
  "extends": vue_chartjs__WEBPACK_IMPORTED_MODULE_0__["Bar"],
  mixins: [reactiveProp],
  props: ['options'],
  mounted: function mounted() {
    // this.chartData is created in the mixin.
    // If you want to pass options please create a local options object
    this.renderChart(this.chartData, this.options);
  }
});

/***/ }),

/***/ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue ***!
  \**************************************************************************************/
=======
/***/ "./resources/js/components/FUEL/Payment.vue":
/*!**************************************************!*\
  !*** ./resources/js/components/FUEL/Payment.vue ***!
  \**************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _DARReportsPerPayStationComponent_vue_vue_type_template_id_5dfc6f33___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33& */ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33&");
/* harmony import */ var _DARReportsPerPayStationComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DARReportsPerPayStationComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

=======
/* harmony import */ var _Payment_vue_vue_type_template_id_41a82bd8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Payment.vue?vue&type=template&id=41a82bd8& */ "./resources/js/components/FUEL/Payment.vue?vue&type=template&id=41a82bd8&");
/* harmony import */ var _Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Payment.vue?vue&type=script&lang=js& */ "./resources/js/components/FUEL/Payment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _DARReportsPerPayStationComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DARReportsPerPayStationComponent_vue_vue_type_template_id_5dfc6f33___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DARReportsPerPayStationComponent_vue_vue_type_template_id_5dfc6f33___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Payment_vue_vue_type_template_id_41a82bd8___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Payment_vue_vue_type_template_id_41a82bd8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue"
=======
component.options.__file = "resources/js/components/FUEL/Payment.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************/
=======
/***/ "./resources/js/components/FUEL/Payment.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./resources/js/components/FUEL/Payment.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./DARReportsPerPayStationComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************!*\
  !*** ./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************/
/*! no static exports found */
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Payment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/Payment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/FUEL/Payment.vue?vue&type=template&id=41a82bd8&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/FUEL/Payment.vue?vue&type=template&id=41a82bd8& ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Payment_vue_vue_type_template_id_41a82bd8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Payment.vue?vue&type=template&id=41a82bd8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/Payment.vue?vue&type=template&id=41a82bd8&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Payment_vue_vue_type_template_id_41a82bd8___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Payment_vue_vue_type_template_id_41a82bd8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/FUEL/ShowDetailModal.vue":
/*!**********************************************************!*\
  !*** ./resources/js/components/FUEL/ShowDetailModal.vue ***!
  \**********************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33& ***!
  \*********************************************************************************************************************/
=======
/* harmony import */ var _ShowDetailModal_vue_vue_type_template_id_79ea24f1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ShowDetailModal.vue?vue&type=template&id=79ea24f1& */ "./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=template&id=79ea24f1&");
/* harmony import */ var _ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ShowDetailModal.vue?vue&type=script&lang=js& */ "./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ShowDetailModal_vue_vue_type_template_id_79ea24f1___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ShowDetailModal_vue_vue_type_template_id_79ea24f1___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/FUEL/ShowDetailModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ShowDetailModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=template&id=79ea24f1&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=template&id=79ea24f1& ***!
  \*****************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_template_id_5dfc6f33___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/AdminComponents/DARReportsPerPayStationComponent.vue?vue&type=template&id=5dfc6f33&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_template_id_5dfc6f33___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DARReportsPerPayStationComponent_vue_vue_type_template_id_5dfc6f33___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_template_id_79ea24f1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./ShowDetailModal.vue?vue&type=template&id=79ea24f1& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/ShowDetailModal.vue?vue&type=template&id=79ea24f1&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_template_id_79ea24f1___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_template_id_79ea24f1___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);