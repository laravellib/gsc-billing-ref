(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[83],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _search_SearchPHB_SearchPHBVehicle_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchPHB/SearchPHBVehicle.vue */ "./resources/js/components/search/SearchPHB/SearchPHBVehicle.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======
/* harmony import */ var _Vanrental_Menu_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Vanrental-Menu.vue */ "./resources/js/components/vanrental/Vanrental-Menu.vue");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-phbvehicle': _search_SearchPHB_SearchPHBVehicle_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      editmode: false,
      vehiclerates: [],
      vehicles: [],
      form: new Form({
        MVRRID: "",
        MVID_Link: "",
        PlateNumber: "",
        EffectiveDate: "",
        PerTransactionRate: "",
        DailyRate: "",
        PerKilometerRate: "",
        PerHourRate: "",
        PerAreaRate: "",
        FixedMonthlyRate: "",
        PerBagRate: "",
        PerDestinationRate: "",
        Status: ""
      })
    };
  },
  mounted: function mounted() {
    this.$parent.getSearchVehicleRate();
  },
  methods: {
    updateTitleVehicle: function updateTitleVehicle(updatedTitleVehicle) {
      this.form.MVID_Link = updatedTitleVehicle.MVID;
      this.form.PlateNumber = updatedTitleVehicle.PlateNumber;
    },
    searchVehicleFunction: function searchVehicleFunction() {
      $('#searchVehicle').modal('show');
    },
    getVehicleIsReal: function getVehicleIsReal() {
      var _this = this;

      axios.get("api/vehicle").then(function (_ref) {
        var data = _ref.data;
        return _this.vehicles = data;
      });
      console.log(this.vehicles);
    },
    getResults: function getResults() {
      var _this2 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/vehiclerate?page=' + page).then(function (response) {
        _this2.vehiclerates = response.data;
      });
    },
    updateVehicleRate: function updateVehicleRate(MVTID) {
      this.$Progress.start();
      this.form.put('api/phbvehiclerate/' + this.form.MVRRID);
      $('#addNew').modal('hide');
      toast.fire({
        icon: "success",
        title: "Vehicle Rate successfully updated"
      });
      this.$Progress.finish();
      this.loadVehicleRate();
    },
    deleteModal: function deleteModal(MVRRID) {
      var _this3 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this3.$Progress.start();

          $('#addNew').modal('hide');

          _this3.form["delete"]('api/phbvehiclerate/' + MVRRID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');

          _this3.$Progress.finish();

          _this3.loadVehicleRate();
        }
      });
    },
    editModal: function editModal(vr) {
      this.editmode = true;
      this.form.reset();
      $('#addNew').modal('show');
      this.form.fill(vr);
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      var d = new Date();
      var today = new Date().toISOString().slice(0, 10);
      this.form.EffectiveDate = today;
      $('#addNew').modal('show');
    },
    loadVehicleRate: function loadVehicleRate() {
      var _this4 = this;

      // axios.get("api/vehiclerate").then(({ data }) => (this.vehiclerates = data));
      axios.get('api/getSearchPHBVehicleRate').then(function (response) {
        _this4.vehiclerates = response.data;
        console.log(_this4.vehiclerates);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    createVehicleRate: function createVehicleRate() {
      var _this5 = this;

      this.$Progress.start();
      this.form.post("api/phbvehiclerate").then(function () {
        $('#addNew').modal('hide');
        $('.modal-backdrop').remove();
        toast.fire({
          icon: "success",
          title: "Vehicle Rate successfully created"
        });

        _this5.$Progress.finish();

        _this5.loadVehicleRate();
      })["catch"](function () {
        _this5.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Vehicle Rate not added successfully'
        });
      });
    }
  },
  created: function created() {
    this.loadVehicleRate(); //setInterval(() => this.loadDriver(),3000);
=======

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'vanrental-menu': _Vanrental_Menu_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      drivers: [],
      filter: [],
      editMode: false,
      searching: '',
      form: new Form({
        id: '',
        FirstName: '',
        MiddleName: '',
        LastName: '',
        ExtName: '',
        Address: '',
        GSCDriver: 'Y',
        VehicleType: 'VANRENTAL'
      })
    };
  },
  methods: {
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      this.form.fill(dataItem);
      this.editMode = true;
    },
    search: function search(ev) {
      this.filter = this.golfcart.filter(function (item) {
        return item.Name.match(ev);
      });
    },
    loadDriver: function loadDriver() {
      var _this = this;

      axios.get('api/driver?VehicleType=VANRENTAL').then(function (_ref) {
        var data = _ref.data;
        data.data.forEach(function (item) {
          var FName = item.FirstName ? item.FirstName + ' ' : '';
          var MName = item.MiddleName ? item.MiddleName + ' ' : '';
          var LName = item.LastName ? item.LastName + ' ' : '';
          var ExtName = item.ExtName ? item.ExtName : '';
          item.Name = FName + MName + LName + ExtName;
        });
        _this.drivers = data.data;
        _this.filter = _this.drivers;
      });
    },
    createDriver: function createDriver() {
      var _this2 = this;

      this.$Progress.start();
      this.form.post('api/driver').then(function () {
        toast.fire({
          icon: 'success',
          title: 'Driver successfully created'
        });

        _this2.$Progress.finish();

        _this2.loadDriver();

        _this2.clear();
      })["catch"](function () {
        _this2.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Driver not added successfully'
        });
      });
    },
    updateDriver: function updateDriver(id) {
      this.$Progress.start();
      this.form.put('api/driver/' + this.form.id);
      toast.fire({
        icon: 'success',
        title: 'Driver successfully updated'
      });
      this.$Progress.finish();
      this.loadDriver();
      this.clear();
    },
    deleteData: function deleteData(id) {
      var _this3 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this3.$Progress.start();

          $('#addNew').modal('hide');

          _this3.form["delete"]('api/driver/' + id);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');

          _this3.$Progress.finish();

          _this3.loadDriver();

          _this3.clear();
        }
      });
    },
    clear: function clear() {
      this.editMode = false;
      this.form.reset();
    }
  },
  created: function created() {
    this.loadDriver();
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
});

/***/ }),
<<<<<<< HEAD

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n  pointer-events: none;\n}\r\n\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51& ***!
  \****************************************************************************************************************************************************************************************************************************************/
=======

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=template&id=1c461161&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=template&id=1c461161& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      { staticClass: "row" },
      [
        _c("img", { attrs: { src: __webpack_require__(/*! ./PassengerVan.png */ "./resources/js/components/vanrental/PassengerVan.png") } }),
        _vm._v(" "),
        _c("vanrental-menu"),
        _vm._v(" "),
        _c("div", { staticClass: "row mt-3" }, [
          _c("div", { staticClass: "col-sm" }, [
            _vm._v("\n        Add New Passenger Van Driver\n        "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    _vm.editMode ? _vm.updateDriver() : _vm.createDriver()
                  }
                }
              },
              [
                _c("div", { staticClass: "modal-body" }, [
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.FirstName,
                          expression: "form.FirstName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: { "is-invalid": _vm.form.errors.has("name") },
                      attrs: {
                        type: "text",
                        name: "name",
                        placeholder: "First Name"
                      },
                      domProps: { value: _vm.form.FirstName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "FirstName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.MiddleName,
                          expression: "form.MiddleName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "asset_no",
                        placeholder: "Middle Name"
                      },
                      domProps: { value: _vm.form.MiddleName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "MiddleName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.LastName,
                          expression: "form.LastName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "engine_no",
                        placeholder: "Last Name"
                      },
                      domProps: { value: _vm.form.LastName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "LastName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.ExtName,
                          expression: "form.ExtName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "serial_no",
                        placeholder: "Extention Name"
                      },
                      domProps: { value: _vm.form.ExtName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "ExtName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.Address,
                          expression: "form.Address"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "Address",
                        placeholder: "Address"
                      },
                      domProps: { value: _vm.form.Address },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "Address", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.GSCDriver,
                          expression: "form.GSCDriver"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "serial_no",
                        placeholder: "GSC Driver?"
                      },
                      domProps: { value: _vm.form.GSCDriver },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "GSCDriver", $event.target.value)
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "modal-footer" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { type: "submit" }
                    },
                    [_vm._v(_vm._s(_vm.editMode ? "Update" : "Add New"))]
                  ),
                  _vm._v(" "),
                  _vm.editMode
                    ? _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              return _vm.deleteData(_vm.form.id)
                            }
                          }
                        },
                        [_vm._v("Delete")]
                      )
                    : _vm._e()
                ])
              ]
            )
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "col-sm-8" },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.searching,
                    expression: "searching"
                  }
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "text", placeholder: "Search by Name..." },
                domProps: { value: _vm.searching },
                on: {
                  keyup: function($event) {
                    return _vm.search(_vm.searching)
                  },
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.searching = $event.target.value
                  }
                }
              }),
              _vm._v(" "),
              _c(
                "kendo-grid",
                {
                  attrs: {
                    height: 400,
                    "data-source": _vm.filter,
                    selectable: true,
                    sortable: true
                  },
                  on: { change: _vm.onChange }
                },
                [
                  _c("kendo-grid-column", {
                    attrs: { field: "id", title: "ID" }
                  }),
                  _vm._v(" "),
                  _c("kendo-grid-column", {
                    attrs: { field: "Name", title: "Name" }
                  }),
                  _vm._v(" "),
                  _c("kendo-grid-column", {
                    attrs: { field: "Address", title: "Address" }
                  })
                ],
                1
              )
            ],
            1
          )
        ])
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/vanrental/Vanrental-Menu.vue?vue&type=template&id=23e29778&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/vanrental/Vanrental-Menu.vue?vue&type=template&id=23e29778& ***!
  \***************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
<<<<<<< HEAD
    "div",
    { staticClass: "container" },
    [
      _c(
        "nav",
        {
          staticClass:
            "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
        },
        [
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNavDropdown" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#mlist"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Master File\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "mlist"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/driverlist" }
                            },
                            [_c("a", [_vm._v("Driver List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/phbvehiclelist" }
                            },
                            [_c("a", [_vm._v("PHB Vehicle List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehicletype" }
                            },
                            [_c("a", [_vm._v("Vehicle Type List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/phbvehiclerate" }
                            },
                            [_c("a", [_vm._v("PHB Rate List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/clientlist" }
                            },
                            [_c("a", [_vm._v("Client List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/locationlist" }
                            },
                            [_c("a", [_vm._v("Location List")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#trans"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Transactions\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "trans"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/phbvehiclelogentry" }
                            },
                            [_c("a", [_vm._v("PHB Vehicle Log Entry")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#report"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              PHB Reports\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "report"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistPHB" }
                            },
                            [_c("a", [_vm._v("Standard PHB Report")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistPHBPerJeep" }
                            },
                            [
                              _c("a", [
                                _vm._v("PHB's Vehicle Log Billing Report")
                              ])
                            ]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ])
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }, [
              _c(
                "button",
                { staticClass: "btn btn-success", on: { click: _vm.newModal } },
                [
                  _vm._v("\n            Add New Vehicle Rate\n            "),
                  _c("i", { staticClass: "fa fa-user-plus fa fw" })
                ]
              )
            ]),
            _vm._v(" "),
            _c("br")
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _c(
                  "tbody",
                  [
                    _vm._m(1),
                    _vm._v(" "),
                    _vm._l(_vm.vehiclerates, function(vr) {
                      return _c("tr", { key: vr.MVRRID }, [
                        _c("td", [_vm._v(_vm._s(vr.PlateNumber))]),
                        _vm._v(" "),
                        _c("td", [
                          _vm._v(_vm._s(_vm._f("formatDate")(vr.EffectiveDate)))
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _vm._v(
                            _vm._s(
                              "Php " +
                                vr.PerKilometerRate.toLocaleString(undefined, {
                                  maximumFractionDigits: 2,
                                  minimumFractionDigits: 2
                                })
                            )
                          )
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "a",
                            {
                              attrs: { href: "#" },
                              on: {
                                click: function($event) {
                                  return _vm.editModal(vr)
                                }
                              }
                            },
                            [_c("i", { staticClass: "fa fa-edit" })]
                          ),
                          _vm._v("\n                /\n                "),
                          _c(
                            "a",
                            {
                              attrs: { href: "#" },
                              on: {
                                click: function($event) {
                                  return _vm.deleteModal(vr.MVRRID)
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-trash",
                                staticStyle: { color: "red" }
                              })
                            ]
                          )
                        ])
                      ])
                    })
                  ],
                  2
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" })
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-dialog-centered",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Vehicle Rate")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Vehicle Rate's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(2)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode
                          ? _vm.updateVehicleRate()
                          : _vm.createVehicleRate()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "form-inline" }, [
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: {
                                "margin-left": "5px",
                                "text-transform": "uppercase"
                              }
                            },
                            [
                              _vm._m(3),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.MVID_Link,
                                    expression: "form.MVID_Link"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "MVID_Link",
                                  placeholder: "MVID Link"
                                },
                                domProps: { value: _vm.form.MVID_Link },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "MVID_Link",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.PlateNumber,
                                    expression: "form.PlateNumber"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "PlateNumber",
                                  placeholder: "Plate Number",
                                  "data-readonly": "",
                                  required: ""
                                },
                                domProps: { value: _vm.form.PlateNumber },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "PlateNumber",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "b-input-group-append",
                                [
                                  _c(
                                    "b-button",
                                    {
                                      attrs: {
                                        variant: "outline-primary",
                                        size: "sm"
                                      },
                                      on: {
                                        click: function($event) {
                                          return _vm.searchVehicleFunction()
                                        }
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-search",
                                        attrs: { "aria-hidden": "true" }
                                      })
                                    ]
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-inline" }, [
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(4),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.EffectiveDate,
                                    expression: "form.EffectiveDate"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "date",
                                  placeholder: "Effective Date",
                                  required: ""
                                },
                                domProps: { value: _vm.form.EffectiveDate },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "EffectiveDate",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ]
                          )
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-inline" }, [
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(5),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.PerKilometerRate,
                                    expression: "form.PerKilometerRate"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "decimal",
                                  placeholder: "Per Kilometer Rate"
                                },
                                domProps: { value: _vm.form.PerKilometerRate },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "PerKilometerRate",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ]
                          )
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-phbvehicle", {
        on: {
          changeTitleVehicle: function($event) {
            return _vm.updateTitleVehicle($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("PHB Rate List")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", [_vm._v("Plate Number")]),
      _vm._v(" "),
      _c("th", [_vm._v("Effective Date")]),
      _vm._v(" "),
      _c("th", [_vm._v("Per Kilometer Rate")]),
      _vm._v(" "),
      _c("th", [_vm._v("Modify")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Plate Number")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("EffectiveDate")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Per Kilometer Rate")
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue ***!
  \***************************************************************************/
=======
    "nav",
    { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
    [
      _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
        _vm._v("VAN RENTAL SECTION")
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "collapse navbar-collapse", attrs: { id: "navbarNav" } },
        [
          _c("ul", { staticClass: "navbar-nav" }, [
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-list"
                    }
                  },
                  [_vm._v("Van Rental List")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-location"
                    }
                  },
                  [_vm._v("Route")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-driver"
                    }
                  },
                  [_vm._v("Driver")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-po"
                    }
                  },
                  [_vm._v("Purchase Order")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-rental"
                    }
                  },
                  [_vm._v("Rental")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-soa"
                    }
                  },
                  [_vm._v("Create SOA")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-payment"
                    }
                  },
                  [_vm._v("Payment Collection")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-ledger"
                    }
                  },
                  [_vm._v("Ledger")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/vanrental-reports"
                    }
                  },
                  [_vm._v("Reports")]
                )
              ],
              1
            )
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/vanrental/PassengerVan.png":
/*!************************************************************!*\
  !*** ./resources/js/components/vanrental/PassengerVan.png ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/PassengerVan.png?1d66cde6a45ab3ac874df6a6542dc9f6";

/***/ }),

/***/ "./resources/js/components/vanrental/VanRental-Driver.vue":
/*!****************************************************************!*\
  !*** ./resources/js/components/vanrental/VanRental-Driver.vue ***!
  \****************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _PHBVehicleRateComponent_vue_vue_type_template_id_47a3ee51___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51& */ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51&");
/* harmony import */ var _PHBVehicleRateComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PHBVehicleRateComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _VanRental_Driver_vue_vue_type_template_id_1c461161___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VanRental-Driver.vue?vue&type=template&id=1c461161& */ "./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=template&id=1c461161&");
/* harmony import */ var _VanRental_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VanRental-Driver.vue?vue&type=script&lang=js& */ "./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





<<<<<<< HEAD

/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PHBVehicleRateComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PHBVehicleRateComponent_vue_vue_type_template_id_47a3ee51___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PHBVehicleRateComponent_vue_vue_type_template_id_47a3ee51___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VanRental_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _VanRental_Driver_vue_vue_type_template_id_1c461161___WEBPACK_IMPORTED_MODULE_0__["render"],
  _VanRental_Driver_vue_vue_type_template_id_1c461161___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/PHBComponents/PHBVehicleRateComponent.vue"
=======
component.options.__file = "resources/js/components/vanrental/VanRental-Driver.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
=======
/***/ "./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleRateComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51& ***!
  \**********************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VanRental_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./VanRental-Driver.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VanRental_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=template&id=1c461161&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=template&id=1c461161& ***!
  \***********************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_template_id_47a3ee51___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleRateComponent.vue?vue&type=template&id=47a3ee51&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_template_id_47a3ee51___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleRateComponent_vue_vue_type_template_id_47a3ee51___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VanRental_Driver_vue_vue_type_template_id_1c461161___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./VanRental-Driver.vue?vue&type=template&id=1c461161& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/vanrental/VanRental-Driver.vue?vue&type=template&id=1c461161&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VanRental_Driver_vue_vue_type_template_id_1c461161___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VanRental_Driver_vue_vue_type_template_id_1c461161___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/vanrental/Vanrental-Menu.vue":
/*!**************************************************************!*\
  !*** ./resources/js/components/vanrental/Vanrental-Menu.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Vanrental_Menu_vue_vue_type_template_id_23e29778___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Vanrental-Menu.vue?vue&type=template&id=23e29778& */ "./resources/js/components/vanrental/Vanrental-Menu.vue?vue&type=template&id=23e29778&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _Vanrental_Menu_vue_vue_type_template_id_23e29778___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Vanrental_Menu_vue_vue_type_template_id_23e29778___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/vanrental/Vanrental-Menu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/vanrental/Vanrental-Menu.vue?vue&type=template&id=23e29778&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/components/vanrental/Vanrental-Menu.vue?vue&type=template&id=23e29778& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Vanrental_Menu_vue_vue_type_template_id_23e29778___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Vanrental-Menu.vue?vue&type=template&id=23e29778& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/vanrental/Vanrental-Menu.vue?vue&type=template&id=23e29778&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Vanrental_Menu_vue_vue_type_template_id_23e29778___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Vanrental_Menu_vue_vue_type_template_id_23e29778___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);