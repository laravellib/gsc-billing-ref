(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[117],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _search_SearchAllowance_SearchTransmittal_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchAllowance/SearchTransmittal.vue */ "./resources/js/components/search/SearchAllowance/SearchTransmittal.vue");
/* harmony import */ var _allowance_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../allowance/ShowDetailModal.vue */ "./resources/js/components/allowance/ShowDetailModal.vue");
/* harmony import */ var _search_SearchAllowance_SearchSOAAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSOAAllowanceHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchSOAAllowanceHeader.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "search-transmittal": _search_SearchAllowance_SearchTransmittal_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-allowanceDetail": _allowance_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "search-allowanceSOAHeader": _search_SearchAllowance_SearchSOAAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
<<<<<<< HEAD
      from: this.$root.formatDate(new Date()),
      to: this.$root.formatDate(new Date()),
      checkTableArrays: [],
      checkHeader: false,
      rows: [],
      search: "",
      transmittal_no: "",
      prepared_by: "",
      SOANo: "",
      SoaTransNo: ""
=======
      editmode: false,
      vehicletypes: {},
      form: new Form({
        MVTID: '',
        MVType: ''
      })
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    };
  },
  mounted: function mounted() {
    this.generate();
    this.getUser();
    this.getTransmittal();
  },
  methods: {
<<<<<<< HEAD
    checkTableAll: function checkTableAll() {
      console.log(this.rows);

      if (!this.checkHeader) {
        var arrays = [];
        var index = 0;
        this.rows.forEach(function (item) {
          arrays.push(item);
          document.getElementById(item.AHID).checked = true;
        });
        this.checkTableArrays = arrays;
      } else {
        this.rows.forEach(function (item) {
          document.getElementById(item.AHID).checked = false;
        });
        this.checkTableArrays = [];
      }
    },
    checkTable: function checkTable(row) {
      if (this.checkTableArrays.indexOf(row) < 0) {
        this.checkTableArrays.push(row);
      } else {
        this.checkTableArrays.splice(this.checkTableArrays.indexOf(row), 1);
      }
    },
    generate: function generate() {
      var _this = this;

      this.checkHeader = false;
      this.checkTableArrays = [];
      axios.get("api/allowance", {
        params: {
          SOAHeaderDate: true,
          from: this.from,
          to: this.to
        }
      }).then(function (response) {
        _this.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getUser: function getUser() {
=======
    getResults: function getResults() {
      var _this = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/vehicletype?page=' + page).then(function (response) {
        _this.vehicletypes = response.data;
      });
    },
    updateVehicleType: function updateVehicleType(MVTID) {
      this.$Progress.start();
      this.form.put('api/vehicletype/' + this.form.MVTID);
      $('#addNew').modal('hide');
      toast.fire({
        icon: 'success',
        title: 'Vehicle Type successfully updated'
      });
      this.$Progress.finish();
      this.loadVehicleType();
    },
    deleteModal: function deleteModal(MVTID) {
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      var _this2 = this;

      axios.get("api/allowance", {
        params: {
          getUser: true
        }
      }).then(function (response) {
        _this2.prepared_by = response.data.name;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getTransmittal: function getTransmittal() {
      var _this3 = this;

      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getTransmittalNo: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          _this3.transmittal_no = response.data;
        } else {
          var dateNow = new Date();
          var month = dateNow.getMonth() + 1;
          _this3.transmittal_no = "TF" + dateNow.getFullYear().toString().substring(2) + month.toString().padStart(2, "0") + "-1";
        }

        _this3.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    clickDetails: function clickDetails(id) {
      Fire.$emit("searchAllowanceDetail", id);
    },
    createTransmittal: function createTransmittal() {
      var _this4 = this;

      if (this.checkTableArrays.length < 1) {
        return toast.fire({
          icon: "warning",
          title: "No Data Selected."
        });
      }

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
<<<<<<< HEAD
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Create Transmittal!"
      }).then(function (result) {
        if (result.value) {
          _this4.$Progress.start();

          axios.get("api/allowance", {
            params: {
              searchTransmittalExists: true,
              transmittal_no: _this4.transmittal_no
            }
          }).then(function (response) {
            if (response.data.length > 0) {
              swal.fire({
                title: "Transmittal Number Already Exists!",
                text: "Do you want to merge current selected records?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, Merge it!"
              }).then(function (result) {
                if (result.value) {
                  _this4.$Progress.start();

                  var submitArray = [];

                  _this4.checkTableArrays.forEach(function (item) {
                    submitArray.push(item.SOANo);
                  });

                  var data = {
                    transmittal_no: _this4.transmittal_no,
                    prepared_by: _this4.prepared_by,
                    soa_no_list: submitArray,
                    type: "ALLOWANCE",
                    merge: true
                  };

                  _this4.$Progress.start();

                  axios.post("api/allowanceCreateTransmittal", data).then(function (response) {
                    if (response.data.success) {
                      _this4.checkTableArrays = [];
                      _this4.rows = [];
                      _this4.checkHeader = false;
                      _this4.SOANo = "";
                      _this4.prepared_by = "";
                      _this4.SoaTransNo = "";
                      window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this4.transmittal_no + "&type=ALLOWANCE");
                      _this4.transmittal_no = "";

                      _this4.generate();

                      _this4.getUser();

                      _this4.getTransmittal();
                    } else {
                      toast.fire({
                        icon: "warning",
                        title: response.data.message
                      });
                    }

                    _this4.$Progress.finish();
                  })["catch"](function (error) {
                    console.log(error);
                  });
                } else {
                  swal.fire("Information!", "Cancelled.", "warning");
                }
              });
            } else {
              _this4.$Progress.start();

              var submitArray = [];

              _this4.checkTableArrays.forEach(function (item) {
                submitArray.push(item.SOANo);
              });

              var data = {
                transmittal_no: _this4.transmittal_no,
                prepared_by: _this4.prepared_by,
                type: "ALLOWANCE",
                soa_no_list: submitArray
              };

              _this4.$Progress.start();

              axios.post("api/allowanceCreateTransmittal", data).then(function (response) {
                if (response.data.success) {
                  _this4.checkTableArrays = [];
                  _this4.rows = [];
                  _this4.checkHeader = false;
                  _this4.SOANo = "";
                  _this4.prepared_by = "";
                  _this4.SoaTransNo = "";
                  window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this4.transmittal_no + "&type=ALLOWANCE");
                  _this4.transmittal_no = "";

                  _this4.generate();

                  _this4.getUser();

                  _this4.getTransmittal();
                } else {
                  toast.fire({
                    icon: "warning",
                    title: response.data.message
                  });
                }

                _this4.$Progress.finish();
              })["catch"](function (error) {
                console.log(error);
              });
            }

            _this4.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    removeTransmittal: function removeTransmittal() {
      var _this5 = this;

      if (!this.SOANo) {
        return toast.fire({
          icon: "warning",
          title: "Please select/enter SOA number to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Remove Transmittal #!"
      }).then(function (result) {
        if (result.value) {
          var data = {
            SOANo: _this5.SOANo,
            prepared_by: _this5.prepared_by,
            type: "PPE"
          };

          _this5.$Progress.start();

          axios.post("api/allowanceRemoveTransmittal", data).then(function (response) {
            if (response.data.success) {
              _this5.SOANo = "";
              _this5.SoaTransNo = "";
              toast.fire({
                icon: "success",
                title: response.data.message
              });
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this5.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    searchAllowanceSOAHeaderButton: function searchAllowanceSOAHeaderButton() {
      Fire.$emit("searchSOAAllowanceHeader", "transmittal");
    },
    allowanceSOAHeaderClose: function allowanceSOAHeaderClose(row) {
      this.SoaTransNo = row.SOANo + " ( " + row.transmittal_no + ")";
      this.SOANo = row.SOANo;
    },
    searchTransmittal: function searchTransmittal() {
      Fire.$emit("searchTransmittal", "allowance");
    },
    transmittalClose: function transmittalClose(row) {
      this.transmittal_no = row.transmittal_no;
    },
    printTransmittal: function printTransmittal() {
      var _this6 = this;

      axios.get("api/reportAllowanceTransmittal", {
        params: {
          searchTransmittalExists: true,
          transmittal_no: this.transmittal_no,
          type: "ALLOWANCE"
        }
      }).then(function (response) {
        if (response.data.success) {
          window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this6.transmittal_no + "&type=ALLOWANCE");

          _this6.getTransmittal();
        } else {
          return toast.fire({
            icon: "warning",
            title: "No data found in this transmittal number."
          });
        }

        _this6.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
=======
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this2.$Progress.start();

          $('#addNew').modal('hide');

          _this2.form["delete"]('api/vehicletype/' + MVTID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');

          _this2.$Progress.finish();

          _this2.loadVehicleType();
        }
      });
    },
    editModal: function editModal(vt) {
      this.editmode = true;
      this.form.reset();
      $('#addNew').modal('show');
      this.form.fill(vt);
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      $('#addNew').modal('show');
    },
    loadVehicleType: function loadVehicleType() {
      var _this3 = this;

      axios.get('api/vehicletype').then(function (_ref) {
        var data = _ref.data;
        return _this3.vehicletypes = data;
      });
    },
    createVehicleType: function createVehicleType() {
      var _this4 = this;

      /*this.$Progress.start();
         this.form.post("api/driver");
           $('#addNew').modal('hide');
         $('.modal-backdrop').remove();
         toast.fire({
           icon: "success",
           title: "Driver successfully created"
         });
         this.$Progress.finish();
         this.loadDriver();*/
      this.$Progress.start();
      this.form.post('api/vehicletype').then(function () {
        $('#addNew').modal('hide');
        $('.modal-backdrop').remove();
        toast.fire({
          icon: 'success',
          title: 'Vehicle Type successfully created'
        });

        _this4.$Progress.finish();

        _this4.loadVehicleType();
      })["catch"](function () {
        _this4.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Vehicle Rate not added successfully'
        });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this7 = this;

<<<<<<< HEAD
      return this.rows.filter(function (item) {
        return _this7.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toLowerCase().includes(v);
        });
      });
    }
=======
    Fire.$on('searchingVehicleType', function () {
      var query = _this5.$parent.search;
      axios.get('api/findVehicleType?q=' + query).then(function (data) {
        _this5.vehicletypes = data.data;
      })["catch"](function () {});
    });
    this.loadVehicleType(); //setInterval(() => this.loadDriver(),3000);
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6& ***!
  \************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=template&id=7effa122&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=template&id=7effa122& ***!
  \**************************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c(
    "div",
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12" }, [
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.generate()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-3" }, [
                        _c("div", { staticClass: "form-group" }, [
                          _c("label", [_vm._v("SOA Date From")]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.from,
                                expression: "from"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "date",
                              name: "from",
                              placeholder: ""
                            },
                            domProps: { value: _vm.from },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.from = $event.target.value
                              }
                            }
                          })
                        ])
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-3" }, [
                        _c("div", { staticClass: "form-group" }, [
                          _c("label", [_vm._v("SOA Date From")]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.to,
                                expression: "to"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "date",
                              name: "to",
                              placeholder: ""
                            },
                            domProps: { value: _vm.to },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.to = $event.target.value
                              }
                            }
                          })
                        ])
                      ]),
                      _vm._v(" "),
                      _vm._m(1),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4" }, [
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c("label", [_vm._v("Transmittal Number")]),
                            _vm._v(" "),
                            _c(
                              "b-input-group",
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.transmittal_no,
                                      expression: "transmittal_no"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "transmittal_no",
                                    placeholder: "",
                                    disabled: ""
                                  },
                                  domProps: { value: _vm.transmittal_no },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.transmittal_no = $event.target.value
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "b-input-group-append",
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.getTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-sync",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.searchTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-search",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.printTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-print",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ])
                    ])
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-6 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _c("thead", { staticClass: "dave-thead" }, [
                      _c("tr", [
                        _c(
                          "th",
                          {
                            staticStyle: {
                              "text-align": "center",
                              width: "10%"
                            }
                          },
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.checkHeader,
                                  expression: "checkHeader"
                                }
                              ],
                              staticStyle: { height: "10px !important" },
                              attrs: {
                                type: "checkbox",
                                checked: "checked",
                                id: "checkboxAll"
                              },
                              domProps: {
                                checked: Array.isArray(_vm.checkHeader)
                                  ? _vm._i(_vm.checkHeader, null) > -1
                                  : _vm.checkHeader
                              },
                              on: {
                                click: function($event) {
                                  return _vm.checkTableAll()
                                },
                                change: function($event) {
                                  var $$a = _vm.checkHeader,
                                    $$el = $event.target,
                                    $$c = $$el.checked ? true : false
                                  if (Array.isArray($$a)) {
                                    var $$v = null,
                                      $$i = _vm._i($$a, $$v)
                                    if ($$el.checked) {
                                      $$i < 0 &&
                                        (_vm.checkHeader = $$a.concat([$$v]))
                                    } else {
                                      $$i > -1 &&
                                        (_vm.checkHeader = $$a
                                          .slice(0, $$i)
                                          .concat($$a.slice($$i + 1)))
                                    }
                                  } else {
                                    _vm.checkHeader = $$c
                                  }
                                }
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v("SOA")
                        ]),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v(
                            "\n                                        Billed Amount\n                                    "
                          )
                        ]),
                        _vm._v(" "),
                        _c(
                          "th",
                          {
                            staticStyle: {
                              "text-align": "center",
                              width: "20%"
                            }
                          },
                          [
                            _vm._v(
                              "\n                                        Action\n                                    "
                            )
                          ]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody modal-tbody" },
                      _vm._l(_vm.filteredBlogs, function(item) {
                        return _c("tr", { key: item.id }, [
                          _c(
                            "td",
                            {
                              staticStyle: {
                                width: "10%",
                                "text-align": "center"
                              }
                            },
                            [
                              _c("input", {
                                staticStyle: { height: "10px !important" },
                                attrs: { id: item.AHID, type: "checkbox" },
                                on: {
                                  click: function($event) {
                                    return _vm.checkTable(item)
                                  }
                                }
                              })
                            ]
                          ),
                          _vm._v(" "),
                          _c("td", { staticClass: "text-center" }, [
                            _vm._v(
                              "\n                                        " +
                                _vm._s(item.SOANo) +
                                "\n                                    "
                            )
                          ]),
                          _vm._v(" "),
                          _c("td", { staticClass: "text-center" }, [
                            _vm._v(
                              "\n                                        " +
                                _vm._s(
                                  _vm._f("formatNumber")(item.TotalAmount)
                                ) +
                                "\n                                    "
                            )
                          ]),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-center",
                              staticStyle: { width: "20%" }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-eye text-primary",
                                staticStyle: { "font-size": "120%" },
                                on: {
                                  click: function($event) {
                                    return _vm.clickDetails(item.AHID)
                                  }
                                }
                              })
                            ]
                          )
                        ])
                      }),
                      0
=======
  return _c("div", { staticClass: "container" }, [
    _c(
      "nav",
      {
        staticClass:
          "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
      },
      [
        _c(
          "div",
          {
            staticClass: "collapse navbar-collapse",
            attrs: { id: "navbarNavDropdown" }
          },
          [
            _c("ul", { staticClass: "navbar-nav" }, [
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#mlist"
                    }
                  },
                  [
                    _vm._v(
                      "\n                              Master File\n                              "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "mlist"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/driverlist" }
                          },
                          [_c("a", [_vm._v("Driver List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/operatorlist" }
                          },
                          [_c("a", [_vm._v("Operator List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/vehiclelist" }
                          },
                          [_c("a", [_vm._v("JEEP Vehicle List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/vehicletype" }
                          },
                          [_c("a", [_vm._v("Vehicle Type List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/vehiclerate" }
                          },
                          [_c("a", [_vm._v("JEEP Rate List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/clientlist" }
                          },
                          [_c("a", [_vm._v("Client List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ratePercent" }
                          },
                          [_c("a", [_vm._v("Admin Rate Percentage")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#trans"
                    }
                  },
                  [
                    _vm._v(
                      "\n                              Transactions\n                              "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "trans"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/jeepvehiclelogentry" }
                          },
                          [_c("a", [_vm._v("Jeep Vehicle Log Entry")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/createsoa" }
                          },
                          [_c("a", [_vm._v("Create Jeep SOA")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/soatransactions" }
                          },
                          [_c("a", [_vm._v("SOA Transaction")])]
                        )
                      ],
                      1
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                    )
                  ]
                )
              ]),
              _vm._v(" "),
<<<<<<< HEAD
              _c("div", { staticClass: "col-md-6" }, [
                _c("div", { staticClass: "row" }, [
                  _vm._m(2),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-7" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Prepared By")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.prepared_by,
                            expression: "prepared_by"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "prepared_by",
                          placeholder: "",
                          disabled: ""
                        },
                        domProps: { value: _vm.prepared_by },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.prepared_by = $event.target.value
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.createTransmittal()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-check-square",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Create Transmittal\n                                    "
                          )
                        ]
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _vm._m(3),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-7" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", [_vm._v("SOA Number")]),
                        _vm._v(" "),
                        _c(
                          "b-input-group",
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.SoaTransNo,
                                  expression: "SoaTransNo"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "SoaTransNo",
                                placeholder: "",
                                disabled: ""
                              },
                              domProps: { value: _vm.SoaTransNo },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.SoaTransNo = $event.target.value
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "b-input-group-append",
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      variant: "outline-primary",
                                      size: "sm"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.searchAllowanceSOAHeaderButton()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-search",
                                      attrs: { "aria-hidden": "true" }
                                    })
                                  ]
                                )
                              ],
                              1
                            )
                          ],
                          1
=======
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#report"
                    }
                  },
                  [
                    _vm._v(
                      "\n                              Jeep Reports\n                              "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "report"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistJVL" }
                          },
                          [_c("a", [_vm._v("Standard Jeep Report")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistJVLPerJeep" }
                          },
                          [
                            _c("a", [
                              _vm._v("Jeepney's Vehicle Log Billing Report")
                            ])
                          ]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/JeepSOATransmittal" }
                          },
                          [_c("a", [_vm._v("Jeepney's SOA Transmittal")])]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        )
                      ],
                      1
                    )
<<<<<<< HEAD
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.removeTransmittal()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-times",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Remove Transmittal\n                                    "
                          )
                        ]
                      )
                    ])
                  ])
                ])
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("search-transmittal", {
        on: {
          rowClick: function($event) {
            return _vm.transmittalClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-allowanceSOAHeader", {
        on: {
          rowClick: function($event) {
            return _vm.allowanceSOAHeaderClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-allowanceDetail")
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("Create/Generate Allowance Transmittal")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-2" }, [
      _c("label", [_vm._v(" ")]),
      _vm._v(" "),
      _c("div", { staticClass: "form-group" }, [
        _c(
          "button",
          {
            staticClass: "btn btn-primary",
            attrs: { type: "submit", bold: "" }
          },
          [
            _c("i", {
              staticClass: "fa fa-search",
              attrs: { "aria-hidden": "true" }
            }),
            _vm._v(
              "\n                                            SEARCH\n                                        "
            )
          ]
        )
      ])
=======
                  ]
                )
              ])
            ])
          ]
        )
      ]
    ),
    _vm._v(" "),
    _c("div", { staticClass: "col-xs-12" }, [
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-header" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-tools" }, [
            _c(
              "button",
              { staticClass: "btn btn-success", on: { click: _vm.newModal } },
              [
                _vm._v("\n            Add New Vehicle Type\n            "),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            )
          ]),
          _vm._v(" "),
          _c("br")
        ]),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "card-body table-responsive pre-scrollable" },
          [
            _c("table", { staticClass: "table table-hover" }, [
              _c(
                "tbody",
                [
                  _vm._m(1),
                  _vm._v(" "),
                  _vm._l(_vm.vehicletypes.data, function(vt) {
                    return _c("tr", { key: vt.MVTID }, [
                      _c("td", [_vm._v(_vm._s(vt.MVTID))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(vt.MVType))]),
                      _vm._v(" "),
                      _c("td", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.editModal(vt)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-edit" })]
                        ),
                        _vm._v("\n                /\n                "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.deleteModal(vt.MVTID)
                              }
                            }
                          },
                          [
                            _c("i", {
                              staticClass: "fa fa-trash",
                              staticStyle: { color: "red" }
                            })
                          ]
                        )
                      ])
                    ])
                  })
                ],
                2
              )
            ])
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "card-footer" },
          [
            _c("pagination", {
              attrs: { data: _vm.vehicletypes },
              on: { "pagination-change-page": _vm.getResults }
            })
          ],
          1
        )
      ])
    ]),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "addNew",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c(
          "div",
          {
            staticClass: "modal-dialog modal-dialog-centered",
            attrs: { role: "document" }
          },
          [
            _c("div", { staticClass: "modal-content" }, [
              _c("div", { staticClass: "modal-header" }, [
                _c(
                  "h5",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: !_vm.editmode,
                        expression: "!editmode"
                      }
                    ],
                    staticClass: "modal-title",
                    attrs: { id: "addNewLabel" }
                  },
                  [_vm._v("Add New Driver")]
                ),
                _vm._v(" "),
                _c(
                  "h5",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.editmode,
                        expression: "editmode"
                      }
                    ],
                    staticClass: "modal-title",
                    attrs: { id: "addNewLabel" }
                  },
                  [_vm._v("Update Driver's Info")]
                ),
                _vm._v(" "),
                _vm._m(2)
              ]),
              _vm._v(" "),
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      _vm.editmode
                        ? _vm.updateVehicleType()
                        : _vm.createVehicleType()
                    }
                  }
                },
                [
                  _c("div", { staticClass: "modal-body" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.form.MVType,
                            expression: "form.MVType"
                          }
                        ],
                        staticClass: "form-control",
                        staticStyle: { "text-transform": "uppercase" },
                        attrs: {
                          type: "text",
                          name: "MVType",
                          placeholder: "Motor Vehicle Name",
                          required: ""
                        },
                        domProps: { value: _vm.form.MVType },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.form, "MVType", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-footer" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-secondary",
                        attrs: { type: "button", "data-dismiss": "modal" }
                      },
                      [_vm._v("Close")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: !_vm.editmode,
                            expression: "!editmode"
                          }
                        ],
                        staticClass: "btn btn-primary",
                        attrs: { type: "submit" }
                      },
                      [_vm._v("Save")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.editmode,
                            expression: "editmode"
                          }
                        ],
                        staticClass: "btn btn-success",
                        attrs: { type: "submit" }
                      },
                      [_vm._v("Update")]
                    )
                  ])
                ]
              )
            ])
          ]
        )
      ]
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("Vehicle Type List")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "col-md-12" }, [
      _c("h6", [_c("b", [_c("i", [_vm._v("Create/Generate Transmittal")])])])
=======
    return _c("tr", [
      _c("th", [_vm._v("ID")]),
      _vm._v(" "),
      _c("th", [_vm._v("Moto Vehicle Type")]),
      _vm._v(" "),
      _c("th", [_vm._v("Modify")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "col-md-12" }, [
      _c("h6", [_c("b", [_c("i", [_vm._v("Remove Transmittal Number")])])])
    ])
=======
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/allowance/Transmittal.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/allowance/Transmittal.vue ***!
  \***********************************************************/
=======
/***/ "./resources/js/components/JeepComponents/VehicleTypeComponent.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleTypeComponent.vue ***!
  \*************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Transmittal.vue?vue&type=template&id=d1924bc6& */ "./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&");
/* harmony import */ var _Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Transmittal.vue?vue&type=script&lang=js& */ "./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&");
=======
/* harmony import */ var _VehicleTypeComponent_vue_vue_type_template_id_7effa122___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleTypeComponent.vue?vue&type=template&id=7effa122& */ "./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=template&id=7effa122&");
/* harmony import */ var _VehicleTypeComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleTypeComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=script&lang=js&");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _VehicleTypeComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleTypeComponent_vue_vue_type_template_id_7effa122___WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleTypeComponent_vue_vue_type_template_id_7effa122___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/allowance/Transmittal.vue"
=======
component.options.__file = "resources/js/components/JeepComponents/VehicleTypeComponent.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
=======
/***/ "./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Transmittal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6& ***!
  \******************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleTypeComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleTypeComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleTypeComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=template&id=7effa122&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=template&id=7effa122& ***!
  \********************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Transmittal.vue?vue&type=template&id=d1924bc6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleTypeComponent_vue_vue_type_template_id_7effa122___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleTypeComponent.vue?vue&type=template&id=7effa122& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleTypeComponent.vue?vue&type=template&id=7effa122&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleTypeComponent_vue_vue_type_template_id_7effa122___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleTypeComponent_vue_vue_type_template_id_7effa122___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);