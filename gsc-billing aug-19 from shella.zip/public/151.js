(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[151],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/OthersEntry.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Others/OthersEntry.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSignatories.vue */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue");
/* harmony import */ var _search_SearchAllowance_SearchOthersHeader_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchAllowance/SearchOthersHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchOthersHeader.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "search-signatory": _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-othersHeader": _search_SearchAllowance_SearchOthersHeader_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      rows: [],
      search: "",
      type: "",
      formHeader: {
        OHID: "",
        SOANo: "",
        Prepared_by: this.user,
        Prepared_by_desig: "Encoder/User",
        Checked_by: "CATRINA B. OPEÑA",
        Checked_by_desig: "",
        Noted_by: "BERNARDITO M. GARCIA",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        Approved_by2: "",
        Approved_by_desig2: ""
      },
      header: {
        OHID: "",
        SOANo: "",
        Prepared_by: "",
        Prepared_by_desig: "",
        Checked_by: "",
        Checked_by_desig: "",
        Noted_by: "",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        Approved_by2: "",
        Approved_by_desig2: ""
      },
      dtl: {
        OEDID: "",
        hdr_idLink: "",
        Date: this.$root.formatDate(new Date()),
        InvoiceNo: "",
        Qty: "0",
        Unit: "",
        Description: "",
        Price: "0.00",
        Amount: "0.00",
        Supplier: "",
        GL: "",
        CC: "",
        markup: "",
        subPrice: "0.00",
        subtAmount: "0.00"
      },
      details: [],
      dtlData: false,
      updateMeHeader: false,
      TotalAmount: "0.00",
      markup: 0,
      CCList: [],
      GLList: [],
      reportData: {
        to: "",
        thru: "",
        body: "",
        body2: "",
        Prepared_by: "",
        Prepared_by_desig: "",
        Checked_by: "",
        Checked_by_desig: "",
        Noted_by: "",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        department: "",
        url1: "",
        url2: ""
      },
      modalPage: 1,
      depList: []
    };
  },
  mounted: function mounted() {
    this.getDropDownData();
    this.getUser();
  },
  methods: {
    getUser: function getUser() {
      var _this = this;

      axios.get("api/allowance", {
        params: {
          getUser: true
        }
      }).then(function (response) {
        if (response.data) {
          _this.user = response.data.name;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getDropDownData: function getDropDownData() {
      var _this2 = this;

      axios.get("api/allowance", {
        params: {
          getCostCenter: true
        }
      }).then(function (response) {
        console.log(response.data);
        _this2.CCList = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
      axios.get("api/allowance", {
        params: {
          getGL: true
        }
      }).then(function (response) {
        console.log(response.data);
        _this2.GLList = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    openOthersHdr: function openOthersHdr() {
      this.clearHeader("formHeader");
      $("#OthersHdrModal").modal("show");
      this.updateMeHeader = false;
    },
    getDetail: function getDetail() {
      var _this3 = this;

      if (this.header.OHID) {
        axios.get("api/others", {
          params: {
            getDtl: true,
            id: this.header.OHID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this3.details = response.data;
            _this3.dtlData = true;
          } else {
            _this3.dtlData = false;
          }

          _this3.getTotal();
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    getTotal: function getTotal() {
      var _this4 = this;

      if (this.header.OHID) {
        axios.get("api/others", {
          params: {
            getTotal: true,
            id: this.header.OHID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this4.TotalAmount = _this4.$root.formatNumberCommaRound(response.data[0].TotalAmount);
          } else {
            _this4.TotalAmount = "0.00";
          }
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    getMarkup: function getMarkup() {
      var _this5 = this;

      axios.get("api/markup").then(function (response) {
        _this5.markup = response.data[0].OtherMarkUp;
        _this5.dtl.markup = _this5.markup;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    rowClick: function rowClick(row) {
      this.dtl = Object.assign({}, row);
      this.dtl.Price = this.$root.formatNumberCommaRound(row.Price);
      this.dtl.Amount = this.$root.formatNumberCommaRound(row.Amount);
      this.dtl.subPrice = this.$root.formatNumberCommaRound(row.subPrice);
      this.dtl.subAmount = this.$root.formatNumberCommaRound(row.subAmount);
    },
    saveHdr: function saveHdr() {
      var _this6 = this;

      var data = Object.assign({}, this.formHeader);
      this.$Progress.start();
      axios.post("api/othersHdr", data).then(function (response) {
        if (response.data.success) {
          _this6.header = Object.assign({}, _this6.formHeader);

          if (response.data.id) {
            _this6.header.OHID = response.data.id;
            _this6.header.SOANo = response.data.SOANo;
          }

          toast.fire({
            icon: "success",
            title: response.data.message
          });

          _this6.clearHeader("formHeader");

          _this6.clearHeader("detail");

          if (!_this6.updateMeHeader) {
            _this6.details = [];
          }

          $("#OthersHdrModal").modal("hide");
        } else {
          toast.fire({
            icon: "warning",
            title: response.data.message
          });
        }

        _this6.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    updateHdr: function updateHdr() {
      if (!this.header.OHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select/save OTHERS Header to continue."
        });
      }

      this.formHeader = Object.assign({}, this.header);
      this.updateMeHeader = true;
      $("#OthersHdrModal").modal("show");
    },
    deleteHdr: function deleteHdr() {
      var _this7 = this;

      if (!this.header.OHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select OTHERS SOA Header to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(function (result) {
        if (result.value) {
          _this7.$Progress.start();

          axios["delete"]("api/othersHdrDelete/".concat(_this7.header.OHID)).then(function (response) {
            if (response.data.success) {
              _this7.clearAll();

              swal.fire("Deleted!", response.data.message, "success");
            } else {
              swal.fire("Warning!", response.data.message, "warning");
            }

            _this7.$Progress.finish();
          })["catch"](function (err) {
            console.log(err);
          });
        } else {
          swal.fire("Information!", "Deletion is cancelled.", "warning");
        }
      });
    },
    searchOthersHeader: function searchOthersHeader() {
      Fire.$emit("searchOthersHeader");
    },
    othersHeaderClose: function othersHeaderClose(row) {
      this.header = Object.assign({}, row);
      this.getDetail();
      this.getMarkup();
    },
    searchSearchSignatoryButton: function searchSearchSignatoryButton(number) {
      Fire.$emit("searchSignatory", number);
    },
    signatoryClose: function signatoryClose(row) {
      if (row.number == 1) {
        this.formHeader.Prepared_by = row.SignatoryName;
        this.formHeader.Prepared_by_desig = row.Designation;
      } else if (row.number == 2) {
        this.formHeader.Checked_by = row.SignatoryName;
        this.formHeader.Checked_by_desig = row.Designation;
      } else if (row.number == 3) {
        this.formHeader.Noted_by = row.SignatoryName;
        this.formHeader.Noted_by_desig = row.Designation;
      } else if (row.number == 4) {
        this.formHeader.Approved_by = row.SignatoryName;
        this.formHeader.Approved_by_desig = row.Designation;
      } else if (row.number == 5) {
        this.formHeader.Approved_by2 = row.SignatoryName;
        this.formHeader.Approved_by_desig2 = row.Designation;
      } else if (row.number == 6) {
        this.reportData.Prepared_by = row.SignatoryName;
        this.reportData.Prepared_by_desig = row.Designation;
      } else if (row.number == 7) {
        this.reportData.Checked_by = row.SignatoryName;
        this.reportData.Checked_by_desig = row.Designation;
      } else if (row.number == 8) {
        this.reportData.Noted_by = row.SignatoryName;
        this.reportData.Noted_by_desig = row.Designation;
      } else if (row.number == 9) {
        this.reportData.Approved_by = row.SignatoryName;
        this.reportData.Approved_by_desig = row.Designation;
      }
    },
    computeMarkup: function computeMarkup() {
      if (this.dtl.markup == 0) {
        this.dtl.subPrice = this.dtl.Price;
      } else {
        if (this.dtl.markup) {
          if (!isNaN(this.dtl.Qty)) {
            this.dtl.subPrice = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.dtl.Price) + this.dtl.markup / 100 * this.$root.formatNumber(this.dtl.Price));
          }
        }
      }

      this.computeAmount();
    },
    computeAmount: function computeAmount() {
      if (this.dtl.Qty) {
        if (!isNaN(this.dtl.Qty)) {
          this.dtl.Amount = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.dtl.Qty) * this.$root.formatNumber(this.dtl.Price));
          this.dtl.subAmount = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.dtl.Qty) * this.$root.formatNumber(this.dtl.subPrice));
        } else {
          this.dtl.Amount = "0.00";
        }
      } else {
        this.dtl.Amount = "0.00";
      }
    },
    saveDtl: function saveDtl() {
      var _this8 = this;

      if (this.$root.formatNumber(this.dtl.Amount) == 0 || this.$root.formatNumber(this.dtl.Amount) < 0) {
        return toast.fire({
          icon: "warning",
          title: "Amount is invalid."
        });
      }

      var data = Object.assign({}, this.dtl);
      data.Price = this.$root.formatNumber(this.dtl.Price);
      data.Amount = this.$root.formatNumber(this.dtl.Amount);
      data.subPrice = this.$root.formatNumber(this.dtl.subPrice);
      data.subAmount = this.$root.formatNumber(this.dtl.subAmount);
      data.hdr_idLink = this.header.OHID;
      this.$Progress.start();
      axios.post("api/othersDtl", data).then(function (response) {
        if (response.data.success) {
          if (response.data.id) {
            _this8.header.OEDID = response.data.id;
          }

          toast.fire({
            icon: "success",
            title: response.data.message
          });

          _this8.getDetail();

          _this8.clearHeader("detail");
        } else {
          toast.fire({
            icon: "warning",
            title: response.data.message
          });
        }

        _this8.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    deleteDtl: function deleteDtl() {
      var _this9 = this;

      if (!this.dtl.OEDID) {
        return toast.fire({
          icon: "warning",
          title: "Please select OTHERS Detail to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(function (result) {
        if (result.value) {
          _this9.$Progress.start();

          axios["delete"]("api/deleteOthersHDR/".concat(_this9.dtl.OEDID)).then(function (response) {
            if (response.data.success) {
              _this9.getDetail();

              _this9.clearHeader("detail");

              swal.fire("Deleted!", response.data.message, "success");
            } else {
              swal.fire("Warning!", response.data.message, "warning");
            }

            _this9.$Progress.finish();
          })["catch"](function (err) {
            console.log(err);
          });
        } else {
          swal.fire("Information!", "Deletion is cancelled.", "warning");
        }
      });
    },
    generatePrint: function generatePrint() {
      var _this10 = this;

      this.$Progress.start();
      axios.get("api/reportOthers", {
        params: {
          SOANo: this.header.SOANo
        }
      }).then(function (response) {
        console.log(response.data);

        if (response.data.success) {
          _this10.reportData.url2 = "api/reportOthers?report=true&SOANo=" + _this10.header.SOANo;
        } else {
          swal.fire("Warning!", response.data.message, "warning");
        }

        _this10.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    postLedger: function postLedger() {
      var _this11 = this;

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Post it!"
      }).then(function (result) {
        if (result.value) {
          _this11.$Progress.start();

          var data = {
            SOANo: _this11.header.SOANo,
            amount: _this11.$root.formatNumber(_this11.TotalAmount)
          };
          axios.post("api/othersPostLedger", data).then(function (response) {
            if (response.data.success) {
              _this11.header.Status = "POSTED TO LEDGER";
              toast.fire({
                icon: "success",
                title: response.data.message
              });
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this11.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    clearAll: function clearAll() {
      this.clearHeader("header");
      this.clearHeader("formHeader");
      this.clearHeader("detail");
      this.details = [];
    },
    clearHeader: function clearHeader($type) {
      if ($type == "header") {
        this.header = {
          OHID: "",
          SOANo: "",
          Prepared_by: "",
          Prepared_by_desig: "",
          Checked_by: "",
          Checked_by_desig: "",
          Noted_by: "",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          Approved_by2: "",
          Approved_by_desig2: ""
        };
      } else if ($type == "formHeader") {
        this.formHeader = {
          OHID: "",
          SOANo: "",
          Prepared_by: this.user,
          Prepared_by_desig: "Encoder/User",
          Checked_by: "CATRINA B. OPEÑA",
          Checked_by_desig: "",
          Noted_by: "BERNARDITO M. GARCIA",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          Approved_by2: "",
          Approved_by_desig2: ""
        };
      } else if ($type == "reportData") {
        this.reportData = {
          to: "",
          thru: "",
          body: "",
          body2: "",
          Prepared_by: "",
          Prepared_by_desig: "",
          Checked_by: "",
          Checked_by_desig: "",
          Noted_by: "",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          department: "",
          url1: "",
          url2: ""
        };
      } else {
        this.dtl = {
          OEDID: "",
          hdr_idLink: "",
          Date: this.$root.formatDate(new Date()),
          InvoiceNo: "",
          Qty: "0",
          Unit: "",
          Description: "",
          Price: "0.00",
          Amount: "0.00",
          Supplier: "",
          GL: "",
          CC: "",
          markup: "",
          subPrice: "0.00",
          subtAmount: "0.00"
        };
        this.getMarkup();
      }
    },
    // modal for print
    viewReport: function viewReport() {
      var _this12 = this;

      if (this.modalPage == 1) {
        this.modalPage = 2;
        axios.post("api/reportAllowanceSOASave", {
          to: this.reportData.to,
          thru: this.reportData.thru,
          body: this.reportData.body,
          body2: this.reportData.body2
        }).then(function (response) {
          if (response.data.success) {
            _this12.reportData.url1 = "api/reportSOA?report=true&SOANo=" + _this12.header.SOANo + "&Prepared_by=" + _this12.reportData.Prepared_by + "&Checked_by=" + _this12.reportData.Checked_by + "&Noted_by=" + _this12.reportData.Noted_by + "&Approved_by=" + _this12.reportData.Approved_by + "&reportID=" + response.data.id + "&type=OTHERS";
          }

          _this12.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
        this.generatePrint();
      } else {
        this.modalPage = 1;
      }
    },
    reportModal: function reportModal() {
      console.log(this.$root.formatNumber(this.TotalAmount));
      var dec = this.$root.formatNumber(this.TotalAmount).toString().split(".");

      if (dec.length == 1) {
        var decimal = "00";
      } else {
        var decimal = dec[1].toString().padEnd(2, "0");
      }

      var numberToWord = this.$root.number2word(this.$root.formatNumber(this.TotalAmount)).toString().toUpperCase();
      this.reportData.to = "TO: MS.LORNA SEVILLEJO\n\xa0\xa0\xa0\xa0Accounting Supervisor\n\xa0\xa0\xa0\xa0Del Monte, Inc\n\xa0\xa0\xa0\xa0Camp Philips, Manolo Fortich, Bukidnon";
      this.reportData.thru = "THRU:\n\xa0\xa0\xa0\xa0MS.KAREN I. DOMINGUEZ\n\xa0\xa0\xa0\xa0HR Plantation Supervisor\n\xa0\xa0\xa0\xa0Del Monte, Inc\n\xa0\xa0\xa0\xa0Camp Philips, Manolo Fortich, Bukidnon";
      this.reportData.body = "Dear Ms. Sevillejo,\n\n\nThis is to bill Del Monte, Inc. the amount of " + numberToWord + " PESOS & " + decimal + "/100 ONLY (Php " + this.TotalAmount + ") for PPE issuance of Philpack Freezing Plant production employees. Please see attached file for your perusal.";
      this.reportData.body2 = "Please issue check in the name of GENERAL SERVICES MULTIPURPOSE COOPERATIVE.";
      this.reportData.Prepared_by = this.header.Prepared_by;
      this.reportData.Prepared_by_desig = this.header.Prepared_by_desig;
      this.reportData.Noted_by = this.header.Noted_by;
      this.reportData.Noted_by_desig = this.header.Noted_by_desig;
      this.reportData.Approved_by = this.header.Approved_by;
      this.reportData.Approved_by_desig = this.header.Approved_by_desig;
      $("#reportModal").modal("show");
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this13 = this;

      return this.details.filter(function (item) {
        return _this13.search.toLowerCase().split(" ").every(function (v) {
          return item.InvoiceNo.toLowerCase().includes(v) || item.Description.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      number: 0
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("searchSignatory", function (data) {
      _this.number = data;

      _this.getData();

      $("#SearchSignatory").modal("show");
    });
  },
  methods: {
    rowClick: function rowClick(row) {
      row.number = this.number;
      this.$emit("rowClick", row);
      $("#SearchSignatory").modal("hide");
    },
    getData: function getData() {
      var _this2 = this;

      axios.get("api/signatoryList").then(function (response) {
        response.data.forEach(function (item) {
          var extname = item.ename ? " " + item.ename : "";
          var mname = item.mname ? " " + item.mname[0] + "." : "";
          item.SignatoryName = item.fname + mname + " " + item.lname + extname;
          item.Designation = item.position;
        });
        _this2.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.SignatoryName.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/OthersEntry.vue?vue&type=template&id=6ca6f62e&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Others/OthersEntry.vue?vue&type=template&id=6ca6f62e& ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-2" }, [
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", [_vm._v("Control No.")]),
                    _vm._v(" "),
                    _c(
                      "b-input-group",
                      [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.header.OHID,
                              expression: "header.OHID"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "OHID",
                            placeholder: "",
                            disabled: ""
                          },
                          domProps: { value: _vm.header.OHID },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.header, "OHID", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c(
                          "b-input-group-append",
                          [
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  variant: "outline-primary",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.searchOthersHeader(1)
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-search",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  disabled: this.header.Status != "ACTIVE",
                                  variant: "outline-success",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.updateHdr()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-edit",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  disabled: this.header.Status != "ACTIVE",
                                  variant: "outline-danger",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.deleteHdr()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-trash",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("SOANo")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.SOANo,
                        expression: "header.SOANo"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "SOANo",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.SOANo },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "SOANo", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Prepared By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Prepared_by,
                        expression: "header.Prepared_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Prepared_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Prepared_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Prepared_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Checked By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Checked_by,
                        expression: "header.Checked_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Checked_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Checked_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Checked_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-4 text-right" }, [
                _c("label", { staticClass: "text-danger" }, [
                  _vm._v(_vm._s(_vm.header.Status))
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "form-group" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-warning",
                      attrs: {
                        disabled: this.header.Status != "TRANSMITTED",
                        type: "button",
                        bold: ""
                      },
                      on: {
                        click: function($event) {
                          return _vm.postLedger()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-calculator",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                POST\n                            "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-warning",
                      attrs: { type: "button", bold: "" },
                      on: {
                        click: function($event) {
                          return _vm.reportModal()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-print",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                PRINT\n                            "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { type: "button", bold: "" },
                      on: {
                        click: function($event) {
                          return _vm.openOthersHdr()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-plus",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                NEW OTHERS HEADER\n                            "
                      )
                    ]
                  )
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Noted By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Noted_by,
                        expression: "header.Noted_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Noted_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Noted_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Noted_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Approved By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Approved_by,
                        expression: "header.Approved_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Approved_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Approved_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Approved_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Approved For Payment By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Approved_by2,
                        expression: "header.Approved_by2"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Approved_by2",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Approved_by2 },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(
                          _vm.header,
                          "Approved_by2",
                          $event.target.value
                        )
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _vm._m(1),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.TotalAmount,
                      expression: "TotalAmount"
                    }
                  ],
                  staticClass: "form-control text-primary text-right",
                  attrs: {
                    type: "text",
                    name: "TotalAmount",
                    placeholder: "",
                    disabled: ""
                  },
                  domProps: { value: _vm.TotalAmount },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.TotalAmount = $event.target.value
                    }
                  }
                })
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _vm._m(2),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody tbody-160" },
                      [
                        _c(
                          "tr",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: !_vm.dtlData,
                                expression: "!dtlData"
                              }
                            ]
                          },
                          [_vm._m(3)]
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.filteredBlogs, function(item) {
                          return _c(
                            "tr",
                            {
                              on: {
                                click: function($event) {
                                  return _vm.rowClick(item)
                                }
                              }
                            },
                            [
                              _c("td", [
                                _vm._v(_vm._s(_vm._f("formatDate")(item.Date)))
                              ]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.InvoiceNo))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.Description))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.Qty))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.Unit))]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(
                                  _vm._s(_vm._f("formatNumber")(item.Price))
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.Amount)
                                    ) +
                                    "\n                                    "
                                )
                              ])
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    return _vm.saveDtl()
                  }
                }
              },
              [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-4" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Description")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Description,
                            expression: "dtl.Description"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Description",
                          placeholder: ""
                        },
                        domProps: { value: _vm.dtl.Description },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.dtl,
                              "Description",
                              $event.target.value
                            )
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Unit")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Unit,
                            expression: "dtl.Unit"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "text", name: "Unit", placeholder: "" },
                        domProps: { value: _vm.dtl.Unit },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Unit", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Unit Price")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Price,
                            expression: "dtl.Price"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Price",
                          placeholder: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.Price },
                        on: {
                          keyup: function($event) {
                            return _vm.computeMarkup()
                          },
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Price", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Markup (%)")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.markup,
                            expression: "dtl.markup"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "markup",
                          placeholder: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.markup },
                        on: {
                          keyup: function($event) {
                            return _vm.computeMarkup()
                          },
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "markup", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Markup Price")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.subPrice,
                            expression: "dtl.subPrice"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "subPrice",
                          placeholder: "",
                          disabled: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.subPrice },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "subPrice", $event.target.value)
                          }
                        }
                      })
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Qty")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Qty,
                            expression: "dtl.Qty"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Qty",
                          placeholder: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.Qty },
                        on: {
                          keyup: function($event) {
                            return _vm.computeAmount()
                          },
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Qty", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Amount")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Amount,
                            expression: "dtl.Amount"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Amount",
                          placeholder: "",
                          disabled: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.Amount },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Amount", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Date")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Date,
                            expression: "dtl.Date"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "date",
                          name: "Date",
                          placeholder: "",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.Date },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Date", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Supplier Invoice No")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.InvoiceNo,
                            expression: "dtl.InvoiceNo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "InvoiceNo",
                          placeholder: "",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.InvoiceNo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "InvoiceNo", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("GL")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.GL,
                            expression: "dtl.GL"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Amount",
                          placeholder: "",
                          list: "gl",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.GL },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "GL", $event.target.value)
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "datalist",
                        { attrs: { id: "gl" } },
                        _vm._l(_vm.GLList, function(item) {
                          return _c("option", [_vm._v(_vm._s(item.GL))])
                        }),
                        0
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Cost Center")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.CC,
                            expression: "dtl.CC"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "CC",
                          placeholder: "",
                          list: "costcenter",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.CC },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "CC", $event.target.value)
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "datalist",
                        { attrs: { id: "costcenter" } },
                        _vm._l(_vm.CCList, function(item) {
                          return _c("option", [_vm._v(_vm._s(item.Costcenter))])
                        }),
                        0
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Sub Amount")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.subAmount,
                            expression: "dtl.subAmount"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "subAmount",
                          placeholder: "",
                          disabled: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.subAmount },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "subAmount", $event.target.value)
                          }
                        }
                      })
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 text-right" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.clearHeader("detail")
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-eraser",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                    CLEAR\n                                "
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: {
                            disabled: this.header.Status != "ACTIVE",
                            type: "button",
                            bold: ""
                          },
                          on: {
                            click: function($event) {
                              return _vm.deleteDtl()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-trash",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                    DELETE\n                                "
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: {
                            disabled: this.header.Status != "ACTIVE",
                            type: "submit",
                            bold: ""
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-save",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                    SAVE\n                                "
                          )
                        ]
                      )
                    ])
                  ])
                ])
              ]
            )
          ])
        ]),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass: "modal fade",
            attrs: {
              id: "OthersHdrModal",
              tabindex: "-1",
              role: "dialog",
              "aria-labelledby": "addNewLabel",
              "aria-hidden": "true"
            }
          },
          [
            _c(
              "div",
              {
                staticClass: "modal-dialog modal-dialog-centered modal-md",
                attrs: { role: "document" }
              },
              [
                _c("div", { staticClass: "modal-content" }, [
                  _c("div", { staticClass: "modal-header-cus" }, [
                    _c("div", { staticClass: "row container-fluid" }, [
                      _c("div", { staticClass: "col-md-11" }, [
                        _c("h5", [
                          _c(
                            "b",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: !_vm.updateMeHeader,
                                  expression: "!updateMeHeader"
                                }
                              ]
                            },
                            [_vm._v("CREATE OTHERS HEADER")]
                          ),
                          _vm._v(" "),
                          _c(
                            "b",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.updateMeHeader,
                                  expression: "updateMeHeader"
                                }
                              ]
                            },
                            [_vm._v("UPDATE OTHERS HEADER")]
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _vm._m(4)
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-body-cus" }, [
                    _c("div", { staticClass: "container-fluid" }, [
                      _c(
                        "form",
                        {
                          on: {
                            submit: function($event) {
                              $event.preventDefault()
                              return _vm.saveHdr()
                            }
                          }
                        },
                        [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col-md-12" }, [
                              _c("div", { staticClass: "form-group" }, [
                                _c("label", [_vm._v("SOANo")]),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.formHeader.SOANo,
                                      expression: "formHeader.SOANo"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "SOANo",
                                    placeholder: "",
                                    disabled: ""
                                  },
                                  domProps: { value: _vm.formHeader.SOANo },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.formHeader,
                                        "SOANo",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ])
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Prepared By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Prepared_by,
                                            expression:
                                              "\n                                                        formHeader.Prepared_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Prepared_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Prepared_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Prepared_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    1
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Checked By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Checked_by,
                                            expression:
                                              "\n                                                        formHeader.Checked_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Checked_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Checked_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Checked_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    2
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Noted By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Noted_by,
                                            expression:
                                              "\n                                                        formHeader.Noted_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Noted_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Noted_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Noted_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    3
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Approved By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Approved_by,
                                            expression:
                                              "\n                                                        formHeader.Approved_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Approved_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Approved_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Approved_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    4
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [
                                    _vm._v("Approved For Payment By")
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Approved_by2,
                                            expression:
                                              "\n                                                        formHeader.Approved_by2\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Approved_by2",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Approved_by2
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Approved_by2",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    5
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _vm._m(5)
                        ]
                      )
                    ])
                  ])
                ])
              ]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass: "modal fade",
            attrs: {
              id: "reportModal",
              tabindex: "-1",
              role: "dialog",
              "aria-labelledby": "addNewLabel",
              "aria-hidden": "true"
            }
          },
          [
            _c(
              "div",
              {
                staticClass: "modal-dialog modal-dialog-centered modal-full",
                attrs: { role: "document" }
              },
              [
                _c("div", { staticClass: "modal-content" }, [
                  _vm._m(6),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-body-cus" }, [
                    _c("div", { staticClass: "container-fluid" }, [
                      _c(
                        "div",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.modalPage == 1,
                              expression: "modalPage == 1"
                            }
                          ],
                          staticClass: "row"
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass: "col-md-6",
                              staticStyle: { "border-right": "2px solid black" }
                            },
                            [
                              _c("div", { staticClass: "row" }, [
                                _c("div", { staticClass: "col-md-6" }, [
                                  _c(
                                    "button",
                                    {
                                      staticClass: "btn btn-primary btn-xs",
                                      attrs: { type: "button", bold: "" },
                                      on: {
                                        click: function($event) {
                                          return _vm.viewReport()
                                        }
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-eye",
                                        attrs: { "aria-hidden": "true" }
                                      }),
                                      _vm._v(
                                        "\n                                                View Report\n                                            "
                                      )
                                    ]
                                  )
                                ]),
                                _vm._v(" "),
                                _vm._m(7)
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "row" }, [
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("TO:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.to,
                                        expression: "reportData.to"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "100px"
                                    },
                                    domProps: { value: _vm.reportData.to },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "to",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("THRU:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.thru,
                                        expression: "reportData.thru"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "100px"
                                    },
                                    domProps: { value: _vm.reportData.thru },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "thru",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("BODY:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.body,
                                        expression: "reportData.body"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "130px"
                                    },
                                    domProps: { value: _vm.reportData.body },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "body",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("BODY2:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.body2,
                                        expression: "reportData.body2"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "100px"
                                    },
                                    domProps: { value: _vm.reportData.body2 },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "body2",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ])
                              ])
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "col-md-6",
                              staticStyle: { "border-right": "2px solid black" }
                            },
                            [
                              _vm._m(8),
                              _vm._v(" "),
                              _c("div", { staticClass: "row" }, [
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Prepared By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Prepared_by,
                                              expression:
                                                "\n                                                        reportData.Prepared_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Prepared_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Prepared_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Prepared_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      6
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Checked By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Checked_by,
                                              expression:
                                                "\n                                                        reportData.Checked_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Checked_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Checked_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Checked_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      7
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "row" }, [
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Noted By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Noted_by,
                                              expression:
                                                "\n                                                        reportData.Noted_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Noted_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Noted_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Noted_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      8
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Approved By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Approved_by,
                                              expression:
                                                "\n                                                        reportData.Approved_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Approved_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Approved_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Approved_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      9
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ])
                            ]
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.modalPage == 2,
                              expression: "modalPage == 2"
                            }
                          ],
                          staticClass: "row"
                        },
                        [
                          _c("div", { staticClass: "col-md-6" }, [
                            _c("div", { staticClass: "row" }, [
                              _c("div", { staticClass: "col-md-6" }, [
                                _c(
                                  "button",
                                  {
                                    staticClass: "btn btn-primary btn-xs",
                                    attrs: { type: "button", bold: "" },
                                    on: {
                                      click: function($event) {
                                        return _vm.viewReport()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-arrow-left",
                                      attrs: { "aria-hidden": "true" }
                                    }),
                                    _vm._v(
                                      "\n                                                Back to Setting\n                                            "
                                    )
                                  ]
                                )
                              ]),
                              _vm._v(" "),
                              _vm._m(9)
                            ]),
                            _vm._v(" "),
                            _c("iframe", {
                              attrs: {
                                width: "100%",
                                height: "550px",
                                src: _vm.reportData.url1
                              }
                            })
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-md-6" }, [
                            _vm._m(10),
                            _vm._v(" "),
                            _c("iframe", {
                              attrs: {
                                width: "100%",
                                height: "550px",
                                src: _vm.reportData.url2
                              }
                            })
                          ])
                        ]
                      )
                    ])
                  ])
                ])
              ]
            )
          ]
        )
      ]),
      _vm._v(" "),
      _c("search-signatory", {
        on: {
          rowClick: function($event) {
            return _vm.signatoryClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-othersHeader", {
        on: {
          rowClick: function($event) {
            return _vm.othersHeaderClose($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("Others Entry")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-4 text-right" }, [
      _c("b", [_vm._v("TOTAL AMOUNT :")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("Invoice No.")]),
        _vm._v(" "),
        _c("th", [_vm._v("Description")]),
        _vm._v(" "),
        _c("th", [_vm._v("Qty")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit Price")]),
        _vm._v(" "),
        _c("th", [_vm._v("Amount")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "7" } }, [
      _c("i", [_vm._v("No Data Found...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-1" }, [
      _c(
        "button",
        {
          staticClass: "close close-modal",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12 text-right" }, [
        _c("label", [_vm._v(" ")]),
        _vm._v(" "),
        _c(
          "button",
          {
            staticClass: "btn btn-success",
            attrs: { type: "submit", bold: "" }
          },
          [
            _c("i", {
              staticClass: "fa fa-save",
              attrs: { "aria-hidden": "true" }
            }),
            _vm._v(
              "\n                                            SAVE\n                                        "
            )
          ]
        )
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Generate SOA Report")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-6 text-right" }, [
      _c("h6", [_c("i", [_vm._v("Page 1")])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-6" }),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-6 text-right" }, [
        _c("h6", [_c("i", [_vm._v("Page 2 (Attachment)")])])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-6 text-right" }, [
      _c("h6", [_c("i", [_vm._v("Page 1")])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-6" }),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-6 text-right" }, [
        _c("h6", [_c("i", [_vm._v("Page 2 (Attachment)")])])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "SearchSignatory",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-md",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.search,
                          expression: "search"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "search",
                        placeholder: "Search Signatory here..."
                      },
                      domProps: { value: _vm.search },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.search = $event.target.value
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          _vm._l(_vm.filteredBlogs, function(item) {
                            return _c(
                              "tr",
                              {
                                key: item.SID,
                                on: {
                                  click: function($event) {
                                    return _vm.rowClick(item)
                                  }
                                }
                              },
                              [
                                _c("td", [_vm._v(_vm._s(item.SignatoryName))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Designation))])
                              ]
                            )
                          }),
                          0
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Signatory List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Signatory Name")]),
        _vm._v(" "),
        _c("th", [_vm._v("Designation")])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/Others/OthersEntry.vue":
/*!********************************************************!*\
  !*** ./resources/js/components/Others/OthersEntry.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OthersEntry_vue_vue_type_template_id_6ca6f62e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OthersEntry.vue?vue&type=template&id=6ca6f62e& */ "./resources/js/components/Others/OthersEntry.vue?vue&type=template&id=6ca6f62e&");
/* harmony import */ var _OthersEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OthersEntry.vue?vue&type=script&lang=js& */ "./resources/js/components/Others/OthersEntry.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OthersEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OthersEntry_vue_vue_type_template_id_6ca6f62e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OthersEntry_vue_vue_type_template_id_6ca6f62e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/Others/OthersEntry.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/Others/OthersEntry.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/Others/OthersEntry.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OthersEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OthersEntry.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/OthersEntry.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OthersEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/Others/OthersEntry.vue?vue&type=template&id=6ca6f62e&":
/*!***************************************************************************************!*\
  !*** ./resources/js/components/Others/OthersEntry.vue?vue&type=template&id=6ca6f62e& ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OthersEntry_vue_vue_type_template_id_6ca6f62e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OthersEntry.vue?vue&type=template&id=6ca6f62e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Others/OthersEntry.vue?vue&type=template&id=6ca6f62e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OthersEntry_vue_vue_type_template_id_6ca6f62e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OthersEntry_vue_vue_type_template_id_6ca6f62e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchSignatories.vue?vue&type=template&id=93faadfe& */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&");
/* harmony import */ var _SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchSignatories.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/search/SearchAllowance/SearchSignatories.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchSignatories.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchSignatories.vue?vue&type=template&id=93faadfe& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);