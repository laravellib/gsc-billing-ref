(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[45],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
/* harmony import */ var _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchOperator.vue */ "./resources/js/components/search/SearchJeep/SearchOperator.vue");
/* harmony import */ var _search_SearchPHB_SearchPHBVehicle_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchPHB/SearchPHBVehicle.vue */ "./resources/js/components/search/SearchPHB/SearchPHBVehicle.vue");
/* harmony import */ var _search_SearchPHB_SearchLocation_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/SearchPHB/SearchLocation.vue */ "./resources/js/components/search/SearchPHB/SearchLocation.vue");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_4__);
=======
/* harmony import */ var _search_commonMasterList_Signatory_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/commonMasterList/Signatory.vue */ "./resources/js/components/search/commonMasterList/Signatory.vue");
/* harmony import */ var _search_dmpi_sar_SearchDmpiSar_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/dmpi/sar/SearchDmpiSar.vue */ "./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
<<<<<<< HEAD
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-operator': _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-phbvehicle': _search_SearchPHB_SearchPHBVehicle_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    'search-location': _search_SearchPHB_SearchLocation_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      PHBDetails: [],
      loc: '',
      checkedNames: [],
      filteredblogs: [],
      csoatotals: [],
      checkedNamesFilter: [],
      editmode: false,
      equalequal: false,
      allSelected: false,
      editCollection: false,
      jvls: [],
      jvlsobject: {},
      search: '',
      jvcps: {},
      drivers: [],
      vehicles: {},
      rates: {},
      operators: {},
      batch: [],
      jvlfilter: [],
      jvlbalamt: [],
      var1: '',
      var2: '',
      first: '',
      second: '',
      eq: 'true',
      truevalue: '',
      falsevalue: '',
      SearchPHBPlateNo: '',
      DateFrom: '',
      DateTo: '',
      JeepVehicleCollectionPayments: {},
      form: new Form({
        PHBVLHDRID: '',
        PHBVLHDRIDFilter: '',
        PHBVLDate: '',
        OVLNo: '',
        PHBIDLink: '',
        PHBPlateNo: '',
        DriverIDLink: '',
        DriverLastName: '',
        DriverFirstName: '',
        DriverMiddleName: '',
        DriverExtName: '',
        TruckerIDLink: '',
        TruckerLastName: '',
        TruckerFirstName: '',
        TruckerMiddleName: '',
        TruckerExtName: '',
        BillAmount: '',
        LessAdmin: '',
        LessFuel: '',
        NetTrucker: '',
        Status: '',
        SOANumber: '',
        SOADate: '',
        ChargeInvoiceNumber: '',
        GLCode: '',
        CostCenter: '',
        PerKilometerRate: '',
        NumberofDays: '',
        DriverName: '',
        TruckerName: '',
        CollectedAmount: '',
        CollectedAmountHDR: '',
        BalanceAmountHDR: '',
        BalanceAmount: '',
        ORCRNumber: '',
        ORCRDate: '',
        Remarks: '',
        PHBVLHDRID_Link: '',
        TotalAmount: '',
        startreading: '',
        endreading: '',
        actualstartreading: '',
        actualendreading: '',
        totalrun: '',
        totalactualrun: '',
        LocationName: '',
        LocationID: '',
        Assignment: '',
        TimeIn: '',
        TimeOut: '',
        FuelLiters: ''
      }),
      view: new Form({
        ViewLessFuel: '',
        ViewBillAmount: '',
        ViewNetTrucker: '',
        ViewPerKilometerRate: '',
        ViewBalanceAmount: ''
      }),
      collection: new Form({
        PHBVCDTLID: '',
        CollectedAmount: '',
        ORCRNumber: '',
        ORCRDate: '',
        Remarks: ''
      }),
      detail: new Form({
        Assignment: '',
        PHBVLHDRID_Link: '',
        LoadingLocationName: '',
        LoadingTimeIn: '',
        LoadingTimeStart: '',
        LoadingTimeEnd: '',
        UnLoadingLocationName: '',
        UnLoadingTimeIn: '',
        UnLoadingTimeStart: '',
        UnLoadingTimeEnd: '',
        PHBVLDTLID: ''
      })
    };
  },
  mounted: function mounted() {//this.$parent.getSearchDriver();
    //this.$parent.getSearchOperator();
  },
  methods: {
    refreshtotalsoa: function refreshtotalsoa() {
      var _this = this;

      this.form.TotalAmount = '';
      this.form.PHBVLHDRID = this.checkedNames.join();
      axios.get('/api/getcsoasum', {
        params: {
          PHBVLHDRID: this.form.PHBVLHDRID
        }
      }).then(function (_ref) {
        var data = _ref.data;
        _this.csoatotals = data;
        _this.form.TotalAmount = _this.csoatotals[0].BillAmount;
      })["catch"](function (err) {});
    },
    selectAll: function selectAll() {
      this.checkedNames = [];

      if (this.allSelected == false) {
        for (var user in this.filteredBlogs) {
          this.checkedNames.push(this.filteredBlogs[user].PHBVLHDRID);
        } // this.form.PHBVLHDRID = this.checkedNames.join();
        // // axios.get('/api/getphbcsoasum', {params: {PHBVLHDRID: this.form.PHBVLHDRID}})
        // // .then(({ data }) => {
        // //     this.csoatotals = data;
        // //     this.form.TotalAmount = this.csoatotals[0].BillAmount;
        // //     console.log(this.form.TotalAmount);
        // // })
        // // .catch((err)=>{
        // // })

      } else {
        this.form.TotalAmount = '';
      }
    },
    select: function select() {
      this.allSelected = false;
    },
    SearchDateFromTo: function SearchDateFromTo() {//return this.jvls.filter(jvl =>{
      //       return jvl.PHBVLDate.includes(this.form.DateFrom)
      //    });

      /*var vm = this;
                 var startdate = vm.form.DateFrom;
                 var enddate = vm.form.DateTo;
                 return _.filter(vm.jvls,(function(data){
                   if ((_.isNull(startdate) && _.isNull(enddate))){
                     return true
                   }
                   else{
                     var date = data.PHBVLDate;
                     return date.includes(date >= startdate && date <= enddate);
                     
                   }
                 }))*/
    },
    AddCollection: function AddCollection() {
      this.editCollection = false;
      this.collection.reset();
      var today = new Date().toISOString().slice(0, 10);
      this.collection.ORCRDate = today;
      $('#addPHBCollection').modal('show');
    },
    UpdateCollection: function UpdateCollection() {
      this.editCollection = true;
      $('#addPHBCollection').modal('show');
    },
    createPHBCollection: function createPHBCollection() {
      var _this2 = this;

      this.$Progress.start();
      this.collection.PHBVLHDRID_Link = this.form.PHBVLHDRID;
      this.collection.post('api/phbCollection').then(function () {
        var today = new Date().toISOString().slice(0, 10);
        _this2.collection.ORCRDate = today;
        toast.fire({
          icon: 'success',
          title: 'PHB Collection successfully saved'
        });

        _this2.$Progress.finish();

        _this2.getJVCP();

        $('#addPHBCollection').modal('hide');
      })["catch"](function () {
        _this2.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'PHB Vehicle Log not added successfully'
        });
      });
    },
    InsertDetails: function InsertDetails() {
      this.detail.reset();
      this.detail.PHBVLHDRID_Link = this.form.PHBVLHDRID;
      this.loadPHBDTL();
      $('#addPHBDetails').modal('show');
    },
    SetToUnpaid: function SetToUnpaid() {
      if (this.form.Status == 'POSTED') {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Can not Set to Unpaid. The Status is still POSTED.'
        });
      } else {
        this.form.Status = 'POSTED';
        this.form.BalanceAmount = this.form.BillAmount;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
        this.form.CollectedAmount = 0;
        this.$Progress.start();
        this.form.put('api/jvlpaidtoposted/' + this.form.PHBVLHDRID); //$('#addNew').modal('hide');

        toast.fire({
          icon: 'success',
          title: 'Vehicle Log is back to Unpaid'
        });
        this.deleteEntirePaymentDetail();
        this.loadJVL();
        this.getJVLBalanceAmount();
        this.$Progress.finish();
        this.form.PHBVLHDRID_Link = this.form.PHBVLHDRID;
      }
    },
    signalChangestartreading: function signalChangestartreading() {
      var totalreading = 0;

      if (this.form.endreading !== '') {
        totalreading = this.form.endreading - this.form.startreading;
        this.form.BillAmount = parseFloat(totalreading * this.form.PerKilometerRate).toFixed(2);
        this.form.LessAdmin = 0; //parseFloat(this.form.BillAmount * 0.1).toFixed(2);

        var semitotal = this.form.LessAdmin + this.form.LessFuel;
        this.form.NetTrucker = parseFloat(this.form.BillAmount - semitotal).toFixed(2);
        this.form.totalrun = totalreading;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        this.view.ViewBillAmount = numeral(this.form.BillAmount).format('0,0.00');
        this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
        this.view.ViewLessAdmin = numeral(this.form.LessAdmin).format('0,0.00');

        if (this.eq == 'true') {
          this.form.BalanceAmount = this.form.BillAmount;
        }
      }
    },
    signalChangeactualstartreading: function signalChangeactualstartreading() {
      var totalreading = 0;

      if (this.form.endreading !== '') {
        totalreading = this.form.actualendreading - this.form.actualstartreading;
        this.form.totalactualrun = totalreading;

        if (this.eq == 'true') {// this.form.BalanceAmount = this.form.BillAmount;
        }
      }
    },
    signalChangeendreading: function signalChangeendreading() {
      var totalreading = 0;
      totalreading = this.form.endreading - this.form.startreading;
      this.form.BillAmount = parseFloat(totalreading * this.form.PerKilometerRate).toFixed(2);
      this.form.LessAdmin = 0; //parseFloat(this.form.BillAmount * 0.1).toFixed(2);

      var semitotal = this.form.LessAdmin + this.form.LessFuel;
      this.form.NetTrucker = parseFloat(this.form.BillAmount - semitotal).toFixed(2);
      this.form.totalrun = totalreading;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBillAmount = numeral(this.form.BillAmount).format('0,0.00');
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.view.ViewLessAdmin = numeral(this.form.LessAdmin).format('0,0.00');

      if (this.eq == 'true') {
        this.form.BalanceAmount = this.form.BillAmount;
        this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
      }
    },
    signalChangeactualendreading: function signalChangeactualendreading() {
      var totalreading = 0;
      totalreading = this.form.actualendreading - this.form.actualstartreading;
      this.form.totalactualrun = totalreading;

      if (this.eq == 'true') {// this.form.BalanceAmount = this.form.BillAmount;
        // this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
      }
    },
    signalChangeLessFuel: function signalChangeLessFuel() {
      var semitotalss = 0 + this.form.LessFuel; //this.form.LessAdmin + this.form.LessFuel;

      this.form.NetTrucker = this.form.BillAmount - this.form.LessFuel; //this.form.BillAmount - this.form.LessAdmin - this.form.LessFuel;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
    },
    signalChangeCollectedAmount: function signalChangeCollectedAmount() {
      this.collection.BalanceAmount = this.form.BalanceAmountHDR - this.form.CollectedAmount;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');

      if (this.form.BalanceAmount == 0) {
        this.form.Status = 'PAID';
      } //this.form.CollectedAmount = this.form.CollectedAmountHDR;

    },
    updateTitleLocation: function updateTitleLocation(updatedTitleLocation) {
      if (this.loc == 'MAIN') {
        this.form.LocationName = updatedTitleLocation.LocationName;
      } else if (this.loc == 'LOADING') {
        this.detail.LoadingLocationName = updatedTitleLocation.LocationName;
      } else if (this.loc == 'UNLOADING') {
        this.detail.UnLoadingLocationName = updatedTitleLocation.LocationName;
      } // console.log(updatedTitle);

    },
    updateTitle: function updateTitle(updatedTitle) {
      this.form.DriverName = updatedTitle.LastName + ',' + updatedTitle.FirstName + ' ' + updatedTitle.MiddleName + ' ' + updatedTitle.ExtName;
      this.form.DriverIDLink = updatedTitle.id;
      this.form.DriverLastName = updatedTitle.LastName;
      this.form.DriverFirstName = updatedTitle.FirstName;
      this.form.DriverMiddleName = updatedTitle.MiddleName;
      this.form.DriverExtName = updatedTitle.ExtName; // console.log(updatedTitle);
    },
    updateTitleOperator: function updateTitleOperator(updatedTitleOperator) {
      this.form.TruckerName = updatedTitleOperator.LastName + ',' + updatedTitleOperator.FirstName + ' ' + updatedTitleOperator.MiddleName + ' ' + updatedTitleOperator.ExtName;
      this.form.TruckerIDLink = updatedTitleOperator.id;
      this.form.TruckerLastName = updatedTitleOperator.LastName;
      this.form.TruckerFirstName = updatedTitleOperator.FirstName;
      this.form.TruckerMiddleName = updatedTitleOperator.MiddleName;
      this.form.TruckerExtName = updatedTitleOperator.ExtName; // console.log(updatedTitle);
    },
    updateTitleVehicle: function updateTitleVehicle(updatedTitleVehicle) {
      if (this.eq == 'true') {
        this.form.PHBPlateNo = updatedTitleVehicle.PlateNumber;
        this.form.PHBIDLink = updatedTitleVehicle.MVID;
        this.form.TruckerName = updatedTitleVehicle.TruckerName;
        this.form.TruckerIDLink = updatedTitleVehicle.TruckerID;
        this.form.TruckerLastName = updatedTitleVehicle.TruckerLastName;
        this.form.TruckerFirstName = updatedTitleVehicle.TruckerFirstName;
        this.form.TruckerMiddleName = updatedTitleVehicle.TruckerMiddleName;
        this.form.TruckerExtName = updatedTitleVehicle.TruckerExtName;
        this.form.DriverName = updatedTitleVehicle.DriverName;
        this.form.DriverIDLink = updatedTitleVehicle.DriverID;
        this.form.DriverLastName = updatedTitleVehicle.DriverLastName;
        this.form.DriverFirstName = updatedTitleVehicle.DriverFirstName;
        this.form.DriverMiddleName = updatedTitleVehicle.DriverMiddleName;
        this.form.DriverExtName = updatedTitleVehicle.DriverExtName; // console.log(updatedTitle);

        this.getVehicleRate();
      } else {
        this.form.SearchPHBPlateNo = updatedTitleVehicle.PlateNumber;
      }
    },
    getVehicleRate: function getVehicleRate() {
      var _this3 = this;

      axios.get('/api/getphbvehiclerate', {
        params: {
          PHBIDLink: this.form.PHBIDLink
        }
      }).then(function (response) {
        _this3.batch = response.data;
        _this3.form.PerKilometerRate = _this3.batch[0].PerKilometerRate;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        _this3.view.ViewPerKilometerRate = numeral(_this3.form.PerKilometerRate).format('0,0.00');
      })["catch"](function (err) {});
    },
    getJVLFilter: function getJVLFilter() {
      var _this4 = this;

      axios.get('/api/getphbfilter', {
        params: {
          PHBIDLink: this.form.PHBIDLink
        }
      }).then(function (response) {
        _this4.jvlfilter = response.data; //this.form.PerKilometerRate=this.jvlfilter[0].BillAmount;
      })["catch"](function (err) {});
    },
    getJVCP: function getJVCP() {
      var _this5 = this;

      console.log(this.form.PHBVLHDRID);
      axios.get('/api/getphbvcp', {
        params: {
          PHBVLHDRID_Link: this.form.PHBVLHDRID
        }
      }).then(function (_ref2) {
        var data = _ref2.data;
        _this5.JeepVehicleCollectionPayments = data;
        console.log(JeepVehicleCollectionPayments);
      })["catch"](function (err) {});
    },
    searchsearchVehicleFunction: function searchsearchVehicleFunction() {
      this.eq = 'false';
      $('#searchVehicle').modal('show');
    },
    searchVehicleFunction: function searchVehicleFunction() {
      $('#searchVehicle').modal('show');
    },
    getVehicleIsReal: function getVehicleIsReal() {
      var _this6 = this;

      axios.get('api/vehicle').then(function (_ref3) {
        var data = _ref3.data;
        return _this6.vehicles = data;
      });
      console.log(this.vehicles);
    },
    searchOperatorFunction: function searchOperatorFunction() {
      $('#searchOperator').modal('show');
    },
    getOperatorIsReal: function getOperatorIsReal() {
      var _this7 = this;

      axios.get('api/operator').then(function (_ref4) {
        var data = _ref4.data;
        return _this7.operators = data;
      });
      console.log(this.operators);
    },
    searchDriverFunction: function searchDriverFunction() {
      $('#searchDriver').modal('show');
    },
    searchLocationFunction: function searchLocationFunction() {
      this.loc = 'MAIN';
      $('#searchLocation').modal('show');
    },
    searchLoadingLocationFunction: function searchLoadingLocationFunction() {
      this.loc = 'LOADING';
      $('#searchLocation').modal('show');
    },
    searchUnLoadingLocationFunction: function searchUnLoadingLocationFunction() {
      this.loc = 'UNLOADING';
      $('#searchLocation').modal('show');
    },
    getDriverIsReal: function getDriverIsReal() {
      var _this8 = this;

      axios.get('api/driver').then(function (_ref5) {
        var data = _ref5.data;
        return _this8.drivers = data;
      });
    },
    getResults: function getResults() {
      var _this9 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/jvl?page=' + page).then(function (response) {
        _this9.jeepvehiclelog = response.data;
      });
    },
    updateJVL: function updateJVL(PHBVLHDRID) {
      this.$Progress.start();
      this.form.put('api/phbvl/' + this.form.PHBVLHDRID); //$('#addNew').modal('hide');

      toast.fire({
        icon: 'success',
        title: 'PHB Vehicle Log successfully updated'
      });
      this.$Progress.finish();

      if (this.form.CollectedAmount !== '') {
        //KUNG HEADER RA ANG GI UPDATE
        this.form.PHBVLHDRID_Link = this.form.PHBVLHDRID;
        this.createJVCP();
      }

      this.loadJVL();
    },
    deleteModal: function deleteModal(PHBVLHDRID) {
      var _this10 = this;
=======
    AgGridVue: AgGridVue,
    'search-signatory': _search_commonMasterList_Signatory_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-dmpi-sar': _search_dmpi_sar_SearchDmpiSar_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      general: new Form({
        batchLocation: {},
        SarActivity: {},
        glSar: {},
        whichSignatory: "",
        signatories: "",
        batch: {},
        isBatchLoading: false,
        soaNumberCorrect: 0,
        //0-loading, 1=error, 2=correct
        header: {},
        soaComponentKey: "",
        units: {},
        checked: false,
        dayTypeData: [{
          id: 1,
          day: 'REGULAR DAY'
        }, {
          id: 3,
          day: 'SUNDAY/ REST DAY'
        }, {
          id: 4,
          day: 'SPECIAL HOLIDAY'
        }, {
          id: 5,
          day: 'SPECIAL HOLIDAY ON REST DAY'
        }, {
          id: 6,
          day: 'REGULAR HOLIDAY'
        }, {
          id: 6,
          day: 'REGULAR HOLIDAY ON REST DAY'
        }],
        filter: null,
        selectedData: {},
        IdToDelete: []
      }),
      form: new Form({
        refID: "",
        locationID: "",
        toPaymentOf: "",
        periodCoveredFrom: "",
        periodCoveredTo: "",
        soaDate: "",
        controlNo: "",
        preparedBy: "",
        verifiedBy: "",
        notedBy: "",
        approvedBy: "",
        preparedByPos: "",
        verifiedByPos: "",
        notedByPos: "",
        approvedByPos: "",
        test: "",
        soaNumber: "",
        sarData: {},
        isPayrollBatched: false,
        status: '-'
      }),
      soaForm: new Form({
        hdrid: "",
        //form.refID
        refID: "",
        datePerformed: "",
        serviceNumber: "",
        activityID: "",
        poNumber: "",
        glAccount: "",
        costCenter: "",
        qty: "",
        unit: "",
        rate: "",
        rateID: "",
        amount: "",
        entrySheetNumber: "",
        details: {},
        glID: "",
        batchDaytype: "",
        batchDaytypeID: "",
        month: "",
        year: "",
        period: "",
        batchNumber: "",
        batchKey: "",
        batchInfo: {},
        filter: null,
        activity: "",
        gl: ""
      }),
      reactivateForm: new Form({
        reasonofreactivation: ""
      })
    };
  },
  mounted: function mounted() {
    this.getBatchLocation();
    this.getSarRateActivity();
    this.getGl();
    this.getSignatories();
    this.getUnitsFromSarRate();
  },
  methods: {
    onChange: function onChange(e) {
      var _this = this;

      this.general.IdToDelete = [];
      this.form.applied_amount = 0;
      this.form.filter = [];
      var selectedRows = this.gridApi.getSelectedNodes();
      console.log('lenght', selectedRows.length);
      this.general.selectedData = selectedRows.map(function (node) {
        return node.data;
      });
      var selectedDataStringPresentation = this.general.selectedData.map(function (node) {
        return _this.general.IdToDelete.push(node.id);
      });
      var push = this.general.selectedData.map(function (node) {
        return _this.form.filter.push(node);
      });
      console.log(this.general.IdToDelete);
    },
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    getBatchLocation: function getBatchLocation() {
      var _this2 = this;

      axios.get("api/dmpiSarGetLocation/").then(function (_ref) {
        var data = _ref.data;
        _this2.general.batchLocation = data;
      });
    },
    getSarRateActivity: function getSarRateActivity() {
      var _this3 = this;

      axios.get("api/dmpiSarGetActivity/").then(function (_ref2) {
        var data = _ref2.data;
        _this3.general.SarActivity = data;
      });
    },
    getGl: function getGl() {
      var _this4 = this;

      axios.post("api/getSelectedGl", {
        type: 'SAR'
      }).then(function (_ref3) {
        var data = _ref3.data;
        _this4.general.glSar = data;
      });
    },
    sarHeaderEntry: function sarHeaderEntry() {
      $('#sarEntry').modal('show');
    },
    reactivate_detail: function reactivate_detail() {
      $('#reactivate_details').modal('show');
    },
    searchSignatory: function searchSignatory(wS) {
      $('#searchSignatory').modal('show');
      this.general.whichSignatory = wS;
    },
    setSign: function setSign(value) {
      if (this.general.whichSignatory == 'prepared') {
        this.form.preparedBy = value.name;
        this.form.preparedByPos = value.position;
      } else if (this.general.whichSignatory == 'verified') {
        this.form.verifiedBy = value.name;
        this.form.verifiedByPos = value.position;
      } else if (this.general.whichSignatory == 'noted') {
        this.form.notedBy = value.name;
        this.form.notedByPos = value.position;
      } else if (this.general.whichSignatory == 'approved') {
        this.form.approvedBy = value.name;
        this.form.approvedByPos = value.position;
      }
    },
    saveNewHeader: function saveNewHeader() {
      var _this5 = this;

      this.$Progress.start();

      if (this.general.soaNumberCorrect == 2) {
        this.form.post("api/dmpiSar").then(function (_ref4) {
          var data = _ref4.data;
          toast.fire({
            icon: 'success',
            title: 'data successfully saved.'
          });

          _this5.getHeaderDetail(data);

          _this5.$Progress.finish();

          $('#sarEntry').modal('hide');
        })["catch"](function (_ref5) {
          var err = _ref5.err;
          toast.fire({
            icon: 'error',
            title: 'Something went wrong'
          });

          _this5.$Progress.fail();

          console.log(err);
        });
      } else {
        toast.fire({
          icon: 'error',
          title: 'Check SOA Number'
        });
        this.$Progress.fail();
      }
    },
    updateHeader: function updateHeader() {
      var _this6 = this;

      this.$Progress.start();
      this.form.post("api/updateHeader").then(function (_ref6) {
        var data = _ref6.data;

        _this6.$Progress.finish();

        toast.fire({
          icon: 'success',
          title: 'data sucessfully updated.'
        });
      })["catch"](function (_ref7) {
        var error = _ref7.error;
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this6.$Progress.fail();

        console.log(error);
      });
    },
    saveNewDetail: function saveNewDetail() {
      var _this7 = this;

      this.$Progress.start();
      this.soaForm.hdrid = this.form.refID;
      this.soaForm.post("api/saveDetail").then(function (_ref8) {
        var data = _ref8.data;
        toast.fire({
          icon: 'success',
          title: 'data successfully saved.'
        });
        console.log('success', data);
        _this7.soaForm.refID = data;

        _this7.$Progress.finish();

        _this7.getSarDetails(_this7.form.refID);

        $('#sardetail').modal('hide');
      })["catch"](function (_ref9) {
        var err = _ref9.err;
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this7.$Progress.fail();

        console.log(err);
      });
    },
    updateDetail: function updateDetail() {
      var _this8 = this;

      console.log('dtlid', this.soaForm.refID);
      this.$Progress.start();
      this.soaForm.hdrid = this.form.refID;
      this.soaForm.put("api/dmpiSar/" + this.soaForm.refID).then(function (_ref10) {
        var data = _ref10.data;
        toast.fire({
          icon: 'success',
          title: 'data successfully saved.'
        });
        _this8.soaForm.refID = data;

        _this8.$Progress.finish();

        $('#sardetail').modal('hide');

        _this8.getSarDetails(_this8.form.refID);
      })["catch"](function (_ref11) {
        var err = _ref11.err;
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this8.$Progress.fail();

        console.log(err);
      });
    },
    getSignatories: function getSignatories() {
      var _this9 = this;

      axios({
        method: 'GET',
        url: '/api/billingsignatoryGetForSearch'
      }).then(function (_ref12) {
        var data = _ref12.data;
        _this9.general.signatories = data;
      });
    },
    getSoas: function getSoas() {
      var _this10 = this;

      this.general.isBatchLoading = true;
      axios.get('/api/dmpidargetbatch', {
        params: {
          month: this.soaForm.month,
          year: this.soaForm.year,
          period: this.soaForm.period,
          isVolume: 1
        }
      }).then(function (_ref13) {
        var data = _ref13.data;
        _this10.general.batch = data;
        _this10.general.isBatchLoading = false;
      })["catch"](function (err) {
        _this10.general.isBatchLoading = true;
      });
    },
    getBatchInfo: function getBatchInfo() {
      var _this11 = this;

      this.general.isBatchLoading = true; // this.form.soaNumber = ""

      axios.get('/api/getBatchInfo', {
        params: {
          id: this.soaForm.batchKey
        }
      }).then(function (_ref14) {
        var data = _ref14.data;
        _this11.soaForm.batchInfo = data;
        _this11.soaForm.batchNumber = data[0]['BNo'];
        _this11.soaForm.batchDaytype = _this11.soaForm.batchInfo[0]['DayType'];
        _this11.soaForm.batchDaytypeID = _this11.soaForm.batchInfo[0]['DayTypeID_Link']; // this.form.soaNumber = data[0]['Code_Location'] + data[0]['Code_Date'] + data[0]['Code_Series']

        _this11.general.isBatchLoading = false; // this.soaNumberCheck(); 
      })["catch"](function (err) {
        _this11.general.isBatchLoading = true;
        console.log(err);
      });
    },
    getHeaderDetail: function getHeaderDetail(id) {
      var _this12 = this;

      this.form.refID = id;
      axios.post('/api/getHeaderDetail', {
        id: id
      }).then(function (_ref15) {
        var data = _ref15.data;
        console.log(data);
        _this12.general.header = data['hdr'];
        _this12.form.details = data['dtl'];
      })["catch"](function (_ref16) {
        var error = _ref16.error;
        console.log(error);
      });
    },
    soaNumberCheck: function soaNumberCheck() {
      var _this13 = this;

      if (this.form.soaNumber.trim() != "") {
        axios.get('/api/checkifSoaExists', {
          params: {
            soaNumber: this.form.soaNumber,
            id: this.form.refID,
            type: "SAR"
          }
        }).then(function (_ref17) {
          var data = _ref17.data;

          if (data == true) {
            _this13.general.soaNumberCorrect = 1;
          } else {
            _this13.general.soaNumberCorrect = 2;
          }
        })["catch"](function (err) {
          console.log(err);
        });
      } else {
        this.general.soaNumberCorrect = 0;
      }
    },
    sourceChangedPrepared: _.debounce(function (e) {
      var _this14 = this;

      axios.get('/api/getPosition', {
        params: {
          name: this.form.preparedBy
        }
      }).then(function (_ref18) {
        var data = _ref18.data;
        _this14.form.preparedByPos = data[0]['position'];
      })["catch"](function (err) {
        console.log(err);
      });
    }, 1000),
    sourceChangedVerified: _.debounce(function (e) {
      var _this15 = this;

      axios.get('/api/getPosition', {
        params: {
          name: this.form.verifiedBy
        }
      }).then(function (_ref19) {
        var data = _ref19.data;
        _this15.form.verifiedByPos = data[0]['position'];
      })["catch"](function (err) {
        console.log(err);
      });
    }, 1000),
    sourceChangedNoted: _.debounce(function (e) {
      var _this16 = this;

      axios.get('/api/getPosition', {
        params: {
          name: this.form.notedBy
        }
      }).then(function (_ref20) {
        var data = _ref20.data;
        _this16.form.notedByPos = data[0]['position'];
      })["catch"](function (err) {
        console.log(err);
      });
    }, 1000),
    sourceChangedApproved: _.debounce(function (e) {
      var _this17 = this;

      axios.get('/api/getPosition', {
        params: {
          name: this.form.approvedBy
        }
      }).then(function (_ref21) {
        var data = _ref21.data;
        _this17.form.approvedByPos = data[0]['position'];
      })["catch"](function (err) {
        console.log(err);
      });
    }, 1000),
    getSarRate: function getSarRate() {
      var _this18 = this;

      this.soaForm.post('api/getRateSar').then(function (_ref22) {
        var data = _ref22.data;
        _this18.soaForm.rate = data[0]['rate'];
        _this18.soaForm.rateID = data[0]['VRALID'];

        if (_this18.soaForm.qty != '') {
          _this18.soaForm.amount = (_this18.soaForm.rate * _this18.soaForm.qty).toFixed(3);
        }
      })["catch"](function (_ref23) {
        var error = _ref23.error;
        console.log(error);
      });
    },
    setSoa: function setSoa(value) {
      console.log(value);
      this.form.refID = value.id;
      this.provideDataForSelectedSoa(value);
      this.general.soaComponentKey += 1;
    },
    provideDataForSelectedSoa: function provideDataForSelectedSoa(hdr) {
      // set the header
      this.form.locationID = hdr.locationID;
      this.form.periodCoveredFrom = hdr.periodCoveredFrom;
      this.form.periodCoveredTo = hdr.periodCoveredTo;
      this.form.soaDate = hdr.soaDate;
      this.form.controlNo = hdr.controlNo;
      this.form.preparedBy = hdr.preparedBy;
      this.form.verifiedBy = hdr.verifiedBy;
      this.form.notedBy = hdr.notedBy;
      this.form.approvedBy = hdr.approvedBy;
      this.form.preparedByPos = hdr.approvedByPosition;
      this.form.verifiedByPos = hdr.verifiedByPosition;
      this.form.notedByPos = hdr.notedByPosition;
      this.form.approvedByPos = hdr.approvedByPosition;
      this.form.soaNumber = hdr.soaNumber;
      this.form.status = hdr.status; // get sar details 

      this.getSarDetails(hdr.id);
    },
    getSarDetails: function getSarDetails(id) {
      var _this19 = this;

      console.log('hdr', id);
      axios.post("api/getSarDtl/", {
        refID: id
      }).then(function (_ref24) {
        var data = _ref24.data;
        _this19.general.filter = data;
      });
    },
    getUnitsFromSarRate: function getUnitsFromSarRate() {
      var _this20 = this;

      axios.get('api/getUnitsFromSarRate').then(function (_ref25) {
        var data = _ref25.data;
        _this20.general.units = data;
        console.log(data);
      })["catch"](function (_ref26) {
        var error = _ref26.error;
        console.log(error);
      });
    },
    getLocationName: function getLocationName(loc_ID) {
      var _this21 = this;

      axios.post('api/getLocationName', {
        loc: loc_ID
      }).then(function (_ref27) {
        var data = _ref27.data;
        _this21.form.location = data;
      })["catch"](function (_ref28) {
        var error = _ref28.error;
        console.log(error);
      });
    },
    searchDmpiSar: function searchDmpiSar() {
      $('#searchDmpiSar').modal('show');
    },
    deleteSarHeader: function deleteSarHeader() {
      var _this22 = this;
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
<<<<<<< HEAD
          _this10.$Progress.start();

          _this10.form["delete"]('api/phbvl/' + PHBVLHDRID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');
          _this10.form.PHBVLHDRID_Link = PHBVLHDRID;
          axios.get('/api/deletephbvcpdtl', {
            params: {
              PHBVLHDRID_Link: _this10.form.PHBVLHDRID_Link
            }
          }).then(function (_ref6) {
            var data = _ref6.data;
          })["catch"](function (err) {});
          axios.get('/api/deleteallphbdtl', {
            params: {
              PHBVLHDRID_Link: _this10.form.PHBVLHDRID_Link
            }
          }).then(function (_ref7) {
            var data = _ref7.data;
          })["catch"](function (err) {});

          _this10.$Progress.finish();

          _this10.loadJVL();
        }
      });
    },
    deleteModalJVCP: function deleteModalJVCP(jvcp) {
      var _this11 = this;

      if (this.form.BalanceAmount == 0 && this.form.Status == 'PAID') {
        swal.fire({
          title: 'Ooopsie Doopsieee',
          text: 'The transaction is already PAID.',
          icon: 'error',
          showCancelButton: true,
          showConfirmButton: false,
          cancelButtonColor: '#d33'
        }).then(function (result) {
          if (result.value) {}
        });
      } else {
        swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then(function (result) {
          if (result.value) {
            _this11.form.Status = 'PAID';
            _this11.form.BalanceAmount = _this11.form.BalanceAmount + jvcp.CollectedAmount;

            var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

            _this11.view.ViewBalanceAmount = numeral(_this11.form.BalanceAmount).format('0,0.00');
            var collectedamount = _this11.form.BillAmount - _this11.form.BalanceAmount;
            _this11.form.CollectedAmount = collectedamount;
            console.log('Bill Amount Before Delete:' + _this11.form.BillAmount);
            console.log('Balance Amount Before Delete:' + _this11.form.BalanceAmount);
            console.log('Selected Payment Detail Collected Amount Before Delete:' + jvcp.CollectedAmount);
            console.log('Value of Collected Amount Variable' + _this11.form.CollectedAmount);
            _this11.form.ORCRNumber = jvcp.ORCRNumber;
            _this11.form.ORCRDate = jvcp.ORCRDate;
            _this11.form.Remarks = jvcp.Remarks;

            _this11.$Progress.start(); //UPDATE FIRST


            _this11.form.put('api/phbvl/' + _this11.form.PHBVLHDRID); //$('#addNew').modal('hide');


            _this11.loadJVL();

            _this11.form.PHBVLHDRID_Link = _this11.form.PHBVLHDRID; //END UPDATE

            _this11.form["delete"]('api/phbvcp/' + jvcp.PHBVCDTLID);

            swal.fire('Deleted!', 'Your file has been deleted.', 'success');

            _this11.getJVCP();

            _this11.getJVLBalanceAmount();

            _this11.$Progress.finish();

            _this11.form.PHBVLHDRID_Link = jvcp.PHBVLHDRID_Link;
            _this11.form.CollectedAmount = '';
            _this11.form.ORCRNumber = '';
            _this11.form.ORCRDate = '';
            _this11.form.Remarks = '';
          }
        });
      }
    },
    editModal: function editModal(jvl) {
      this.form.PHBVLHDRID_Link = jvl.PHBVLHDRID;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBillAmount = numeral(jvl.BillAmount).format('0,0.00');
      this.view.ViewNetTrucker = numeral(jvl.NetTrucker).format('0,0.00');
      this.view.ViewLessAdmin = numeral(jvl.LessAdmin).format('0,0.00');
      this.view.ViewPerKilometerRate = numeral(jvl.PerKilometerRate).format('0,0.00'); //console.log(this.form.PHBVLHDRID_Link);

      this.editmode = true;
      this.form.reset();
      $('#addNew').modal('show');
      this.form.fill(jvl);
      this.form.CollectedAmount = '';
      this.form.BalanceAmount = jvl.BalanceAmount;
      this.form.BalanceAmountHDR = jvl.BalanceAmount;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
      this.form.ORCRNumber = '';
      this.form.ORCRDate = '';
      this.form.Remarks = '';
      this.getJVCP();
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      this.view.reset();
      $('#addNew').modal('show');
      var today = new Date().toISOString().slice(0, 10);
      this.form.PHBVLDate = today;
      this.form.LessFuel = 0;
      this.form.FuelLiters = 0;
    },
    closeModalMultiple: function closeModalMultiple() {
      location.reload();
      $('#addNewMultiple').modal('hide');
    },
    newModalMultiple: function newModalMultiple() {
      var _this12 = this;

      this.var1 = 0;
      this.first = 0;
      var i = 0;
      this.form.PHBVLHDRID = this.checkedNames;
      this.$Progress.start();

      if (this.checkedNames == '') {
        this.$Progress.fail();
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'No Transaction Selected.'
        });
      } else {
        axios.get('/api/getphbvlfilter', {
          params: {
            PHBVLHDRID: this.checkedNames
          }
        }).then(function (response) {
          _this12.jvlfilter = response.data;

          for (i = 0; i < _this12.jvlfilter.length; i++) {
            if (_this12.jvlfilter[i].BillAmount != _this12.jvlfilter[0].BillAmount) {
              _this12.$Progress.fail();

              swal.fire({
                title: 'Ooopsie Doopsieee',
                text: 'The transactions that you have selected are not uniform in Bill Amount. Please review.',
                icon: 'error',
                showCancelButton: true,
                showConfirmButton: false,
                cancelButtonColor: '#d33'
              }).then(function (result) {
                if (result.value) {} else {
                  $('#addNewMultiple').modal('hide');
                }
              });
              break;
            } else {
              _this12.editmode = false;

              _this12.form.reset();

              _this12.form.BillAmount = _this12.jvlfilter[0].BillAmount;
              _this12.form.BalanceAmount = _this12.jvlfilter[0].BalanceAmount;
              _this12.form.BalanceAmountHDR = _this12.jvlfilter[0].BalanceAmount;

              var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

              _this12.view.ViewBalanceAmount = numeral(_this12.form.BalanceAmount).format('0,0.00'); //this.form.CollectedAmount = this.jvlfilter[0].CollectedAmount;
              //this.form.BalanceAmount = this.form.BillAmount - this.form.CollectedAmount;

              $('#addNewMultiple').modal('show');
            }
          }
        }); //END AXIOS

        this.$Progress.finish();
      }
    },
    doSomething: function doSomething(data) {
      console.log(data);
    },
    loadJVL: function loadJVL() {
      var _this13 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getphbvl').then(function (response) {
        _this13.jvls = response.data;
        console.log(_this13.jvls);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    loadPHBDTL: function loadPHBDTL() {
      var _this14 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getphbdtl', {
        params: {
          PHBVLHDRID_Link: this.detail.PHBVLHDRID_Link
        }
      }).then(function (response) {
        _this14.PHBDetails = response.data;
        console.log(_this14.PHBDetails);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    loadJVCP: function loadJVCP() {
      var _this15 = this;

      axios.get('api/jvcp').then(function (_ref8) {
        var data = _ref8.data;
        return _this15.jvcps = data;
      });
    },
    createJVL: function createJVL() {
      var _this16 = this;

      this.$Progress.start();
      this.form.post('api/phbvl').then(function () {
        //$('#addNew').modal('hide');
        //$('.modal-backdrop').remove();
        _this16.form.reset();

        _this16.view.reset();

        var today = new Date().toISOString().slice(0, 10);
        _this16.form.PHBVLDate = today;
        toast.fire({
          icon: 'success',
          title: 'PHB Vehicle Log successfully created'
        });

        _this16.$Progress.finish();

        _this16.loadJVL();

        _this16.form.LessFuel = 0;
        _this16.form.FuelLiters = 0;
      })["catch"](function () {
        _this16.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'PHB Vehicle Log not added successfully'
        });
      });
    },
    createPHBDetails: function createPHBDetails() {
      var _this17 = this;

      this.$Progress.start();
      axios.get('api/insertphbdtl', {
        params: {
          PHBVLHDRID_Link: this.detail.PHBVLHDRID_Link,
          Assignment: this.detail.Assignment,
          LoadingLocationName: this.detail.LoadingLocationName,
          LoadingTimeIn: this.detail.LoadingTimeIn,
          LoadingTimeStart: this.detail.LoadingTimeStart,
          UnLoadingLocationName: this.detail.UnLoadingLocationName,
          UnLoadingTimeIn: this.detail.UnLoadingTimeIn,
          UnLoadingTimeStart: this.detail.UnLoadingTimeStart,
          UnLoadingTimeEnd: this.detail.UnLoadingTimeEnd
        }
      }).then(function (response) {
        toast.fire({
          icon: 'success',
          title: 'PHB Detail successfully created'
        });

        _this17.$Progress.finish();

        _this17.loadPHBDTL();
      })["catch"](function (error) {
        this.$Progress.fail();
        toast.fire({
          icon: 'error',
          title: 'PHB Detail not added successfully'
        });
      });
    },
    createJVCP: function createJVCP() {
      var _this18 = this;

      this.form.post('api/phbvcp').then(function () {
        toast.fire({
          icon: 'success',
          title: 'PHB Vehicle Log successfully created'
        });

        _this18.getJVCP();

        _this18.form.CollectedAmount = ''; //this.form.BalanceAmount=0;

        _this18.form.ORCRNumber = '';
        _this18.form.ORCRDate = '';
        _this18.form.Remarks = '';

        _this18.getJVLBalanceAmount();
      })["catch"](function () {
        _this18.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'PHB Vehicle Collection Payment not added successfully'
        });
      });
    },
    getJVLBalanceAmount: function getJVLBalanceAmount() {
      var _this19 = this;

      axios.get('/api/getphbvlbalanceamount', {
        params: {
          PHBVLHDRID: this.form.PHBVLHDRID
        }
      }).then(function (response) {
        _this19.jvlbalamt = response.data;
        _this19.form.BalanceAmountHDR = _this19.jvlbalamt[0].BalanceAmount;
        console.log(_this19.jvlbalamt[0].BalanceAmount);
      })["catch"](function (err) {});
    },
    deleteEntirePaymentDetail: function deleteEntirePaymentDetail() {
      this.form["delete"]('api/phbdeleteentirepaymentdetail/' + this.form.PHBVLHDRID);
      swal.fire('Deleted!', 'Your file has been deleted.', 'success');
      this.form.PHBVLHDRID_Link = this.form.PHBVLHDRID;
      this.getJVCP();
    },
    deleteModalPHBDTL: function deleteModalPHBDTL(PHBDTL) {
      this.detail.PHBVLDTLID = PHBDTL.PHBVLDTLID;
      axios.get('/api/deletephbdtl', {
        params: {
          PHBVLDTLID: this.detail.PHBVLDTLID
        }
      }).then(function (_ref9) {
        var data = _ref9.data;
        swal.fire('Deleted!', 'Your file has been deleted.', 'success');
      })["catch"](function (err) {});
      this.loadPHBDTL();
    },
    createJVCPMultiple: function createJVCPMultiple() {
      var _this20 = this;

      if (this.form.BalanceAmount == 0) {
        this.form.Status = 'PAID';
      } else {
        this.form.Status = 'POSTED';
      }

      this.editmode = false;
      swal.fire({
        title: 'Are you sure you watn to save?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, save it!'
      }).then(function (result) {
        if (result.value) {
          _this20.$Progress.start(); ////console.log(this.checkedNames);


          var arr = 0;

          for (var i = 0; i < _this20.checkedNames.length; i++) {
            arr = i;
            console.log(_this20.checkedNames.length);
            _this20.form.PHBVLHDRID_Link = _this20.checkedNames[i]; //console.log(this.form.PHBVLHDRID_Link);
            //UPDATE VEHICLE LOG HDR

            _this20.form.put('api/phbvlphbvcp/' + _this20.checkedNames[i]);

            $('#addNewMultiple').modal('hide'); //END UPDATE
            //CREATE INSERT TO JEEP VEHICLE COLLECTION PAYMENT

            _this20.form.post('api/phbvcp').then(function () {
              //toast.fire({
              //   icon: "success",
              //  title: "Transaction done."
              //});
              swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 1500
              });
            }); //END CREATE

          }

          _this20.$Progress.finish(); //location.reload();


          _this20.loadJVL();

          _this20.checkedNames = [];
        }
      });
    }
  },
  created: function created() {
    this.loadJVL(); //setInterval(() => this.loadDriver(),3000);
  },
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this21 = this;

      if (this.DateFrom !== '' || this.DateTo !== '' && this.SearchPHBPlateNo !== '') {
        this.SearchPHBPlateNo = '';
        var vm = this;
        var startdate = vm.DateFrom;
        var enddate = vm.DateTo;
        return _.filter(vm.jvls, function (data) {
          if (_.isNull(startdate) && _.isNull(enddate)) {
            return true;
          } else {
            var date = data.PHBVLDate;
            return date >= startdate && date <= enddate;
          }
        });
      } else {
        this.DateFrom = '';
        this.DateTo = ''; //return this.jvls.filter(jvl =>{
        //return jvl.PHBPlateNo.includes(this.form.PHBPlateNo)
        //});

        return this.jvls.filter(function (samsung) {
          return _this21.SearchPHBPlateNo.toLowerCase().split(' ').every(function (v) {
            return samsung.PHBPlateNo.toLowerCase().includes(v);
          });
        });
      }
=======
          _this22.form["delete"]('api/billingsignatory/' + id).then(function () {
            swal.fire('Deleted!', 'Your file has been deleted.', 'success');

            _this22.getResults();
          })["catch"](function () {
            swal.fire('Failed!', 'Something went wrong.', 'error');
          });
        }
      });
    },
    checkUncheckBatch: function checkUncheckBatch() {
      // if (this.checked){
      //   if(this.form.batchInfo[0]['DayTypeID_Link']){
      //     this.soaForm.batchDaytypeID = this.form.batchInfo[0]['DayTypeID_Link']
      //   }
      // }
      this.getSarRate;
    },
    clearAll: function clearAll() {
      this.general.reset();
      this.soaForm.reset();
      this.form.reset();
      this.getBatchLocation();
      this.getSarRateActivity();
      this.getGl();
      this.getSignatories();
      this.getUnitsFromSarRate();
    },
    activityChange: function activityChange() {
      var _this23 = this;

      axios.post('api/getSelectedActivity', {
        id: this.soaForm.activityID
      }).then(function (_ref29) {
        var data = _ref29.data;
        _this23.soaForm.activity = data[0]['SubActivity'];
      })["catch"](function (_ref30) {
        var error = _ref30.error;
        console.log(error);
      });
      this.getSarRate;
    },
    sarDetailModal: function sarDetailModal(editOrDelete) {
      if (this.form.refID != "") {
        if (editOrDelete == "add") {
          $('#sardetail').modal('show');
          this.soaForm.reset();
          this.general.checked = false;
        } else if (editOrDelete == "edit") {
          console.log(this.general.selectedData[0]);
          this.soaForm.fill(this.general.selectedData[0]);
          this.soaForm.refID = this.general.selectedData[0].id;
          this.soaForm.hdrid = this.general.selectedData[0].hdr_id;
          this.soaForm.rateID = this.general.selectedData[0].rate_id;

          if (this.general.selectedData[0].batchID) {
            this.general.checked = true;
            this.soaForm.month = this.general.selectedData[0].pmy.substr(this.general.selectedData[0].pmy.length - 2);
            this.soaForm.year = this.general.selectedData[0].pmy.substring(0, 4);
            this.getSoas();
            this.soaForm.batchKey = this.general.selectedData[0].batchID;
            this.soaForm.batchNumber = this.general.selectedData[0].batchNo;
          } else {
            this.general.checked = false;
          } // pmy: (...)


          $('#sardetail').modal('show');
        }
      }
    },
    deleteSarDetail: function deleteSarDetail() {
      var _this24 = this;

      console.log('ids to delete', this.general.IdToDelete);
      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          axios.get('/api/deleteSarDetail', {
            params: {
              ids: _this24.general.IdToDelete
            }
          }).then(function (res) {
            swal.fire('Deleted!', 'Data has been deleted.', 'success');
            console.log('res', res);

            _this24.getSarDetails(_this24.form.refID);
          })["catch"](function () {
            swal.fire('Failed!', 'Something went wrong.', 'error');
          });
        }
      });
    },
    submit: function submit() {
      var _this25 = this;

      this.$Progress.start();
      console.log(this.form.refId);
      this.form.post('/api/dmpiSarSubmit').then(function (_ref31) {
        var data = _ref31.data;
        _this25.form.status = data;
        console.log;
        toast.fire({
          icon: 'success',
          title: 'Successfully submitted'
        });

        _this25.$Progress.finish();
      })["catch"](function (err) {
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this25.$Progress.fail();
      });
    },
    confirm: function confirm() {
      var _this26 = this;

      this.$Progress.start();
      console.log(this.form.refId);
      this.form.post('/api/dmpiSarConfirm').then(function (_ref32) {
        var data = _ref32.data;
        _this26.form.status = data;
        console.log;
        toast.fire({
          icon: 'success',
          title: 'Successfully confirmed'
        });

        _this26.$Progress.finish();
      })["catch"](function (err) {
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this26.$Progress.fail();
      });
    },
    transmit: function transmit() {
      var _this27 = this;

      this.$Progress.start();
      console.log(this.form.refId);
      this.form.post('/api/dmpiSarTransmit').then(function (_ref33) {
        var data = _ref33.data;
        _this27.form.status = data;
        console.log;
        toast.fire({
          icon: 'success',
          title: 'Successfully transmitted'
        });

        _this27.$Progress.finish();
      })["catch"](function (err) {
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this27.$Progress.fail();
      });
    },
    reactivate: function reactivate() {
      var _this28 = this;

      this.$Progress.start();
      this.reactivateForm.refID = this.form.refID;
      this.reactivateForm.post('/api/dmpiSarReactivate').then(function (_ref34) {
        var data = _ref34.data;
        _this28.form.status = data;
        toast.fire({
          icon: 'success',
          title: 'Successfully reactivated'
        });
        _this28.soaForm.refID = data;

        _this28.$Progress.finish();

        _this28.getSarDetails(_this28.form.refID);

        $('#reactivate_details').modal('hide');
      })["catch"](function (err) {
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });

        _this28.$Progress.fail();
      });
    }
  },
  //method end
  created: function created() {
    // data grid 
    this.columnDefs = [{
      headerName: "Date Performed",
      field: "datePerformed",
      resizable: true,
      width: 170,
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true
    }, {
      headerName: "Service Number",
      field: "serviceNumber",
      resizable: true,
      width: 170
    }, {
      headerName: "Activity",
      field: "activity",
      resizable: true,
      width: 170
    }, {
      headerName: "PO Number",
      field: "poNumber",
      resizable: true,
      width: 170
    }, {
      headerName: "GL Account",
      field: "gl",
      resizable: true,
      width: 170
    }, {
      headerName: "Cost Center",
      field: "costCenter",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }, {
      headerName: "Quantity",
      field: "qty",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }, {
      headerName: "Unit",
      field: "unit",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      }
    }, {
      headerName: "Rate",
      field: "rate",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }, {
      headerName: "Amount",
      field: "amount",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }, {
      headerName: "Entry sheet number",
      field: "entrySheetNumber",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }];
    this.general.filter = []; // end data grid 

    var d = new Date();
    this.soaForm.month = d.getMonth();
    this.soaForm.year = d.getFullYear();
    var day = d.getDate();

    if (day < 16) {
      this.soaForm.period = 1;
    } else {
      this.soaForm.period = 2;
    }

    this.getSoas();
  },
  computed: {
    years: function years() {
      var year = new Date().getFullYear();
      return Array.from({
        length: 5
      }, function (value, index) {
        return year + 2 - index;
      });
    },
    months: function months() {
      var month = 12;
      return Array.from({
        length: 12
      }, function (value, index) {
        return month - index;
      });
    },
    periods: function periods() {
      var period = 1;
      return Array.from({
        length: 2
      }, function (value, index) {
        return period + index;
      });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    }
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      locations: [],
      swegets: [],
      searchClientVar: "",
      form: new Form({
        search: ""
      })
    };
  },
  mounted: function mounted() {
    this.loadLocation();
  },
  methods: {
    changeTitleLocation: function changeTitleLocation(location) {
      // console.log(driver);
      this.$emit('changeTitleLocation', location); // this.$emit('kuhaDriverID',driver.id);

      $('#searchLocation').modal('hide');
    },
    loadLocation: function loadLocation() {
      var _this = this;

      axios.get('api/getlocation').then(function (response) {
        _this.locations = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this2 = this;

      //return this.drivers.filter(driver =>{
      //return driver.LastName.includes(this.form.search)
      //});
      return this.locations.filter(function (samsung) {
        return _this2.form.search.toLowerCase().split(' ').every(function (v) {
          return samsung.LocationName.toLowerCase().includes(v);
        });
=======
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      searching: "",
      data: {},
      filter: {},
      datas: []
    };
  },
  methods: {
    loadMode: function loadMode() {
      var _this = this;

      axios.get("/api/billingsignatoryGetForSearch").then(function (_ref) {
        var data = _ref.data;
        _this.data = data;
        _this.filter = _this.data;
        console.log(_this.filter);
      });
    },
    search: function search(e) {
      this.filter = this.data.filter(function (item) {
        return item.name.match(e);
      });
    },
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      this.$emit("selectSign", dataItem);
      $("#searchSignatory").modal("hide");
    }
  },
  mounted: function mounted() {
    this.loadMode();
  },
  created: function created() {}
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      searchAll: false,
      soas: {},
      selectedSoa: {},
      searchSoaVar: ''
    };
  },
  mounted: function mounted() {},
  methods: {
    getSoa: function getSoa() {
      var _this = this;

      axios({
        method: 'GET',
        url: '/api/dmpisarsearch'
      }).then(function (_ref) {
        var data = _ref.data;
        return _this.soas = data;
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      });
      console.log(this.soas);
    },
    searchSoa: _.debounce(function () {
      Fire.$emit('searchSignStart');
    }, 500),
    setsoa: function setsoa(data) {
      this.selectedSoa = data;
      this.selectSoa();
      $('#searchDmpiSar').modal('hide'); // console.log(data)
    },
    selectSoa: function selectSoa(event) {
      this.$emit('selectSoa', this.selectedSoa);
      this.soas = {};
      this.selectedSoa = {};
    }
<<<<<<< HEAD
=======
  },
  created: function created() {
    var _this2 = this;

    Fire.$on('searchSignStart', function () {
      axios.get('/api/dmpisarsearch', {
        params: {
          soa: _this2.searchSoaVar
        }
      }).then(function (data) {
        _this2.soas = data.data;
      })["catch"](function (err) {
        console.log(err.data);
      });
    });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n\tpointer-events: none;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& ***!
  \***************************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=template&id=e5260026&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=template&id=e5260026& ***!
  \************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
<<<<<<< HEAD
    { staticClass: "container", attrs: { id: "sweget" } },
    [
      _c(
        "nav",
        {
          staticClass:
            "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
        },
        [
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNavDropdown" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#mlist"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Master File\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "mlist"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/driverlist" }
                            },
                            [_c("a", [_vm._v("Driver List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/phbvehiclelist" }
                            },
                            [_c("a", [_vm._v("PHB Vehicle List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehicletype" }
                            },
                            [_c("a", [_vm._v("Vehicle Type List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/phbvehiclerate" }
                            },
                            [_c("a", [_vm._v("PHB Rate List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/clientlist" }
                            },
                            [_c("a", [_vm._v("Client List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/locationlist" }
                            },
                            [_c("a", [_vm._v("Location List")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#trans"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Transactions\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "trans"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/phbvehiclelogentry" }
                            },
                            [_c("a", [_vm._v("PHB Vehicle Log Entry")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#report"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              PHB Reports\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "report"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistPHB" }
                            },
                            [_c("a", [_vm._v("Standard PHB Report")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistPHBPerJeep" }
                            },
                            [
                              _c("a", [
                                _vm._v("PHB's Vehicle Log Billing Report")
                              ])
                            ]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ])
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
=======
    { staticClass: "container" },
    [
      _c("div", { staticClass: "justify-content-center" }, [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c(
              "form",
              {
                staticStyle: {
                  "border-style": "solid",
                  "border-color": "coral"
                }
              },
              [
                _c("div", { staticClass: "form-inline" }, [
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(1),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateFrom,
                            expression: "DateFrom"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateFrom" },
                        domProps: { value: _vm.DateFrom },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateFrom = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(2),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateTo,
                            expression: "DateTo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateTo" },
                        domProps: { value: _vm.DateTo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateTo = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              _vm.filterKey = "all"
                            }
                          }
                        },
                        [_vm._v("Search")]
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-left": "5px",
                        "margin-top": "10px"
                      }
                    },
                    [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.SearchPHBPlateNo,
                            expression: "SearchPHBPlateNo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "SearchPHBPlateNo",
                          placeholder: "PHB Plate Number"
                        },
                        domProps: { value: _vm.SearchPHBPlateNo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.SearchPHBPlateNo = $event.target.value
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-primary", size: "sm" },
                              on: {
                                click: function($event) {
                                  return _vm.searchsearchVehicleFunction()
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-search",
                                attrs: { "aria-hidden": "true" }
                              })
                            ]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }),
            _vm._v(" "),
            _c("br")
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _c("thead", [
                  _c("tr", [
                    _c("th", [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.allSelected,
                            expression: "allSelected"
                          }
                        ],
                        attrs: { type: "checkbox" },
                        domProps: {
                          checked: Array.isArray(_vm.allSelected)
                            ? _vm._i(_vm.allSelected, null) > -1
                            : _vm.allSelected
                        },
                        on: {
                          click: _vm.selectAll,
                          change: function($event) {
                            var $$a = _vm.allSelected,
                              $$el = $event.target,
                              $$c = $$el.checked ? true : false
                            if (Array.isArray($$a)) {
                              var $$v = null,
                                $$i = _vm._i($$a, $$v)
                              if ($$el.checked) {
                                $$i < 0 && (_vm.allSelected = $$a.concat([$$v]))
                              } else {
                                $$i > -1 &&
                                  (_vm.allSelected = $$a
                                    .slice(0, $$i)
                                    .concat($$a.slice($$i + 1)))
                              }
                            } else {
                              _vm.allSelected = $$c
                            }
                          }
                        }
                      })
                    ]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Date")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("VL No")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Plate No")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Driver")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Billable Amt")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Less Fuel")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Net Operator")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Status")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Modify")])
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.filteredBlogs, function(jvl) {
                    return _c("tr", { key: jvl.PHBVLHDRID }, [
                      _c("td", [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.checkedNames,
                              expression: "checkedNames"
                            }
                          ],
                          attrs: { type: "checkbox" },
                          domProps: {
                            value: jvl.PHBVLHDRID,
                            checked: Array.isArray(_vm.checkedNames)
                              ? _vm._i(_vm.checkedNames, jvl.PHBVLHDRID) > -1
                              : _vm.checkedNames
                          },
                          on: {
                            change: function($event) {
                              var $$a = _vm.checkedNames,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = jvl.PHBVLHDRID,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    (_vm.checkedNames = $$a.concat([$$v]))
                                } else {
                                  $$i > -1 &&
                                    (_vm.checkedNames = $$a
                                      .slice(0, $$i)
                                      .concat($$a.slice($$i + 1)))
                                }
                              } else {
                                _vm.checkedNames = $$c
                              }
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.PHBVLDate))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.PHBPlateNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.DriverName))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(
                            "Php" +
                              jvl.BillAmount.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.LessFuel))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(
                            "Php" +
                              jvl.NetTrucker.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.Status))]),
                      _vm._v(" "),
                      _c("td", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.editModal(jvl)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-edit" })]
                        ),
                        _vm._v("\n                /\n                "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.deleteModal(jvl.PHBVLHDRID)
                              }
                            }
                          },
                          [
                            _c("i", {
                              staticClass: "fa fa-trash",
                              staticStyle: { color: "red" }
                            })
                          ]
                        )
                      ])
                    ])
                  }),
                  0
                )
              ])
            ]
          ),
          _vm._v(" "),
<<<<<<< HEAD
          _c("div", { staticClass: "card-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-warning",
                on: { click: _vm.newModalMultiple }
              },
              [
                _vm._v(
                  "\n            Add New Multiple PHB Vehicle Collection Payment\n            "
                ),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            ),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "btn btn-success", on: { click: _vm.newModal } },
              [
                _vm._v("\n            Add New PHB Vehicle Log\n            "),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            ),
            _vm._v(" "),
            _c("div", { staticStyle: { float: "right" } }, [
              _vm._v("Total SOA Amount : " + _vm._s(_vm.form.TotalAmount))
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New PHB Vehicle Log")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update PHB Vehicle Log's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(3)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode ? _vm.updateJVL() : _vm.createJVL()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(4),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBVLDate,
                                        expression: "form.PHBVLDate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      id: "PHBVLDate",
                                      type: "date",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.PHBVLDate },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBVLDate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBVLHDRID,
                                        expression: "form.PHBVLHDRID"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "hidden" },
                                    domProps: { value: _vm.form.PHBVLHDRID },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBVLHDRID",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(5),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLNo,
                                        expression: "form.OVLNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "OVLNo" },
                                    domProps: { value: _vm.form.OVLNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBPlateNo,
                                        expression: "form.PHBPlateNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PHBPlateNo",
                                      placeholder: "PHB Plate Number",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.PHBPlateNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBPlateNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PHBIDLink,
                                        expression: "form.PHBIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "PHBIDLink",
                                      placeholder: "PHBIDLink"
                                    },
                                    domProps: { value: _vm.form.PHBIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "PHBIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchVehicleFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverName,
                                        expression: "form.DriverName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "DriverName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "DriverName",
                                      placeholder: "Driver Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.DriverName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverLastName,
                                        expression: "form.DriverLastName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverLastName",
                                      placeholder: "DriverLastName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverLastName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverLastName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverFirstName,
                                        expression: "form.DriverFirstName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverFirstName",
                                      placeholder: "DriverFirstName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverFirstName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverFirstName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverMiddleName,
                                        expression: "form.DriverMiddleName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverMiddleName",
                                      placeholder: "DriverMiddleName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverMiddleName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverMiddleName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverExtName,
                                        expression: "form.DriverExtName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverExtName",
                                      placeholder: "DriverExtName"
                                    },
                                    domProps: { value: _vm.form.DriverExtName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverExtName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverIDLink,
                                        expression: "form.DriverIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverIDLink",
                                      placeholder: "DriverIDLink"
                                    },
                                    domProps: { value: _vm.form.DriverIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchDriverFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(6),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.GLCode,
                                        expression: "form.GLCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "GLCode" },
                                    domProps: { value: _vm.form.GLCode },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "GLCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(7),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CostCenter,
                                        expression: "form.CostCenter"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "CostCenter" },
                                    domProps: { value: _vm.form.CostCenter },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "CostCenter",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(8),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewPerKilometerRate,
                                        expression: "view.ViewPerKilometerRate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PerKilometerRate"
                                    },
                                    domProps: {
                                      value: _vm.view.ViewPerKilometerRate
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewPerKilometerRate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LocationName,
                                        expression: "form.LocationName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "LocationName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "LocationName",
                                      placeholder: "Location Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.LocationName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LocationName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchLocationFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(9),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.Assignment,
                                        expression: "form.Assignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "Assignment" },
                                    domProps: { value: _vm.form.Assignment },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Assignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(10),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.TimeIn,
                                        expression: "form.TimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "time", name: "TimeIn" },
                                    domProps: { value: _vm.form.TimeIn },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "TimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(11),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.TimeOut,
                                        expression: "form.TimeOut"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "time", name: "TimeOut" },
                                    domProps: { value: _vm.form.TimeOut },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "TimeOut",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c(
                              "div",
                              { staticClass: "col" },
                              [
                                _c("center", [
                                  _c("h3", [_vm._v("Kilometer Run - DMPI")])
                                ])
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "col" },
                              [
                                _c("center", [
                                  _c("h3", [
                                    _vm._v("Actual Kilometer Run - GSC")
                                  ])
                                ])
                              ],
                              1
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(12),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.startreading,
                                        expression: "form.startreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#82E0AA" },
                                    attrs: {
                                      type: "number",
                                      name: "startreading",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.startreading },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "startreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangestartreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(13),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.actualstartreading,
                                        expression: "form.actualstartreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85C1E9" },
                                    attrs: {
                                      type: "number",
                                      name: "endreading",
                                      required: ""
                                    },
                                    domProps: {
                                      value: _vm.form.actualstartreading
                                    },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "actualstartreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeactualstartreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(14),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.endreading,
                                        expression: "form.endreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#82E0AA" },
                                    attrs: {
                                      type: "number",
                                      name: "startreading",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.endreading },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "endreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangestartreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(15),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.actualendreading,
                                        expression: "form.actualendreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85C1E9" },
                                    attrs: {
                                      type: "number",
                                      name: "endreading",
                                      required: ""
                                    },
                                    domProps: {
                                      value: _vm.form.actualendreading
                                    },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "actualendreading",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeactualendreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(16),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.totalrun,
                                        expression: "form.totalrun"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#82E0AA" },
                                    attrs: {
                                      type: "number",
                                      name: "totalrun",
                                      "data-readonly": ""
                                    },
                                    domProps: { value: _vm.form.totalrun },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "totalrun",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(17),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.totalactualrun,
                                        expression: "form.totalactualrun"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85C1E9" },
                                    attrs: {
                                      type: "number",
                                      name: "totalactualrun",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.form.totalactualrun
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "totalactualrun",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(18),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.FuelLiters,
                                        expression: "form.FuelLiters"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "number",
                                      name: "FuelLiters"
                                    },
                                    domProps: { value: _vm.form.FuelLiters },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "FuelLiters",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(19),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LessFuel,
                                        expression: "form.LessFuel"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "number", name: "LessFuel" },
                                    domProps: { value: _vm.form.LessFuel },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "LessFuel",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangeLessFuel()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(20),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewNetTrucker,
                                        expression: "view.ViewNetTrucker"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "ViewNetTrucker",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewNetTrucker
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewNetTrucker",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(21),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewBillAmount,
                                        expression: "view.ViewBillAmount"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "ViewBillAmount",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewBillAmount
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewBillAmount",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "pre-scrollable" }, [
                          _c(
                            "table",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.editmode,
                                  expression: "editmode"
                                }
                              ],
                              staticClass: "table table-hover"
                            },
                            [
                              _c(
                                "tbody",
                                [
                                  _vm._m(22),
                                  _vm._v(" "),
                                  _vm._l(
                                    _vm.JeepVehicleCollectionPayments,
                                    function(jvcp) {
                                      return _c(
                                        "tr",
                                        { key: jvcp.PHBVCDTLID },
                                        [
                                          _c("td", [
                                            _vm._v(
                                              _vm._s(
                                                "Php" +
                                                  jvcp.CollectedAmount.toLocaleString(
                                                    undefined,
                                                    {
                                                      maximumFractionDigits: 2,
                                                      minimumFractionDigits: 2
                                                    }
                                                  )
                                              )
                                            )
                                          ]),
                                          _vm._v(" "),
                                          _c("td", [
                                            _vm._v(
                                              _vm._s(
                                                _vm._f("formatDate")(
                                                  jvcp.ORCRDate
                                                )
                                              )
                                            )
                                          ]),
                                          _vm._v(" "),
                                          _c("td", [
                                            _vm._v(_vm._s(jvcp.ORCRNumber))
                                          ]),
                                          _vm._v(" "),
                                          _c("td"),
                                          _c("td", [
                                            _c(
                                              "a",
                                              {
                                                attrs: { href: "#" },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.deleteModalJVCP(
                                                      jvcp
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-trash",
                                                  staticStyle: { color: "red" }
                                                })
                                              ]
                                            )
                                          ])
                                        ]
                                      )
                                    }
                                  )
                                ],
                                2
                              )
                            ]
                          )
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: { click: _vm.AddCollection }
                        },
                        [_vm._v("Add PHB Amount Collection")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: { click: _vm.InsertDetails }
                        },
                        [_vm._v("Add PHB Details")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-warning",
                          attrs: { type: "button" },
                          on: { click: _vm.SetToUnpaid }
                        },
                        [_vm._v("Set to Unpaid")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNewMultiple",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Multiple PHB Vehicle Log")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Multiple PHB Vehicle Log's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(23)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode
                          ? _vm.updateJVL()
                          : _vm.createJVCPMultiple()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body" }, [
                      _c(
                        "div",
                        {
                          staticClass: "form-inline",
                          staticStyle: {
                            "border-style": "solid",
                            "border-color": "coral"
                          }
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(24),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.BillAmount,
                                    expression: "form.BillAmount"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "BillAmount",
                                  "data-readonly": ""
                                },
                                domProps: { value: _vm.form.BillAmount },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "BillAmount",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.PHBVLHDRID_Link,
                                    expression: "form.PHBVLHDRID_Link"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: { type: "hidden" },
                                domProps: { value: _vm.form.PHBVLHDRID_Link },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "PHBVLHDRID_Link",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.CollectedAmount,
                                    expression: "form.CollectedAmount"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "CollectedAmount"
                                },
                                domProps: { value: _vm.form.CollectedAmount },
                                on: {
                                  input: [
                                    function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "CollectedAmount",
                                        $event.target.value
                                      )
                                    },
                                    function($event) {
                                      return _vm.signalChangeCollectedAmount()
                                    }
                                  ]
                                }
                              })
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(25),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.BalanceAmount,
                                    expression: "form.BalanceAmount"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: { type: "text", name: "BalanceAmount" },
                                domProps: { value: _vm.form.BalanceAmount },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "BalanceAmount",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.BalanceAmountHDR,
                                    expression: "form.BalanceAmountHDR"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "BalanceAmountHDR"
                                },
                                domProps: { value: _vm.form.BalanceAmountHDR },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "BalanceAmountHDR",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(26),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.ORCRNumber,
                                    expression: "form.ORCRNumber"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: { type: "text", name: "ORCRNumber" },
                                domProps: { value: _vm.form.ORCRNumber },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "ORCRNumber",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(27),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.ORCRDate,
                                    expression: "form.ORCRDate"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  id: "date",
                                  type: "date",
                                  name: "ORCRDate"
                                },
                                domProps: { value: _vm.form.ORCRDate },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "ORCRDate",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "input-group mb-3 input-group-sm",
                              staticStyle: { "margin-left": "5px" }
                            },
                            [
                              _vm._m(28),
                              _vm._v(" "),
                              _c("textarea", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.Remarks,
                                    expression: "form.Remarks"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: { type: "text", name: "Remarks" },
                                domProps: { value: _vm.form.Remarks },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "Remarks",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            ]
                          )
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addPHBDetails",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add PHB Details")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update PHB Details")]
                  ),
                  _vm._v(" "),
                  _vm._m(29)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        !_vm.editmode ? _vm.updateJVL() : _vm.createPHBDetails()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c("div", { staticClass: "pre-scrollable" }, [
                                _c(
                                  "table",
                                  {
                                    directives: [
                                      {
                                        name: "show",
                                        rawName: "v-show",
                                        value: _vm.editmode,
                                        expression: "editmode"
                                      }
                                    ],
                                    staticClass: "table table-hover"
                                  },
                                  [
                                    _c(
                                      "tbody",
                                      [
                                        _vm._m(30),
                                        _vm._v(" "),
                                        _vm._l(_vm.PHBDetails, function(
                                          PHBDTL
                                        ) {
                                          return _c(
                                            "tr",
                                            { key: PHBDTL.PHBVLDTLID },
                                            [
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(PHBDTL.Assignment)
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(
                                                    PHBDTL.LoadingLocationName
                                                  )
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(PHBDTL.LoadingTimeIn)
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(
                                                    PHBDTL.LoadingTimeStart
                                                  )
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(PHBDTL.LoadingTimeEnd)
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(
                                                    PHBDTL.UnLoadingLocationName
                                                  )
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(PHBDTL.UnLoadingTimeIn)
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(
                                                    PHBDTL.UnLoadingTimeStart
                                                  )
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _vm._v(
                                                  _vm._s(
                                                    PHBDTL.UnLoadingTimeEnd
                                                  )
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("td", [
                                                _c(
                                                  "a",
                                                  {
                                                    attrs: { href: "#" },
                                                    on: {
                                                      click: function($event) {
                                                        return _vm.deleteModalPHBDTL(
                                                          PHBDTL
                                                        )
                                                      }
                                                    }
                                                  },
                                                  [
                                                    _c("i", {
                                                      staticClass:
                                                        "fa fa-trash",
                                                      staticStyle: {
                                                        color: "red"
                                                      }
                                                    })
                                                  ]
                                                )
                                              ])
                                            ]
                                          )
                                        })
                                      ],
                                      2
                                    )
                                  ]
                                )
                              ])
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(31),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.PHBVLHDRID_Link,
                                        expression: "detail.PHBVLHDRID_Link"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PHBVLHDRID_Link"
                                    },
                                    domProps: {
                                      value: _vm.detail.PHBVLHDRID_Link
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "PHBVLHDRID_Link",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(32),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.Assignment,
                                        expression: "detail.Assignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "Assignment" },
                                    domProps: { value: _vm.detail.Assignment },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "Assignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("LOADING")])])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("UNLOADING")])])],
                              1
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(33),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingLocationName,
                                        expression: "detail.LoadingLocationName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "LoadingLocationName"
                                      )
                                    },
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingLocationName",
                                      "data-readonl": ""
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingLocationName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingLocationName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          staticStyle: {
                                            "border-color": "#E985A9"
                                          },
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchLoadingLocationFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(34),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingLocationName,
                                        expression:
                                          "detail.UnLoadingLocationName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "UnLoadingLocationName"
                                      )
                                    },
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingLocationName",
                                      "data-readonl": ""
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingLocationName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingLocationName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          staticStyle: {
                                            "border-color": "#85E9C5"
                                          },
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchUnLoadingLocationFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(35),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeIn,
                                        expression: "detail.LoadingTimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingLocationName"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeIn
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(36),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeIn,
                                        expression: "detail.UnLoadingTimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeIn"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeIn
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(37),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeStart,
                                        expression: "detail.LoadingTimeStart"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingTimeStart"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeStart
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeStart",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(38),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeStart,
                                        expression: "detail.UnLoadingTimeStart"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeStart"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeStart
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeStart",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(39),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeEnd,
                                        expression: "detail.LoadingTimeEnd"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingTimeEnd"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeEnd
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeEnd",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(40),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeEnd,
                                        expression: "detail.UnLoadingTimeEnd"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeEnd"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeEnd
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeEnd",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addPHBCollection",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-m",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editCollection,
                          expression: "!editCollection"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add PHB Collection")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editCollection,
                          expression: "editCollection"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update PHB Collection")]
                  ),
                  _vm._v(" "),
                  _vm._m(41)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editCollection
                          ? _vm.updateCollection()
                          : _vm.createPHBCollection()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "300px", "overflow-y": "auto" }
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: { "margin-left": "5px" }
                          },
                          [
                            _vm._m(42),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.collection.CollectedAmount,
                                  expression: "collection.CollectedAmount"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: { type: "text", name: "CollectedAmount" },
                              domProps: {
                                value: _vm.collection.CollectedAmount
                              },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.collection,
                                    "CollectedAmount",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: { "margin-left": "5px" }
                          },
                          [
                            _vm._m(43),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.collection.ORCRNumber,
                                  expression: "collection.ORCRNumber"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: { type: "text", name: "ORCRNumber" },
                              domProps: { value: _vm.collection.ORCRNumber },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.collection,
                                    "ORCRNumber",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: { "margin-left": "5px" }
                          },
                          [
                            _vm._m(44),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.collection.ORCRDate,
                                  expression: "collection.ORCRDate"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                id: "date",
                                type: "date",
                                name: "ORCRDate"
                              },
                              domProps: { value: _vm.collection.ORCRDate },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.collection,
                                    "ORCRDate",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: { "margin-left": "5px" }
                          },
                          [
                            _vm._m(45),
                            _vm._v(" "),
                            _c("textarea", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.collection.Remarks,
                                  expression: "collection.Remarks"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: { type: "text", name: "Remarks" },
                              domProps: { value: _vm.collection.Remarks },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.collection,
                                    "Remarks",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editCollection,
                              expression: "!editCollection"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editCollection,
                              expression: "editCollection"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-driver", {
        on: {
          changeTitle: function($event) {
            return _vm.updateTitle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-operator", {
        on: {
          changeTitleOperator: function($event) {
            return _vm.updateTitleOperator($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-phbvehicle", {
        on: {
          changeTitleVehicle: function($event) {
            return _vm.updateTitleVehicle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-location", {
        on: {
          changeTitleLocation: function($event) {
            return _vm.updateTitleLocation($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("PHB Vehicle Log Entry")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("VL No")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("GL Code")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Cost Center")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Per Kilometer Rate")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Assignment")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time In")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time Out")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#82E0AA",
            "border-color": "#82E0AA"
          }
        },
        [_vm._v("Start Reading")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85C1E9",
            "border-color": "#85C1E9"
          }
        },
        [_vm._v("Actual Start Reading")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#82E0AA",
            "border-color": "#82E0AA"
          }
        },
        [_vm._v("End Reading")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85C1E9",
            "border-color": "#85C1E9"
          }
        },
        [_vm._v("Actual End Reading")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#82E0AA",
            "border-color": "#82E0AA"
          }
        },
        [_vm._v("Total DMPI Run")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85C1E9",
            "border-color": "#85C1E9"
          }
        },
        [_vm._v("Total Actual Run")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("No. Of Liters")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Less Fuel")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Net Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Bill Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", [_vm._v("Amount Collected")]),
      _vm._v(" "),
      _c("th", [_vm._v("OR/CR Date")]),
      _vm._v(" "),
      _c("th", [_vm._v("OR/CR No")]),
      _vm._v(" "),
      _c("th", [_vm._v("Modify")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Collected Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Balance Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR No./CR No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR/CR Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Remarks")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", [_vm._v("Assignment")]),
      _vm._v(" "),
      _c("th", [_vm._v("Loading Location")]),
      _vm._v(" "),
      _c("th", [_vm._v("Loading Time In")]),
      _vm._v(" "),
      _c("th", [_vm._v("Loading Time Start")]),
      _vm._v(" "),
      _c("th", [_vm._v("Loading Time End")]),
      _vm._v(" "),
      _c("th", [_vm._v("UnLoading Location")]),
      _vm._v(" "),
      _c("th", [_vm._v("UnLoading Time In")]),
      _vm._v(" "),
      _c("th", [_vm._v("UnLoading Time Start")]),
      _vm._v(" "),
      _c("th", [_vm._v("UnLoading Time End")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Header ID")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Assignment")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Location")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("UnLoading Location")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time In")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time In")]
      )
    ])
  },
=======
          _c("div", { staticClass: "card-body" }, [
            _c("div", { staticClass: "row" }, [
              _c(
                "div",
                { staticClass: "col col-3" },
                [
                  _c("label", [_vm._v("Search entry (Ref ID):")]),
                  _vm._v(" "),
                  _c(
                    "b-input-group",
                    { attrs: { size: "sm" } },
                    [
                      _c("b-form-input", {
                        attrs: { disabled: "" },
                        model: {
                          value: _vm.form.refID,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "refID", $$v)
                          },
                          expression: "form.refID"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          !_vm.form.refID
                            ? _c(
                                "b-button",
                                {
                                  attrs: {
                                    variant: "outline-success",
                                    size: "sm"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.searchDmpiSar()
                                    }
                                  }
                                },
                                [
                                  _c("i", {
                                    staticClass: "fa fa-search",
                                    attrs: { "aria-hidden": "true" }
                                  })
                                ]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.form.refID
                            ? _c(
                                "b-button",
                                {
                                  attrs: {
                                    variant: "outline-success",
                                    size: "sm"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.sarHeaderEntry()
                                    }
                                  }
                                },
                                [
                                  _c("i", {
                                    staticClass: "fa fa-pen",
                                    attrs: { "aria-hidden": "true" }
                                  })
                                ]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          !_vm.form.refID
                            ? _c(
                                "b-button",
                                {
                                  attrs: {
                                    variant: "outline-success",
                                    size: "sm"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.sarHeaderEntry()
                                    }
                                  }
                                },
                                [
                                  _c("i", {
                                    staticClass: "fa fa-plus",
                                    attrs: { "aria-hidden": "true" }
                                  })
                                ]
                              )
                            : _vm._e()
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                  _vm._v("To Payment Of:")
                ]),
                _vm._v(" "),
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.form.locationID,
                        expression: "form.locationID"
                      }
                    ],
                    staticClass: "form-control form-control-sm",
                    attrs: { disabled: "", required: true },
                    on: {
                      change: function($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function(o) {
                            return o.selected
                          })
                          .map(function(o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.form,
                          "locationID",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      }
                    }
                  },
                  _vm._l(_vm.general.batchLocation, function(loc) {
                    return _c(
                      "option",
                      {
                        key: loc.LocationID,
                        domProps: { value: loc.LocationID }
                      },
                      [_vm._v(_vm._s(loc.Location))]
                    )
                  }),
                  0
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                  _vm._v("SOA Number")
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.form.soaNumber,
                      expression: "form.soaNumber"
                    }
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { disabled: "", type: "text" },
                  domProps: { value: _vm.form.soaNumber },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.form, "soaNumber", $event.target.value)
                    }
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-sm-3" }, [
                _vm.form.status == "active"
                  ? _c(
                      "h2",
                      [
                        _c(
                          "b-badge",
                          {
                            staticClass: "float-right",
                            attrs: { variant: "primary" }
                          },
                          [_vm._v(_vm._s(this.form.status))]
                        )
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.form.status == "submitted"
                  ? _c(
                      "h2",
                      [
                        _c(
                          "b-badge",
                          {
                            staticClass: "float-right",
                            attrs: { variant: "success" }
                          },
                          [_vm._v(_vm._s(this.form.status))]
                        )
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.form.status == "confirmed"
                  ? _c(
                      "h2",
                      [
                        _c(
                          "b-badge",
                          {
                            staticClass: "float-right",
                            attrs: { variant: "warning" }
                          },
                          [_vm._v(_vm._s(this.form.status))]
                        )
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.form.status == "transmitted"
                  ? _c(
                      "h2",
                      [
                        _c(
                          "b-badge",
                          {
                            staticClass: "float-right",
                            attrs: { variant: "danger" }
                          },
                          [_vm._v(_vm._s(this.form.status))]
                        )
                      ],
                      1
                    )
                  : _vm._e()
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row mt-3" }, [
              _c("div", { staticClass: "col-3" }, [
                _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                  _vm._v("Period Covered From:")
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.form.periodCoveredFrom,
                      expression: "form.periodCoveredFrom"
                    }
                  ],
                  staticClass: "form-control form-control-sm mb-2",
                  attrs: {
                    disabled: "",
                    type: "date",
                    placeholder: "Search Rental..."
                  },
                  domProps: { value: _vm.form.periodCoveredFrom },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(
                        _vm.form,
                        "periodCoveredFrom",
                        $event.target.value
                      )
                    }
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                  _vm._v("Period Covered To:")
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.form.periodCoveredTo,
                      expression: "form.periodCoveredTo"
                    }
                  ],
                  staticClass: "form-control form-control-sm mb-2",
                  attrs: {
                    disabled: "",
                    type: "date",
                    placeholder: "Search Rental..."
                  },
                  domProps: { value: _vm.form.periodCoveredTo },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.form, "periodCoveredTo", $event.target.value)
                    }
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                  _vm._v("SOA Date:")
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.form.soaDate,
                      expression: "form.soaDate"
                    }
                  ],
                  staticClass: "form-control form-control-sm mb-2",
                  attrs: {
                    disabled: "",
                    type: "date",
                    placeholder: "Search Rental..."
                  },
                  domProps: { value: _vm.form.soaDate },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.form, "soaDate", $event.target.value)
                    }
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                  _vm._v("Control Number")
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.form.controlNo,
                      expression: "form.controlNo"
                    }
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { disabled: "", type: "text" },
                  domProps: { value: _vm.form.controlNo },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.form, "controlNo", $event.target.value)
                    }
                  }
                })
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row mt-3" }, [
              _c(
                "div",
                { staticClass: "col-sm-6" },
                [
                  _c("strong", [_vm._v("Prepared By:")]),
                  _vm._v(" "),
                  _c("b-form-input", {
                    attrs: { disabled: "", size: "sm", list: "preparedBy" },
                    model: {
                      value: _vm.form.preparedBy,
                      callback: function($$v) {
                        _vm.$set(_vm.form, "preparedBy", $$v)
                      },
                      expression: "form.preparedBy"
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "datalist",
                    { attrs: { id: "preparedBy" } },
                    _vm._l(_vm.general.signatories, function(signatory) {
                      return _c("option", {
                        key: signatory.id,
                        domProps: { value: signatory.name }
                      })
                    }),
                    0
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "col-sm-6" },
                [
                  _c("strong", [_vm._v("Verified and Checked By:")]),
                  _vm._v(" "),
                  _c("b-form-input", {
                    attrs: { disabled: "", size: "sm", list: "verifiedBy" },
                    model: {
                      value: _vm.form.verifiedBy,
                      callback: function($$v) {
                        _vm.$set(_vm.form, "verifiedBy", $$v)
                      },
                      expression: "form.verifiedBy"
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "datalist",
                    { attrs: { id: "verifiedBy" } },
                    _vm._l(_vm.general.signatories, function(signatory) {
                      return _c("option", {
                        key: signatory.id,
                        domProps: { value: signatory.name }
                      })
                    }),
                    0
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "col-sm-6" },
                [
                  _c("strong", [_vm._v("Noted By:")]),
                  _vm._v(" "),
                  _c("b-form-input", {
                    attrs: { disabled: "", size: "sm", list: "notedBy" },
                    model: {
                      value: _vm.form.notedBy,
                      callback: function($$v) {
                        _vm.$set(_vm.form, "notedBy", $$v)
                      },
                      expression: "form.notedBy"
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "datalist",
                    { attrs: { id: "notedBy" } },
                    _vm._l(_vm.general.signatories, function(signatory) {
                      return _c("option", {
                        key: signatory.id,
                        domProps: { value: signatory.name }
                      })
                    }),
                    0
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "col-sm-6" },
                [
                  _c("strong", [_vm._v("Approved By:")]),
                  _vm._v(" "),
                  _c("b-form-input", {
                    attrs: { disabled: "", size: "sm", list: "approvedBy" },
                    model: {
                      value: _vm.form.approvedBy,
                      callback: function($$v) {
                        _vm.$set(_vm.form, "approvedBy", $$v)
                      },
                      expression: "form.approvedBy"
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "datalist",
                    { attrs: { id: "approvedBy" } },
                    _vm._l(_vm.general.signatories, function(signatory) {
                      return _c("option", {
                        key: signatory.id,
                        domProps: { value: signatory.name }
                      })
                    }),
                    0
                  )
                ],
                1
              )
            ]),
            _vm._v(" "),
            _c("hr", { staticClass: "hr-1" }),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c(
                "div",
                { staticClass: "col-12" },
                [
                  _c(
                    "b-button",
                    {
                      staticClass: "float-right",
                      attrs: {
                        type: "button",
                        disabled: _vm.form.refID == "",
                        variant: "success"
                      },
                      on: {
                        click: function($event) {
                          return _vm.sarDetailModal("add")
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "far fa-plus-square" }, [
                        _vm._v(" Add new detail")
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  this.general.selectedData.length == 1
                    ? _c(
                        "b-button",
                        {
                          staticClass: "float-right",
                          attrs: { type: "button", variant: "primary" },
                          on: {
                            click: function($event) {
                              return _vm.sarDetailModal("edit")
                            }
                          }
                        },
                        [
                          _c("i", { staticClass: "fa fa-pen" }, [
                            _vm._v(" Edit detail")
                          ])
                        ]
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  this.general.selectedData.length > 0
                    ? _c(
                        "b-button",
                        {
                          staticClass: "float-right",
                          attrs: { type: "button", variant: "danger" },
                          on: { click: _vm.deleteSarDetail }
                        },
                        [
                          _c("i", { staticClass: "fa fa-trash" }, [
                            _vm._v(" Delete selected")
                          ])
                        ]
                      )
                    : _vm._e()
                ],
                1
              )
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row mt-2" }, [
              _c(
                "div",
                { staticClass: "col" },
                [
                  _c("ag-grid-vue", {
                    staticClass: "ag-theme-balham",
                    staticStyle: { width: "100%", height: "200px" },
                    attrs: {
                      columnDefs: _vm.columnDefs,
                      rowData: _vm.general.filter,
                      rowSelection: "multiple"
                    },
                    on: {
                      "grid-ready": _vm.onGridReady,
                      selectionChanged: _vm.onChange
                    }
                  })
                ],
                1
              )
            ]),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-9" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-primary",
                    attrs: { disabled: _vm.form.status != "active" },
                    on: {
                      click: function($event) {
                        return _vm.submit()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-save" }),
                    _vm._v("    Submit")
                  ]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-primary",
                    attrs: { disabled: _vm.form.status != "submitted" },
                    on: {
                      click: function($event) {
                        return _vm.confirm()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-save" }),
                    _vm._v("    Confirm")
                  ]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-primary",
                    attrs: { disabled: _vm.form.status != "confirmed" },
                    on: {
                      click: function($event) {
                        return _vm.transmit()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-save" }),
                    _vm._v("    Transmit")
                  ]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-warning",
                    attrs: {
                      disabled:
                        _vm.form.status == "active" || _vm.form.status == "-"
                    },
                    on: {
                      click: function($event) {
                        return _vm.reactivate_detail()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-redo" }),
                    _vm._v("   Reactivate")
                  ]
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-success float-right",
                    attrs: { type: "button" },
                    on: {
                      click: function($event) {
                        return _vm.clearAll()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-backspace" }),
                    _vm._v("    Clear")
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row margin-top-10" }, [
              _c("div", { staticClass: "col-12" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-outline-info btn-sm",
                    attrs: { type: "button" },
                    on: {
                      click: function($event) {
                        return _vm.printPdf()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-print" }),
                    _vm._v("   print pdf")
                  ]
                )
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal modal-overflow fade",
          attrs: {
            id: "sarEntry",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c("div", { staticClass: "modal-dialog modal-lg" }, [
            _c("div", { staticClass: "modal-content" }, [
              _vm._m(1),
              _vm._v(" "),
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                    }
                  }
                },
                [
                  _c("div", { staticClass: "modal-body" }, [
                    _c("div", { staticClass: "row mt-3" }, [
                      _c("div", { staticClass: "col-3" }, [
                        _c("label", { attrs: { for: "" } }, [_vm._v("RefID")]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.id,
                              expression: "form.id"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { disabled: "", type: "text", name: "id" },
                          domProps: { value: _vm.form.id },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "id", $event.target.value)
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-6" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("To Payment Of:")
                        ]),
                        _vm._v(" "),
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.locationID,
                                expression: "form.locationID"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: { required: true },
                            on: {
                              change: function($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function(o) {
                                    return o.selected
                                  })
                                  .map(function(o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.$set(
                                  _vm.form,
                                  "locationID",
                                  $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                )
                              }
                            }
                          },
                          _vm._l(_vm.general.batchLocation, function(loc) {
                            return _c(
                              "option",
                              {
                                key: loc.LocationID,
                                domProps: { value: loc.LocationID }
                              },
                              [_vm._v(_vm._s(loc.Location))]
                            )
                          }),
                          0
                        )
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-3" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Period Covered From:")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.periodCoveredFrom,
                              expression: "form.periodCoveredFrom"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          class: {
                            "is-invalid": _vm.form.errors.has(
                              "periodCoveredFrom"
                            )
                          },
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.form.periodCoveredFrom },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "periodCoveredFrom",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("hr"),
                    _vm._v(" "),
                    _c("div", { staticClass: "row mt-3" }, [
                      _c("div", { staticClass: "col-3" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Period Covered To:")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.periodCoveredTo,
                              expression: "form.periodCoveredTo"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          class: {
                            "is-invalid": _vm.form.errors.has("periodCoveredTo")
                          },
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.form.periodCoveredTo },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "periodCoveredTo",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-3" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("SOA Date:")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.soaDate,
                              expression: "form.soaDate"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          class: {
                            "is-invalid": _vm.form.errors.has("soaDate")
                          },
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.form.soaDate },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "soaDate", $event.target.value)
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-3" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Control Number")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.controlNo,
                              expression: "form.controlNo"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.form.errors.has("controlNo")
                          },
                          attrs: { type: "text" },
                          domProps: { value: _vm.form.controlNo },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "controlNo",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "col-3" },
                        [
                          _c("label", [_vm._v("SOA Number:")]),
                          _vm._v(" "),
                          _vm.general.soaNumberCorrect == 2
                            ? _c("i", {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: _vm.general.soaNumberCorrect == 2,
                                    expression: "general.soaNumberCorrect==2"
                                  }
                                ],
                                staticClass: "fas fa-check green"
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.general.soaNumberCorrect == 1
                            ? _c(
                                "b-badge",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: _vm.general.soaNumberCorrect == 1,
                                      expression: "general.soaNumberCorrect==1"
                                    }
                                  ],
                                  attrs: { pill: "", variant: "danger" }
                                },
                                [_vm._v("Soa # exists")]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.soaNumber,
                                expression: "form.soaNumber"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            class: {
                              "is-invalid": _vm.form.errors.has("soaNumber")
                            },
                            attrs: { required: "", type: "text" },
                            domProps: { value: _vm.form.soaNumber },
                            on: {
                              change: _vm.soaNumberCheck,
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "soaNumber",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ],
                        1
                      )
                    ]),
                    _vm._v(" "),
                    _c("hr"),
                    _vm._v(" "),
                    _c("div", { staticClass: "row mt-3" }, [
                      _c(
                        "div",
                        { staticClass: "col-sm-6" },
                        [
                          _c("strong", [_vm._v("Prepared By:")]),
                          _vm._v(" "),
                          _c("b-form-input", {
                            class: {
                              "is-invalid": _vm.form.errors.has("preparedBy")
                            },
                            attrs: { size: "sm", list: "preparedBy" },
                            on: { keyup: _vm.sourceChangedPrepared },
                            model: {
                              value: _vm.form.preparedBy,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "preparedBy", $$v)
                              },
                              expression: "form.preparedBy"
                            }
                          }),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.preparedByPos,
                                expression: "form.preparedByPos"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            class: {
                              "is-invalid": _vm.form.errors.has("preparedByPos")
                            },
                            attrs: { type: "text" },
                            domProps: { value: _vm.form.preparedByPos },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "preparedByPos",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "datalist",
                            { attrs: { id: "preparedBy" } },
                            _vm._l(_vm.general.signatories, function(
                              signatory
                            ) {
                              return _c("option", {
                                key: signatory.id,
                                domProps: { value: signatory.name }
                              })
                            }),
                            0
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "col-sm-6" },
                        [
                          _c("strong", [_vm._v("Verified and Checked By:")]),
                          _vm._v(" "),
                          _c("b-form-input", {
                            class: {
                              "is-invalid": _vm.form.errors.has("verifiedBy")
                            },
                            attrs: { size: "sm", list: "verifiedBy" },
                            on: { keyup: _vm.sourceChangedVerified },
                            model: {
                              value: _vm.form.verifiedBy,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "verifiedBy", $$v)
                              },
                              expression: "form.verifiedBy"
                            }
                          }),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.verifiedByPos,
                                expression: "form.verifiedByPos"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            class: {
                              "is-invalid": _vm.form.errors.has("verifiedByPos")
                            },
                            attrs: { type: "text" },
                            domProps: { value: _vm.form.verifiedByPos },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "verifiedByPos",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "datalist",
                            { attrs: { id: "verifiedBy" } },
                            _vm._l(_vm.general.signatories, function(
                              signatory
                            ) {
                              return _c("option", {
                                key: signatory.id,
                                domProps: { value: signatory.name }
                              })
                            }),
                            0
                          )
                        ],
                        1
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row mt-3" }, [
                      _c(
                        "div",
                        { staticClass: "col-sm-6" },
                        [
                          _c("strong", [_vm._v("Noted By:")]),
                          _vm._v(" "),
                          _c("b-form-input", {
                            class: {
                              "is-invalid": _vm.form.errors.has("notedBy")
                            },
                            attrs: { size: "sm", list: "notedBy" },
                            on: { keyup: _vm.sourceChangedNoted },
                            model: {
                              value: _vm.form.notedBy,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "notedBy", $$v)
                              },
                              expression: "form.notedBy"
                            }
                          }),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.notedByPos,
                                expression: "form.notedByPos"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            class: {
                              "is-invalid": _vm.form.errors.has("notedByPos")
                            },
                            attrs: { type: "text" },
                            domProps: { value: _vm.form.notedByPos },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "notedByPos",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "datalist",
                            { attrs: { id: "notedBy" } },
                            _vm._l(_vm.general.signatories, function(
                              signatory
                            ) {
                              return _c("option", {
                                key: signatory.id,
                                domProps: { value: signatory.name }
                              })
                            }),
                            0
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "col-sm-6" },
                        [
                          _c("strong", [_vm._v("Approved By:")]),
                          _vm._v(" "),
                          _c("b-form-input", {
                            class: {
                              "is-invalid": _vm.form.errors.has("approvedBy")
                            },
                            attrs: { size: "sm", list: "approvedBy" },
                            on: { keyup: _vm.sourceChangedApproved },
                            model: {
                              value: _vm.form.approvedBy,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "approvedBy", $$v)
                              },
                              expression: "form.approvedBy"
                            }
                          }),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.approvedByPos,
                                expression: "form.approvedByPos"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            class: {
                              "is-invalid": _vm.form.errors.has("approvedByPos")
                            },
                            attrs: { type: "text" },
                            domProps: { value: _vm.form.approvedByPos },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "approvedByPos",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "datalist",
                            { attrs: { id: "approvedBy" } },
                            _vm._l(_vm.general.signatories, function(
                              signatory
                            ) {
                              return _c("option", {
                                key: signatory.id,
                                domProps: { value: signatory.name }
                              })
                            }),
                            0
                          )
                        ],
                        1
                      )
                    ]),
                    _vm._v(" "),
                    _c("br")
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "modal-footer justify-content-between" },
                    [
                      _vm._m(2),
                      _vm._v(" "),
                      !_vm.form.refID
                        ? _c(
                            "button",
                            {
                              staticClass: "btn btn-primary",
                              attrs: { type: "button" },
                              on: {
                                click: function($event) {
                                  return _vm.saveNewHeader()
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "far fa-save" }),
                              _vm._v(" Create")
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.form.refID
                        ? _c(
                            "button",
                            {
                              staticClass: "btn btn-primary",
                              attrs: { type: "button" },
                              on: {
                                click: function($event) {
                                  return _vm.updateHeader()
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "far fa-save" }),
                              _vm._v(" Update")
                            ]
                          )
                        : _vm._e()
                    ]
                  )
                ]
              )
            ])
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal modal-overflow fade",
          attrs: {
            id: "sardetail",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c("div", { staticClass: "modal-dialog modal-xl" }, [
            _c("div", { staticClass: "modal-content" }, [
              _c("div", { staticClass: "modal-header" }, [
                this.soaForm.refID != ""
                  ? _c("h4", { staticClass: "modal-title" }, [_vm._v("Update")])
                  : _c("h4", { staticClass: "modal-title" }, [
                      _vm._v("Add New")
                    ]),
                _vm._v(" "),
                _vm._m(3)
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c("div", { staticClass: "row mt-3" }, [
                  _c(
                    "div",
                    { staticClass: "col-6" },
                    [
                      _c(
                        "b-form-checkbox",
                        {
                          attrs: { id: "checkbox-1" },
                          on: { change: _vm.checkUncheckBatch },
                          model: {
                            value: _vm.general.checked,
                            callback: function($$v) {
                              _vm.$set(_vm.general, "checked", $$v)
                            },
                            expression: "general.checked"
                          }
                        },
                        [_vm._v("Link a batch from payroll")]
                      )
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _vm.general.checked
                  ? _c(
                      "div",
                      {
                        staticClass: "row mt-3",
                        attrs: { id: "payrollbatch" }
                      },
                      [
                        _c("div", { staticClass: "col-12" }, [
                          _c("div", { staticClass: "card card-success" }, [
                            _vm._m(4),
                            _vm._v(" "),
                            _c("div", { staticClass: "card-body" }, [
                              _c(
                                "div",
                                { staticClass: "row", attrs: { id: "auto" } },
                                [
                                  _c("div", { staticClass: "col-sm-3" }, [
                                    _c("div", { staticClass: "form-group" }, [
                                      _c("label", { attrs: { for: "sel1" } }, [
                                        _vm._v("Month")
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "select",
                                        {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.soaForm.month,
                                              expression: "soaForm.month"
                                            }
                                          ],
                                          staticClass:
                                            "form-control form-control-sm",
                                          class: {
                                            "is-invalid": _vm.soaForm.errors.has(
                                              "month"
                                            )
                                          },
                                          on: {
                                            change: [
                                              function($event) {
                                                var $$selectedVal = Array.prototype.filter
                                                  .call(
                                                    $event.target.options,
                                                    function(o) {
                                                      return o.selected
                                                    }
                                                  )
                                                  .map(function(o) {
                                                    var val =
                                                      "_value" in o
                                                        ? o._value
                                                        : o.value
                                                    return val
                                                  })
                                                _vm.$set(
                                                  _vm.soaForm,
                                                  "month",
                                                  $event.target.multiple
                                                    ? $$selectedVal
                                                    : $$selectedVal[0]
                                                )
                                              },
                                              function($event) {
                                                return _vm.getSoas()
                                              }
                                            ]
                                          }
                                        },
                                        _vm._l(_vm.months, function(month) {
                                          return _c(
                                            "option",
                                            {
                                              key: month,
                                              domProps: { value: month }
                                            },
                                            [_vm._v(_vm._s(month))]
                                          )
                                        }),
                                        0
                                      )
                                    ])
                                  ]),
                                  _vm._v(" "),
                                  _c("div", { staticClass: "col-sm-3" }, [
                                    _c("div", { staticClass: "form-group" }, [
                                      _c("label", { attrs: { for: "sel1" } }, [
                                        _vm._v("Year")
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "select",
                                        {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.soaForm.year,
                                              expression: "soaForm.year"
                                            }
                                          ],
                                          staticClass:
                                            "form-control form-control-sm",
                                          class: {
                                            "is-invalid": _vm.soaForm.errors.has(
                                              "year"
                                            )
                                          },
                                          on: {
                                            change: [
                                              function($event) {
                                                var $$selectedVal = Array.prototype.filter
                                                  .call(
                                                    $event.target.options,
                                                    function(o) {
                                                      return o.selected
                                                    }
                                                  )
                                                  .map(function(o) {
                                                    var val =
                                                      "_value" in o
                                                        ? o._value
                                                        : o.value
                                                    return val
                                                  })
                                                _vm.$set(
                                                  _vm.soaForm,
                                                  "year",
                                                  $event.target.multiple
                                                    ? $$selectedVal
                                                    : $$selectedVal[0]
                                                )
                                              },
                                              function($event) {
                                                return _vm.getSoas()
                                              }
                                            ]
                                          }
                                        },
                                        _vm._l(_vm.years, function(year) {
                                          return _c(
                                            "option",
                                            {
                                              key: year,
                                              domProps: { value: year }
                                            },
                                            [_vm._v(_vm._s(year))]
                                          )
                                        }),
                                        0
                                      )
                                    ])
                                  ]),
                                  _vm._v(" "),
                                  _c("div", { staticClass: "col-sm-3" }, [
                                    _c("div", { staticClass: "form-group" }, [
                                      _c("label", { attrs: { for: "sel1" } }, [
                                        _vm._v("Period")
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "select",
                                        {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.soaForm.period,
                                              expression: "soaForm.period"
                                            }
                                          ],
                                          staticClass:
                                            "form-control form-control-sm",
                                          class: {
                                            "is-invalid": _vm.soaForm.errors.has(
                                              "period"
                                            )
                                          },
                                          on: {
                                            change: [
                                              function($event) {
                                                var $$selectedVal = Array.prototype.filter
                                                  .call(
                                                    $event.target.options,
                                                    function(o) {
                                                      return o.selected
                                                    }
                                                  )
                                                  .map(function(o) {
                                                    var val =
                                                      "_value" in o
                                                        ? o._value
                                                        : o.value
                                                    return val
                                                  })
                                                _vm.$set(
                                                  _vm.soaForm,
                                                  "period",
                                                  $event.target.multiple
                                                    ? $$selectedVal
                                                    : $$selectedVal[0]
                                                )
                                              },
                                              function($event) {
                                                return _vm.getSoas()
                                              }
                                            ]
                                          }
                                        },
                                        _vm._l(_vm.periods, function(period) {
                                          return _c(
                                            "option",
                                            {
                                              key: period,
                                              domProps: { value: period }
                                            },
                                            [_vm._v(_vm._s(period))]
                                          )
                                        }),
                                        0
                                      )
                                    ])
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    { staticClass: "col-sm-3" },
                                    [
                                      _c("label", [_vm._v("Batch Number:")]),
                                      _vm._v(" "),
                                      _c("b-spinner", {
                                        directives: [
                                          {
                                            name: "show",
                                            rawName: "v-show",
                                            value: _vm.general.isBatchLoading,
                                            expression: "general.isBatchLoading"
                                          }
                                        ],
                                        staticClass: "batch_load",
                                        staticStyle: {
                                          width: "1rem",
                                          height: "1rem"
                                        },
                                        attrs: {
                                          label: "Large Spinner",
                                          type: "grow",
                                          variant: "success"
                                        }
                                      }),
                                      _vm._v(" "),
                                      !_vm.general.batch.length
                                        ? _c(
                                            "b-badge",
                                            {
                                              directives: [
                                                {
                                                  name: "show",
                                                  rawName: "v-show",
                                                  value: !_vm.general
                                                    .isBatchLoading,
                                                  expression:
                                                    "!general.isBatchLoading"
                                                }
                                              ],
                                              attrs: {
                                                pill: "",
                                                variant: "danger"
                                              }
                                            },
                                            [_vm._v("No batch found")]
                                          )
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _c(
                                        "select",
                                        {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.soaForm.batchKey,
                                              expression: "soaForm.batchKey"
                                            }
                                          ],
                                          staticClass:
                                            "form-control form-control-sm",
                                          class: {
                                            "is-invalid": _vm.soaForm.errors.has(
                                              "batchNumber"
                                            )
                                          },
                                          attrs: { required: "" },
                                          on: {
                                            change: [
                                              function($event) {
                                                var $$selectedVal = Array.prototype.filter
                                                  .call(
                                                    $event.target.options,
                                                    function(o) {
                                                      return o.selected
                                                    }
                                                  )
                                                  .map(function(o) {
                                                    var val =
                                                      "_value" in o
                                                        ? o._value
                                                        : o.value
                                                    return val
                                                  })
                                                _vm.$set(
                                                  _vm.soaForm,
                                                  "batchKey",
                                                  $event.target.multiple
                                                    ? $$selectedVal
                                                    : $$selectedVal[0]
                                                )
                                              },
                                              function($event) {
                                                return _vm.getBatchInfo()
                                              }
                                            ]
                                          }
                                        },
                                        _vm._l(_vm.general.batch, function(
                                          soa
                                        ) {
                                          return _c(
                                            "option",
                                            {
                                              key: soa.BID,
                                              domProps: { value: soa.BID }
                                            },
                                            [_vm._v(_vm._s(soa.BNo))]
                                          )
                                        }),
                                        0
                                      )
                                    ],
                                    1
                                  )
                                ]
                              )
                            ])
                          ])
                        ])
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c("div", { staticClass: "row", attrs: { id: "manual" } }, [
                  _c("div", { staticClass: "col-3" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", { attrs: { for: "sel1" } }, [
                        _vm._v("Select a DayType")
                      ]),
                      _vm._v(" "),
                      _c(
                        "select",
                        {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.soaForm.batchDaytypeID,
                              expression: "soaForm.batchDaytypeID"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          class: {
                            "is-invalid": _vm.soaForm.errors.has(
                              "batchDaytypeID"
                            )
                          },
                          on: {
                            change: [
                              function($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function(o) {
                                    return o.selected
                                  })
                                  .map(function(o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.$set(
                                  _vm.soaForm,
                                  "batchDaytypeID",
                                  $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                )
                              },
                              function($event) {
                                return _vm.getSarRate()
                              }
                            ]
                          }
                        },
                        _vm._l(_vm.general.dayTypeData, function(day) {
                          return _c("option", { domProps: { value: day.id } }, [
                            _vm._v(_vm._s(day.day))
                          ])
                        }),
                        0
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "date" } }, [
                      _vm._v("Date Performed")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.datePerformed,
                          expression: "soaForm.datePerformed"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: {
                        "is-invalid": _vm.soaForm.errors.has("datePerformed")
                      },
                      attrs: { type: "date" },
                      domProps: { value: _vm.soaForm.datePerformed },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.soaForm,
                            "datePerformed",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "refence" } }, [
                      _vm._v("Service Number")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.serviceNumber,
                          expression: "soaForm.serviceNumber"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: {
                        "is-invalid": _vm.soaForm.errors.has("serviceNumber")
                      },
                      attrs: { type: "text" },
                      domProps: { value: _vm.soaForm.serviceNumber },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.soaForm,
                            "serviceNumber",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Activity / Operation:")
                    ]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.soaForm.activityID,
                            expression: "soaForm.activityID"
                          }
                        ],
                        staticClass: "form-control form-control-sm",
                        class: {
                          "is-invalid": _vm.soaForm.errors.has("activityID")
                        },
                        attrs: { required: true },
                        on: {
                          change: [
                            function($event) {
                              var $$selectedVal = Array.prototype.filter
                                .call($event.target.options, function(o) {
                                  return o.selected
                                })
                                .map(function(o) {
                                  var val = "_value" in o ? o._value : o.value
                                  return val
                                })
                              _vm.$set(
                                _vm.soaForm,
                                "activityID",
                                $event.target.multiple
                                  ? $$selectedVal
                                  : $$selectedVal[0]
                              )
                            },
                            _vm.activityChange
                          ]
                        }
                      },
                      _vm._l(_vm.general.SarActivity, function(activity) {
                        return _c(
                          "option",
                          {
                            key: activity.SAID,
                            domProps: { value: activity.SAID }
                          },
                          [_vm._v(_vm._s(activity.activity))]
                        )
                      }),
                      0
                    )
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "refence" } }, [
                      _vm._v("PO Number")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.poNumber,
                          expression: "soaForm.poNumber"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: {
                        "is-invalid": _vm.soaForm.errors.has("poNumber")
                      },
                      attrs: { type: "text" },
                      domProps: { value: _vm.soaForm.poNumber },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.soaForm, "poNumber", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("GL Account:")
                    ]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.soaForm.glID,
                            expression: "soaForm.glID"
                          }
                        ],
                        staticClass: "form-control form-control-sm",
                        class: { "is-invalid": _vm.soaForm.errors.has("glID") },
                        attrs: { required: true },
                        on: {
                          change: function($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function(o) {
                                return o.selected
                              })
                              .map(function(o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.$set(
                              _vm.soaForm,
                              "glID",
                              $event.target.multiple
                                ? $$selectedVal
                                : $$selectedVal[0]
                            )
                          }
                        }
                      },
                      _vm._l(_vm.general.glSar, function(gl) {
                        return _c(
                          "option",
                          { key: gl.id, domProps: { value: gl.id } },
                          [_vm._v(_vm._s(gl.gl))]
                        )
                      }),
                      0
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Cost Center")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.costCenter,
                          expression: "soaForm.costCenter"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: {
                        "is-invalid": _vm.soaForm.errors.has("costCenter")
                      },
                      attrs: { type: "text" },
                      domProps: { value: _vm.soaForm.costCenter },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.soaForm,
                            "costCenter",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Qty")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.qty,
                          expression: "soaForm.qty"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: { "is-invalid": _vm.soaForm.errors.has("qty") },
                      staticStyle: { "text-align": "right" },
                      attrs: { type: "number" },
                      domProps: { value: _vm.soaForm.qty },
                      on: {
                        change: _vm.getSarRate,
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.soaForm, "qty", $event.target.value)
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row mt-3" }, [
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", [_vm._v("Unit:")]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.soaForm.unit,
                            expression: "soaForm.unit"
                          }
                        ],
                        staticClass: "form-control form-control-sm",
                        class: { "is-invalid": _vm.soaForm.errors.has("unit") },
                        attrs: { required: true },
                        on: {
                          change: [
                            function($event) {
                              var $$selectedVal = Array.prototype.filter
                                .call($event.target.options, function(o) {
                                  return o.selected
                                })
                                .map(function(o) {
                                  var val = "_value" in o ? o._value : o.value
                                  return val
                                })
                              _vm.$set(
                                _vm.soaForm,
                                "unit",
                                $event.target.multiple
                                  ? $$selectedVal
                                  : $$selectedVal[0]
                              )
                            },
                            _vm.getSarRate
                          ]
                        }
                      },
                      _vm._l(_vm.general.units, function(unit) {
                        return _c(
                          "option",
                          { key: unit.unit, domProps: { value: unit.unit } },
                          [_vm._v(_vm._s(unit.unit))]
                        )
                      }),
                      0
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Rate")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.rate,
                          expression: "soaForm.rate"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: { "is-invalid": _vm.soaForm.errors.has("rate") },
                      staticStyle: { "text-align": "right" },
                      attrs: { disabled: "", type: "text" },
                      domProps: { value: _vm.soaForm.rate },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.soaForm, "rate", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Amount")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.amount,
                          expression: "soaForm.amount"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: { "is-invalid": _vm.soaForm.errors.has("amount") },
                      staticStyle: { "text-align": "right" },
                      attrs: { disabled: "", type: "text" },
                      domProps: { value: _vm.soaForm.amount },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.soaForm, "amount", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-3" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Entry Sheet Number")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.soaForm.entrySheetNumber,
                          expression: "soaForm.entrySheetNumber"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: {
                        "is-invalid": _vm.soaForm.errors.has("entrySheetNumber")
                      },
                      attrs: { type: "text" },
                      domProps: { value: _vm.soaForm.entrySheetNumber },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.soaForm,
                            "entrySheetNumber",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-footer" }, [
                _vm._m(5),
                _vm._v(" "),
                this.soaForm.refID != ""
                  ? _c(
                      "button",
                      {
                        staticClass: "btn btn-success",
                        attrs: { type: "button" },
                        on: { click: _vm.updateDetail }
                      },
                      [
                        _c("i", { staticClass: "fas fa-save" }),
                        _vm._v("    Update")
                      ]
                    )
                  : _c(
                      "button",
                      {
                        staticClass: "btn btn-success",
                        attrs: { type: "button" },
                        on: { click: _vm.saveNewDetail }
                      },
                      [
                        _c("i", { staticClass: "fas fa-save" }),
                        _vm._v("    Save")
                      ]
                    )
              ])
            ])
          ])
        ]
      ),
      _vm._v(" "),
      _c("search-signatory", { on: { selectSign: _vm.setSign } }),
      _vm._v(" "),
      _c("search-dmpi-sar", {
        key: this.general.soaComponentKey,
        on: { selectSoa: _vm.setSoa }
      }),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "reactivate_details",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "exampleModalLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            { staticClass: "modal-dialog", attrs: { role: "document" } },
            [
              _c("div", { staticClass: "modal-content" }, [
                _vm._m(6),
                _vm._v(" "),
                _c("div", { staticClass: "modal-body" }, [
                  _c("div", { staticClass: "input-group" }, [
                    _c("div", { staticClass: "col-12" }, [
                      _c("label", [_vm._v("Reason of Reactivation")]),
                      _vm._v(" "),
                      _c("textarea", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.reactivateForm.reasonofreactivation,
                            expression: "reactivateForm.reasonofreactivation"
                          }
                        ],
                        staticClass: "form-control",
                        class: {
                          "is-invalid": _vm.reactivateForm.errors.has(
                            "reasonofreactivation"
                          )
                        },
                        attrs: { "aria-label": "With textarea" },
                        domProps: {
                          value: _vm.reactivateForm.reasonofreactivation
                        },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.reactivateForm,
                              "reasonofreactivation",
                              $event.target.value
                            )
                          }
                        }
                      })
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "modal-footer" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-warning",
                      attrs: { type: "button" },
                      on: {
                        click: function($event) {
                          return _vm.reactivate()
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "fas fa-redo" }),
                      _vm._v("  Reactivate")
                    ]
                  )
                ])
              ])
            ]
          )
        ]
      )
    ],
    1
  )
}
var staticRenderFns = [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time Start")]
      )
=======
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [_vm._v("DMPI SAR / Volume DAR")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time Start")]
=======
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Add new SAR")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time End")]
      )
    ])
=======
    return _c(
      "button",
      {
        staticClass: "btn btn-default",
        attrs: { type: "button", "data-dismiss": "modal" }
      },
      [_c("i", { staticClass: "far fa-window-close" }), _vm._v(" Close")]
    )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time End")]
      )
    ])
=======
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
=======
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [_vm._v("Batch Information")])
    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Collected Amount")
      ])
=======
    return _c("div", [
      _c(
        "button",
        {
          staticClass: "btn btn-default",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [_c("i", { staticClass: "far fa-window-close" }), _vm._v(" Close")]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR No./CR No.")])
    ])
  },
=======
    return _c("div", { staticClass: "modal-header" }, [
      _c("h5", { staticClass: "modal-title" }, [_vm._v("Reactivation Detail")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=template&id=521139e4&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=template&id=521139e4& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "searchSignatory",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body search-modal" }, [
              _c(
                "div",
                [
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.searching,
                        expression: "searching"
                      }
                    ],
                    staticClass: "form-control form-control-sm mb-2",
                    attrs: { type: "text", placeholder: "Search by Mode..." },
                    domProps: { value: _vm.searching },
                    on: {
                      keyup: function($event) {
                        return _vm.search(_vm.searching)
                      },
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.searching = $event.target.value
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "kendo-grid",
                    {
                      attrs: {
                        height: 400,
                        "data-source": _vm.filter,
                        selectable: true,
                        sortable: true,
                        "scrollable-endless": true,
                        filterable: true
                      },
                      on: { change: _vm.onChange }
                    },
                    [
                      _c("kendo-grid-column", {
                        attrs: { field: "id", title: "ID" }
                      }),
                      _vm._v(" "),
                      _c("kendo-grid-column", {
                        attrs: { field: "name", title: "Name" }
                      }),
                      _vm._v(" "),
                      _c("kendo-grid-column", {
                        attrs: { field: "position", title: "Position" }
                      })
                    ],
                    1
                  )
                ],
                1
              )
            ]),
            _vm._v(" "),
            _vm._m(1)
          ])
        ])
      ]
    )
  ])
}
var staticRenderFns = [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("OR/CR Date")])
=======
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Search Signatory")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Remarks")])
=======
    return _c("div", { staticClass: "modal-footer" }, [
      _c(
        "button",
        {
          staticClass: "btn btn-danger",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [
          _c("i", { staticClass: "far fa-window-close" }),
          _vm._v(" Close\n          ")
        ]
      )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156& ***!
  \**********************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=template&id=31e35124&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=template&id=31e35124& ***!
  \********************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
<<<<<<< HEAD
          id: "searchLocation",
=======
          id: "searchDmpiSar",
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
<<<<<<< HEAD
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("form", [
              _c("div", { staticClass: "modal-body" }, [
                _c("div", { staticClass: "card-body" }, [
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-lg-6" },
                      [
                        _c(
                          "b-input-group",
                          { staticClass: "mt-3", attrs: { size: "sm" } },
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.form.search,
                                  expression: "form.search"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "search",
                                placeholder: "Search for..."
                              },
                              domProps: { value: _vm.form.search },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.form,
                                    "search",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "b-input-group-append",
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      variant: "outline-success",
                                      size: "sm"
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-search",
                                      attrs: { "aria-hidden": "true" }
                                    })
                                  ]
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "card-body table-responsive pre-scrollable"
                    },
                    [
                      _c("table", { staticClass: "table table-hover" }, [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.filteredBlogs, function(location) {
                            return _c(
                              "tr",
                              {
                                key: location.LocationID,
                                staticStyle: { cursor: "pointer" },
                                attrs: { id: "element" },
                                on: {
                                  click: function($event) {
                                    return _vm.changeTitleLocation(location)
                                  }
                                }
                              },
                              [
                                _c("td", [
                                  _vm._v(_vm._s(location.LocationCode))
                                ]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(_vm._s(location.LocationName))
                                ])
                              ]
                            )
                          }),
                          0
                        )
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  !_vm.locations
                    ? _c(
                        "div",
                        {
                          staticClass: "alert alert-default",
                          attrs: { role: "alert" }
                        },
                        [
                          _vm._v(
                            "\n                        No Data\n                    "
                          )
                        ]
                      )
                    : _vm._e()
                ])
              ]),
              _vm._v(" "),
              _vm._m(2)
            ])
=======
        _c("div", { staticClass: "modal-dialog modal-xl" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                  }
                }
              },
              [
                _c("div", { staticClass: "modal-body" }, [
                  _c("div", { staticClass: "card-body" }, [
                    _c("div", { staticClass: "row" }, [
                      _c(
                        "div",
                        { staticClass: "col-lg-6" },
                        [
                          _c(
                            "b-input-group",
                            { staticClass: "mt-3", attrs: { size: "sm" } },
                            [
                              _c("b-form-input", {
                                attrs: { placeholder: "Search for..." },
                                on: { keyup: _vm.searchSoa },
                                model: {
                                  value: _vm.searchSoaVar,
                                  callback: function($$v) {
                                    _vm.searchSoaVar = $$v
                                  },
                                  expression: "searchSoaVar"
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "b-input-group-append",
                                [
                                  _c(
                                    "b-button",
                                    {
                                      attrs: {
                                        variant: "outline-success",
                                        size: "sm"
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-search",
                                        attrs: { "aria-hidden": "true" }
                                      })
                                    ]
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "col-lg-6" },
                        [
                          _c(
                            "b-button",
                            {
                              staticClass: "btn-modal-lock",
                              attrs: { variant: "warning", size: "sm" }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-lock",
                                attrs: { "aria-hidden": "true" }
                              }),
                              _vm._v(" Show All Active")
                            ]
                          )
                        ],
                        1
                      )
                    ]),
                    _vm._v(" "),
                    _c("table", { staticClass: "table table-bordered" }, [
                      _vm._m(1),
                      _vm._v(" "),
                      _c(
                        "tbody",
                        _vm._l(_vm.soas, function(soa) {
                          return _c(
                            "tr",
                            {
                              key: soa.id,
                              staticClass: "hover-green",
                              on: {
                                click: function($event) {
                                  return _vm.setsoa(soa)
                                }
                              }
                            },
                            [
                              _c("td", [_vm._v(_vm._s(soa.soaNumber))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(soa.soaDate))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(soa.adminencodedby))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(soa.created_at))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(soa.updated_at))])
                            ]
                          )
                        }),
                        0
                      )
                    ]),
                    _vm._v(" "),
                    !_vm.soas
                      ? _c(
                          "div",
                          {
                            staticClass: "alert alert-default",
                            attrs: { role: "alert" }
                          },
                          [
                            _vm._v(
                              "\n                        No Data\n                    "
                            )
                          ]
                        )
                      : _vm._e()
                  ])
                ]),
                _vm._v(" "),
                _vm._m(2)
              ]
            )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          ])
        ])
      ]
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header" }, [
<<<<<<< HEAD
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Search Location")]),
=======
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Search DMPI SAR")]),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
<<<<<<< HEAD
        _c("th", [_vm._v("Location Code")]),
        _vm._v(" "),
        _c("th", [_vm._v("Location Name")])
=======
        _c("th", [_vm._v("Soa Number")]),
        _vm._v(" "),
        _c("th", [_vm._v("Soa Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("Encoded By")]),
        _vm._v(" "),
        _c("th", [_vm._v("Created")]),
        _vm._v(" "),
        _c("th", [_vm._v("Last Updated")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-footer " }, [
      _c(
        "button",
        {
          staticClass: "btn btn-default",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [_c("i", { staticClass: "far fa-window-close" }), _vm._v(" Close")]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue ***!
  \**************************************************************************/
=======
/***/ "./resources/js/components/dmpi/DmpiSarComponent.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/dmpi/DmpiSarComponent.vue ***!
  \***********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& */ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&");
/* harmony import */ var _PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PHBVehicleLogComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

=======
/* harmony import */ var _DmpiSarComponent_vue_vue_type_template_id_e5260026___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DmpiSarComponent.vue?vue&type=template&id=e5260026& */ "./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=template&id=e5260026&");
/* harmony import */ var _DmpiSarComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DmpiSarComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DmpiSarComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DmpiSarComponent_vue_vue_type_template_id_e5260026___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DmpiSarComponent_vue_vue_type_template_id_e5260026___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/PHBComponents/PHBVehicleLogComponent.vue"
=======
component.options.__file = "resources/js/components/dmpi/DmpiSarComponent.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
=======
/***/ "./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& ***!
  \*********************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiSarComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./DmpiSarComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiSarComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=template&id=e5260026&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=template&id=e5260026& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PHBComponents/PHBVehicleLogComponent.vue?vue&type=template&id=3e4a3675&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PHBVehicleLogComponent_vue_vue_type_template_id_3e4a3675___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiSarComponent_vue_vue_type_template_id_e5260026___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./DmpiSarComponent.vue?vue&type=template&id=e5260026& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dmpi/DmpiSarComponent.vue?vue&type=template&id=e5260026&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiSarComponent_vue_vue_type_template_id_e5260026___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DmpiSarComponent_vue_vue_type_template_id_e5260026___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchPHB/SearchLocation.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/components/search/SearchPHB/SearchLocation.vue ***!
  \*********************************************************************/
=======
/***/ "./resources/js/components/search/commonMasterList/Signatory.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/components/search/commonMasterList/Signatory.vue ***!
  \***********************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchLocation.vue?vue&type=template&id=5581f156& */ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&");
/* harmony import */ var _SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchLocation.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&");
=======
/* harmony import */ var _Signatory_vue_vue_type_template_id_521139e4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Signatory.vue?vue&type=template&id=521139e4& */ "./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=template&id=521139e4&");
/* harmony import */ var _Signatory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Signatory.vue?vue&type=script&lang=js& */ "./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=script&lang=js&");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _Signatory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Signatory_vue_vue_type_template_id_521139e4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Signatory_vue_vue_type_template_id_521139e4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/search/SearchPHB/SearchLocation.vue"
=======
component.options.__file = "resources/js/components/search/commonMasterList/Signatory.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
=======
/***/ "./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchLocation.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156& ***!
  \****************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Signatory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Signatory.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Signatory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=template&id=521139e4&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=template&id=521139e4& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Signatory_vue_vue_type_template_id_521139e4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Signatory.vue?vue&type=template&id=521139e4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/commonMasterList/Signatory.vue?vue&type=template&id=521139e4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Signatory_vue_vue_type_template_id_521139e4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Signatory_vue_vue_type_template_id_521139e4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue":
/*!*******************************************************************!*\
  !*** ./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SearchDmpiSar_vue_vue_type_template_id_31e35124___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchDmpiSar.vue?vue&type=template&id=31e35124& */ "./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=template&id=31e35124&");
/* harmony import */ var _SearchDmpiSar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchDmpiSar.vue?vue&type=script&lang=js& */ "./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SearchDmpiSar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchDmpiSar_vue_vue_type_template_id_31e35124___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchDmpiSar_vue_vue_type_template_id_31e35124___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/search/dmpi/sar/SearchDmpiSar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=script&lang=js&":
/*!********************************************************************************************!*\
  !*** ./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchDmpiSar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchDmpiSar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchDmpiSar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=template&id=31e35124&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=template&id=31e35124& ***!
  \**************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchLocation.vue?vue&type=template&id=5581f156& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchPHB/SearchLocation.vue?vue&type=template&id=5581f156&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchLocation_vue_vue_type_template_id_5581f156___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchDmpiSar_vue_vue_type_template_id_31e35124___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchDmpiSar.vue?vue&type=template&id=31e35124& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/dmpi/sar/SearchDmpiSar.vue?vue&type=template&id=31e35124&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchDmpiSar_vue_vue_type_template_id_31e35124___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchDmpiSar_vue_vue_type_template_id_31e35124___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);