(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[40],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/FUELEntry.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/FUEL/FUELEntry.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
/* harmony import */ var _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchOperator.vue */ "./resources/js/components/search/SearchJeep/SearchOperator.vue");
/* harmony import */ var _search_SearchJeep_SearchVehicleType_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchJeep/SearchVehicleType.vue */ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue");
=======
/* harmony import */ var _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSignatories.vue */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue");
/* harmony import */ var _search_SearchAllowance_SearchFUELHeader_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchAllowance/SearchFUELHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchFUELHeader.vue");
/* harmony import */ var _search_SearchAllowance_SearchFUELList_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchAllowance/SearchFUELList.vue */ "./resources/js/components/search/SearchAllowance/SearchFUELList.vue");
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
=======
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-operator': _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-vehicletype': _search_SearchJeep_SearchVehicleType_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      drivers: [],
      driverses: [],
      signatories: {},
      vehicletypes: {},
      operators: {},
      editmode: false,
      vehicles: [],
      title: '',
      kdid: '',
      form: new Form({
        MVID: "",
        PlateNumber: "",
        EngineNumber: "",
        SerialNumber: "",
        AssetNumber: "",
        DriverName: "",
        DriverLastName: "",
        DriverFirstName: "",
        DriverMiddleName: "",
        DriverExtName: "",
        DriverID: "",
        TruckerName: "",
        TruckerLastName: "",
        TruckerFirstName: "",
        TruckerMiddleName: "",
        TruckerExtName: "",
        TruckerID: "",
        MVTID_Link: "",
        MVTypeName: "",
        IsGSCUnit: ""
      })
    };
  },
  mounted: function mounted() {//this.$parent.getSearchDriver();
    //this.$parent.getSearchOperator();
    //this.$parent.getSearchVehicleType();
  },
  methods: {
    updateTitle: function updateTitle(updatedTitle) {
      this.form.DriverName = updatedTitle.LastName + ',' + updatedTitle.FirstName + ' ' + updatedTitle.MiddleName + ' ' + updatedTitle.ExtName;
      this.form.DriverID = updatedTitle.id;
      this.form.DriverLastName = updatedTitle.LastName;
      this.form.DriverFirstName = updatedTitle.FirstName;
      this.form.DriverMiddleName = updatedTitle.MiddleName;
      this.form.DriverExtName = updatedTitle.ExtName; // console.log(updatedTitle);
    },
    updateTitleOperator: function updateTitleOperator(updatedTitleOperator) {
      this.form.TruckerName = updatedTitleOperator.LastName + ',' + updatedTitleOperator.FirstName + ' ' + updatedTitleOperator.MiddleName + ' ' + updatedTitleOperator.ExtName;
      this.form.TruckerID = updatedTitleOperator.id;
      this.form.TruckerLastName = updatedTitleOperator.LastName;
      this.form.TruckerFirstName = updatedTitleOperator.FirstName;
      this.form.TruckerMiddleName = updatedTitleOperator.MiddleName;

      if (updatedTitleOperator.ExtName == "") {
        this.form.TruckerExtName = " ";
      } else {
        this.form.TruckerExtName = updatedTitleOperator.ExtName;
      } // console.log(updatedTitle);

    },
    updateTitleVehicleType: function updateTitleVehicleType(updatedTitleVehicleType) {
      this.form.MVTID_Link = updatedTitleVehicleType.MVTID;
      this.form.MVTypeName = updatedTitleVehicleType.MVType; // console.log(updatedTitle);
    },
    searchVehicleTypeFunction: function searchVehicleTypeFunction() {
      $('#searchVehicleType').modal('show');
    },
    getVehicleTypeIsReal: function getVehicleTypeIsReal() {
      var _this = this;

      axios.get("api/vehicletype").then(function (_ref) {
        var data = _ref.data;
        return _this.vehicletypes = data;
      });
      console.log(this.vehicletypes);
    },
    searchOperatorFunction: function searchOperatorFunction() {
      $('#searchOperator').modal('show');
    },
    getOperatorIsReal: function getOperatorIsReal() {
      var _this2 = this;

      axios.get("api/operator").then(function (_ref2) {
        var data = _ref2.data;
        return _this2.operators = data;
      });
      console.log(this.operators);
    },
    searchDriverFunction: function searchDriverFunction() {
      $('#searchDriver').modal('show');
    },
    getDriverIsReal: function getDriverIsReal() {
      var _this3 = this;

      axios.get("api/driver").then(function (_ref3) {
        var data = _ref3.data;
        return _this3.drivers = data;
      });
      console.log(this.drivers);
    },
    getResults: function getResults() {
      var _this4 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/vehicle?page=' + page).then(function (response) {
        _this4.vehicles = response.data;
      });
    },
    updateVehicle: function updateVehicle(MVID) {
      if (this.form.DriverExtName == "") {
        this.form.DriverExtName = " ";
      }

      if (this.form.TruckerExtName == "") {
        this.form.TruckerExtName = " ";
      }

      this.$Progress.start();
      this.form.put('api/vehicle/' + this.form.MVID);
      $('#addNew').modal('hide');
      toast.fire({
        icon: "success",
        title: "Vehicle successfully updated"
      });
      this.$Progress.finish();
      this.loadVehicle();
    },
    deleteModal: function deleteModal(MVID) {
      var _this5 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this5.$Progress.start();

          $('#addNew').modal('hide');

          _this5.form["delete"]('api/vehicle/' + MVID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');

          _this5.$Progress.finish();

          _this5.loadVehicle();
        }
      });
    },
    editModal: function editModal(vehicle) {
      this.editmode = true;
      this.form.reset();
      $('#addNew').modal('show');
      this.form.fill(vehicle);
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      $('#addNew').modal('show');
    },
    loadVehicle: function loadVehicle() {
      var _this6 = this;

      // axios.get("api/getSearchVehicle").then(({ data }) => (this.vehicles = data));
      axios.get('api/getSearchVehicle').then(function (response) {
        _this6.vehicles = response.data;
        console.log(_this6.vehicles);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    createVehicle: function createVehicle() {
      var _this7 = this;

      /*this.$Progress.start();
      this.form.post("api/vehicle");
        $('#addNew').modal('hide');
      $('.modal-backdrop').remove();
      toast.fire({
        icon: "success",
        title: "Vehicle successfully created"
      });
      this.$Progress.finish();
      this.loadVehicle();*/
      this.$Progress.start();
      this.form.post("api/vehicle").then(function () {
        $('#addNew').modal('hide');
        $('.modal-backdrop').remove();
        toast.fire({
          icon: "success",
          title: "Vehicle successfully created"
        });

        _this7.$Progress.finish();

        _this7.loadVehicle();
      })["catch"](function () {
        _this7.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Vehicle not added successfully'
        });
      });
    }
  },
  created: function created() {
    var _this8 = this;

    Fire.$on('searchingVehicle', function () {
      var query = _this8.$parent.search;
      axios.get('api/findVehicle?q=' + query).then(function (data) {
        _this8.vehicles = data.data;
      })["catch"](function () {});
    });
    this.loadVehicle(); //setInterval(() => this.loadDriver(),3000);
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      vehicletypes: {},
      searchVehicleTypeVar: ''
    };
  },
  mounted: function mounted() {
    this.searcherVehicleType();
  },
  methods: {
    changeTitleVehicleType: function changeTitleVehicleType(vt) {
      //console.log(vehicle);
      this.$emit('changeTitleVehicleType', vt); // this.$emit('kuhaDriverID',driver.id);

      $('#searchVehicleType').modal('hide');
    },
    searcherVehicleType: function searcherVehicleType() {
      var _this = this;

      axios.get("api/vehicletype").then(function (_ref) {
        var data = _ref.data;
        return _this.vehicletypes = data;
      });
      console.log(this.vehicletypes);
    },
    searchVehiType: _.debounce(function () {
      Fire.$emit('searchVehicleTypeStart');
    }, 500)
  },
  created: function created() {
    var _this2 = this;

    Fire.$on('searchVehicleTypeStart', function () {
      var query = _this2.searchVehicleTypeVar;
      axios.get('api/findVehicleType?q=' + query).then(function (data) {
        _this2.vehicletypes = data.data;
      });
    });
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n  pointer-events: none;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleList.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=template&id=07eb7a42&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=template&id=07eb7a42& ***!
  \*****************************************************************************************************************************************************************************************************************************/
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "search-signatory": _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-fuelHeader": _search_SearchAllowance_SearchFUELHeader_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "search-fuelListModal": _search_SearchAllowance_SearchFUELList_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      rows: [],
      search: "",
      type: "",
      formHeader: {
        FHID: "",
        SOANo: "",
        Prepared_by: this.user,
        Prepared_by_desig: "Encoder/User",
        Checked_by: "CATRINA B. OPEÑA",
        Checked_by_desig: "",
        Noted_by: "BERNARDITO M. GARCIA",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        Approved_by2: "",
        Approved_by_desig2: ""
      },
      header: {
        FHID: "",
        SOANo: "",
        Prepared_by: "",
        Prepared_by_desig: "",
        Checked_by: "",
        Checked_by_desig: "",
        Noted_by: "",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        Approved_by2: "",
        Approved_by_desig2: ""
      },
      dtl: {
        FEDID: "",
        hdr_idLink: "",
        Date: this.$root.formatDate(new Date()),
        InvoiceNo: "",
        Qty: "0",
        Unit: "",
        Description: "",
        Price: "0.00",
        Amount: "0.00",
        Supplier: "",
        GL: "",
        CC: "",
        markup: "",
        subPrice: "0.00",
        subtAmount: "0.00"
      },
      details: [],
      dtlData: false,
      updateMeHeader: false,
      TotalAmount: "0.00",
      markup: 0,
      CCList: [],
      GLList: [],
      reportData: {
        to: "",
        thru: "",
        body: "",
        body2: "",
        Prepared_by: "",
        Prepared_by_desig: "",
        Checked_by: "",
        Checked_by_desig: "",
        Noted_by: "",
        Noted_by_desig: "",
        Approved_by: "",
        Approved_by_desig: "",
        department: "",
        url1: "",
        url2: ""
      },
      modalPage: 1,
      depList: [],
      user: ""
    };
  },
  mounted: function mounted() {
    this.getDropDownData();
    this.getUser();
  },
  methods: {
    getUser: function getUser() {
      var _this = this;

      axios.get("api/allowance", {
        params: {
          getUser: true
        }
      }).then(function (response) {
        if (response.data) {
          _this.user = response.data.name;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getDropDownData: function getDropDownData() {
      var _this2 = this;

      axios.get("api/allowance", {
        params: {
          getCostCenter: true
        }
      }).then(function (response) {
        _this2.CCList = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
      axios.get("api/allowance", {
        params: {
          getGL: true
        }
      }).then(function (response) {
        _this2.GLList = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    openFUELHdr: function openFUELHdr() {
      this.clearHeader("formHeader");
      $("#FUELHdrModal").modal("show");
      this.updateMeHeader = false;
    },
    getDetail: function getDetail() {
      var _this3 = this;

      if (this.header.FHID) {
        axios.get("api/fuel", {
          params: {
            getDtl: true,
            id: this.header.FHID
          }
        }).then(function (response) {
          _this3.clearHeader('detail');

          if (response.data.length > 0) {
            _this3.details = response.data;
            _this3.dtlData = true;
          } else {
            _this3.details = [];
            _this3.dtlData = false;
          }

          _this3.getTotal();
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    getTotal: function getTotal() {
      var _this4 = this;

      if (this.header.FHID) {
        axios.get("api/fuel", {
          params: {
            getTotal: true,
            id: this.header.FHID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this4.TotalAmount = _this4.$root.formatNumberCommaRound(response.data[0].TotalAmount);
          } else {
            _this4.TotalAmount = "0.00";
          }
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    getMarkup: function getMarkup() {
      var _this5 = this;

      axios.get("api/markup").then(function (response) {
        _this5.markup = response.data[0].FuelMarkUp;
        _this5.dtl.markup = _this5.markup;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    rowClick: function rowClick(row) {
      this.dtl = Object.assign({}, row);
      this.dtl.Price = this.$root.formatNumberCommaRound(row.Price);
      this.dtl.Amount = this.$root.formatNumberCommaRound(row.Amount);
      this.dtl.subPrice = this.$root.formatNumberCommaRound(row.subPrice);
      this.dtl.subAmount = this.$root.formatNumberCommaRound(row.subAmount);
    },
    saveHdr: function saveHdr() {
      var _this6 = this;

      var data = Object.assign({}, this.formHeader);
      this.$Progress.start();
      axios.post("api/fuelHdr", data).then(function (response) {
        if (response.data.success) {
          _this6.header = Object.assign({}, _this6.formHeader);

          if (response.data.id) {
            _this6.header.FHID = response.data.id;
            _this6.header.SOANo = response.data.SOANo;
            _this6.header.Status = "ACTIVE";
          }

          toast.fire({
            icon: "success",
            title: response.data.message
          });

          _this6.clearHeader("formHeader");

          _this6.clearHeader("detail");

          if (!_this6.updateMeHeader) {
            _this6.details = [];
          }

          $("#FUELHdrModal").modal("hide");
        } else {
          toast.fire({
            icon: "warning",
            title: response.data.message
          });
        }

        _this6.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    updateHdr: function updateHdr() {
      if (!this.header.FHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select/save FUEL Header to continue."
        });
      }

      this.formHeader = Object.assign({}, this.header);
      this.updateMeHeader = true;
      $("#FUELHdrModal").modal("show");
    },
    deleteHdr: function deleteHdr() {
      var _this7 = this;

      if (!this.header.FHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select FUEL SOA Header to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(function (result) {
        if (result.value) {
          _this7.$Progress.start();

          axios["delete"]("api/fuelHdrDelete/".concat(_this7.header.FHID)).then(function (response) {
            if (response.data.success) {
              _this7.clearAll();

              swal.fire("Deleted!", response.data.message, "success");
            } else {
              swal.fire("Warning!", response.data.message, "warning");
            }

            _this7.$Progress.finish();
          })["catch"](function (err) {
            console.log(err);
          });
        } else {
          swal.fire("Information!", "Deletion is cancelled.", "warning");
        }
      });
    },
    searchFUELHeader: function searchFUELHeader() {
      Fire.$emit("searchFUELHeader");
    },
    fuelHeaderClose: function fuelHeaderClose(row) {
      this.header = Object.assign({}, row);
      this.getDetail();
      this.getMarkup();
    },
    searchSearchSignatoryButton: function searchSearchSignatoryButton(number) {
      Fire.$emit("searchSignatory", number);
    },
    signatoryClose: function signatoryClose(row) {
      if (row.number == 1) {
        this.formHeader.Prepared_by = row.SignatoryName;
        this.formHeader.Prepared_by_desig = row.Designation;
      } else if (row.number == 2) {
        this.formHeader.Checked_by = row.SignatoryName;
        this.formHeader.Checked_by_desig = row.Designation;
      } else if (row.number == 3) {
        this.formHeader.Noted_by = row.SignatoryName;
        this.formHeader.Noted_by_desig = row.Designation;
      } else if (row.number == 4) {
        this.formHeader.Approved_by = row.SignatoryName;
        this.formHeader.Approved_by_desig = row.Designation;
      } else if (row.number == 5) {
        this.formHeader.Approved_by2 = row.SignatoryName;
        this.formHeader.Approved_by_desig2 = row.Designation;
      } else if (row.number == 6) {
        this.reportData.Prepared_by = row.SignatoryName;
        this.reportData.Prepared_by_desig = row.Designation;
      } else if (row.number == 7) {
        this.reportData.Checked_by = row.SignatoryName;
        this.reportData.Checked_by_desig = row.Designation;
      } else if (row.number == 8) {
        this.reportData.Noted_by = row.SignatoryName;
        this.reportData.Noted_by_desig = row.Designation;
      } else if (row.number == 9) {
        this.reportData.Approved_by = row.SignatoryName;
        this.reportData.Approved_by_desig = row.Designation;
      }
    },
    searchFUELList: function searchFUELList() {
      if (!this.header.FHID) {
        return toast.fire({
          icon: "warning",
          title: "Please select a Header to continue."
        });
      }

      Fire.$emit("FUELListModal");
    },
    fuelListClose: function fuelListClose(row) {
      this.dtl.Description = row.Description;
      this.dtl.Unit = row.Unit;
      this.dtl.Price = this.$root.formatNumberCommaRound(row.UnitPrice);
      this.computeMarkup();
    },
    computeMarkup: function computeMarkup() {
      if (this.dtl.markup == 0) {
        this.dtl.subPrice = this.dtl.Price;
      } else {
        if (this.dtl.markup) {
          if (!isNaN(this.dtl.Qty)) {
            this.dtl.subPrice = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.dtl.Price) + this.dtl.markup / 100 * this.$root.formatNumber(this.dtl.Price));
          }
        }
      }

      this.computeAmount();
    },
    computeAmount: function computeAmount() {
      if (this.dtl.Qty) {
        if (!isNaN(this.dtl.Qty)) {
          this.dtl.Amount = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.dtl.Qty) * this.$root.formatNumber(this.dtl.Price));
          this.dtl.subAmount = this.$root.formatNumberCommaRound(this.$root.formatNumber(this.dtl.Qty) * this.$root.formatNumber(this.dtl.subPrice));
        } else {
          this.dtl.Amount = "0.00";
        }
      } else {
        this.dtl.Amount = "0.00";
      }
    },
    saveDtl: function saveDtl() {
      var _this8 = this;

      if (this.$root.formatNumber(this.dtl.Amount) == 0 || this.$root.formatNumber(this.dtl.Amount) < 0) {
        return toast.fire({
          icon: "warning",
          title: "Amount is invalid."
        });
      }

      var data = Object.assign({}, this.dtl);
      data.Price = this.$root.formatNumber(this.dtl.Price);
      data.Amount = this.$root.formatNumber(this.dtl.Amount);
      data.subPrice = this.$root.formatNumber(this.dtl.subPrice);
      data.subAmount = this.$root.formatNumber(this.dtl.subAmount);
      data.hdr_idLink = this.header.FHID;
      this.$Progress.start();
      axios.post("api/fuelDtl", data).then(function (response) {
        if (response.data.success) {
          if (response.data.id) {
            _this8.header.FEDID = response.data.id;
          }

          toast.fire({
            icon: "success",
            title: response.data.message
          });

          _this8.getDetail();
        } else {
          toast.fire({
            icon: "warning",
            title: response.data.message
          });
        }

        _this8.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    deleteDtl: function deleteDtl() {
      var _this9 = this;

      if (!this.dtl.FEDID) {
        return toast.fire({
          icon: "warning",
          title: "Please select FUEL Detail to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(function (result) {
        if (result.value) {
          _this9.$Progress.start();

          axios["delete"]("api/deleteFUELHDR/".concat(_this9.dtl.FEDID)).then(function (response) {
            if (response.data.success) {
              _this9.getDetail();

              _this9.clearHeader("detail");

              swal.fire("Deleted!", response.data.message, "success");
            } else {
              swal.fire("Warning!", response.data.message, "warning");
            }

            _this9.$Progress.finish();
          })["catch"](function (err) {
            console.log(err);
          });
        } else {
          swal.fire("Information!", "Deletion is cancelled.", "warning");
        }
      });
    },
    generatePrint: function generatePrint() {
      var _this10 = this;

      this.$Progress.start();
      axios.get("api/reportFUEL", {
        params: {
          SOANo: this.header.SOANo
        }
      }).then(function (response) {
        console.log(response.data);

        if (response.data.success) {
          _this10.reportData.url2 = "api/reportFUEL?report=true&SOANo=" + _this10.header.SOANo;
        } else {
          swal.fire("Warning!", response.data.message, "warning");
        }

        _this10.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    postLedger: function postLedger() {
      var _this11 = this;

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Post it!"
      }).then(function (result) {
        if (result.value) {
          _this11.$Progress.start();

          var data = {
            SOANo: _this11.header.SOANo,
            amount: _this11.$root.formatNumber(_this11.TotalAmount)
          };
          axios.post("api/fuelPostLedger", data).then(function (response) {
            if (response.data.success) {
              _this11.header.Status = "POSTED TO LEDGER";
              toast.fire({
                icon: "success",
                title: response.data.message
              });
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this11.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    clearAll: function clearAll() {
      this.clearHeader("header");
      this.clearHeader("formHeader");
      this.clearHeader("detail");
      this.details = [];
    },
    clearHeader: function clearHeader($type) {
      if ($type == "header") {
        this.header = {
          FHID: "",
          SOANo: "",
          Prepared_by: "",
          Prepared_by_desig: "",
          Checked_by: "",
          Checked_by_desig: "",
          Noted_by: "",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          Approved_by2: "",
          Approved_by_desig2: ""
        };
      } else if ($type == "formHeader") {
        this.formHeader = {
          FHID: "",
          SOANo: "",
          Prepared_by: this.user,
          Prepared_by_desig: "Encoder/User",
          Checked_by: "CATRINA B. OPEÑA",
          Checked_by_desig: "",
          Noted_by: "BERNARDITO M. GARCIA",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          Approved_by2: "",
          Approved_by_desig2: ""
        };
      } else if ($type == "reportData") {
        this.reportData = {
          to: "",
          thru: "",
          body: "",
          body2: "",
          Prepared_by: "",
          Prepared_by_desig: "",
          Checked_by: "",
          Checked_by_desig: "",
          Noted_by: "",
          Noted_by_desig: "",
          Approved_by: "",
          Approved_by_desig: "",
          department: "",
          url1: "",
          url2: ""
        };
      } else {
        this.dtl = {
          FEDID: "",
          hdr_idLink: "",
          Date: this.$root.formatDate(new Date()),
          InvoiceNo: "",
          Qty: "0",
          Unit: "",
          Description: "",
          Price: "0.00",
          Amount: "0.00",
          Supplier: "",
          GL: "",
          CC: "",
          markup: "",
          subPrice: "0.00",
          subtAmount: "0.00"
        };
        this.getMarkup();
      }
    },
    // modal for print
    viewReport: function viewReport() {
      var _this12 = this;

      if (this.modalPage == 1) {
        this.modalPage = 2;
        axios.post("api/reportAllowanceSOASave", {
          to: this.reportData.to,
          thru: this.reportData.thru,
          body: this.reportData.body,
          body2: this.reportData.body2
        }).then(function (response) {
          if (response.data.success) {
            _this12.reportData.url1 = "api/reportSOA?report=true&SOANo=" + _this12.header.SOANo + "&Prepared_by=" + _this12.reportData.Prepared_by + "&Checked_by=" + _this12.reportData.Checked_by + "&Noted_by=" + _this12.reportData.Noted_by + "&Approved_by=" + _this12.reportData.Approved_by + "&reportID=" + response.data.id + "&type=FUEL";
          }

          _this12.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
        this.generatePrint();
      } else {
        this.modalPage = 1;
      }
    },
    reportModal: function reportModal() {
      console.log(this.$root.formatNumber(this.TotalAmount));
      var dec = this.$root.formatNumber(this.TotalAmount).toString().split(".");

      if (dec.length == 1) {
        var decimal = "00";
      } else {
        var decimal = dec[1].toString().padEnd(2, "0");
      }

      var numberToWord = this.$root.number2word(this.$root.formatNumber(this.TotalAmount)).toString().toUpperCase();
      this.reportData.to = "TO: MS.LORNA SEVILLEJO\n\xa0\xa0\xa0\xa0Accounting Supervisor\n\xa0\xa0\xa0\xa0Del Monte, Inc\n\xa0\xa0\xa0\xa0Camp Philips, Manolo Fortich, Bukidnon";
      this.reportData.thru = "THRU:\n\xa0\xa0\xa0\xa0MS.KAREN I. DOMINGUEZ\n\xa0\xa0\xa0\xa0HR Plantation Supervisor\n\xa0\xa0\xa0\xa0Del Monte, Inc\n\xa0\xa0\xa0\xa0Camp Philips, Manolo Fortich, Bukidnon";
      this.reportData.body = "Dear Ms. Sevillejo,\n\n\nThis is to bill Del Monte, Inc. the amount of " + numberToWord + " PESOS & " + decimal + "/100 ONLY (Php " + this.TotalAmount + ") for PPE issuance of Philpack Freezing Plant production employees. Please see attached file for your perusal.";
      this.reportData.body2 = "Please issue check in the name of GENERAL SERVICES MULTIPURPOSE COOPERATIVE.";
      this.reportData.Prepared_by = this.header.Prepared_by;
      this.reportData.Prepared_by_desig = this.header.Prepared_by_desig;
      this.reportData.Noted_by = this.header.Noted_by;
      this.reportData.Noted_by_desig = this.header.Noted_by_desig;
      this.reportData.Approved_by = this.header.Approved_by;
      this.reportData.Approved_by_desig = this.header.Approved_by_desig;
      $("#reportModal").modal("show");
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this13 = this;

      return this.details.filter(function (item) {
        return _this13.search.toLowerCase().split(" ").every(function (v) {
          return item.InvoiceNo.toLowerCase().includes(v) || item.Description.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      type: ""
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("FUELListModal", function (data) {
      _this.getData();

      $("#FUELListModal").modal("show");
    });
  },
  methods: {
    rowClick: function rowClick(row) {
      this.$emit("rowClick", row);
      $("#FUELListModal").modal("hide");
    },
    getData: function getData() {
      var _this2 = this;

      axios.get("api/fuel", {
        params: {
          getFUELList: true
        }
      }).then(function (response) {
        _this2.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.Code.toLowerCase().includes(v) || item.Description.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      number: 0
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("searchSignatory", function (data) {
      _this.number = data;

      _this.getData();

      $("#SearchSignatory").modal("show");
    });
  },
  methods: {
    rowClick: function rowClick(row) {
      row.number = this.number;
      this.$emit("rowClick", row);
      $("#SearchSignatory").modal("hide");
    },
    getData: function getData() {
      var _this2 = this;

      axios.get("api/signatoryList").then(function (response) {
        response.data.forEach(function (item) {
          var extname = item.ename ? " " + item.ename : "";
          var mname = item.mname ? " " + item.mname[0] + "." : "";
          item.SignatoryName = item.fname + mname + " " + item.lname + extname;
          item.Designation = item.position;
        });
        _this2.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.SignatoryName.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/FUELEntry.vue?vue&type=template&id=0b16ae64&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/FUEL/FUELEntry.vue?vue&type=template&id=0b16ae64& ***!
  \*****************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
<<<<<<< HEAD
    { staticClass: "container" },
    [
      _c(
        "nav",
        {
          staticClass:
            "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
        },
        [
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNavDropdown" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#mlist"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Master File\n                              "
=======
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-2" }, [
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", [_vm._v("Control No.")]),
                    _vm._v(" "),
                    _c(
                      "b-input-group",
                      [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.header.FHID,
                              expression: "header.FHID"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "FHID",
                            placeholder: "",
                            disabled: ""
                          },
                          domProps: { value: _vm.header.FHID },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.header, "FHID", $event.target.value)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c(
                          "b-input-group-append",
                          [
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  variant: "outline-primary",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.searchFUELHeader(1)
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-search",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  disabled: this.header.Status != "ACTIVE",
                                  variant: "outline-success",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.updateHdr()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-edit",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                attrs: {
                                  disabled: this.header.Status != "ACTIVE",
                                  variant: "outline-danger",
                                  size: "sm"
                                },
                                on: {
                                  click: function($event) {
                                    return _vm.deleteHdr()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-trash",
                                  attrs: { "aria-hidden": "true" }
                                })
                              ]
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("SOANo")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.SOANo,
                        expression: "header.SOANo"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "SOANo",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.SOANo },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "SOANo", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Prepared By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Prepared_by,
                        expression: "header.Prepared_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Prepared_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Prepared_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Prepared_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Checked By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Checked_by,
                        expression: "header.Checked_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Checked_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Checked_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Checked_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-4 text-right" }, [
                _c("label", { staticClass: "text-danger" }, [
                  _vm._v(_vm._s(_vm.header.Status))
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "form-group" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-warning",
                      attrs: {
                        disabled: this.header.Status != "TRANSMITTED",
                        type: "button",
                        bold: ""
                      },
                      on: {
                        click: function($event) {
                          return _vm.postLedger()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-calculator",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                POST\n                            "
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
<<<<<<< HEAD
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "mlist"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/driverlist" }
                            },
                            [_c("a", [_vm._v("Driver List")])]
                          )
=======
                    "button",
                    {
                      staticClass: "btn btn-warning",
                      attrs: { type: "button", bold: "" },
                      on: {
                        click: function($event) {
                          return _vm.reportModal()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-print",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                PRINT\n                            "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { type: "button", bold: "" },
                      on: {
                        click: function($event) {
                          return _vm.openFUELHdr()
                        }
                      }
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-plus",
                        attrs: { "aria-hidden": "true" }
                      }),
                      _vm._v(
                        "\n                                NEW FUEL HEADER\n                            "
                      )
                    ]
                  )
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Noted By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Noted_by,
                        expression: "header.Noted_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Noted_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Noted_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Noted_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Approved By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Approved_by,
                        expression: "header.Approved_by"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Approved_by",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Approved_by },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.header, "Approved_by", $event.target.value)
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("div", { staticClass: "form-group" }, [
                  _c("label", [_vm._v("Approved For Payment By")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.header.Approved_by2,
                        expression: "header.Approved_by2"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "Approved_by2",
                      placeholder: "",
                      disabled: ""
                    },
                    domProps: { value: _vm.header.Approved_by2 },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(
                          _vm.header,
                          "Approved_by2",
                          $event.target.value
                        )
                      }
                    }
                  })
                ])
              ]),
              _vm._v(" "),
              _vm._m(1),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-2" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.TotalAmount,
                      expression: "TotalAmount"
                    }
                  ],
                  staticClass: "form-control text-primary text-right",
                  attrs: {
                    type: "text",
                    name: "TotalAmount",
                    placeholder: "",
                    disabled: ""
                  },
                  domProps: { value: _vm.TotalAmount },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.TotalAmount = $event.target.value
                    }
                  }
                })
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _vm._m(2),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody tbody-160" },
                      [
                        _c(
                          "tr",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: !_vm.dtlData,
                                expression: "!dtlData"
                              }
                            ]
                          },
                          [_vm._m(3)]
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.filteredBlogs, function(item) {
                          return _c(
                            "tr",
                            {
                              on: {
                                click: function($event) {
                                  return _vm.rowClick(item)
                                }
                              }
                            },
                            [
                              _c("td", [
                                _vm._v(_vm._s(_vm._f("formatDate")(item.Date)))
                              ]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.InvoiceNo))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.Description))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.Qty))]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(item.Unit))]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(
                                  _vm._s(_vm._f("formatNumber")(item.Price))
                                )
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatNumber")(item.Amount)
                                    ) +
                                    "\n                                    "
                                )
                              ])
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    return _vm.saveDtl()
                  }
                }
              },
              [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-4" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", [_vm._v("Description")]),
                        _vm._v(" "),
                        _c(
                          "b-input-group",
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.dtl.Description,
                                  expression: "dtl.Description"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "Description",
                                placeholder: "",
                                disabled: ""
                              },
                              domProps: { value: _vm.dtl.Description },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.dtl,
                                    "Description",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "b-input-group-append",
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      variant: "outline-primary",
                                      size: "sm"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.searchFUELList()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-search",
                                      attrs: { "aria-hidden": "true" }
                                    })
                                  ]
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Unit")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Unit,
                            expression: "dtl.Unit"
                          }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Unit",
                          placeholder: "",
                          disabled: ""
                        },
                        domProps: { value: _vm.dtl.Unit },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Unit", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Unit Price")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Price,
                            expression: "dtl.Price"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Price",
                          placeholder: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.Price },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Price", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Markup (%)")]),
                      _vm._v(" "),
<<<<<<< HEAD
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehiclelist" }
                            },
                            [_c("a", [_vm._v("JEEP Vehicle List")])]
                          )
=======
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.markup,
                            expression: "dtl.markup"
                          }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "markup",
                          placeholder: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.markup },
                        on: {
                          keyup: function($event) {
                            return _vm.computeMarkup()
                          },
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "markup", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Markup Price")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.subPrice,
                            expression: "dtl.subPrice"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "subPrice",
                          placeholder: "",
                          disabled: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.subPrice },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "subPrice", $event.target.value)
                          }
                        }
                      })
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Qty")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Qty,
                            expression: "dtl.Qty"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Qty",
                          placeholder: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.Qty },
                        on: {
                          keyup: function($event) {
                            return _vm.computeAmount()
                          },
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Qty", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Amount")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Amount,
                            expression: "dtl.Amount"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Amount",
                          placeholder: "",
                          disabled: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.Amount },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Amount", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Date")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.Date,
                            expression: "dtl.Date"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "date",
                          name: "Date",
                          placeholder: "",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.Date },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "Date", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Supplier Invoice No")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.InvoiceNo,
                            expression: "dtl.InvoiceNo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "InvoiceNo",
                          placeholder: "",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.InvoiceNo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "InvoiceNo", $event.target.value)
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("GL")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.GL,
                            expression: "dtl.GL"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "Amount",
                          placeholder: "",
                          list: "gl",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.GL },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "GL", $event.target.value)
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
<<<<<<< HEAD
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehiclerate" }
                            },
                            [_c("a", [_vm._v("JEEP Rate List")])]
                          )
=======
                        "datalist",
                        { attrs: { id: "gl" } },
                        _vm._l(_vm.GLList, function(item) {
                          return _c("option", [_vm._v(_vm._s(item.GL))])
                        }),
                        0
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Cost Center")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.CC,
                            expression: "dtl.CC"
                          }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "CC",
                          placeholder: "",
                          list: "costcenter",
                          required: ""
                        },
                        domProps: { value: _vm.dtl.CC },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "CC", $event.target.value)
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "datalist",
                        { attrs: { id: "costcenter" } },
                        _vm._l(_vm.CCList, function(item) {
                          return _c("option", [_vm._v(_vm._s(item.Costcenter))])
                        }),
                        0
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Sub Amount")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.dtl.subAmount,
                            expression: "dtl.subAmount"
                          }
                        ],
<<<<<<< HEAD
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/ratePercent" }
                            },
                            [_c("a", [_vm._v("Admin Rate Percentage")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
=======
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "subAmount",
                          placeholder: "",
                          disabled: "",
                          "text-right": ""
                        },
                        domProps: { value: _vm.dtl.subAmount },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.dtl, "subAmount", $event.target.value)
                          }
                        }
                      })
                    ])
                  ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 text-right" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.clearHeader("detail")
                            }
                          }
                        },
                        [
<<<<<<< HEAD
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/jeepvehiclelogentry" }
                            },
                            [_c("a", [_vm._v("Jeep Vehicle Log Entry")])]
=======
                          _c("i", {
                            staticClass: "fa fa-eraser",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                    CLEAR\n                                "
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: {
                            disabled: this.header.Status != "ACTIVE",
                            type: "button",
                            bold: ""
                          },
                          on: {
                            click: function($event) {
                              return _vm.deleteDtl()
                            }
                          }
                        },
                        [
<<<<<<< HEAD
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/createsoa" }
                            },
                            [_c("a", [_vm._v("Create Jeep SOA")])]
=======
                          _c("i", {
                            staticClass: "fa fa-trash",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                    DELETE\n                                "
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c(
<<<<<<< HEAD
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/soatransactions" }
                            },
                            [_c("a", [_vm._v("SOA Transaction")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#report"
                      }
                    },
                    [
                      _vm._v(
                        "\n                              Jeep Reports\n                              "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "report"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistJVL" }
                            },
                            [_c("a", [_vm._v("Standard Jeep Report")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistJVLPerJeep" }
                            },
                            [
                              _c("a", [
                                _vm._v("Jeepney's Vehicle Log Billing Report")
                              ])
                            ]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/JeepSOATransmittal" }
                            },
                            [_c("a", [_vm._v("Jeepney's SOA Transmittal")])]
=======
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: {
                            disabled: this.header.Status != "ACTIVE",
                            type: "submit",
                            bold: ""
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-save",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                    SAVE\n                                "
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                          )
                        ]
                      )
                    ])
                  ])
                ])
<<<<<<< HEAD
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }, [
              _c(
                "button",
                { staticClass: "btn btn-success", on: { click: _vm.newModal } },
                [
                  _vm._v("\n            Add New Vehicle\n            "),
                  _c("i", { staticClass: "fa fa-user-plus fa fw" })
                ]
              )
            ])
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _c(
                  "tbody",
                  [
                    _vm._m(1),
                    _vm._v(" "),
                    _vm._l(_vm.vehicles, function(vehicle) {
                      return _c("tr", { key: vehicle.MVID }, [
                        _c("td", [_vm._v(_vm._s(vehicle.PlateNumber))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(vehicle.DriverName))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(vehicle.TruckerName))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(vehicle.EngineNumber))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(vehicle.SerialNumber))]),
                        _vm._v(" "),
                        _c("td", [
=======
              ]
            )
          ])
        ]),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass: "modal fade",
            attrs: {
              id: "FUELHdrModal",
              tabindex: "-1",
              role: "dialog",
              "aria-labelledby": "addNewLabel",
              "aria-hidden": "true"
            }
          },
          [
            _c(
              "div",
              {
                staticClass: "modal-dialog modal-dialog-centered modal-md",
                attrs: { role: "document" }
              },
              [
                _c("div", { staticClass: "modal-content" }, [
                  _c("div", { staticClass: "modal-header-cus" }, [
                    _c("div", { staticClass: "row container-fluid" }, [
                      _c("div", { staticClass: "col-md-11" }, [
                        _c("h5", [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                          _c(
                            "b",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: !_vm.updateMeHeader,
                                  expression: "!updateMeHeader"
                                }
                              ]
                            },
                            [_vm._v("CREATE FUEL HEADER")]
                          ),
                          _vm._v(" "),
                          _c(
                            "b",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.updateMeHeader,
                                  expression: "updateMeHeader"
                                }
                              ]
                            },
                            [_vm._v("UPDATE FUEL HEADER")]
                          )
                        ])
<<<<<<< HEAD
                      ])
                    })
                  ],
                  2
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" })
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-dialog-centered",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Vehicle")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Vehicle's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(2)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    attrs: { id: "sweget" },
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode ? _vm.updateVehicle() : _vm.createVehicle()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body" }, [
                      _c("div", { staticClass: "form-group" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.PlateNumber,
                              expression: "form.PlateNumber"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "PlateNumber",
                            placeholder: "Plate Number",
                            required: ""
                          },
                          domProps: { value: _vm.form.PlateNumber },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "PlateNumber",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.EngineNumber,
                              expression: "form.EngineNumber"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "EngineNumber",
                            placeholder: "Engine Number",
                            required: ""
                          },
                          domProps: { value: _vm.form.EngineNumber },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "EngineNumber",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.SerialNumber,
                              expression: "form.SerialNumber"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "SerialNumber",
                            placeholder: "Serial Number",
                            required: ""
                          },
                          domProps: { value: _vm.form.SerialNumber },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "SerialNumber",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.AssetNumber,
                              expression: "form.AssetNumber"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "AssetNumber",
                            placeholder: "Asset Number",
                            required: ""
                          },
                          domProps: { value: _vm.form.AssetNumber },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "AssetNumber",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c(
                            "b-input-group",
                            { staticClass: "mt-3" },
                            [
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.DriverName,
                                    expression: "form.DriverName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "DriverName",
                                  placeholder: "Driver Name",
                                  required: "",
                                  "data-readonly": ""
                                },
                                domProps: { value: _vm.form.DriverName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "DriverName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.DriverID,
                                    expression: "form.DriverID"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "DriverID",
                                  placeholder: "DriverID"
                                },
                                domProps: { value: _vm.form.DriverID },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "DriverID",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.DriverLastName,
                                    expression: "form.DriverLastName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "DriverLastName",
                                  placeholder: "DriverLastName"
                                },
                                domProps: { value: _vm.form.DriverLastName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "DriverLastName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.DriverFirstName,
                                    expression: "form.DriverFirstName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "DriverFirstName",
                                  placeholder: "DriverFirstName"
                                },
                                domProps: { value: _vm.form.DriverFirstName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "DriverFirstName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.DriverMiddleName,
                                    expression: "form.DriverMiddleName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "DriverMiddleName",
                                  placeholder: "DriverMiddleName"
                                },
                                domProps: { value: _vm.form.DriverMiddleName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "DriverMiddleName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.DriverExtName,
                                    expression: "form.DriverExtName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "DriverExtName",
                                  placeholder: "DriverExtName"
                                },
                                domProps: { value: _vm.form.DriverExtName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "DriverExtName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "b-input-group-append",
                                [
                                  _c(
                                    "b-button",
                                    {
                                      attrs: {
                                        variant: "outline-primary",
                                        size: "sm"
                                      },
                                      on: {
                                        click: function($event) {
                                          return _vm.searchDriverFunction()
                                        }
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-search",
                                        attrs: { "aria-hidden": "true" }
                                      })
                                    ]
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
=======
                      ]),
                      _vm._v(" "),
                      _vm._m(4)
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-body-cus" }, [
                    _c("div", { staticClass: "container-fluid" }, [
                      _c(
                        "form",
                        {
                          on: {
                            submit: function($event) {
                              $event.preventDefault()
                              return _vm.saveHdr()
                            }
                          }
                        },
                        [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col-md-12" }, [
                              _c("div", { staticClass: "form-group" }, [
                                _c("label", [_vm._v("SOANo")]),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.formHeader.SOANo,
                                      expression: "formHeader.SOANo"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "SOANo",
                                    placeholder: "",
                                    disabled: ""
                                  },
                                  domProps: { value: _vm.formHeader.SOANo },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.formHeader,
                                        "SOANo",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ])
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Prepared By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Prepared_by,
                                            expression:
                                              "\n                                                        formHeader.Prepared_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Prepared_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Prepared_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Prepared_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    1
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Checked By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Checked_by,
                                            expression:
                                              "\n                                                        formHeader.Checked_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Checked_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Checked_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Checked_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    2
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Noted By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Noted_by,
                                            expression:
                                              "\n                                                        formHeader.Noted_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Noted_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Noted_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Noted_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    3
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [_vm._v("Approved By")]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Approved_by,
                                            expression:
                                              "\n                                                        formHeader.Approved_by\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Approved_by",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Approved_by
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Approved_by",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    4
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col-md-12" }, [
                              _c(
                                "div",
                                { staticClass: "form-group" },
                                [
                                  _c("label", [
                                    _vm._v("Approved For Payment By")
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group",
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.formHeader.Approved_by2,
                                            expression:
                                              "\n                                                        formHeader.Approved_by2\n                                                    "
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: "Approved_by2",
                                          placeholder: "",
                                          disabled: ""
                                        },
                                        domProps: {
                                          value: _vm.formHeader.Approved_by2
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.formHeader,
                                              "Approved_by2",
                                              $event.target.value
                                            )
                                          }
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "b-input-group-append",
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              attrs: {
                                                variant: "outline-primary",
                                                size: "sm"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.searchSearchSignatoryButton(
                                                    5
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "fa fa-search",
                                                attrs: { "aria-hidden": "true" }
                                              })
                                            ]
                                          )
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _vm._m(5)
                        ]
                      )
                    ])
                  ])
                ])
              ]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass: "modal fade",
            attrs: {
              id: "reportModal",
              tabindex: "-1",
              role: "dialog",
              "aria-labelledby": "addNewLabel",
              "aria-hidden": "true"
            }
          },
          [
            _c(
              "div",
              {
                staticClass: "modal-dialog modal-dialog-centered modal-full",
                attrs: { role: "document" }
              },
              [
                _c("div", { staticClass: "modal-content" }, [
                  _vm._m(6),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-body-cus" }, [
                    _c("div", { staticClass: "container-fluid" }, [
                      _c(
                        "div",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.modalPage == 1,
                              expression: "modalPage == 1"
                            }
                          ],
                          staticClass: "row"
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass: "col-md-6",
                              staticStyle: { "border-right": "2px solid black" }
                            },
                            [
                              _c("div", { staticClass: "row" }, [
                                _c("div", { staticClass: "col-md-6" }, [
                                  _c(
                                    "button",
                                    {
                                      staticClass: "btn btn-primary btn-xs",
                                      attrs: { type: "button", bold: "" },
                                      on: {
                                        click: function($event) {
                                          return _vm.viewReport()
                                        }
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-eye",
                                        attrs: { "aria-hidden": "true" }
                                      }),
                                      _vm._v(
                                        "\n                                                View Report\n                                            "
                                      )
                                    ]
                                  )
                                ]),
                                _vm._v(" "),
                                _vm._m(7)
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "row" }, [
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("TO:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.to,
                                        expression: "reportData.to"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "100px"
                                    },
                                    domProps: { value: _vm.reportData.to },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "to",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("THRU:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.thru,
                                        expression: "reportData.thru"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "100px"
                                    },
                                    domProps: { value: _vm.reportData.thru },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "thru",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("BODY:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.body,
                                        expression: "reportData.body"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "130px"
                                    },
                                    domProps: { value: _vm.reportData.body },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "body",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "col-md-12" }, [
                                  _c("label", [_vm._v("BODY2:")]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.reportData.body2,
                                        expression: "reportData.body2"
                                      }
                                    ],
                                    staticStyle: {
                                      width: "100%",
                                      height: "100px"
                                    },
                                    domProps: { value: _vm.reportData.body2 },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.reportData,
                                          "body2",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ])
                              ])
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "col-md-6",
                              staticStyle: { "border-right": "2px solid black" }
                            },
                            [
                              _vm._m(8),
                              _vm._v(" "),
                              _c("div", { staticClass: "row" }, [
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Prepared By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Prepared_by,
                                              expression:
                                                "\n                                                        reportData.Prepared_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Prepared_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Prepared_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Prepared_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      6
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Checked By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Checked_by,
                                              expression:
                                                "\n                                                        reportData.Checked_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Checked_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Checked_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Checked_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      7
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "row" }, [
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Noted By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Noted_by,
                                              expression:
                                                "\n                                                        reportData.Noted_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Noted_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Noted_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Noted_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      8
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "col-md-6" },
                                  [
                                    _c("label", [_vm._v("Approved By:")]),
                                    _vm._v(" "),
                                    _c(
                                      "b-input-group",
                                      [
                                        _c("input", {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.reportData.Approved_by,
                                              expression:
                                                "\n                                                        reportData.Approved_by\n                                                    "
                                            }
                                          ],
                                          staticClass: "form-control",
                                          attrs: {
                                            type: "text",
                                            name: "Approved_by",
                                            placeholder: "",
                                            required: "",
                                            disabled: ""
                                          },
                                          domProps: {
                                            value: _vm.reportData.Approved_by
                                          },
                                          on: {
                                            input: function($event) {
                                              if ($event.target.composing) {
                                                return
                                              }
                                              _vm.$set(
                                                _vm.reportData,
                                                "Approved_by",
                                                $event.target.value
                                              )
                                            }
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "b-input-group-append",
                                          [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  variant: "outline-primary",
                                                  size: "sm"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.searchSearchSignatoryButton(
                                                      9
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-search",
                                                  attrs: {
                                                    "aria-hidden": "true"
                                                  }
                                                })
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ])
                            ]
                          )
                        ]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
<<<<<<< HEAD
                        { staticClass: "form-group" },
                        [
                          _c(
                            "b-input-group",
                            { staticClass: "mt-3" },
                            [
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.TruckerName,
                                    expression: "form.TruckerName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "TruckerName",
                                  placeholder: "Trucker Name",
                                  required: "",
                                  "data-readonly": ""
                                },
                                domProps: { value: _vm.form.TruckerName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "TruckerName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.TruckerID,
                                    expression: "form.TruckerID"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "TruckerID",
                                  placeholder: "TruckerID"
                                },
                                domProps: { value: _vm.form.TruckerID },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "TruckerID",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.TruckerLastName,
                                    expression: "form.TruckerLastName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "TruckerLastName",
                                  placeholder: "TruckerLastName"
                                },
                                domProps: { value: _vm.form.TruckerLastName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "TruckerLastName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.TruckerFirstName,
                                    expression: "form.TruckerFirstName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "TruckerFirstName",
                                  placeholder: "TruckerFirstName"
                                },
                                domProps: { value: _vm.form.TruckerFirstName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "TruckerFirstName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.TruckerMiddleName,
                                    expression: "form.TruckerMiddleName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "TruckerMiddleName",
                                  placeholder: "TruckerMiddleName"
                                },
                                domProps: { value: _vm.form.TruckerMiddleName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "TruckerMiddleName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.TruckerExtName,
                                    expression: "form.TruckerExtName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "hidden",
                                  name: "TruckerExtName",
                                  placeholder: "TruckerExtName"
                                },
                                domProps: { value: _vm.form.TruckerExtName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "TruckerExtName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "b-input-group-append",
                                [
                                  _c(
                                    "b-button",
                                    {
                                      attrs: {
                                        variant: "outline-primary",
                                        size: "sm"
                                      },
                                      on: {
                                        click: function($event) {
                                          return _vm.searchOperatorFunction()
                                        }
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-search",
                                        attrs: { "aria-hidden": "true" }
                                      })
                                    ]
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c(
                            "b-input-group",
                            { staticClass: "mt-3" },
                            [
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.MVTID_Link,
                                    expression: "form.MVTID_Link"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: { type: "hidden", name: "MVTID_Link" },
                                domProps: { value: _vm.form.MVTID_Link },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "MVTID_Link",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.MVTypeName,
                                    expression: "form.MVTypeName"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: {
                                  type: "text",
                                  name: "Type",
                                  placeholder: "Vehicle Type",
                                  "data-readonly": ""
                                },
                                domProps: { value: _vm.form.MVTypeName },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "MVTypeName",
                                      $event.target.value
                                    )
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "b-input-group-append",
                                [
                                  _c(
                                    "b-button",
                                    {
                                      attrs: {
                                        variant: "outline-primary",
                                        size: "sm"
                                      },
                                      on: {
                                        click: function($event) {
                                          return _vm.searchVehicleTypeFunction()
                                        }
                                      }
                                    },
                                    [
                                      _c("i", {
                                        staticClass: "fa fa-search",
                                        attrs: { "aria-hidden": "true" }
                                      })
                                    ]
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.IsGSCUnit,
                              expression: "form.IsGSCUnit"
                            }
                          ],
                          staticClass: "form-control",
                          staticStyle: { "text-transform": "uppercase" },
                          attrs: {
                            type: "text",
                            name: "Type",
                            placeholder: "Is GSC Unit? Y/N",
                            maxlength: "1",
                            required: ""
                          },
                          domProps: { value: _vm.form.IsGSCUnit },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "IsGSCUnit",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-driver", {
        on: {
          changeTitle: function($event) {
            return _vm.updateTitle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-operator", {
        on: {
          changeTitleOperator: function($event) {
            return _vm.updateTitleOperator($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-vehicletype", {
        on: {
          changeTitleVehicleType: function($event) {
            return _vm.updateTitleVehicleType($event)
          }
        }
      })
    ],
    1
=======
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.modalPage == 2,
                              expression: "modalPage == 2"
                            }
                          ],
                          staticClass: "row"
                        },
                        [
                          _c("div", { staticClass: "col-md-6" }, [
                            _c("div", { staticClass: "row" }, [
                              _c("div", { staticClass: "col-md-6" }, [
                                _c(
                                  "button",
                                  {
                                    staticClass: "btn btn-primary btn-xs",
                                    attrs: { type: "button", bold: "" },
                                    on: {
                                      click: function($event) {
                                        return _vm.viewReport()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-arrow-left",
                                      attrs: { "aria-hidden": "true" }
                                    }),
                                    _vm._v(
                                      "\n                                                Back to Setting\n                                            "
                                    )
                                  ]
                                )
                              ]),
                              _vm._v(" "),
                              _vm._m(9)
                            ]),
                            _vm._v(" "),
                            _c("iframe", {
                              attrs: {
                                width: "100%",
                                height: "550px",
                                src: _vm.reportData.url1
                              }
                            })
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-md-6" }, [
                            _vm._m(10),
                            _vm._v(" "),
                            _c("iframe", {
                              attrs: {
                                width: "100%",
                                height: "550px",
                                src: _vm.reportData.url2
                              }
                            })
                          ])
                        ]
                      )
                    ])
                  ])
                ])
              ]
            )
          ]
        )
      ]),
      _vm._v(" "),
      _c("search-signatory", {
        on: {
          rowClick: function($event) {
            return _vm.signatoryClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-fuelHeader", {
        on: {
          rowClick: function($event) {
            return _vm.fuelHeaderClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-fuelListModal", {
        on: {
          rowClick: function($event) {
            return _vm.fuelListClose($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("FUEL Entry")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-4 text-right" }, [
      _c("b", [_vm._v("TOTAL AMOUNT :")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("Invoice No.")]),
        _vm._v(" "),
        _c("th", [_vm._v("Description")]),
        _vm._v(" "),
        _c("th", [_vm._v("Qty")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit Price")]),
        _vm._v(" "),
        _c("th", [_vm._v("Amount")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "7" } }, [
      _c("i", [_vm._v("No Data Found...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-1" }, [
      _c(
        "button",
        {
          staticClass: "close close-modal",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12 text-right" }, [
        _c("label", [_vm._v(" ")]),
        _vm._v(" "),
        _c(
          "button",
          {
            staticClass: "btn btn-success",
            attrs: { type: "submit", bold: "" }
          },
          [
            _c("i", {
              staticClass: "fa fa-save",
              attrs: { "aria-hidden": "true" }
            }),
            _vm._v(
              "\n                                            SAVE\n                                        "
            )
          ]
        )
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Generate SOA Report")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-6 text-right" }, [
      _c("h6", [_c("i", [_vm._v("Page 1")])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-6" }),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-6 text-right" }, [
        _c("h6", [_c("i", [_vm._v("Page 2 (Attachment)")])])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-6 text-right" }, [
      _c("h6", [_c("i", [_vm._v("Page 1")])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-6" }),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-6 text-right" }, [
        _c("h6", [_c("i", [_vm._v("Page 2 (Attachment)")])])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=template&id=0e8521f2&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=template&id=0e8521f2& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "FUELListModal",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-md",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.search,
                          expression: "search"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "search",
                        placeholder: "Search here..."
                      },
                      domProps: { value: _vm.search },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.search = $event.target.value
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          _vm._l(_vm.filteredBlogs, function(item) {
                            return _c(
                              "tr",
                              {
                                on: {
                                  click: function($event) {
                                    return _vm.rowClick(item)
                                  }
                                }
                              },
                              [
                                _c("td", [
                                  _vm._v(
                                    "\n                                            " +
                                      _vm._s(item.Code) +
                                      "\n                                        "
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(
                                    "\n                                            " +
                                      _vm._s(item.Description) +
                                      "\n                                        "
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Unit))]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(
                                    "\n                                            " +
                                      _vm._s(
                                        _vm._f("formatNumber")(item.UnitPrice)
                                      ) +
                                      "\n                                        "
                                  )
                                ])
                              ]
                            )
                          }),
                          0
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("JEEP Vehicle List")])
=======
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("FUEL List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("tr", [
      _c("th", [_vm._v("Plate Number")]),
      _vm._v(" "),
      _c("th", [_vm._v("Driver Name")]),
      _vm._v(" "),
      _c("th", [_vm._v("Operator Name")]),
      _vm._v(" "),
      _c("th", [_vm._v("Engine")]),
      _vm._v(" "),
      _c("th", [_vm._v("Serial Number")]),
      _vm._v(" "),
      _c("th", [_vm._v("Modify")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
=======
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Code")]),
        _vm._v(" "),
        _c("th", [_vm._v("Description")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit Price")])
      ])
    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "SearchSignatory",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-md",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.search,
                          expression: "search"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "search",
                        placeholder: "Search Signatory here..."
                      },
                      domProps: { value: _vm.search },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.search = $event.target.value
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          _vm._l(_vm.filteredBlogs, function(item) {
                            return _c(
                              "tr",
                              {
                                key: item.SID,
                                on: {
                                  click: function($event) {
                                    return _vm.rowClick(item)
                                  }
                                }
                              },
                              [
                                _c("td", [_vm._v(_vm._s(item.SignatoryName))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Designation))])
                              ]
                            )
                          }),
                          0
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("Signatory List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Signatory Name")]),
        _vm._v(" "),
<<<<<<< HEAD
        _c("th", [_vm._v("Motor Vehicle Type Name")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-footer " }, [
      _c(
        "button",
        {
          staticClass: "btn btn-default",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [_c("i", { staticClass: "far fa-window-close" }), _vm._v(" Close")]
      )
    ])
=======
        _c("th", [_vm._v("Designation")])
      ])
    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/JeepComponents/VehicleList.vue":
/*!****************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleList.vue ***!
  \****************************************************************/
=======
/***/ "./resources/js/components/FUEL/FUELEntry.vue":
/*!****************************************************!*\
  !*** ./resources/js/components/FUEL/FUELEntry.vue ***!
  \****************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _VehicleList_vue_vue_type_template_id_07eb7a42___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleList.vue?vue&type=template&id=07eb7a42& */ "./resources/js/components/JeepComponents/VehicleList.vue?vue&type=template&id=07eb7a42&");
/* harmony import */ var _VehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleList.vue?vue&type=script&lang=js& */ "./resources/js/components/JeepComponents/VehicleList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VehicleList.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

=======
/* harmony import */ var _FUELEntry_vue_vue_type_template_id_0b16ae64___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FUELEntry.vue?vue&type=template&id=0b16ae64& */ "./resources/js/components/FUEL/FUELEntry.vue?vue&type=template&id=0b16ae64&");
/* harmony import */ var _FUELEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FUELEntry.vue?vue&type=script&lang=js& */ "./resources/js/components/FUEL/FUELEntry.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleList_vue_vue_type_template_id_07eb7a42___WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleList_vue_vue_type_template_id_07eb7a42___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FUELEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FUELEntry_vue_vue_type_template_id_0b16ae64___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FUELEntry_vue_vue_type_template_id_0b16ae64___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/JeepComponents/VehicleList.vue"
=======
component.options.__file = "resources/js/components/FUEL/FUELEntry.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/JeepComponents/VehicleList.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleList.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
=======
/***/ "./resources/js/components/FUEL/FUELEntry.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/FUEL/FUELEntry.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css& ***!
  \*************************************************************************************************/
/*! no static exports found */
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FUELEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FUELEntry.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/FUELEntry.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FUELEntry_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/FUEL/FUELEntry.vue?vue&type=template&id=0b16ae64&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/FUEL/FUELEntry.vue?vue&type=template&id=0b16ae64& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FUELEntry_vue_vue_type_template_id_0b16ae64___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./FUELEntry.vue?vue&type=template&id=0b16ae64& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/FUEL/FUELEntry.vue?vue&type=template&id=0b16ae64&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FUELEntry_vue_vue_type_template_id_0b16ae64___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FUELEntry_vue_vue_type_template_id_0b16ae64___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchFUELList.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchFUELList.vue ***!
  \***************************************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleList.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/JeepComponents/VehicleList.vue?vue&type=template&id=07eb7a42&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/VehicleList.vue?vue&type=template&id=07eb7a42& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
=======
/* harmony import */ var _SearchFUELList_vue_vue_type_template_id_0e8521f2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchFUELList.vue?vue&type=template&id=0e8521f2& */ "./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=template&id=0e8521f2&");
/* harmony import */ var _SearchFUELList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchFUELList.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SearchFUELList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchFUELList_vue_vue_type_template_id_0e8521f2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchFUELList_vue_vue_type_template_id_0e8521f2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/search/SearchAllowance/SearchFUELList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_template_id_07eb7a42___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleList.vue?vue&type=template&id=07eb7a42& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/VehicleList.vue?vue&type=template&id=07eb7a42&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_template_id_07eb7a42___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleList_vue_vue_type_template_id_07eb7a42___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchFUELList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchFUELList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchFUELList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=template&id=0e8521f2&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=template&id=0e8521f2& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchFUELList_vue_vue_type_template_id_0e8521f2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchFUELList.vue?vue&type=template&id=0e8521f2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchFUELList.vue?vue&type=template&id=0e8521f2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchFUELList_vue_vue_type_template_id_0e8521f2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchFUELList_vue_vue_type_template_id_0e8521f2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/components/search/SearchJeep/SearchVehicleType.vue ***!
  \*************************************************************************/
=======
/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue ***!
  \******************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchVehicleType.vue?vue&type=template&id=d79c782e& */ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&");
/* harmony import */ var _SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchVehicleType.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&");
=======
/* harmony import */ var _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchSignatories.vue?vue&type=template&id=93faadfe& */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&");
/* harmony import */ var _SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchSignatories.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/search/SearchJeep/SearchVehicleType.vue"
=======
component.options.__file = "resources/js/components/search/SearchAllowance/SearchSignatories.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
=======
/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchVehicleType.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e& ***!
  \********************************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchSignatories.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe& ***!
  \*************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchVehicleType.vue?vue&type=template&id=d79c782e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchSignatories.vue?vue&type=template&id=93faadfe& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchAllowance/SearchSignatories.vue?vue&type=template&id=93faadfe&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchSignatories_vue_vue_type_template_id_93faadfe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);