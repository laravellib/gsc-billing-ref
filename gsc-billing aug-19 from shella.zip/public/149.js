(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[149],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _WingVan_SOA_Search_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-SOA-Search.vue */ "./resources/js/components/wingvan/WingVan-SOA-Search.vue");
/* harmony import */ var _WingVan_Menu_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WingVan-Menu.vue */ "./resources/js/components/wingvan/WingVan-Menu.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-soa': _WingVan_SOA_Search_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'wingvan-menu': _WingVan_Menu_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      mode: [],
      form: new Form({
        id: '',
        gclid_link: 0,
        mode: '',
        payment_date: '',
        or_ref_no: '',
        check_card_no: '',
        check_card_bank_name: '',
        amount: 0,
        remarks: '',
        applied_amount: 0,
        filter: null,
        soa_link: 0,
        soa_no: ''
      })
    };
  },
  methods: {
    clear: function clear() {
      this.form.reset();
      this.form.payment_date = moment__WEBPACK_IMPORTED_MODULE_0___default()().format('YYYY-MM-DD');
    },
    loadMode: function loadMode() {
      var _this = this;

      axios.get('api/mode').then(function (_ref) {
        var data = _ref.data;
        _this.mode = data.data;
      });
    },
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    create_payment: function create_payment() {
      var _this2 = this;

      if (this.form.soa_link == 0) {
        return swal.fire('Select SOA', 'warning');
      }

      if (!this.form.or_ref_no) {
        return swal.fire('Please enter Official Receipt or Reference Number', 'warning');
      }

      if (!this.form.amount) {
        return swal.fire('Please Enter Amount', 'warning');
      }

      if (this.form.amount <= 0) {
        return swal.fire('Amount needs to be greater than 0', 'warning');
      }

      if (this.form.amount > this.form.applied_amount) {
        this.form.amount = this.form.applied_amount;
      }

      this.$Progress.start();
      this.form.post('wingvan/payment_store').then(function (data) {
        toast.fire({
          icon: 'success',
          title: 'Added Data in successfully'
        });

        _this2.clear();

        _this2.filter = null;
      })["catch"](function () {
        _this2.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Error Found'
        });
      });
      this.$Progress.finish();
    },
    searchSOA: function searchSOA() {
      $('#searchSOA').modal('show');
    },
    get_soa: function get_soa(data) {
      this.form.soa_no = data.series_no;
      this.form.soa_link = data.id;
      this.getBalance(data.id, data.amount);
    },
    getBalance: function getBalance(id, amount) {
      var _this3 = this;

      axios.get('wingvan/payments/' + id).then(function (response) {
        var sum = 0;
        response.data.data.forEach(function (item) {
          sum = sum + parseFloat(item.amount);
        });
        _this3.form.applied_amount = amount - sum;
      });
    }
  },
  created: function created() {
    this.loadMode();
    this.form.payment_date = moment__WEBPACK_IMPORTED_MODULE_0___default()().format('YYYY-MM-DD');
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf& ***!
  \**************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container" },
    [
      _c(
        "div",
        { staticClass: "row" },
        [
          _c("img", { attrs: { src: __webpack_require__(/*! ./WingVan.png */ "./resources/js/components/wingvan/WingVan.png") } }),
          _vm._v(" "),
          _c("wingvan-menu"),
          _vm._v(" "),
          _c("div", { staticClass: "container" }, [
            _c("div", { staticClass: "row mt-3" }, [
              _c("div", { staticClass: "col" }, [
                _c("h4", [_vm._v("Entry Payments")]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.create_payment()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-sm" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("SOA No.")
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "input-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.soa_no,
                                expression: "form.soa_no"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: {
                              type: "text",
                              name: "soa_no",
                              disabled: ""
                            },
                            domProps: { value: _vm.form.soa_no },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "soa_no",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("span", { staticClass: "input-group-btn" }, [
                            _c(
                              "button",
                              {
                                staticClass: "btn btn-outline-primary btn-sm",
                                attrs: { type: "button" },
                                on: {
                                  click: function($event) {
                                    return _vm.searchSOA()
                                  }
                                }
                              },
                              [_c("i", { staticClass: "fa fa-search fa-fw" })]
                            )
                          ])
                        ])
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-sm" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Billed To")
                        ]),
                        _vm._v(" "),
                        _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.mode,
                                expression: "form.mode"
                              }
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: { required: true },
                            on: {
                              change: function($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function(o) {
                                    return o.selected
                                  })
                                  .map(function(o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.$set(
                                  _vm.form,
                                  "mode",
                                  $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                )
                              }
                            }
                          },
                          _vm._l(_vm.mode, function(m) {
                            return _c(
                              "option",
                              { key: m.id, domProps: { value: m.name } },
                              [_vm._v(_vm._s(m.name))]
                            )
                          }),
                          0
                        )
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-sm" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Payment Date")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.payment_date,
                              expression: "form.payment_date"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date" },
                          domProps: { value: _vm.form.payment_date },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "payment_date",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-sm-4" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("OR / Ref No")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.or_ref_no,
                              expression: "form.or_ref_no"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text" },
                          domProps: { value: _vm.form.or_ref_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "or_ref_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Check Card No")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.check_card_no,
                              expression: "form.check_card_no"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text" },
                          domProps: { value: _vm.form.check_card_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "check_card_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Check Card / Bank Name")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.check_card_bank_name,
                              expression: "form.check_card_bank_name"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text" },
                          domProps: { value: _vm.form.check_card_bank_name },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "check_card_bank_name",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Amount")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.amount,
                              expression: "form.amount"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          staticStyle: { "text-align": "right" },
                          attrs: { type: "text" },
                          domProps: { value: _vm.form.amount },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "amount", $event.target.value)
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                          _vm._v("Applied Amount")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.applied_amount,
                              expression: "form.applied_amount"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          staticStyle: { "text-align": "right" },
                          attrs: { type: "text", disabled: "" },
                          domProps: { value: _vm.form.applied_amount },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "applied_amount",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row mt-2" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "remarks" } }, [
                          _vm._v("Remarks")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.remarks,
                              expression: "form.remarks"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text" },
                          domProps: { value: _vm.form.remarks },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "remarks", $event.target.value)
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row mt-2" }, [
                      _c("div", { staticClass: "col" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-secondary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.clear()
                              }
                            }
                          },
                          [_vm._v("New / Clear")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-success",
                            attrs: { type: "submit" }
                          },
                          [_vm._v("Save")]
                        )
                      ])
                    ])
                  ]
                )
              ])
            ])
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("search-soa", { on: { search: _vm.get_soa } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Payment.vue":
/*!*************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Payment.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Payment.vue?vue&type=template&id=506fa9bf& */ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&");
/* harmony import */ var _WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-Payment.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/wingvan/WingVan-Payment.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Payment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&":
/*!********************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Payment.vue?vue&type=template&id=506fa9bf& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);