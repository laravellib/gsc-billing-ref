(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[86],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
=======
/* harmony import */ var _WingVan_Menu_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Menu.vue */ "./resources/js/components/wingvan/WingVan-Menu.vue");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
/* harmony default export */ __webpack_exports__["default"] = ({
  components: {},
  data: function data() {
    return {
      rows: [],
      noDataFound: true,
      noDataFound2: true,
      loading: false,
      search: "",
      OverAllBalance: 0,
      detailRows: [],
      showTable1: true
    };
  },
  mounted: function mounted() {
    this.getData();
  },
  methods: {
    getData: function getData() {
      var _this = this;

      this.loading = true;
      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getLedger: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          var Balance = 0;
          response.data.forEach(function (item) {
            item.bcolor = item.SOANo != '' ? "bcolor-blue" : "bcolor-red";
            Balance = Balance + item.Amount;
            item.Balance = Balance;
          });
          _this.OverAllBalance = _this.$root.formatNumberCommaRound(Balance);
          _this.rows = response.data;
          _this.noDataFound = false;
        } else {
          _this.noDataFound = true;
        }

        _this.$Progress.finish();

        _this.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    rowClick: function rowClick(row) {
      var _this2 = this;

      console.log(row);

      if (row.SOANo == "") {
        this.showTable1 = false;
        this.$Progress.start();
        axios.get("api/allowance", {
          params: {
            getLedgerPayment: true,
            id: row.ALID
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this2.detailRows = response.data;
            _this2.noDataFound2 = false;
          } else {
            _this2.detailRows = [];
            _this2.noDataFound2 = true;
          }

          _this2.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
      } else {
        this.showTable1 = true;
        this.$Progress.start();
        axios.get("api/allowance", {
          params: {
            getLedgerPaymentSOA: true,
            SOANo: row.SOANo
          }
        }).then(function (response) {
          if (response.data.length > 0) {
            _this2.detailRows = response.data;
            _this2.noDataFound2 = false;
          } else {
            _this2.detailRows = [];
            _this2.noDataFound2 = true;
          }

          _this2.$Progress.finish();
        })["catch"](function (error) {
          console.log(error);
        });
      }
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.rows.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toString().toLowerCase().includes(v) || item.check_no.toString().toLowerCase().includes(v) || item.orNumber.toString().toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.height-modified {\n    height:300px !important;\n}\n.height-modified2 {\n    height:100px !important;\n}\n.bcolor-red {\n    background-color: #5eff69 !important;\n}\n.bcolor-blue {\n    background-color: #e5e1fc !important;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa& ***!
  \*******************************************************************************************************************************************************************************************************************/
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'wingvan-menu': _WingVan_Menu_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      drivers: [],
      filter: [],
      editMode: false,
      searching: '',
      form: new Form({
        id: '',
        FirstName: '',
        MiddleName: '',
        LastName: '',
        ExtName: '',
        Address: '',
        GSCDriver: 'Y',
        VehicleType: 'WINGVAN'
      })
    };
  },
  methods: {
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      this.form.fill(dataItem);
      this.editMode = true;
    },
    search: function search(ev) {
      this.filter = this.golfcart.filter(function (item) {
        return item.Name.match(ev);
      });
    },
    loadDriver: function loadDriver() {
      var _this = this;

      axios.get('api/driver?VehicleType=WINGVAN').then(function (_ref) {
        var data = _ref.data;
        data.data.forEach(function (item) {
          var FName = item.FirstName ? item.FirstName + ' ' : '';
          var MName = item.MiddleName ? item.MiddleName + ' ' : '';
          var LName = item.LastName ? item.LastName + ' ' : '';
          var ExtName = item.ExtName ? item.ExtName : '';
          item.Name = FName + MName + LName + ExtName;
        });
        _this.drivers = data.data;
        _this.filter = _this.drivers;
      });
    },
    createDriver: function createDriver() {
      var _this2 = this;

      this.$Progress.start();
      this.form.post('api/driver').then(function () {
        toast.fire({
          icon: 'success',
          title: 'Driver successfully created'
        });

        _this2.$Progress.finish();

        _this2.loadDriver();

        _this2.clear();
      })["catch"](function () {
        _this2.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Driver not added successfully'
        });
      });
    },
    updateDriver: function updateDriver(id) {
      this.$Progress.start();
      this.form.put('api/driver/' + this.form.id);
      toast.fire({
        icon: 'success',
        title: 'Driver successfully updated'
      });
      this.$Progress.finish();
      this.loadDriver();
      this.clear();
    },
    deleteData: function deleteData(id) {
      var _this3 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this3.$Progress.start();

          $('#addNew').modal('hide');

          _this3.form["delete"]('api/driver/' + id);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');

          _this3.$Progress.finish();

          _this3.loadDriver();

          _this3.clear();
        }
      });
    },
    clear: function clear() {
      this.editMode = false;
      this.form.reset();
    }
  },
  created: function created() {
    this.loadDriver();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=template&id=07e1b67f&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=template&id=07e1b67f& ***!
  \*************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c("div", { staticClass: "container dave-template" }, [
    _c("div", { staticClass: "col-xs-12" }, [
      _c("div", { staticClass: "card" }, [
        _vm._m(0),
        _vm._v(" "),
        _c("div", { staticClass: "card-body table-responsive" }, [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-12 table-height2" }, [
              _c(
                "table",
                { staticClass: "table table-hover table-striped dave-table" },
                [
                  _vm._m(1),
                  _vm._v(" "),
                  _c(
                    "tbody",
                    { staticClass: "dave-tbody height-modified" },
                    [
                      _c(
                        "tr",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: this.loading,
                              expression: "this.loading"
                            }
                          ]
                        },
                        [_vm._m(2)]
                      ),
                      _vm._v(" "),
                      _c(
                        "tr",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: this.noDataFound,
                              expression: "this.noDataFound"
                            }
                          ]
                        },
                        [_vm._m(3)]
                      ),
                      _vm._v(" "),
                      _vm._l(_vm.filteredBlogs, function(item) {
                        return _c(
                          "tr",
                          {
                            class: item.bcolor,
                            on: {
                              click: function($event) {
                                return _vm.rowClick(item)
                              }
                            }
                          },
                          [
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(
                                      _vm._f("formatDate")(item.paymentDate)
                                    ) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(item.SOANo ? item.SOANo : "PAYMENT")
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.check_no) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.orNumber) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                attrs: { width: "20%" }
                              },
                              [
                                _vm._v(
                                  "\n                                        " +
                                    _vm._s(item.paymentMode) +
                                    "\n                                    "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-right",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.paymentType == "DEBIT"
                                          ? item.Amount
                                          : "0"
                                      )
                                    )
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-right",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.paymentType == "CREDIT"
                                          ? item.Amount
                                          : "0"
                                      )
                                    )
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-right",
                                attrs: { width: "20%" }
                              },
                              [
                                _c("b", [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(
                                        item.Balance ? item.Balance : "0"
                                      )
                                    )
                                  )
                                ])
                              ]
                            ),
                            _vm._v(" "),
                            _c("td", { attrs: { width: "20%" } }, [
                              _vm._v(_vm._s(item.remarks))
                            ])
                          ]
                        )
                      })
                    ],
                    2
                  )
                ]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-8" }, [
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.showTable1,
                      expression: "showTable1"
                    }
                  ],
                  staticClass: "row"
                },
                [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(4),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody height-modified2" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: this.noDataFound2,
                                    expression: "this.noDataFound2"
                                  }
                                ]
                              },
                              [_vm._m(5)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.detailRows, function(item) {
                              return _c("tr", [
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.paymentMode))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatDate")(item.paymentDate)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.check_no))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.orNumber))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.billed_amount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.check_amount)
                                    )
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: !_vm.showTable1,
                      expression: "!showTable1"
                    }
                  ],
                  staticClass: "row"
                },
                [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(6),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody height-modified2" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: this.noDataFound2,
                                    expression: "this.noDataFound2"
                                  }
                                ]
                              },
                              [_vm._m(7)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.detailRows, function(item) {
                              return _c("tr", [
                                _c("td", { staticClass: "text-center" }, [
                                  _vm._v(_vm._s(item.SOANo))
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.billed_amount)
                                    )
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", { staticClass: "text-right" }, [
                                  _vm._v(
                                    _vm._s(
                                      _vm._f("formatNumber")(item.check_amount)
                                    )
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ]
              )
            ]),
            _vm._v(" "),
            _vm._m(8),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-2" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.OverAllBalance,
                    expression: "OverAllBalance"
                  }
                ],
                staticClass: "form-control text-right",
                attrs: {
                  type: "text",
                  name: "OverAllBalance",
                  placeholder: ""
                },
                domProps: { value: _vm.OverAllBalance },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.OverAllBalance = $event.target.value
                  }
                }
              })
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-footer" })
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("VIEW LEDGER")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        PDate\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        SOA #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        Check #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        OR #\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        PMode\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        DEBIT\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        CREDIT\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        BALANCE\n                                    "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center", attrs: { width: "20%" } }, [
          _vm._v(
            "\n                                        REMARKS\n                                    "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center b", attrs: { colspan: "4" } }, [
      _c("i", [_vm._v("Loading...")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "4" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Mode\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Date\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Check #\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                OR #\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Amount\n                                            "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "6" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                SOANo\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Amount\n                                            "
          )
        ]),
        _vm._v(" "),
        _c("th", { staticClass: "text-center" }, [
          _vm._v(
            "\n                                                Payment Amount\n                                            "
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "3" } }, [
      _c("b", [_vm._v("No Data Found")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-2 text-right" }, [
      _c("b", [_vm._v("OVERALL BALANCE :")])
    ])
  }
]
=======
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      { staticClass: "row" },
      [
        _c("img", { attrs: { src: __webpack_require__(/*! ./WingVan.png */ "./resources/js/components/wingvan/WingVan.png") } }),
        _vm._v(" "),
        _c("wingvan-menu"),
        _vm._v(" "),
        _c("div", { staticClass: "row mt-3" }, [
          _c("div", { staticClass: "col-sm" }, [
            _vm._v("\n        Add New Passenger Van Driver\n        "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    _vm.editMode ? _vm.updateDriver() : _vm.createDriver()
                  }
                }
              },
              [
                _c("div", { staticClass: "modal-body" }, [
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.FirstName,
                          expression: "form.FirstName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      class: { "is-invalid": _vm.form.errors.has("name") },
                      attrs: {
                        type: "text",
                        name: "name",
                        placeholder: "First Name"
                      },
                      domProps: { value: _vm.form.FirstName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "FirstName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.MiddleName,
                          expression: "form.MiddleName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "asset_no",
                        placeholder: "Middle Name"
                      },
                      domProps: { value: _vm.form.MiddleName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "MiddleName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.LastName,
                          expression: "form.LastName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "engine_no",
                        placeholder: "Last Name"
                      },
                      domProps: { value: _vm.form.LastName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "LastName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.ExtName,
                          expression: "form.ExtName"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "serial_no",
                        placeholder: "Extention Name"
                      },
                      domProps: { value: _vm.form.ExtName },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "ExtName", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.Address,
                          expression: "form.Address"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "Address",
                        placeholder: "Address"
                      },
                      domProps: { value: _vm.form.Address },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "Address", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.GSCDriver,
                          expression: "form.GSCDriver"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: {
                        type: "text",
                        name: "serial_no",
                        placeholder: "GSC Driver?"
                      },
                      domProps: { value: _vm.form.GSCDriver },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "GSCDriver", $event.target.value)
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "modal-footer" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { type: "submit" }
                    },
                    [_vm._v(_vm._s(_vm.editMode ? "Update" : "Add New"))]
                  ),
                  _vm._v(" "),
                  _vm.editMode
                    ? _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              return _vm.deleteData(_vm.form.id)
                            }
                          }
                        },
                        [_vm._v("Delete")]
                      )
                    : _vm._e()
                ])
              ]
            )
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "col-sm-8" },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.searching,
                    expression: "searching"
                  }
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "text", placeholder: "Search by Name..." },
                domProps: { value: _vm.searching },
                on: {
                  keyup: function($event) {
                    return _vm.search(_vm.searching)
                  },
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.searching = $event.target.value
                  }
                }
              }),
              _vm._v(" "),
              _c(
                "kendo-grid",
                {
                  attrs: {
                    height: 400,
                    "data-source": _vm.filter,
                    selectable: true,
                    sortable: true
                  },
                  on: { change: _vm.onChange }
                },
                [
                  _c("kendo-grid-column", {
                    attrs: { field: "id", title: "ID" }
                  }),
                  _vm._v(" "),
                  _c("kendo-grid-column", {
                    attrs: { field: "Name", title: "Name" }
                  }),
                  _vm._v(" "),
                  _c("kendo-grid-column", {
                    attrs: { field: "Address", title: "Address" }
                  })
                ],
                1
              )
            ],
            1
          )
        ])
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Menu.vue?vue&type=template&id=5b58b814&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Menu.vue?vue&type=template&id=5b58b814& ***!
  \***********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "nav",
    { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
    [
      _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
        _vm._v("WING VAN SECTION")
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "collapse navbar-collapse", attrs: { id: "navbarNav" } },
        [
          _c("ul", { staticClass: "navbar-nav" }, [
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-list"
                    }
                  },
                  [_vm._v("Wing Van List")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-location"
                    }
                  },
                  [_vm._v("Route")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-driver"
                    }
                  },
                  [_vm._v("Driver")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-po"
                    }
                  },
                  [_vm._v("Purchase Order")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-rental"
                    }
                  },
                  [_vm._v("Rental")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-soa"
                    }
                  },
                  [_vm._v("Create SOA")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-payment"
                    }
                  },
                  [_vm._v("Payment Collection")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-ledger"
                    }
                  },
                  [_vm._v("Ledger")]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "li",
              { staticClass: "nav-item" },
              [
                _c(
                  "router-link",
                  {
                    staticClass: "nav-link",
                    attrs: {
                      tag: "a",
                      "active-class": "active",
                      exact: "",
                      to: "/wingvan-reports"
                    }
                  },
                  [_vm._v("Reports")]
                )
              ],
              1
            )
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = []
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/allowance/Ledger.vue":
/*!******************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue ***!
  \******************************************************/
=======
/***/ "./resources/js/components/wingvan/WingVan-Driver.vue":
/*!************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Driver.vue ***!
  \************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Ledger.vue?vue&type=template&id=6e4274aa& */ "./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&");
/* harmony import */ var _Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ledger.vue?vue&type=script&lang=js& */ "./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Ledger.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

=======
/* harmony import */ var _WingVan_Driver_vue_vue_type_template_id_07e1b67f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Driver.vue?vue&type=template&id=07e1b67f& */ "./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=template&id=07e1b67f&");
/* harmony import */ var _WingVan_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-Driver.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_Driver_vue_vue_type_template_id_07e1b67f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_Driver_vue_vue_type_template_id_07e1b67f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/allowance/Ledger.vue"
=======
component.options.__file = "resources/js/components/wingvan/WingVan-Driver.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
=======
/***/ "./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************/
/*! no static exports found */
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Driver.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Driver_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=template&id=07e1b67f&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=template&id=07e1b67f& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Driver_vue_vue_type_template_id_07e1b67f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Driver.vue?vue&type=template&id=07e1b67f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Driver.vue?vue&type=template&id=07e1b67f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Driver_vue_vue_type_template_id_07e1b67f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Driver_vue_vue_type_template_id_07e1b67f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Menu.vue":
/*!**********************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Menu.vue ***!
  \**********************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa& ***!
  \*************************************************************************************/
=======
/* harmony import */ var _WingVan_Menu_vue_vue_type_template_id_5b58b814___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Menu.vue?vue&type=template&id=5b58b814& */ "./resources/js/components/wingvan/WingVan-Menu.vue?vue&type=template&id=5b58b814&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _WingVan_Menu_vue_vue_type_template_id_5b58b814___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_Menu_vue_vue_type_template_id_5b58b814___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/wingvan/WingVan-Menu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Menu.vue?vue&type=template&id=5b58b814&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Menu.vue?vue&type=template&id=5b58b814& ***!
  \*****************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Ledger.vue?vue&type=template&id=6e4274aa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Ledger.vue?vue&type=template&id=6e4274aa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ledger_vue_vue_type_template_id_6e4274aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Menu_vue_vue_type_template_id_5b58b814___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Menu.vue?vue&type=template&id=5b58b814& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Menu.vue?vue&type=template&id=5b58b814&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Menu_vue_vue_type_template_id_5b58b814___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Menu_vue_vue_type_template_id_5b58b814___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });

>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc


/***/ }),

/***/ "./resources/js/components/wingvan/WingVan.png":
/*!*****************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan.png ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/WingVan.png?c4af0557fbfa532543dc43a3e26c4af6";

/***/ })

}]);