(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[36],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _search_client_list_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/client-list.vue */ "./resources/js/components/search/client-list.vue");
/* harmony import */ var _search_signatory_req_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/signatory-req.vue */ "./resources/js/components/search/signatory-req.vue");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

=======
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
/* harmony import */ var _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchOperator.vue */ "./resources/js/components/search/SearchJeep/SearchOperator.vue");
/* harmony import */ var _search_SearchJeep_SearchVehicleType_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchJeep/SearchVehicleType.vue */ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue");
/* harmony import */ var _OVLMenu_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./OVLMenu.vue */ "./resources/js/components/OVLComponents/OVLMenu.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
=======




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-operator': _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-vehicletype': _search_SearchJeep_SearchVehicleType_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    'ovl-menu': _OVLMenu_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      drivers: [],
      driverses: [],
      signatories: {},
      vehicletypes: {},
      operators: {},
      editmode: false,
      vehicles: [],
      title: '',
      kdid: '',
      form: new Form({
        MVID: '',
        PlateNumber: '',
        EngineNumber: '',
        SerialNumber: '',
        AssetNumber: '',
        DriverName: '',
        DriverLastName: '',
        DriverFirstName: '',
        DriverMiddleName: '',
        DriverExtName: '',
        DriverID: '',
        TruckerName: '',
        TruckerLastName: '',
        TruckerFirstName: '',
        TruckerMiddleName: '',
        TruckerExtName: '',
        TruckerID: '',
        MVTID_Link: '',
        MVTypeName: '',
        IsGSCUnit: ''
      }),
      rate: new Form({
        MVRRID: '',
        MVID_Link: '',
        PlateNumber: '',
        EffectiveDate: '',
        PerTransactionRate: '',
        DailyRate: '',
        PerKilometerRate: '',
        PerHourRate: '',
        PerAreaRate: '',
        FixedMonthlyRate: '',
        PerBagRate: '',
        PerDestinationRate: '',
        Status: ''
      })
    };
  },
  mounted: function mounted() {// this.$parent.getSearchDriver();
    // this.$parent.getSearchOperator();
    //this.$parent.getSearchVehicleType();
  },
  methods: {
    updateTitle: function updateTitle(updatedTitle) {
      var LastName = updatedTitle.LastName ? updatedTitle.LastName + ', ' : '';
      var FirstName = updatedTitle.FirstName ? updatedTitle.FirstName + ' ' : '';
      var MiddleName = updatedTitle.MiddleName ? updatedTitle.MiddleName + ' ' : '';
      var ExtName = updatedTitle.ExtName ? updatedTitle.ExtName : '';
      this.form.DriverName = LastName + FirstName + MiddleName + ExtName;
      this.form.DriverID = updatedTitle.id;
      this.form.DriverLastName = updatedTitle.LastName;
      this.form.DriverFirstName = updatedTitle.FirstName;
      this.form.DriverMiddleName = updatedTitle.MiddleName;
      this.form.DriverExtName = updatedTitle.ExtName; // console.log(updatedTitle);
    },
    updateTitleOperator: function updateTitleOperator(updatedTitleOperator) {
      var LastName = updatedTitleOperator.LastName ? updatedTitleOperator.LastName + ', ' : '';
      var FirstName = updatedTitleOperator.FirstName ? updatedTitleOperator.FirstName + ' ' : '';
      var MiddleName = updatedTitleOperator.MiddleName ? updatedTitleOperator.MiddleName + ' ' : '';
      var ExtName = updatedTitleOperator.ExtName ? updatedTitleOperator.ExtName : '';
      this.form.TruckerName = LastName + FirstName + MiddleName + ExtName;
      this.form.TruckerID = updatedTitleOperator.id;
      this.form.TruckerLastName = updatedTitleOperator.LastName;
      this.form.TruckerFirstName = updatedTitleOperator.FirstName;
      this.form.TruckerMiddleName = updatedTitleOperator.MiddleName;

      if (updatedTitleOperator.ExtName == '') {
        this.form.TruckerExtName = ' ';
      } else {
        this.form.TruckerExtName = updatedTitleOperator.ExtName;
      }
    },
    updateTitleVehicleType: function updateTitleVehicleType(updatedTitleVehicleType) {
      this.form.MVTID_Link = updatedTitleVehicleType.MVTID;
      this.form.MVTypeName = updatedTitleVehicleType.MVType; // console.log(updatedTitle);
    },
    searchVehicleTypeFunction: function searchVehicleTypeFunction() {
      $('#searchVehicleType').modal('show');
    },
    getVehicleTypeIsReal: function getVehicleTypeIsReal() {
      var _this = this;

      axios.get('api/vehicletype').then(function (_ref) {
        var data = _ref.data;
        return _this.vehicletypes = data;
      });
    },
    searchOperatorFunction: function searchOperatorFunction() {
      $('#searchOperator').modal('show');
    },
    getOperatorIsReal: function getOperatorIsReal() {
      var _this2 = this;

      axios.get('api/operator').then(function (_ref2) {
        var data = _ref2.data;
        return _this2.operators = data;
      });
    },
    searchDriverFunction: function searchDriverFunction() {
      Fire.$emit('searchDriver', 'OVL'); // $('#searchDriver').modal('show');
    },
    getDriverIsReal: function getDriverIsReal() {
      var _this3 = this;

      axios.get('api/driver').then(function (_ref3) {
        var data = _ref3.data;
        return _this3.drivers = data;
      });
    },
    getResults: function getResults() {
      var _this4 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/ovlvehicle?page=' + page).then(function (response) {
        _this4.vehicles = response;
      });
    },
    updateVehicle: function updateVehicle(MVID) {
      this.$Progress.start();
      this.form.put('api/ovlvehicle/' + this.form.MVID);
      $('#addNew').modal('hide');
      toast.fire({
        icon: 'success',
        title: 'Vehicle successfully updated'
      });
      this.$Progress.finish();
      this.loadVehicle();
    },
    deleteModal: function deleteModal(MVID) {
      var _this5 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this5.$Progress.start();

          $('#addNew').modal('hide');

          _this5.form["delete"]('api/ovlvehicle/' + MVID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');

          _this5.$Progress.finish();

          _this5.loadVehicle();
        }
      });
    },
    editModal: function editModal(vehicle) {
      this.editmode = true;
      this.form.reset();
      $('#addNew').modal('show');
      this.form.fill(vehicle);
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      $('#addNew').modal('show');
    },
    rateModal: function rateModal(vr) {
      var _this6 = this;

      this.editmode = true;
      this.rate.reset();
      axios.get('api/getJeepAllRate?PlateNumber=' + vr.MVID).then(function (response) {
        if (response.data.length > 0) {
          _this6.rate.fill(response.data[0]);
        } else {
          _this6.rate.PlateNumber = vr.PlateNumber;
          _this6.rate.MVID_Link = vr.MVID;
          _this6.rate.EffectiveDate = _this6.$root.formatDate(new Date());
          _this6.rate.PerHourRate = 0;
        }
      })["catch"](function (error) {
        console.log(error);
      });
      $('#rateModal').modal('show');
    },
    loadVehicle: function loadVehicle() {
      var _this7 = this;

      // axios.get("api/getSearchVehicle").then(({ data }) => (this.vehicles = data));
      axios.get('api/getSearchOVLVehicle').then(function (response) {
        _this7.vehicles = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    updateVehicleRate: function updateVehicleRate() {
      this.$Progress.start();
      this.rate.post('api/jeepRate').then(function (_ref4) {
        var data = _ref4.data;
        $('#rateModal').modal('hide');
        $('.modal-backdrop').remove();

        if (data.success) {
          toast.fire({
            icon: 'success',
            title: data.message
          });
        } else {
          toast.fire({
            icon: 'error',
            title: data.message
          });
        }
      })["catch"](function (err) {
        toast.fire({
          icon: 'error',
          title: 'Oops. Something went wrong'
        });
      });
      this.$Progress.finish();
    },
    createVehicle: function createVehicle() {
      var _this8 = this;

      this.$Progress.start();
      this.form.post('api/ovlvehicle').then(function () {
        $('#addNew').modal('hide');
        $('.modal-backdrop').remove();
        toast.fire({
          icon: 'success',
          title: 'Vehicle successfully created'
        });

        _this8.$Progress.finish();

        _this8.loadVehicle();
      })["catch"](function () {
        _this8.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Vehicle not added successfully'
        });
      });
    }
  },
  created: function created() {
    this.loadVehicle(); //setInterval(() => this.loadDriver(),3000);
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "client-list": _search_client_list_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "signatory-req": _search_signatory_req_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    rental: {
      type: [Object, Array]
    }
  },
  data: function data() {
    var _ref;

    return {
      searching: "",
      golfcart: {},
      details_data: {},
      detail: {},
      filter: {},
      datas: [],
      signatory: {},
      form: new Form((_ref = {
        id: "",
        series_no: "",
        billed_id: "",
        billed_name: "",
        billed_address: "",
        soa_date: "",
        charge_invoice_no: "",
        period_covered: "",
        total_amount: "",
        remarks: "",
        details: "",
        status: "ACTIVE"
      }, _defineProperty(_ref, "total_amount", 0), _defineProperty(_ref, "rentals", {}), _defineProperty(_ref, "grandtotals", {}), _ref))
    };
  },
  methods: {
    get_signatory: function get_signatory(data) {
      var _this = this;

      this.signatory = data;
      console.log(this.signatory);
      this.$Progress.start();
      axios.get("rental_liftruck_soa/details/" + this.form.id).then(function (_ref2) {
        var data = _ref2.data;
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_3___default.a();
        doc.setFont("courier");
        doc.setFontType("bold");
        doc.setFontSize(12);
        doc.addImage(Logo, "PNG", 15, 5, 30, 30);
        doc.setFontSize(14);
        doc.text("GENERAL SERVICES MULTIPURPOSE COOPERATIVE", 50, 15);
        doc.setFontSize(11);
        doc.text("Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon", 50, 20);
        doc.text("CDA # 9520-10019987-1 / TIN: 411-478-949-000", 50, 25);
        doc.setFontType("normal");
        doc.text("STATEMENT OF ACCOUNT", 80, 45);
        doc.text("SOA#" + _this.form.series_no, 150, 40);
        doc.text("BILLED TO:           " + _this.form.billed_name, 30, 57);
        doc.text("                     " + _this.form.billed_address, 30, 65);
        doc.text("PERIOD COVERED:      FOR THE MONTH OF " + _this.form.soa_date, 30, 75);
        doc.autoTable({
          columnStyles: {
            0: {
              halign: "center",
              fillColor: [0, 255, 0]
            },
            1: {
              halign: "center",
              fillColor: [255, 255, 0]
            },
            2: {
              halign: "center",
              fillColor: [0, 255, 255]
            }
          },
          // European countries centered
          body: data.data,
          columns: [{
            header: "Date",
            dataKey: "req_date"
          }, {
            header: "Particulars",
            dataKey: "particulars"
          }, {
            header: "Amount",
            dataKey: "amount"
          }],
          margin: {
            top: 80
          }
        });
        doc.text("Prepared By:", 30, 150);
        doc.text(_this.signatory.preparedBy, 30, 155);
        doc.text("Approved By:", 110, 150);
        doc.text(_this.signatory.approvedBy, 110, 155);
        doc.text("Noted By:", 30, 165);
        doc.text(_this.signatory.notedBy, 30, 170);
        doc.save("liftruck_soa_" + _this.form.series_no + ".pdf");
      });
      this.$Progress.finish();
    },
    print_soa: function print_soa() {
      if (this.form.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        $("#signatory-req").modal("show");
      }
    },
    post_soa: function post_soa() {
      var _this2 = this;

      if (this.form.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        this.form.put("api/liftruck_soa_hdr/" + this.form.id).then(function () {
          toast.fire({
            icon: "success",
            title: "Update data successfully"
          });

          _this2.form.reset();
        })["catch"](function () {
          swal.fire("Error Found.", "warning");
        });
      }
    },
    createData: function createData() {
      var _this3 = this;

      if (this.form.id == "") {
        this.form.rentals = this.rental;
        this.form.grandtotals = this.grandtotal;
        this.$Progress.start();
        this.form.post("api/liftruck_soa_hdr").then(function (data) {
          toast.fire({
            icon: "success",
            title: "Added Data in successfully"
          });
          _this3.form.id = data.data.id;
        })["catch"](function () {
          _this3.$Progress.fail();

          toast.fire({
            icon: "error",
            title: "Error Found"
          });
        });
        this.$Progress.finish();
      }
    },
    searchClient: function searchClient() {
      $("#searchGolfcart").modal("show");
    },
    getData: function getData(data) {
      this.form.billed_id = data.id;
      this.form.billed_name = data.FirstName;
      this.form.billed_address = data.Address;
    },
    soa_data: function soa_data(data) {
      this.form.fill(data);
    },
    searchSoa: function searchSoa() {
      $("#searchSOA").modal("show");
    }
  },
  mounted: function mounted() {},
  created: function created() {
    this.form.series_no = "LSOA-" + moment__WEBPACK_IMPORTED_MODULE_0___default()().format("HHMMSS");
    this.form.soa_date = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
    this.form.period_covered = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _search_signatory_review_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/signatory-review.vue */ "./resources/js/components/search/signatory-review.vue");
=======
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "signatory-review": _search_signatory_review_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      id: 0,
      soa_no: "",
      searching: "",
      billed_name: "",
      billed_address: "",
      soa_date: "",
      golfcart: {},
      filter: {},
      detail: {},
      datas: [],
      showButton: false,
      showDetail: false,
      signatory: {}
    };
  },
  methods: {
    get_signatory: function get_signatory(data) {
      var _this = this;

      this.signatory = data;
      console.log(this.signatory);
      this.$Progress.start();
      axios.get("rental_liftruck_soa/details/" + this.id).then(function (_ref) {
        var data = _ref.data;
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_1___default.a();
        doc.setFont("courier");
        doc.setFontType("bold");
        doc.setFontSize(12);
        doc.addImage(Logo, "PNG", 15, 5, 30, 30);
        doc.setFontSize(14);
        doc.text("GENERAL SERVICES MULTIPURPOSE COOPERATIVE", 50, 15);
        doc.setFontSize(11);
        doc.text("Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon", 50, 20);
        doc.text("CDA # 9520-10019987-1 / TIN: 411-478-949-000", 50, 25);
        doc.setFontType("normal");
        doc.text("STATEMENT OF ACCOUNT", 80, 45);
        doc.text("SOA#" + _this.soa_no, 150, 40);
        doc.text("BILLED TO:           " + _this.billed_name, 30, 57);
        doc.text("                     " + _this.billed_address, 30, 65);
        doc.text("PERIOD COVERED:      FOR THE MONTH OF " + _this.soa_date, 30, 75);
        doc.autoTable({
          columnStyles: {
            0: {
              halign: "center",
              fillColor: [0, 255, 0]
            },
            1: {
              halign: "center",
              fillColor: [255, 255, 0]
            },
            2: {
              halign: "center",
              fillColor: [0, 255, 255]
            }
          },
          // European countries centered
          body: data.data,
          columns: [{
            header: "Date",
            dataKey: "req_date"
          }, {
            header: "Particulars",
            dataKey: "particulars"
          }, {
            header: "Amount",
            dataKey: "amount"
          }],
          margin: {
            top: 80
          }
        });
        doc.text("Prepared By:", 30, 150);
        doc.text(_this.signatory.preparedBy, 30, 155);
        doc.text("Approved By:", 110, 150);
        doc.text(_this.signatory.approvedBy, 110, 155);
        doc.text("Noted By:", 30, 165);
        doc.text(_this.signatory.notedBy, 30, 170);
        doc.save("liftruck_soa_" + _this.soa_no + ".pdf");
      });
      this.$Progress.finish();
    },
    soa_detail: function soa_detail() {
      var _this2 = this;

      axios.get("rental_liftruck_soa/details/" + this.id).then(function (_ref2) {
        var data = _ref2.data;
        _this2.detail = data.data;
      });
      this.showDetail = true;
    },
    paid_soa: function paid_soa() {
      var _this3 = this;

      if (this.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        swal.fire({
          title: "Are you sure you want to set this as PAID/COLLECTED?",
          text: "You won't be able to revert this!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Yes, Cancel it!"
        }).then(function (result) {
          if (result.value) {
            axios.get("rental_liftruck_soa/collected/" + _this3.id).then(function (_ref3) {
              var data = _ref3.data;

              _this3.review();
            });
          }
        });
      }
    },
    view_soa: function view_soa() {
      if (this.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        $("#signatory-review").modal("show");
      }
    },
    cancel_soa: function cancel_soa(id) {
      var _this4 = this;

      if (this.id == "") {
        swal.fire("No Data is Selected.", "warning");
      } else {
        swal.fire({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Yes, Cancel it!"
        }).then(function (result) {
          if (result.value) {
            console.log(id);
            axios.get("rental_liftruck_soa/cancel/" + _this4.id).then(function (_ref4) {
              var data = _ref4.data;

              _this4.review();
            });
          }
        });
      }
    },
    review: function review() {
      var _this5 = this;

      axios.get("rental_liftruck_soa/review/" + this.datefrom + "/" + this.dateto).then(function (_ref5) {
        var data = _ref5.data;
        _this5.rental = data.data;
        _this5.filter = _this5.rental;
        console.log(data);
      });
    },
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      console.log(dataItem);
      this.id = dataItem.id;
      this.soa_no = dataItem.series_no;
      this.billed_name = dataItem.billed_name;
      this.billed_address = dataItem.billed_address;
      this.soa_date = dataItem.soa_date;
      this.showButton = true;
      this.showDetail = false;
    }
  },
  mounted: function mounted() {},
  created: function created() {
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Liftruck_SOA_Req_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA-Req.vue */ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue");
/* harmony import */ var _Liftruck_SOA_Review_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA-Review.vue */ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "create-soa": _Liftruck_SOA_Req_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "review-soa": _Liftruck_SOA_Review_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
      datefrom: "",
      dateto: "",
      filter: {},
      selected: [],
      rental: {},
      clients: {},
      client: [],
      columnDefs: null,
      gridApi: null,
      columnApi: null,
      form: new Form({
        billed_id: "",
        billed_name: "",
        billed_address: "",
        series_no: "",
        soa_date: "",
        charge_invoice_no: "",
        remarks: "",
        amount: 0,
        id: 0
      })
    };
  },
  methods: {
    print_soa: function print_soa() {
      var _this = this;

      if (this.form.id == 0) {
        swal.fire("No Data is Selected.", "warning");
      } else {
        this.$Progress.start();
        axios.get("rental_liftruck_soa/details/" + this.form.id).then(function (_ref) {
          var data = _ref.data;
          var doc = new jspdf__WEBPACK_IMPORTED_MODULE_3___default.a();
          doc.setFont("courier");
          doc.setFontType("bold");
          doc.setFontSize(12);
          doc.addImage(Logo, "PNG", 15, 5, 30, 30);
          doc.setFontSize(14);
          doc.text("GENERAL SERVICES MULTIPURPOSE COOPERATIVE", 50, 15);
          doc.setFontSize(11);
          doc.text("Office Address: Borja Road, Damilag, Manolo Fortich, Bukidnon", 50, 20);
          doc.text("CDA # 9520-10019987-1 / TIN: 411-478-949-000", 50, 25);
          doc.setFontType("normal");
          doc.text("STATEMENT OF ACCOUNT", 80, 45);
          doc.text("SOA#" + _this.form.series_no, 150, 40);
          doc.text("BILLED TO:           " + _this.form.billed_name, 30, 57);
          doc.text("                     " + _this.form.billed_address, 30, 65);
          doc.text("PERIOD COVERED:      FOR THE MONTH OF " + _this.form.soa_date, 30, 75);
          doc.autoTable({
            columnStyles: {
              0: {
                halign: "center",
                fillColor: [0, 255, 0]
              },
              1: {
                halign: "center",
                fillColor: [255, 255, 0]
              },
              2: {
                halign: "center",
                fillColor: [0, 255, 255]
              }
            },
            // European countries centered
            body: data.data,
            columns: [{
              header: "Date",
              dataKey: "req_date"
            }, {
              header: "Particulars",
              dataKey: "particulars"
            }, {
              header: "Amount",
              dataKey: "amount"
            }],
            margin: {
              top: 80
            }
          });
          doc.text("Prepared By:", 30, 150);
          doc.text("Approved By:", 85, 150);
          doc.text("Noted By:", 150, 150);
          doc.save("liftruck_soa_" + _this.form.id + ".pdf");
        });
        this.$Progress.finish();
      }
    },
    preview: function preview() {
      var _this2 = this;

      axios.get("rental_liftruck_soa/search/" + this.datefrom + "/" + this.dateto).then(function (_ref2) {
        var data = _ref2.data;
        _this2.selected = [];
        _this2.rental = data.data;
        _this2.filter = _this2.rental;
      });
    },
    create_soa: function create_soa() {
      if (this.selected.length == 0) {
        swal.fire("No Rental Data Found.", "warning");
      } else {
        $("#createSOA").modal("show");
      }
    },
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    onChange: function onChange(e) {
      var _this3 = this;

      this.form.applied_amount = 0;
      this.selected = [];
      var selectedRows = this.gridApi.getSelectedNodes();
      var selectedData = selectedRows.map(function (node) {
        return node.data;
      });
      var push = selectedData.map(function (node) {
        return _this3.selected.push(node);
      });
      console.log(this.selected);
    },
    review_soa: function review_soa() {
      $("#reviewSOA").modal("show");
    },
    get_client: function get_client() {
      var _this4 = this;

      axios.get("search/client").then(function (_ref3) {
        var data = _ref3.data;
        _this4.clients = data.data;
        console.log(_this4.filter);
      });
    }
  },
  created: function created() {
    this.columnDefs = [{
      headerName: "Date",
      field: "date",
      resizable: true,
      width: 170,
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true
    }, {
      headerName: "Type",
      field: "type",
      resizable: true,
      width: 170
    }, {
      headerName: "Activity",
      field: "po_activity",
      resizable: true,
      width: 170
    }, {
      headerName: "Gross Amount",
      field: "gross_amount",
      resizable: true,
      width: 170
    }, {
      headerName: "# Trips",
      field: "no_trips",
      resizable: true,
      width: 170
    }, {
      headerName: "Amount",
      field: "amount",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }];
    this.filter = [];
    this.get_client();
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_2___default()().format("YYYY-MM-DD");
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_2___default()().format("YYYY-MM-DD");
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& ***!
  \****************************************************************************************************************************************************************************************************************************/
=======
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      vehicletypes: {},
      searchVehicleTypeVar: ''
    };
  },
  mounted: function mounted() {
    this.searcherVehicleType();
  },
  methods: {
    changeTitleVehicleType: function changeTitleVehicleType(vt) {
      //console.log(vehicle);
      this.$emit('changeTitleVehicleType', vt); // this.$emit('kuhaDriverID',driver.id);

      $('#searchVehicleType').modal('hide');
    },
    searcherVehicleType: function searcherVehicleType() {
      var _this = this;

      axios.get("api/vehicletype").then(function (_ref) {
        var data = _ref.data;
        return _this.vehicletypes = data;
      });
      console.log(this.vehicletypes);
    },
    searchVehiType: _.debounce(function () {
      Fire.$emit('searchVehicleTypeStart');
    }, 500)
  },
  created: function created() {
    var _this2 = this;

    Fire.$on('searchVehicleTypeStart', function () {
      var query = _this2.searchVehicleTypeVar;
      axios.get('api/findVehicleType?q=' + query).then(function (data) {
        _this2.vehicletypes = data.data;
      });
    });
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n\tpointer-events: none;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleList.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("img", { attrs: { src: __webpack_require__(/*! ./OVL.png */ "./resources/js/components/OVLComponents/OVL.png") } }),
    _vm._v(" "),
    _c(
      "nav",
      {
        staticClass:
          "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
      },
      [
        _c(
          "div",
          {
            staticClass: "collapse navbar-collapse",
            attrs: { id: "navbarNavDropdown" }
          },
          [
            _c("ul", { staticClass: "navbar-nav" }, [
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#mlist"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        Master File\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "mlist"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovldriverlist" }
                          },
                          [_c("a", [_vm._v("OVL Driver List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovlvehiclelist" }
                          },
                          [_c("a", [_vm._v("OVL Vehicle List & Rate")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#trans"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        Transactions\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "trans"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovlvehiclelogentry" }
                          },
                          [_c("a", [_vm._v("OVL Vehicle Log Entry")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovldriverpayroll" }
                          },
                          [_c("a", [_vm._v("Driver Payroll List")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#report"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        OVL Reports\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "report"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistovl" }
                          },
                          [_c("a", [_vm._v("Standard OVL Report")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=template&id=464421f8&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=template&id=464421f8& ***!
  \*******************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container" },
    [
      _c("ovl-menu"),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }, [
              _c(
                "button",
                { staticClass: "btn btn-success", on: { click: _vm.newModal } },
                [
                  _vm._v("\n              Add New OVL Vehicle\n              "),
                  _c("i", { staticClass: "fa fa-user-plus fa fw" })
                ]
              )
            ])
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _c(
                  "tbody",
                  [
                    _vm._m(1),
                    _vm._v(" "),
                    _vm._l(_vm.vehicles, function(vehicle) {
                      return _c("tr", { key: vehicle.MVID }, [
                        _c("td", [_vm._v(_vm._s(vehicle.PlateNumber))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(vehicle.DriverName))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(vehicle.EngineNumber))]),
                        _vm._v(" "),
<<<<<<< HEAD
                        _c("p", [_vm._v(_vm._s(_vm.form.status))])
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "col",
                          staticStyle: { "text-align": "center" }
                        },
                        [
                          _c("label", { attrs: { for: "refence" } }, [
                            _vm._v("Amount")
                          ]),
                          _vm._v(" "),
                          _c("p", [_vm._v(_vm._s(_vm.form.total_amount))])
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "golfcart" } }, [
                          _vm._v("Billed to")
                        ]),
=======
                        _c("td", [_vm._v(_vm._s(vehicle.SerialNumber))]),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "a",
                            {
                              attrs: { href: "#" },
                              on: {
                                click: function($event) {
                                  return _vm.rateModal(vehicle)
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-plus text-success"
                              })
<<<<<<< HEAD
                            ],
                            1
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Period Covered")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.period_covered,
                              expression: "form.period_covered"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date", name: "period_convered" },
                          domProps: { value: _vm.form.period_covered },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
=======
                            ]
                          ),
                          _vm._v("\n\t\t\t\t\t\t\t\t\t/\n                  "),
                          _c(
                            "a",
                            {
                              attrs: { href: "#" },
                              on: {
                                click: function($event) {
                                  return _vm.editModal(vehicle)
                                }
                              }
                            },
                            [_c("i", { staticClass: "fa fa-edit" })]
                          ),
                          _vm._v("\n                  /\n                  "),
                          _c(
                            "a",
                            {
                              attrs: { href: "#" },
                              on: {
                                click: function($event) {
                                  return _vm.deleteModal(vehicle.MVID)
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-trash",
                                staticStyle: { color: "red" }
                              })
                            ]
                          )
                        ])
                      ])
                    })
                  ],
                  2
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" })
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-dialog-centered",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New OVL Vehicle")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update OVL Vehicle's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(2)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    attrs: { id: "sweget" },
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode ? _vm.updateVehicle() : _vm.createVehicle()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "form-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.PlateNumber,
                                expression: "form.PlateNumber"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "text",
                              name: "PlateNumber",
                              placeholder: "Plate Number",
                              required: ""
                            },
                            domProps: { value: _vm.form.PlateNumber },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "PlateNumber",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.EngineNumber,
                                expression: "form.EngineNumber"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "text",
                              name: "EngineNumber",
                              placeholder: "Engine Number"
                            },
                            domProps: { value: _vm.form.EngineNumber },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "EngineNumber",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.SerialNumber,
                                expression: "form.SerialNumber"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "text",
                              name: "SerialNumber",
                              placeholder: "Serial Number"
                            },
                            domProps: { value: _vm.form.SerialNumber },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "SerialNumber",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.AssetNumber,
                                expression: "form.AssetNumber"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "text",
                              name: "AssetNumber",
                              placeholder: "Asset Number"
                            },
                            domProps: { value: _vm.form.AssetNumber },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "AssetNumber",
                                  $event.target.value
                                )
                              }
                            }
                          })
                        ]),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c(
                              "b-input-group",
                              { staticClass: "mt-3" },
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DriverName,
                                      expression: "form.DriverName"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "DriverName",
                                    placeholder: "Driver Name",
                                    required: "",
                                    "data-readonly": ""
                                  },
                                  domProps: { value: _vm.form.DriverName },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DriverName",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DriverID,
                                      expression: "form.DriverID"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "hidden",
                                    name: "DriverID",
                                    placeholder: "DriverID"
                                  },
                                  domProps: { value: _vm.form.DriverID },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DriverID",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DriverLastName,
                                      expression: "form.DriverLastName"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "hidden",
                                    name: "DriverLastName",
                                    placeholder: "DriverLastName"
                                  },
                                  domProps: { value: _vm.form.DriverLastName },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DriverLastName",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DriverFirstName,
                                      expression: "form.DriverFirstName"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "hidden",
                                    name: "DriverFirstName",
                                    placeholder: "DriverFirstName"
                                  },
                                  domProps: { value: _vm.form.DriverFirstName },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DriverFirstName",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DriverMiddleName,
                                      expression: "form.DriverMiddleName"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "hidden",
                                    name: "DriverMiddleName",
                                    placeholder: "DriverMiddleName"
                                  },
                                  domProps: {
                                    value: _vm.form.DriverMiddleName
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DriverMiddleName",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.DriverExtName,
                                      expression: "form.DriverExtName"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "hidden",
                                    name: "DriverExtName",
                                    placeholder: "DriverExtName"
                                  },
                                  domProps: { value: _vm.form.DriverExtName },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "DriverExtName",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "b-input-group-append",
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.searchDriverFunction()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-search",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c(
                              "b-input-group",
                              { staticClass: "mt-3" },
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.MVTID_Link,
                                      expression: "form.MVTID_Link"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "hidden", name: "MVTID_Link" },
                                  domProps: { value: _vm.form.MVTID_Link },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "MVTID_Link",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.MVTypeName,
                                      expression: "form.MVTypeName"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "Type",
                                    placeholder: "Vehicle Type",
                                    "data-readonly": ""
                                  },
                                  domProps: { value: _vm.form.MVTypeName },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "MVTypeName",
                                        $event.target.value
                                      )
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "b-input-group-append",
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.searchVehicleTypeFunction()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-search",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c("div", { staticClass: "form-group" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.form.IsGSCUnit,
                                expression: "form.IsGSCUnit"
                              }
                            ],
                            staticClass: "form-control",
                            staticStyle: { "text-transform": "uppercase" },
                            attrs: {
                              type: "text",
                              name: "Type",
                              placeholder: "Is GSC Unit? Y/N",
                              maxlength: "1",
                              required: ""
                            },
                            domProps: { value: _vm.form.IsGSCUnit },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.form,
                                  "IsGSCUnit",
                                  $event.target.value
                                )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                              }
                              _vm.$set(
                                _vm.form,
                                "period_covered",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Address")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.billed_address,
                              expression: "form.billed_address"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: {
                            type: "text",
                            name: "billed_address",
                            disabled: ""
                          },
                          domProps: { value: _vm.form.billed_address },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "billed_address",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Charge Invoice")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.charge_invoice_no,
                              expression: "form.charge_invoice_no"
                            }
                          ],
<<<<<<< HEAD
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "charge_invoice_no" },
                          domProps: { value: _vm.form.charge_invoice_no },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "charge_invoice_no",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "date" } }, [
                          _vm._v("Remarks")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.remarks,
                              expression: "form.remarks"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "remarks" },
                          domProps: { value: _vm.form.remarks },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "remarks", $event.target.value)
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("label", { attrs: { for: "refence" } }, [
                          _vm._v("Details")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.details,
                              expression: "form.details"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "text", name: "details" },
                          domProps: { value: _vm.form.details },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.form, "details", $event.target.value)
                            }
                          }
                        })
                      ])
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "modal-footer" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-primary",
                        attrs: { type: "submit" }
                      },
                      [_vm._v("Create")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-secondary",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            return _vm.print_soa()
                          }
                        }
                      },
                      [_vm._v("PRINT")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-danger",
                        attrs: { type: "button", "data-dismiss": "modal" }
                      },
                      [_vm._v("Close")]
                    )
                  ])
                ]
              )
            ])
          ])
        ])
      ]
    )
  ])
}
var staticRenderFns = [
=======
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "rateModal",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-dialog-centered",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Vehicle Rate")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Vehicle Rate's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(3)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.updateVehicleRate()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body" }, [
                      _c("div", { staticClass: "form-inline" }, [
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: {
                              "margin-left": "5px",
                              "text-transform": "uppercase"
                            }
                          },
                          [
                            _vm._m(4),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.rate.MVID_Link,
                                  expression: "rate.MVID_Link"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "hidden",
                                name: "MVID_Link",
                                placeholder: "MVID Link"
                              },
                              domProps: { value: _vm.rate.MVID_Link },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.rate,
                                    "MVID_Link",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.rate.PlateNumber,
                                  expression: "rate.PlateNumber"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "PlateNumber",
                                placeholder: "Plate Number",
                                "data-readonly": "",
                                required: ""
                              },
                              domProps: { value: _vm.rate.PlateNumber },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.rate,
                                    "PlateNumber",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        )
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-inline" }, [
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: { "margin-left": "5px" }
                          },
                          [
                            _vm._m(5),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.rate.EffectiveDate,
                                  expression: "rate.EffectiveDate"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "date",
                                placeholder: "Effective Date",
                                required: ""
                              },
                              domProps: { value: _vm.rate.EffectiveDate },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.rate,
                                    "EffectiveDate",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        )
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-inline" }, [
                        _c(
                          "div",
                          {
                            staticClass: "input-group mb-3 input-group-sm",
                            staticStyle: { "margin-left": "5px" }
                          },
                          [
                            _vm._m(6),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.rate.PerHourRate,
                                  expression: "rate.PerHourRate"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "decimal",
                                placeholder: "Per Hour Rate"
                              },
                              domProps: { value: _vm.rate.PerHourRate },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.rate,
                                    "PerHourRate",
                                    $event.target.value
                                  )
                                }
                              }
                            })
                          ]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-driver", {
        on: {
          changeTitle: function($event) {
            return _vm.updateTitle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-operator", {
        on: {
          changeTitleOperator: function($event) {
            return _vm.updateTitleOperator($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-vehicletype", {
        on: {
          changeTitleVehicleType: function($event) {
            return _vm.updateTitleVehicleType($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("OVL Vehicle List")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", [_vm._v("Plate Number")]),
      _vm._v(" "),
      _c("th", [_vm._v("Driver Name")]),
      _vm._v(" "),
      _c("th", [_vm._v("Engine")]),
      _vm._v(" "),
      _c("th", [_vm._v("Serial Number")]),
      _vm._v(" "),
      _c("th", [_vm._v("Modify")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Create Liftruck SOA")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
=======
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Plate Number")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("EffectiveDate")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Per Hour Rate")])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& ***!
  \*******************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e& ***!
  \**************************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
<<<<<<< HEAD
          id: "reviewSOA",
=======
          id: "searchVehicleType",
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
<<<<<<< HEAD
          _c(
            "div",
            { staticClass: "modal-content" },
            [
              _vm._m(0),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c(
                  "div",
                  { staticClass: "container" },
                  [
                    _c("div", { staticClass: "row mt-3" }, [
                      _vm._v(
                        "\n              Search by SOA Date\n              "
                      ),
                      _c("div", { staticClass: "col" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.datefrom,
                              expression: "datefrom"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.datefrom },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.datefrom = $event.target.value
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.dateto,
                              expression: "dateto"
                            }
                          ],
                          staticClass: "form-control form-control-sm mb-2",
                          attrs: {
                            type: "date",
                            placeholder: "Search Rental..."
                          },
                          domProps: { value: _vm.dateto },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.dateto = $event.target.value
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-secondary",
                            on: {
                              click: function($event) {
                                return _vm.review()
                              }
                            }
                          },
                          [_vm._v("Review")]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "kendo-grid",
                      {
                        attrs: {
                          height: 200,
                          "data-source": _vm.filter,
                          selectable: true,
                          sortable: true
                        },
                        on: { change: _vm.onChange }
                      },
                      [
                        _c("kendo-grid-column", {
                          attrs: { field: "soa_date", title: "SOA Date" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "series_no", title: "SOA No" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "billed_name", title: "Billed To" }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: {
                            field: "charge_invoice_no",
                            title: "Charge Invoice No"
                          }
                        }),
                        _vm._v(" "),
                        _c("kendo-grid-column", {
                          attrs: { field: "status", title: "Status" }
                        })
                      ],
                      1
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _vm.showButton
                ? _c("div", { staticClass: "container" }, [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col" }, [
                        _c("p", [_vm._v("SOA: " + _vm._s(_vm.soa_no))]),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.soa_detail()
                              }
                            }
                          },
                          [_vm._v("View Detail")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.cancel_soa(_vm.id)
                              }
                            }
                          },
                          [_vm._v("Cancel SOA")]
                        ),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary",
                            attrs: { type: "button" },
                            on: {
                              click: function($event) {
                                return _vm.view_soa()
                              }
                            }
                          },
                          [_vm._v("Preview SOA Form")]
                        )
                      ])
                    ])
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.showDetail
                ? _c("div", { staticClass: "container" }, [
                    _c(
                      "div",
                      { staticClass: "row" },
                      [
                        _c(
                          "kendo-grid",
                          {
                            attrs: {
                              height: 150,
                              "data-source": _vm.detail,
                              selectable: true,
                              sortable: true
                            }
                          },
                          [
                            _c("kendo-grid-column", {
                              attrs: { field: "req_date", title: "Date" }
                            }),
                            _vm._v(" "),
                            _c("kendo-grid-column", {
                              attrs: {
                                field: "particulars",
                                title: "Particulars"
                              }
                            }),
                            _vm._v(" "),
                            _c("kendo-grid-column", {
                              attrs: { field: "amount", title: "Amount" }
                            })
                          ],
                          1
=======
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("form", [
              _c("div", { staticClass: "modal-body" }, [
                _c("div", { staticClass: "card-body" }, [
                  _c("div", { staticClass: "row" }, [
                    _c(
                      "div",
                      { staticClass: "col-lg-6" },
                      [
                        _c(
                          "b-input-group",
                          { staticClass: "mt-3", attrs: { size: "sm" } },
                          [
                            _c("b-form-input", {
                              ref: "autofocus",
                              attrs: { placeholder: "Search for..." },
                              on: { keyup: _vm.searchVehiType },
                              model: {
                                value: _vm.searchVehicleTypeVar,
                                callback: function($$v) {
                                  _vm.searchVehicleTypeVar = $$v
                                },
                                expression: "searchVehicleTypeVar"
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "b-input-group-append",
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      variant: "outline-success",
                                      size: "sm"
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-search",
                                      attrs: { "aria-hidden": "true" }
                                    })
                                  ]
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "card-body table-responsive pre-scrollable"
                    },
                    [
                      _c("table", { staticClass: "table table-hover" }, [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.vehicletypes.data, function(vt) {
                            return _c(
                              "tr",
                              {
                                key: vt.MVTID,
                                staticClass: "hover-green",
                                staticStyle: { cursor: "pointer" },
                                attrs: { id: "element" },
                                on: {
                                  click: function($event) {
                                    return _vm.changeTitleVehicleType(vt)
                                  }
                                }
                              },
                              [
                                _c("td", [_vm._v(_vm._s(vt.MVTID))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(vt.MVType))])
                              ]
                            )
                          }),
                          0
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        )
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  !_vm.vehicletypes.data
                    ? _c(
                        "div",
                        {
                          staticClass: "alert alert-default",
                          attrs: { role: "alert" }
                        },
                        [
                          _vm._v(
                            "\n                        No Data\n                    "
                          )
                        ]
                      )
                    : _vm._e()
                ])
              ]),
              _vm._v(" "),
<<<<<<< HEAD
              _vm._m(1)
            ],
            1
          )
=======
              _vm._m(2)
            ])
          ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
        ])
      ]
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header" }, [
<<<<<<< HEAD
      _c("h4", { staticClass: "modal-title" }, [_vm._v("SOA Review")]),
=======
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Search Vehicle Type")]),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "modal-footer" }, [
=======
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("ID")]),
        _vm._v(" "),
        _c("th", [_vm._v("Motor Vehicle Type Name")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-footer " }, [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      _c(
        "button",
        {
          staticClass: "btn btn-default",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [_c("i", { staticClass: "far fa-window-close" }), _vm._v(" Close")]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c("div", { staticClass: "row" }, [
      _c(
        "nav",
        { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
        [
          _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
            _vm._v("LIFT TRUCK SECTION")
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNav" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-list"
                        }
                      },
                      [_vm._v("Lift Truck List")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-location"
                        }
                      },
                      [_vm._v("Route")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-po"
                        }
                      },
                      [_vm._v("Purchase Order")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-rental"
                        }
                      },
                      [_vm._v("Rental")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-soa"
                        }
                      },
                      [_vm._v("Create SOA")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-payment"
                        }
                      },
                      [_vm._v("Payment Collection")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-ledger"
                        }
                      },
                      [_vm._v("Ledger")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/liftruck-reports"
                        }
                      },
                      [_vm._v("Reports")]
                    )
                  ],
                  1
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { attrs: { id: "dmpi" } }, [
        _c("div", { staticClass: "row mt-3" }, [
          _vm._v("\n        Search by Trans Date\n        "),
          _c("div", { staticClass: "col" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.datefrom,
                  expression: "datefrom"
                }
              ],
              staticClass: "form-control form-control-sm mb-2",
              attrs: { type: "date", placeholder: "Search Rental..." },
              domProps: { value: _vm.datefrom },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.datefrom = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.dateto,
                  expression: "dateto"
                }
              ],
              staticClass: "form-control form-control-sm mb-2",
              attrs: { type: "date", placeholder: "Search Rental..." },
              domProps: { value: _vm.dateto },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.dateto = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                on: {
                  click: function($event) {
                    return _vm.preview()
                  }
                }
              },
              [_vm._v("Preview")]
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row mt-3" }, [
          _c(
            "div",
            { staticClass: "col-sm" },
            [
              _c("ag-grid-vue", {
                staticClass: "ag-theme-balham",
                staticStyle: { width: "1050px", height: "200px" },
                attrs: {
                  columnDefs: _vm.columnDefs,
                  rowData: _vm.filter,
                  rowSelection: "multiple"
                },
                on: {
                  "grid-ready": _vm.onGridReady,
                  selectionChanged: _vm.onChange
                }
              }),
              _vm._v(" "),
              _c("create-soa", { attrs: { rental: _vm.selected } }),
              _vm._v(" "),
              _c("review-soa")
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: { type: "submit" },
                on: {
                  click: function($event) {
                    return _vm.create_soa()
                  }
                }
              },
              [_vm._v("Create SOA")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-success",
                attrs: { type: "submit" },
                on: {
                  click: function($event) {
                    return _vm.review_soa()
                  }
                }
              },
              [_vm._v("Manage SOA")]
            ),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "btn btn-success", attrs: { type: "submit" } },
              [_vm._v("Print Charge Invoice")]
            ),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "btn btn-success", attrs: { type: "submit" } },
              [_vm._v("Print Delivery")]
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true

=======
/***/ "./resources/js/components/OVLComponents/OVL.png":
/*!*******************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVL.png ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

module.exports = "/images/OVL.png?70ca35f6f16b7d8ea732077eeaa11d02";

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue":
/*!***************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Req.vue ***!
  \***************************************************************/
=======
/***/ "./resources/js/components/OVLComponents/OVLMenu.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLMenu.vue ***!
  \***********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& */ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&");
/* harmony import */ var _Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA-Req.vue?vue&type=script&lang=js& */ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");


=======
/* harmony import */ var _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLMenu.vue?vue&type=template&id=321a0b35& */ "./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

var script = {}


/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/liftruck/Liftruck-SOA-Req.vue"
=======
component.options.__file = "resources/js/components/OVLComponents/OVLMenu.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Req.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& ***!
  \**********************************************************************************************/
=======
/***/ "./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Req.vue?vue&type=template&id=155902c6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Req.vue?vue&type=template&id=155902c6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Req_vue_vue_type_template_id_155902c6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLMenu.vue?vue&type=template&id=321a0b35& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue":
/*!******************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Review.vue ***!
=======
/***/ "./resources/js/components/OVLComponents/OVLVehicleList.vue":
/*!******************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleList.vue ***!
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& */ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&");
/* harmony import */ var _Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA-Review.vue?vue&type=script&lang=js& */ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _OVLVehicleList_vue_vue_type_template_id_464421f8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLVehicleList.vue?vue&type=template&id=464421f8& */ "./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=template&id=464421f8&");
/* harmony import */ var _OVLVehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OVLVehicleList.vue?vue&type=script&lang=js& */ "./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OVLVehicleList.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OVLVehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OVLVehicleList_vue_vue_type_template_id_464421f8___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OVLVehicleList_vue_vue_type_template_id_464421f8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/liftruck/Liftruck-SOA-Review.vue"
=======
component.options.__file = "resources/js/components/OVLComponents/OVLVehicleList.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js& ***!
=======
/***/ "./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=script&lang=js& ***!
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Review.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&":
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleList.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=template&id=464421f8&":
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA-Review.vue?vue&type=template&id=0a5983ae&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_Review_vue_vue_type_template_id_0a5983ae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_template_id_464421f8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleList.vue?vue&type=template&id=464421f8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleList.vue?vue&type=template&id=464421f8&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_template_id_464421f8___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleList_vue_vue_type_template_id_464421f8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/liftruck/Liftruck-SOA.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA.vue ***!
  \***********************************************************/
=======
/***/ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/components/search/SearchJeep/SearchVehicleType.vue ***!
  \*************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Liftruck-SOA.vue?vue&type=template&id=f2b2d828& */ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&");
/* harmony import */ var _Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Liftruck-SOA.vue?vue&type=script&lang=js& */ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
/* harmony import */ var _SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchVehicleType.vue?vue&type=template&id=d79c782e& */ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&");
/* harmony import */ var _SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SearchVehicleType.vue?vue&type=script&lang=js& */ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/liftruck/Liftruck-SOA.vue"
=======
component.options.__file = "resources/js/components/search/SearchJeep/SearchVehicleType.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
=======
/***/ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828& ***!
  \******************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchVehicleType.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e& ***!
  \********************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Liftruck-SOA.vue?vue&type=template&id=f2b2d828& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/liftruck/Liftruck-SOA.vue?vue&type=template&id=f2b2d828&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Liftruck_SOA_vue_vue_type_template_id_f2b2d828___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SearchVehicleType.vue?vue&type=template&id=d79c782e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/search/SearchJeep/SearchVehicleType.vue?vue&type=template&id=d79c782e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SearchVehicleType_vue_vue_type_template_id_d79c782e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);