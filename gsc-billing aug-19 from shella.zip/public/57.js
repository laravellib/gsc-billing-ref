(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[57],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _WingVan_PO_Search_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-PO-Search.vue */ "./resources/js/components/wingvan/WingVan-PO-Search.vue");
//
//
//
//
//
=======
/* harmony import */ var _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchJeep/SearchDriver.vue */ "./resources/js/components/search/SearchJeep/SearchDriver.vue");
/* harmony import */ var _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/SearchJeep/SearchOperator.vue */ "./resources/js/components/search/SearchJeep/SearchOperator.vue");
/* harmony import */ var _search_SearchOVL_SearchOVLVehicle_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchOVL/SearchOVLVehicle.vue */ "./resources/js/components/search/SearchOVL/SearchOVLVehicle.vue");
/* harmony import */ var _search_SearchJeep_SearchClient_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../search/SearchJeep/SearchClient.vue */ "./resources/js/components/search/SearchJeep/SearchClient.vue");
/* harmony import */ var _OVLMenu_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./OVLMenu.vue */ "./resources/js/components/OVLComponents/OVLMenu.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_6__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "search-header": _WingVan_PO_Search_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      reference_no: "",
      header_id: "",
      filter: {},
      balance: {}
    };
  },
  methods: {
    searchReference: function searchReference() {
      $("#searchWPO").modal("show");
    },
    get_header: function get_header(data) {
      this.header_id = data.id;
      this.reference_no = data.doc_no;
      this.get_detail();
    },
    get_detail: function get_detail() {
      var _this = this;

      axios.get("wingvan/dtl/" + this.header_id).then(function (_ref) {
        var data = _ref.data;
        _this.filter = data.data;
      });
    },
    onChange: function onChange(e) {
      var element = e.sender.select();
      var dataItem = e.sender.dataItem(element[0]);
      this.get_balance(dataItem.id);
    },
    get_balance: function get_balance(id) {
      var _this2 = this;

      axios.get("wingvan/ledger/" + id).then(function (_ref2) {
        var data = _ref2.data;
        _this2.balance = data.data;
      });
    }
  },
  created: function created() {}
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD
/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
      searching: "",
      golfcart: null,
      filter: null,
      datas: [],
      gridApi: null,
      columnApi: null,
      columnDefs: null
    };
  },
  methods: {
    loadMode: function loadMode() {
      var _this = this;

      this.columnDefs = [{
        headerName: "Doc #",
        field: "doc_no",
        sortable: true,
        filter: true,
        resizable: true,
        width: 225
      }, {
        headerName: "Date",
        field: "date",
        resizable: true,
        width: 225
      }, {
        headerName: "Status",
        field: "status",
        resizable: true,
        width: 225
      }];
      axios.get("wingvan/hdr").then(function (_ref) {
        var data = _ref.data;
        _this.golfcart = data.data;
        _this.filter = _this.golfcart;
        console.log(_this.filter);
      });
    },
    search: function search(ev) {
      this.filter = this.golfcart.filter(function (item) {
        return item.name.match(ev);
      });
    },
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    onChange: function onChange(e) {
      var selectedRows = this.gridApi.getSelectedNodes();
      this.$emit("data_pass", selectedRows[0].data);
      $("#searchWPO").modal("hide");
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.loadMode();
    Fire.$on("AfterCreate", function () {
      _this2.loadMode();
    });
  },
  created: function created() {}
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340& ***!
  \*************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c("div", { staticClass: "row" }, [
      _c(
        "nav",
        { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
        [
          _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
            _vm._v("WING VAN SECTION")
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNav" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-list"
                        }
                      },
                      [_vm._v("Wing Van List")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-location"
                        }
                      },
                      [_vm._v("Route")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-po"
                        }
                      },
                      [_vm._v("Purchase Order")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-rental"
                        }
                      },
                      [_vm._v("Rental")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-soa"
                        }
                      },
                      [_vm._v("Create SOA")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-payment"
                        }
                      },
                      [_vm._v("Payment Collection")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-ledger"
                        }
                      },
                      [_vm._v("Ledger")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-reports"
                        }
                      },
                      [_vm._v("Reports")]
                    )
                  ],
                  1
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "container" },
        [
          _c("div", { staticClass: "row mt-3" }, [
            _c("div", { staticClass: "col-sm-6" }, [
              _c("label", { attrs: { for: "refence" } }, [
                _vm._v("Reference #")
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "input-group" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.reference_no,
                      expression: "reference_no"
                    }
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { type: "text", name: "reference_no", disabled: "" },
                  domProps: { value: _vm.reference_no },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.reference_no = $event.target.value
                    }
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "input-group-btn" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-outline-primary btn-sm",
                      attrs: { type: "button" },
                      on: {
                        click: function($event) {
                          return _vm.searchReference()
                        }
                      }
                    },
                    [_vm._v("Search")]
                  )
                ])
              ])
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mt-6" }, [
            _c(
              "div",
              { staticClass: "col-7" },
              [
                _c(
                  "kendo-grid",
                  {
                    attrs: {
                      height: 350,
                      "data-source": _vm.filter,
                      selectable: true,
                      sortable: true
                    },
                    on: { change: _vm.onChange }
                  },
                  [
                    _c("kendo-grid-column", {
                      attrs: { field: "mat_code", title: "Mat Code" }
                    }),
                    _vm._v(" "),
                    _c("kendo-grid-column", {
                      attrs: { field: "location", title: "Location" }
                    }),
                    _vm._v(" "),
                    _c("kendo-grid-column", {
                      attrs: { field: "price_per_bag", title: "Price/Bag" }
                    })
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-4" },
              [
                _c(
                  "kendo-grid",
                  {
                    attrs: {
                      height: 350,
                      "data-source": _vm.balance,
                      selectable: true,
                      sortable: true
                    }
                  },
                  [
                    _c("kendo-grid-column", {
                      attrs: { field: "type", title: "Type" }
                    }),
                    _vm._v(" "),
                    _c("kendo-grid-column", {
                      attrs: { field: "qty", title: "Qty" }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ]),
          _vm._v(" "),
          _c("search-header", { on: { data_pass: _vm.get_header } })
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef& ***!
  \****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: {
          id: "searchWPO",
          tabindex: "-1",
          role: "dialog",
          "aria-labelledby": "addNewLabel",
          "aria-hidden": "true"
        }
      },
      [
        _c("div", { staticClass: "modal-dialog modal-lg" }, [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "modal-body" },
              [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.searching,
                      expression: "searching"
                    }
                  ],
                  staticClass: "form-control form-control-sm mb-2",
                  attrs: { type: "text", placeholder: "Search by Mode..." },
                  domProps: { value: _vm.searching },
                  on: {
                    keyup: function($event) {
                      return _vm.search(_vm.searching)
                    },
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.searching = $event.target.value
                    }
                  }
                }),
                _vm._v(" "),
                _c("ag-grid-vue", {
                  staticClass: "ag-theme-balham",
                  staticStyle: { width: "765px", height: "250px" },
                  attrs: {
                    columnDefs: _vm.columnDefs,
                    rowData: _vm.filter,
                    rowSelection: "single"
                  },
                  on: {
                    "grid-ready": _vm.onGridReady,
                    rowClicked: _vm.onChange
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _vm._m(1)
          ])
        ])
      ]
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header" }, [
      _c("h4", { staticClass: "modal-title" }, [_vm._v("Search PO")]),
      _vm._v(" "),
      _c(
        "button",
        {
          staticClass: "close",
          attrs: {
            type: "button",
            "data-dismiss": "modal",
            "aria-label": "Close"
          }
        },
        [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-footer" }, [
      _c(
        "button",
        {
          staticClass: "btn btn-danger",
          attrs: { type: "button", "data-dismiss": "modal" }
        },
        [
          _c("i", { staticClass: "far fa-window-close" }),
          _vm._v(" Close\n          ")
        ]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Ledger.vue":
/*!************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Ledger.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Ledger.vue?vue&type=template&id=01d04340& */ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&");
/* harmony import */ var _WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-Ledger.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






 // import {AgGridVue} from "@ag-grid-community/vue";
// import {AllCommunityModules} from '@ag-grid-community/all-modules';
// import "ag-grid-community/dist/styles/ag-grid.css";
// import "ag-grid-community/dist/styles/ag-theme-balham.css";

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-driver': _search_SearchJeep_SearchDriver_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'search-operator': _search_SearchJeep_SearchOperator_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-ovlvehicle': _search_SearchOVL_SearchOVLVehicle_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    'search-client': _search_SearchJeep_SearchClient_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    'ovl-menu': _OVLMenu_vue__WEBPACK_IMPORTED_MODULE_4__["default"] // AgGridVue

  },
  data: function data() {
    var _ref;

    return {
      // columnDefs: null,
      // rowData: null,
      // gridApi: null,
      // columnApi: null,
      // modules: AllCommunityModules,
      OVLDTLDetails: [],
      checkedNames: [],
      filteredblogs: [],
      csoatotals: [],
      checkedNamesFilter: [],
      editmode: false,
      equalequal: false,
      allSelected: false,
      jvls: [],
      jvlsobject: {},
      search: '',
      jvcps: {},
      drivers: [],
      vehicles: {},
      rates: {},
      operators: {},
      batch: [],
      jvlfilter: [],
      jvlbalamt: [],
      var1: '',
      var2: '',
      first: '',
      second: '',
      eq: 'true',
      truevalue: '',
      falsevalue: '',
      SearchOVLPlateNo: '',
      DateFrom: '',
      DateTo: '',
      JeepVehicleCollectionPayments: {},
      form: new Form({
        OVLVLHDRID: '',
        OVLVLHDRIDFilter: '',
        OVLVLDate: '',
        OVLNo: '',
        OVLIDLink: '',
        OVLPlateNo: '',
        DriverIDLink: '',
        DriverLastName: '',
        DriverFirstName: '',
        DriverMiddleName: '',
        DriverExtName: '',
        TruckerIDLink: '',
        TruckerLastName: '',
        TruckerFirstName: '',
        TruckerMiddleName: '',
        TruckerExtName: '',
        BillAmount: '',
        LessAdmin: '',
        LessFuel: '',
        NetTrucker: '',
        Status: '',
        SOANumber: '',
        SOADate: '',
        ChargeInvoiceNumber: '',
        GLCode: '',
        CostCenter: '',
        PerHourRate: '',
        NumberofDays: '',
        NumberOfHours: '',
        DriverName: '',
        TruckerName: '',
        CollectedAmount: '',
        CollectedAmountHDR: '',
        BalanceAmountHDR: '',
        BalanceAmount: '',
        ORCRNumber: '',
        ORCRDate: '',
        Remarks: '',
        OVLVLHDRID_Link: '',
        TotalAmount: '',
        startreading: '',
        endreading: '',
        ClientName: '',
        ClientFirstName: '',
        ClientMiddleName: '',
        ClientLastName: '',
        ClientExtName: '',
        ClientIDLink: '',
        ModeOfPayment: '',
        MaintenanceCost: '',
        AmountExpense: '',
        Helper: '',
        Labor: '',
        TotalExpense: '',
        SubTotalExpense: '',
        FuelLiters: '',
        LocationFrom: '',
        LocationTo: '',
        FuelRate: ''
      }),
      view: new Form({
        ViewLessFuel: '',
        ViewBillAmount: '',
        ViewNetTrucker: '',
        ViewPerHourRate: '',
        ViewBalanceAmount: '',
        ViewMaintenanceCost: '',
        ViewTotalExpense: '',
        ViewSubTotalExpense: ''
      }),
      detail: new Form({
        LoadingAssignment: '',
        PHBVLHDRID_Link: '',
        // LoadingLocationName:"",
        LoadingFLDLOG: '',
        LoadingTimeIn: '',
        LoadingTimeStart: '',
        LoadingTimeEnd: '',
        LoadingRemarks: '',
        LoadingLoadFill: '',
        LoadingHiredOperatorHour: '',
        LoadingJobCode: '',
        LoadingNoOfLoad: '',
        // UnLoadingLocationName:"",
        UnLoadingAssignment: '',
        UnLoadingFLDLOG: '',
        UnLoadingTimeIn: '',
        UnLoadingTimeStart: '',
        UnLoadingTimeEnd: '',
        UnLoadingRemarks: '',
        UnLoadingLoadFill: '',
        UnLoadingHiredOperatorHour: '',
        UnLoadingJobCode: '',
        UnLoadingNoOfLoad: '',
        OVLVLHDRID_Link: '',
        OVLVLDTLID: ''
      }),
      paymentModes: [],
      payment: new Form((_ref = {
        PONo: '',
        ModeOfPayment: 'CASH',
        ServiceEntrySheet: '',
        RefNo: '',
        DocHeaderText: ''
      }, _defineProperty(_ref, "ServiceEntrySheet", ''), _defineProperty(_ref, "Amount", ''), _defineProperty(_ref, "CheckNumber", ''), _defineProperty(_ref, "CheckDate", new Date().toISOString().slice(0, 10)), _defineProperty(_ref, "CheckBank", ''), _defineProperty(_ref, "PaymentMode", ''), _defineProperty(_ref, "OVLVLHDRID_Link", ''), _defineProperty(_ref, "OVLVCDTLID", ''), _ref)),
      editPayment: false
    };
  },
  mounted: function mounted() {//this.$parent.getSearchDriver();
    //this.$parent.getSearchOperator();
  },
  methods: {
    refreshtotalsoa: function refreshtotalsoa() {
      var _this = this;

      this.form.TotalAmount = '';
      this.form.OVLVLHDRID = this.checkedNames.join();
      axios.get('/api/getcsoasum', {
        params: {
          OVLVLHDRID: this.form.OVLVLHDRID
        }
      }).then(function (_ref2) {
        var data = _ref2.data;
        _this.csoatotals = data;
        _this.form.TotalAmount = _this.csoatotals[0].BillAmount;
      })["catch"](function (err) {});
    },
    selectAll: function selectAll() {
      this.checkedNames = [];

      if (this.allSelected == false) {
        for (var user in this.filteredBlogs) {
          this.checkedNames.push(this.filteredBlogs[user].OVLVLHDRID);
        } // this.form.OVLVLHDRID = this.checkedNames.join();
        // // axios.get('/api/getphbcsoasum', {params: {OVLVLHDRID: this.form.OVLVLHDRID}})
        // // .then(({ data }) => {
        // //     this.csoatotals = data;
        // //     this.form.TotalAmount = this.csoatotals[0].BillAmount;
        // //     console.log(this.form.TotalAmount);
        // // })
        // // .catch((err)=>{
        // // })

      } else {
        this.form.TotalAmount = '';
      }
    },
    select: function select() {
      this.allSelected = false;
    },
    SearchDateFromTo: function SearchDateFromTo() {//return this.jvls.filter(jvl =>{
      //       return jvl.OVLVLDate.includes(this.form.DateFrom)
      //    });

      /*var vm = this;
                 var startdate = vm.form.DateFrom;
                 var enddate = vm.form.DateTo;
                 return _.filter(vm.jvls,(function(data){
                   if ((_.isNull(startdate) && _.isNull(enddate))){
                     return true
                   }
                   else{
                     var date = data.OVLVLDate;
                     return date.includes(date >= startdate && date <= enddate);
                     
                   }
                 }))*/
    },
    InsertDetails: function InsertDetails() {
      this.detail.reset();
      this.detail.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      this.loadOVLDTL();
      $('#addOVLDetails').modal('show');
    },
    SetToUnpaid: function SetToUnpaid() {
      if (this.form.Status == 'POSTED') {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Can not Set to Unpaid. The Status is still POSTED.'
        });
      } else {
        this.form.Status = 'POSTED';
        this.form.BalanceAmount = this.form.BillAmount;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
        this.form.CollectedAmount = 0;
        this.$Progress.start();
        this.form.put('api/ovlpaidtoposted/' + this.form.OVLVLHDRID); //$('#addNew').modal('hide');

        toast.fire({
          icon: 'success',
          title: 'Outsider Vehicle Log is back to Unpaid'
        });
        this.deleteEntirePaymentDetail();
        this.loadJVL();
        this.getJVLBalanceAmount();
        this.$Progress.finish();
        this.form.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      }
    },
    signalChangestartreading: function signalChangestartreading() {
      var totalreading = 0;

      if (this.form.NumberOfHours !== '') {
        // var startTime = moment(this.form.startreading, 'HH:mm:ss a');
        // var endTime = moment(this.form.endreading, 'HH:mm:ss a');
        // totalreading = endTime.diff(startTime, 'hours');
        totalreading = this.form.NumberOfHours;
        this.form.BillAmount = parseFloat(totalreading * this.form.PerHourRate).toFixed(2);
        this.form.MaintenanceCost = parseFloat(this.form.BillAmount * 0.1).toFixed(2);
        var semitotal = this.form.MaintenanceCost + this.form.LessFuel;
        this.form.NetTrucker = parseFloat(this.form.BillAmount - semitotal).toFixed(2);

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        this.view.ViewBillAmount = numeral(this.form.BillAmount).format('0,0.00');
        this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
        this.view.ViewMaintenanceCost = numeral(this.form.MaintenanceCost).format('0,0.00');
        this.form.NumberOfHours = totalreading;
        var tots = 0;
        var LessFuel = this.form.LessFuel ? this.form.LessFuel : 0;
        var MaintenanceCost = this.form.MaintenanceCost ? this.form.MaintenanceCost : 0;
        var LessAdmin = this.form.LessAdmin ? this.form.LessAdmin : 0;
        var Helper = this.form.Helper ? this.form.Helper : 0;
        var Labor = this.form.Labor ? this.form.Labor : 0;
        var BillAmount = this.form.BillAmount ? this.form.BillAmount : 0;
        tots = parseFloat(LessFuel) + parseFloat(MaintenanceCost) + parseFloat(LessAdmin) + parseFloat(Helper) + parseFloat(Labor);
        this.form.TotalExpense = tots;
        this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
        this.form.TotalExpense = tots;
        this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
        this.form.SubTotalExpense = parseFloat(BillAmount) - parseFloat(LessFuel) - parseFloat(MaintenanceCost) - parseFloat(LessAdmin);
        this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');

        if (this.eq == 'true') {
          this.form.BalanceAmount = this.form.BillAmount;
          this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
        }
      }
    },
    signalChangeLessFuel: function signalChangeLessFuel() {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      var tots = 0;
      this.form.LessAdmin = parseFloat(this.form.LessFuel * 0.1).toFixed(2);
      var tots = 0;
      var LessFuel = this.form.LessFuel ? this.form.LessFuel : 0;
      var MaintenanceCost = this.form.MaintenanceCost ? this.form.MaintenanceCost : 0;
      var LessAdmin = this.form.LessAdmin ? this.form.LessAdmin : 0;
      var Helper = this.form.Helper ? this.form.Helper : 0;
      var Labor = this.form.Labor ? this.form.Labor : 0;
      var BillAmount = this.form.BillAmount ? this.form.BillAmount : 0;
      tots = parseFloat(LessFuel) + parseFloat(MaintenanceCost) + parseFloat(LessAdmin) + parseFloat(Helper) + parseFloat(Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.NetTrucker = parseFloat(this.form.BillAmount) - parseFloat(tots);
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(BillAmount) - parseFloat(LessFuel) - parseFloat(MaintenanceCost) - parseFloat(LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');
    },
    signalChangeHelper: function signalChangeHelper() {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      var tots = 0;
      var tots = 0;
      var LessFuel = this.form.LessFuel ? this.form.LessFuel : 0;
      var MaintenanceCost = this.form.MaintenanceCost ? this.form.MaintenanceCost : 0;
      var LessAdmin = this.form.LessAdmin ? this.form.LessAdmin : 0;
      var Helper = this.form.Helper ? this.form.Helper : 0;
      var Labor = this.form.Labor ? this.form.Labor : 0;
      var BillAmount = this.form.BillAmount ? this.form.BillAmount : 0;
      tots = parseFloat(LessFuel) + parseFloat(MaintenanceCost) + parseFloat(LessAdmin) + parseFloat(Helper) + parseFloat(Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.NetTrucker = parseFloat(this.form.BillAmount) - parseFloat(tots);
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(BillAmount) - parseFloat(LessFuel) - parseFloat(MaintenanceCost) - parseFloat(LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');
    },
    signalChangeLabor: function signalChangeLabor() {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      var tots = 0;
      var tots = 0;
      var LessFuel = this.form.LessFuel ? this.form.LessFuel : 0;
      var MaintenanceCost = this.form.MaintenanceCost ? this.form.MaintenanceCost : 0;
      var LessAdmin = this.form.LessAdmin ? this.form.LessAdmin : 0;
      var Helper = this.form.Helper ? this.form.Helper : 0;
      var Labor = this.form.Labor ? this.form.Labor : 0;
      var BillAmount = this.form.BillAmount ? this.form.BillAmount : 0;
      tots = parseFloat(LessFuel) + parseFloat(MaintenanceCost) + parseFloat(LessAdmin) + parseFloat(Helper) + parseFloat(Labor);
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.NetTrucker = parseFloat(this.form.BillAmount) - parseFloat(tots);
      this.view.ViewNetTrucker = numeral(this.form.NetTrucker).format('0,0.00');
      this.form.TotalExpense = tots;
      this.view.ViewTotalExpense = numeral(tots).format('0,0.00');
      this.form.SubTotalExpense = parseFloat(BillAmount) - parseFloat(LessFuel) - parseFloat(MaintenanceCost) - parseFloat(LessAdmin);
      this.view.ViewSubTotalExpense = numeral(this.form.SubTotalExpense).format('0,0.00');
    },
    signalChangeCollectedAmount: function signalChangeCollectedAmount() {
      this.form.BalanceAmount = this.form.BalanceAmountHDR - this.payment.Amount;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');

      if (this.form.BalanceAmount == 0) {
        this.form.Status = 'PAID';
      } //this.form.CollectedAmount = this.form.CollectedAmountHDR;

    },
    updateTitleClient: function updateTitleClient(updatedTitleClient) {
      this.form.ClientName = updatedTitleClient.FullName;
      this.form.ClientIDLink = updatedTitleClient.id;
      this.form.ClientLastName = updatedTitleClient.LastName;
      this.form.ClientFirstName = updatedTitleClient.FirstName;
      this.form.ClientMiddleName = updatedTitleClient.MiddleName;
      this.form.ClientExtName = updatedTitleClient.ExtName;
    },
    updateTitle: function updateTitle(updatedTitle) {
      var LastName = updatedTitle.LastName ? updatedTitle.LastName + ' ' : "";
      var FirstName = updatedTitle.FirstName ? updatedTitle.FirstName + ' ' : "";
      var MiddleName = updatedTitle.MiddleName ? updatedTitle.MiddleName + ' ' : "";
      var ExtName = updatedTitle.ExtName ? updatedTitle.ExtName : "";
      this.form.DriverName = LastName + FirstName + MiddleName + ExtName;
      this.form.DriverIDLink = updatedTitle.id;
      this.form.DriverLastName = updatedTitle.LastName;
      this.form.DriverFirstName = updatedTitle.FirstName;
      this.form.DriverMiddleName = updatedTitle.MiddleName;
      this.form.DriverExtName = updatedTitle.ExtName; // console.log(updatedTitle);
    },
    updateTitleOperator: function updateTitleOperator(updatedTitleOperator) {
      this.form.TruckerName = updatedTitleOperator.LastName + ',' + updatedTitleOperator.FirstName + ' ' + updatedTitleOperator.MiddleName + ' ' + updatedTitleOperator.ExtName;
      this.form.TruckerIDLink = updatedTitleOperator.id;
      this.form.TruckerLastName = updatedTitleOperator.LastName;
      this.form.TruckerFirstName = updatedTitleOperator.FirstName;
      this.form.TruckerMiddleName = updatedTitleOperator.MiddleName;
      this.form.TruckerExtName = updatedTitleOperator.ExtName; // console.log(updatedTitle);
    },
    updateTitleVehicle: function updateTitleVehicle(updatedTitleVehicle) {
      if (this.eq == 'true') {
        this.form.OVLPlateNo = updatedTitleVehicle.PlateNumber;
        this.form.OVLIDLink = updatedTitleVehicle.MVID;
        this.form.TruckerName = updatedTitleVehicle.TruckerName;
        this.form.TruckerIDLink = updatedTitleVehicle.TruckerID;
        this.form.TruckerLastName = updatedTitleVehicle.TruckerLastName;
        this.form.TruckerFirstName = updatedTitleVehicle.TruckerFirstName;
        this.form.TruckerMiddleName = updatedTitleVehicle.TruckerMiddleName;
        this.form.TruckerExtName = updatedTitleVehicle.TruckerExtName;
        this.form.DriverName = updatedTitleVehicle.DriverName;
        this.form.DriverIDLink = updatedTitleVehicle.DriverID;
        this.form.DriverLastName = updatedTitleVehicle.DriverLastName;
        this.form.DriverFirstName = updatedTitleVehicle.DriverFirstName;
        this.form.DriverMiddleName = updatedTitleVehicle.DriverMiddleName;
        this.form.DriverExtName = updatedTitleVehicle.DriverExtName; // console.log(updatedTitle);

        this.getVehicleRate();
      } else {
        this.form.SearchOVLPlateNo = updatedTitleVehicle.PlateNumber;
      }
    },
    getVehicleRate: function getVehicleRate() {
      var _this2 = this;

      axios.get('/api/getovlvehiclerate', {
        params: {
          OVLIDLink: this.form.OVLIDLink
        }
      }).then(function (response) {
        _this2.batch = response.data;
        _this2.form.PerHourRate = _this2.batch[0].PerHourRate;

        var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

        _this2.view.ViewPerHourRate = numeral(_this2.form.PerHourRate).format('0,0.00');
      })["catch"](function (err) {});
    },
    getJVLFilter: function getJVLFilter() {
      var _this3 = this;

      axios.get('/api/getjvlfilter', {
        params: {
          OVLIDLink: this.form.OVLIDLink
        }
      }).then(function (response) {
        _this3.jvlfilter = response.data; //this.form.PerHourRate=this.jvlfilter[0].BillAmount;
      })["catch"](function (err) {});
    },
    getJVCP: function getJVCP() {
      var _this4 = this;

      axios.get('/api/getovcp', {
        params: {
          OVLVLHDRID_Link: this.form.OVLVLHDRID_Link
        }
      }).then(function (_ref3) {
        var data = _ref3.data;
        _this4.JeepVehicleCollectionPayments = data;
      })["catch"](function (err) {});
    },
    searchsearchVehicleFunction: function searchsearchVehicleFunction() {
      this.eq = 'false';
      $('#searchVehicle').modal('show');
    },
    searchVehicleFunction: function searchVehicleFunction() {
      $('#searchVehicle').modal('show');
    },
    getVehicleIsReal: function getVehicleIsReal() {
      var _this5 = this;

      axios.get('api/vehicle').then(function (_ref4) {
        var data = _ref4.data;
        return _this5.vehicles = data;
      });
    },
    searchOperatorFunction: function searchOperatorFunction() {
      $('#searchOperator').modal('show');
    },
    getOperatorIsReal: function getOperatorIsReal() {
      var _this6 = this;

      axios.get('api/operator').then(function (_ref5) {
        var data = _ref5.data;
        return _this6.operators = data;
      });
    },
    searchDriverFunction: function searchDriverFunction() {
      Fire.$emit('searchDriver', 'OVL');
    },
    getDriverIsReal: function getDriverIsReal() {
      var _this7 = this;

      axios.get('api/driver').then(function (_ref6) {
        var data = _ref6.data;
        return _this7.drivers = data;
      });
    },
    searchClientFunction: function searchClientFunction() {
      $('#searchClient').modal('show');
    },
    getResults: function getResults() {
      var _this8 = this;

      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      axios.get('api/jvl?page=' + page).then(function (response) {
        _this8.jeepvehiclelog = response.data;
      });
    },
    updateJVL: function updateJVL(OVLVLHDRID) {
      this.$Progress.start();
      this.form.put('api/ovl/' + this.form.OVLVLHDRID).then(function () {
        toast.fire({
          icon: 'success',
          title: 'Outsider Vehicle Log successfully updated'
        });
        $('#addNew').modal('hide');
      })["catch"](function (error) {
        toast.fire({
          icon: 'error',
          title: 'Something went wrong'
        });
      });
      this.$Progress.finish(); // if (this.form.CollectedAmount !== '') {
      // 	//KUNG HEADER RA ANG GI UPDATE
      // 	this.form.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      // 	this.createJVCP();
      // }

      this.loadJVL();
    },
    deleteModal: function deleteModal(OVLVLHDRID) {
      var _this9 = this;

      swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(function (result) {
        if (result.value) {
          _this9.$Progress.start();

          _this9.form["delete"]('api/phbvl/' + OVLVLHDRID);

          swal.fire('Deleted!', 'Your file has been deleted.', 'success');
          _this9.form.OVLVLHDRID_Link = OVLVLHDRID;
          axios.get('/api/deletephbvcpdtl', {
            params: {
              OVLVLHDRID_Link: _this9.form.OVLVLHDRID_Link
            }
          }).then(function (_ref7) {
            var data = _ref7.data;
          })["catch"](function (err) {});

          _this9.$Progress.finish();

          _this9.loadJVL();
        }
      });
    },
    deleteModalJVCP: function deleteModalJVCP(jvcp) {
      var _this10 = this;

      if (this.form.BalanceAmount == 0 && this.form.Status == 'PAID') {
        swal.fire({
          title: 'Ooopsie Doopsieee',
          text: 'The transaction is already PAID.',
          icon: 'error',
          showCancelButton: true,
          showConfirmButton: false,
          cancelButtonColor: '#d33'
        }).then(function (result) {
          if (result.value) {}
        });
      } else {
        swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then(function (result) {
          if (result.value) {
            _this10.form.Status = 'PAID';
            _this10.form.BalanceAmount = _this10.form.BalanceAmount + jvcp.CollectedAmount;

            var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

            _this10.view.ViewBalanceAmount = numeral(_this10.form.BalanceAmount).format('0,0.00');
            var collectedamount = _this10.form.BillAmount - _this10.form.BalanceAmount;
            _this10.form.CollectedAmount = collectedamount;
            console.log('Bill Amount Before Delete:' + _this10.form.BillAmount);
            console.log('Balance Amount Before Delete:' + _this10.form.BalanceAmount);
            console.log('Selected Payment Detail Collected Amount Before Delete:' + jvcp.CollectedAmount);
            console.log('Value of Collected Amount Variable' + _this10.form.CollectedAmount);
            _this10.form.ORCRNumber = jvcp.ORCRNumber;
            _this10.form.ORCRDate = jvcp.ORCRDate;
            _this10.form.Remarks = jvcp.Remarks;

            _this10.$Progress.start(); //UPDATE FIRST


            _this10.form.put('api/ovl/' + _this10.form.OVLVLHDRID); //$('#addNew').modal('hide');


            _this10.loadJVL();

            _this10.form.OVLVLHDRID_Link = _this10.form.OVLVLHDRID; //END UPDATE

            _this10.form["delete"]('api/ovcp/' + jvcp.OVLVCDTLID);

            swal.fire('Deleted!', 'Your file has been deleted.', 'success');

            _this10.getJVCP();

            _this10.getJVLBalanceAmount();

            _this10.$Progress.finish();

            _this10.form.OVLVLHDRID_Link = jvcp.OVLVLHDRID_Link;
            _this10.form.CollectedAmount = '';
            _this10.form.ORCRNumber = '';
            _this10.form.ORCRDate = '';
            _this10.form.Remarks = '';
          }
        });
      }
    },
    editModal: function editModal(jvl) {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.form.OVLVLHDRID_Link = jvl.OVLVLHDRID; // this.getJVCP();

      this.editmode = true;
      this.form.reset();
      this.form.fill(jvl);
      console.log(jvl.FuelRate);
      this.view.ViewBillAmount = numeral(jvl.BillAmount).format('0,0.00');
      this.view.ViewNetTrucker = numeral(jvl.NetTrucker).format('0,0.00');
      this.view.ViewLessAdmin = numeral(jvl.LessAdmin).format('0,0.00');
      this.view.ViewPerHourRate = numeral(jvl.PerHourRate).format('0,0.00');
      this.view.ViewMaintenanceCost = numeral(jvl.MaintenanceCost).format('0,0.00');
      this.view.ViewSubTotalExpense = numeral(jvl.SubTotalExpense).format('0,0.00');
      this.view.ViewTotalExpense = numeral(jvl.TotalExpense).format('0,0.00');
      this.view.ViewBalanceAmount = numeral(this.form.BalanceAmount).format('0,0.00');
      this.form.BalanceAmount = jvl.BalanceAmount;
      this.form.BalanceAmountHDR = jvl.BalanceAmount;
      $('#addNew').modal('show');
    },
    addPayment: function addPayment(jvl) {
      var _this11 = this;

      this.form.reset();
      this.form.fill(jvl);
      this.form.BalanceAmountHDR = jvl.BalanceAmount;
      this.payment.OVLVLHDRID_Link = jvl.OVLVLHDRID;

      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.editPayment = false;
      axios.get('/api/getovcp', {
        params: {
          OVLVLHDRID_Link: jvl.OVLVLHDRID
        }
      }).then(function (_ref8) {
        var data = _ref8.data;

        if (data.length > 0) {
          _this11.payment.reset();

          _this11.payment.fill(data[0]);

          _this11.view.ViewBalanceAmount = numeral(_this11.form.BalanceAmountHDR - _this11.payment.Amount).format('0,0.00');
          _this11.editPayment = true;
        } else {
          _this11.view.ViewBalanceAmount = numeral(_this11.form.BalanceAmount).format('0,0.00');
        }
      })["catch"](function (err) {});
      $('#addNewMultiple').modal('show');
    },
    createPayment: function createPayment() {
      if (this.payment.BalanceAmount < 0) {
        return swal.fire({
          icon: 'success',
          title: 'Successfully Created'
        });
      }

      this.payment.post('api/ovcp').then(function (response) {
        swal.fire({
          icon: 'success',
          title: 'Successfully Created'
        });
        $('#addNewMultiple').modal('hide');
      })["catch"](function (error) {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong'
        });
      });
    },
    updatePayment: function updatePayment() {
      if (this.payment.BalanceAmount < 0) {
        return swal.fire({
          icon: 'success',
          title: 'Successfully Updated'
        });
      }

      this.payment.put('api/ovcp/' + this.payment.OVLVCDTLID).then(function (response) {
        swal.fire({
          icon: 'success',
          title: 'Successfully Updated'
        });
        $('#addNewMultiple').modal('hide');
      })["catch"](function (error) {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong'
        });
      });
    },
    addExpense: function addExpense(jvl) {
      var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

      this.editmode = true;
      this.form.reset();
      this.form.fill(jvl);
      this.view.ViewBillAmount = numeral(jvl.BillAmount).format('0,0.00');
      this.view.ViewNetTrucker = numeral(jvl.NetTrucker).format('0,0.00');
      this.view.ViewLessAdmin = numeral(jvl.LessAdmin).format('0,0.00');
      this.view.ViewPerHourRate = numeral(jvl.PerHourRate).format('0,0.00');
      this.view.ViewMaintenanceCost = numeral(jvl.MaintenanceCost).format('0,0.00');
      this.view.ViewSubTotalExpense = numeral(jvl.SubTotalExpense).format('0,0.00');
      this.view.ViewTotalExpense = numeral(jvl.TotalExpense).format('0,0.00');
      $('#addNew').modal('show');
    },
    newModal: function newModal() {
      this.editmode = false;
      this.form.reset();
      this.view.reset();
      $('#addNew').modal('show');
      var today = new Date().toISOString().slice(0, 10);
      this.form.OVLVLDate = today;
      this.form.LessFuel = 0;
      this.form.LessAdmin = 0;
      this.form.MaintenanceCost = 0;
      this.form.Helper = 0;
      this.form.Labor = 0;
      this.form.FuelLiters = 0;
    },
    closeModalMultiple: function closeModalMultiple() {
      location.reload();
      $('#addNewMultiple').modal('hide');
    },
    newModalMultiple: function newModalMultiple() {
      var _this12 = this;

      this.var1 = 0;
      this.first = 0;
      var i = 0;
      this.form.OVLVLHDRID = this.checkedNames;
      this.$Progress.start();

      if (this.checkedNames == '') {
        this.$Progress.fail();
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'No Transaction Selected.'
        });
      } else {
        axios.get('/api/getovlvlfilter', {
          params: {
            OVLVLHDRID: this.checkedNames
          }
        }).then(function (response) {
          _this12.jvlfilter = response.data;

          for (i = 0; i < _this12.jvlfilter.length; i++) {
            if (_this12.jvlfilter[i].BillAmount != _this12.jvlfilter[0].BillAmount) {
              _this12.$Progress.fail();

              swal.fire({
                title: 'Ooopsie Doopsieee',
                text: 'The transactions that you have selected are not uniform in Bill Amount. Please review.',
                icon: 'error',
                showCancelButton: true,
                showConfirmButton: false,
                cancelButtonColor: '#d33'
              }).then(function (result) {
                if (result.value) {} else {
                  $('#addNewMultiple').modal('hide');
                }
              });
              break;
            } else {
              _this12.editmode = false;

              _this12.form.reset();

              _this12.form.BillAmount = _this12.jvlfilter[0].BillAmount;
              _this12.form.BalanceAmount = _this12.jvlfilter[0].BalanceAmount;
              _this12.form.BalanceAmountHDR = _this12.jvlfilter[0].BalanceAmount;

              var numeral = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");

              _this12.view.ViewBalanceAmount = numeral(_this12.form.BalanceAmount).format('0,0.00'); //this.form.CollectedAmount = this.jvlfilter[0].CollectedAmount;
              //this.form.BalanceAmount = this.form.BillAmount - this.form.CollectedAmount;

              $('#addNewMultiple').modal('show');
            }
          }
        }); //END AXIOS

        this.$Progress.finish();
      }
    },
    doSomething: function doSomething(data) {
      console.log(data);
    },
    loadJVL: function loadJVL() {
      var _this13 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getovl').then(function (response) {
        _this13.jvls = response.data;
        _this13.rowData = response.data;
        console.log(_this13.jvls);
      })["catch"](function (error) {
        console.log(error);
      });
    },
    loadOVLDTL: function loadOVLDTL() {
      var _this14 = this;

      //axios.get("api/jvl").then(({ data }) => (this.jvls = data));
      axios.get('api/getovldtl', {
        params: {
          OVLVLHDRID_Link: this.detail.OVLVLHDRID_Link
        }
      }).then(function (response) {
        _this14.OVLDTLDetails = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    loadJVCP: function loadJVCP() {
      var _this15 = this;

      axios.get('api/jvcp').then(function (_ref9) {
        var data = _ref9.data;
        return _this15.jvcps = data;
      });
    },
    createJVL: function createJVL() {
      var _this16 = this;

      this.$Progress.start();
      this.form.post('api/ovl').then(function () {
        //$('#addNew').modal('hide');
        //$('.modal-backdrop').remove();
        _this16.form.reset();

        _this16.view.reset();

        var today = new Date().toISOString().slice(0, 10);
        _this16.form.OVLVLDate = today;
        toast.fire({
          icon: 'success',
          title: 'Outsider Vehicle Log successfully created'
        });

        _this16.$Progress.finish();

        _this16.loadJVL();

        _this16.form.LessFuel = 0;
        _this16.form.LessFuel = 0;
        _this16.form.FuelLiters = 0;
        _this16.form.MaintenanceCost = 0;
        _this16.form.LessAdmin = 0;
        _this16.form.Helper = 0;
        _this16.form.Labor = 0;
        $('#addNew').modal('hide');
      })["catch"](function () {
        _this16.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Outsider Vehicle Log not added successfully'
        });
      });
    },
    createOVLDetails: function createOVLDetails() {
      var _this17 = this;

      this.$Progress.start();
      axios.get('api/insertovldtl', {
        params: {
          OVLVLHDRID_Link: this.detail.OVLVLHDRID_Link,
          LoadingAssignment: this.detail.LoadingAssignment,
          LoadingFLDLOG: this.detail.LoadingFLDLOG,
          LoadingTimeIn: this.detail.LoadingTimeIn,
          LoadingTimeStart: this.detail.LoadingTimeStart,
          LoadingTimeEnd: this.detail.LoadingTimeEnd,
          LoadingRemarks: this.detail.LoadingRemarks,
          LoadingLoadFill: this.detail.LoadingLoadFill,
          LoadingHiredOperatorHour: this.detail.LoadingHiredOperatorHour,
          LoadingJobCode: this.detail.LoadingJobCode,
          LoadingNoOfLoad: this.detail.LoadingNoOfLoad,
          UnLoadingAssignment: this.detail.UnLoadingAssignment,
          UnLoadingFLDLOG: this.detail.UnLoadingFLDLOG,
          UnLoadingTimeIn: this.detail.UnLoadingTimeIn,
          UnLoadingTimeStart: this.detail.UnLoadingTimeStart,
          UnLoadingTimeEnd: this.detail.UnLoadingTimeEnd,
          UnLoadingRemarks: this.detail.UnLoadingRemarks,
          UnLoadingLoadFill: this.detail.UnLoadingLoadFill,
          UnLoadingHiredOperatorHour: this.detail.UnLoadingHiredOperatorHour,
          UnLoadingJobCode: this.detail.UnLoadingJobCode,
          UnLoadingNoOfLoad: this.detail.UnLoadingNoOfLoad
        }
      }).then(function (response) {
        toast.fire({
          icon: 'success',
          title: 'OVL Detail successfully created'
        });

        _this17.$Progress.finish();

        _this17.loadOVLDTL();
      })["catch"](function (error) {
        this.$Progress.fail();
        toast.fire({
          icon: 'error',
          title: 'OVL Detail not added successfully'
        });
      });
    },
    createJVCP: function createJVCP() {
      var _this18 = this;

      this.form.post('api/ovcp').then(function () {
        toast.fire({
          icon: 'success',
          title: 'Outsider Vehicle Log successfully created'
        });

        _this18.getJVCP();

        _this18.form.CollectedAmount = ''; //this.form.BalanceAmount=0;

        _this18.form.ORCRNumber = '';
        _this18.form.ORCRDate = '';
        _this18.form.Remarks = '';

        _this18.getJVLBalanceAmount();
      })["catch"](function () {
        _this18.$Progress.fail();

        toast.fire({
          icon: 'error',
          title: 'Outsider Vehicle Collection Payment not added successfully'
        });
      });
    },
    getJVLBalanceAmount: function getJVLBalanceAmount() {
      var _this19 = this;

      axios.get('/api/getovlvlbalanceamount', {
        params: {
          OVLVLHDRID: this.form.OVLVLHDRID
        }
      }).then(function (response) {
        _this19.jvlbalamt = response.data;
        _this19.form.BalanceAmountHDR = _this19.jvlbalamt[0].BalanceAmount;
        console.log(_this19.jvlbalamt[0].BalanceAmount);
      })["catch"](function (err) {});
    },
    deleteEntirePaymentDetail: function deleteEntirePaymentDetail() {
      this.form["delete"]('api/ovldeleteentirepaymentdetail/' + this.form.OVLVLHDRID);
      swal.fire('Deleted!', 'Your file has been deleted.', 'success');
      this.form.OVLVLHDRID_Link = this.form.OVLVLHDRID;
      this.JeepVehicleCollectionPayments = [];
      this.getJVCP();
    },
    deleteModalOVLDTL: function deleteModalOVLDTL(OVLDTL) {
      this.detail.OVLVLDTLID = OVLDTL.OVLVLDTLID;
      axios.get('/api/deleteovldtl', {
        params: {
          OVLVLDTLID: this.detail.OVLVLDTLID
        }
      }).then(function (_ref10) {
        var data = _ref10.data;
        swal.fire('Deleted!', 'Your file has been deleted.', 'success');
      })["catch"](function (err) {});
      this.loadOVLDTL();
    },
    createJVCPMultiple: function createJVCPMultiple() {
      var _this20 = this;

      if (this.form.BalanceAmount == 0) {
        this.form.Status = 'PAID';
      } else {
        this.form.Status = 'POSTED';
      }

      this.editmode = false;
      swal.fire({
        title: 'Are you sure you watn to save?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, save it!'
      }).then(function (result) {
        if (result.value) {
          _this20.$Progress.start(); ////console.log(this.checkedNames);


          var arr = 0;

          for (var i = 0; i < _this20.checkedNames.length; i++) {
            arr = i;
            console.log(_this20.checkedNames.length);
            _this20.form.OVLVLHDRID_Link = _this20.checkedNames[i]; //console.log(this.form.OVLVLHDRID_Link);
            //UPDATE VEHICLE LOG HDR

            _this20.form.put('api/ovlvlovlvcp/' + _this20.checkedNames[i]);

            $('#addNewMultiple').modal('hide'); //END UPDATE
            //CREATE INSERT TO JEEP VEHICLE COLLECTION PAYMENT

            _this20.form.post('api/ovcp').then(function () {
              //toast.fire({
              //   icon: "success",
              //  title: "Transaction done."
              //});
              swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 1500
              });
            }); //END CREATE

          }

          _this20.$Progress.finish(); //location.reload();


          _this20.loadJVL();

          _this20.checkedNames = [];
          _this20.allSelected = false;
        }
      });
    },
    // getSelectedRows(){
    //   const selectedNodes = this.gridApi.getSelectedNodes();
    //   const selectedData = selectedNodes.map(node => node.data);
    //   this.checkedNames= selectedData.map(node => node.OVLVLHDRID).join();
    // },
    // onGridReady(params){
    //   this.gridApi = params.api;
    //   this.columnApi = params.columnApi;
    // },
    // onRowSelected(event) {
    //         const selectedNodes = this.gridApi.getSelectedNodes();
    //   const selectedData = selectedNodes.map(node => node.data);
    //   this.checkedNames= selectedData.map(node => node.OVLVLHDRID).join();
    //     },
    loadPaymentModes: function loadPaymentModes() {
      var _this21 = this;

      axios.get('api/mode').then(function (_ref11) {
        var data = _ref11.data;
        _this21.paymentModes = data.data;
      });
    }
  },
  created: function created() {
    this.loadJVL();
    this.loadPaymentModes(); //setInterval(() => this.loadDriver(),3000);
  },
  // beforeMount() {
  //     this.columnDefs = [
  //         {headerName: 'ID', field: 'OVLVLHDRID',checkboxSelection: true},
  //         {headerName: 'Date', field: 'OVLVLDate'},
  //         {headerName: 'VL No.', field: 'OVLNo'},
  //         {headerName: 'Plate No.', field: 'OVLPlateNo',filter:true},
  //         {headerName: 'Driver', field: 'DriverName',filter:true},
  //         {headerName: 'Billable Amt.', field: 'BillAmount'},
  //         {headerName: 'Less Admin', field: 'LessAdmin'},
  //         {headerName: 'Less Fuel', field: 'LessFuel'},
  //         {headerName: 'Net Operator', field: 'NetTrucker'},
  //         {headerName: 'Status', field: 'Status'},
  //         {headerName: 'SOA No.', field: 'SOANumber'},
  //         {headerName: 'SOA Date', field: 'SOADate'}
  //     ];
  //     // fetch('https://api.myjson.com/bins/15psn9')
  //     //   .then(result => result.json())
  //     //   .then(rowData => this.rowData = rowData);
  //     // this.rowData = this.jvls;
  //     // this.rowData = [
  //     //      {OVLVLDate: this.jvls.OVLVLDate, OVLNo: this.jvls.OVLNo, OVLPlateNo: this.jvls.OVLNo,DriverName: this.jvls.DriverName,BillAmount: this.jvls.BillAmount,LessAdmin: this.jvls.LessAdmin,LessFuel: this.jvls.LessFuel,NetTrucker: this.jvls.NetTrucker,Status: this.jvls.Status,SOANumber: this.jvls.SOANumber,SOADate: this.jvls.SOADate}
  //     // ];
  // },
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this22 = this;

      if (this.DateFrom !== '' || this.DateTo !== '' && this.SearchOVLPlateNo !== '') {
        this.SearchOVLPlateNo = '';
        var vm = this;
        var startdate = vm.DateFrom;
        var enddate = vm.DateTo;
        return _.filter(vm.jvls, function (data) {
          if (_.isNull(startdate) && _.isNull(enddate)) {
            return true;
          } else {
            var date = data.OVLVLDate;
            return date >= startdate && date <= enddate;
          }
        });
      } else {
        this.DateFrom = '';
        this.DateTo = ''; //return this.jvls.filter(jvl =>{
        //return jvl.OVLPlateNo.includes(this.form.OVLPlateNo)
        //});

        return this.jvls.filter(function (samsung) {
          return _this22.SearchOVLPlateNo.toLowerCase().split(' ').every(function (v) {
            return samsung.OVLPlateNo.toLowerCase().includes(v);
          });
        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n\tpointer-events: none;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/wingvan/WingVan-Ledger.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/*! exports provided: default */
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Ledger.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Ledger.vue?vue&type=template&id=01d04340& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-PO-Search.vue":
/*!***************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-PO-Search.vue ***!
  \***************************************************************/
=======
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("img", { attrs: { src: __webpack_require__(/*! ./OVL.png */ "./resources/js/components/OVLComponents/OVL.png") } }),
    _vm._v(" "),
    _c(
      "nav",
      {
        staticClass:
          "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
      },
      [
        _c(
          "div",
          {
            staticClass: "collapse navbar-collapse",
            attrs: { id: "navbarNavDropdown" }
          },
          [
            _c("ul", { staticClass: "navbar-nav" }, [
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#mlist"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        Master File\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "mlist"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovldriverlist" }
                          },
                          [_c("a", [_vm._v("OVL Driver List")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovlvehiclelist" }
                          },
                          [_c("a", [_vm._v("OVL Vehicle List & Rate")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#trans"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        Transactions\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "trans"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovlvehiclelogentry" }
                          },
                          [_c("a", [_vm._v("OVL Vehicle Log Entry")])]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/ovldriverpayroll" }
                          },
                          [_c("a", [_vm._v("Driver Payroll List")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", { staticClass: "nav-item dropdown" }, [
                _c(
                  "a",
                  {
                    staticClass: "nav-link dropdown-toggle",
                    attrs: {
                      href: "#",
                      id: "navbarDropdownMenuLink",
                      role: "button",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false",
                      "data-target": "#report"
                    }
                  },
                  [
                    _vm._v(
                      "\n                        OVL Reports\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "ul",
                  {
                    staticClass: "dropdown-menu",
                    attrs: {
                      "aria-labelledby": "navbarDropdownMenuLink",
                      id: "report"
                    }
                  },
                  [
                    _c(
                      "li",
                      [
                        _c(
                          "router-link",
                          {
                            staticClass: "dropdown-item",
                            attrs: { to: "/reportlistovl" }
                          },
                          [_c("a", [_vm._v("Standard OVL Report")])]
                        )
                      ],
                      1
                    )
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container", attrs: { id: "sweget" } },
    [
      _c("ovl-menu"),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c(
              "form",
              {
                staticStyle: {
                  "border-style": "solid",
                  "border-color": "coral"
                }
              },
              [
                _c("div", { staticClass: "form-inline" }, [
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(1),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateFrom,
                            expression: "DateFrom"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateFrom" },
                        domProps: { value: _vm.DateFrom },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateFrom = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _vm._m(2),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.DateTo,
                            expression: "DateTo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "date", name: "DateTo" },
                        domProps: { value: _vm.DateTo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.DateTo = $event.target.value
                          }
                        }
                      })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-top": "10px",
                        "margin-left": "5px"
                      }
                    },
                    [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              _vm.filterKey = "all"
                            }
                          }
                        },
                        [_vm._v("Search")]
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "input-group mb-3 input-group-sm",
                      staticStyle: {
                        "margin-left": "5px",
                        "margin-top": "10px"
                      }
                    },
                    [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.SearchOVLPlateNo,
                            expression: "SearchOVLPlateNo"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "SearchOVLPlateNo",
                          placeholder: "OVL Plate Number"
                        },
                        domProps: { value: _vm.SearchOVLPlateNo },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.SearchOVLPlateNo = $event.target.value
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-primary", size: "sm" },
                              on: {
                                click: function($event) {
                                  return _vm.searchsearchVehicleFunction()
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-search",
                                attrs: { "aria-hidden": "true" }
                              })
                            ]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-tools" }),
            _vm._v(" "),
            _c("br")
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card-body table-responsive pre-scrollable" },
            [
              _c("table", { staticClass: "table table-hover" }, [
                _vm._m(3),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.filteredBlogs, function(jvl) {
                    return _c("tr", { key: jvl.OVLVLHDRID }, [
                      _c("td", [_vm._v(_vm._s(jvl.OVLVLDate))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.OVLPlateNo))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.DriverName))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(
                            "Php" +
                              jvl.BillAmount.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.LessAdmin))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.LessFuel))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(
                            "Php" +
                              jvl.NetTrucker.toLocaleString(undefined, {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                              })
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(jvl.Status))]),
                      _vm._v(" "),
                      _c("td", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#", title: "Add Payment" },
                            on: {
                              click: function($event) {
                                return _vm.addPayment(jvl)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-coins text-warning" })]
                        ),
                        _vm._v("\n                  /\n                  "),
                        _vm._v(" "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#", title: "Edit Log" },
                            on: {
                              click: function($event) {
                                return _vm.editModal(jvl)
                              }
                            }
                          },
                          [_c("i", { staticClass: "fa fa-edit" })]
                        ),
                        _vm._v("\n                  /\n                  "),
                        _c(
                          "a",
                          {
                            attrs: { href: "#", title: "Delete Log" },
                            on: {
                              click: function($event) {
                                return _vm.deleteModal(jvl.OVLVLHDRID)
                              }
                            }
                          },
                          [
                            _c("i", {
                              staticClass: "fa fa-trash",
                              staticStyle: { color: "red" }
                            })
                          ]
                        )
                      ])
                    ])
                  }),
                  0
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" }, [
            _c(
              "button",
              { staticClass: "btn btn-success", on: { click: _vm.newModal } },
              [
                _vm._v("\n              Add New OVL\n              "),
                _c("i", { staticClass: "fa fa-user-plus fa fw" })
              ]
            ),
            _vm._v(" "),
            _c("div", { staticStyle: { float: "right" } }, [
              _vm._v("Total SOA Amount : " + _vm._s(_vm.form.TotalAmount))
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNew",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-lg",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add New Outsider Vehicle Log")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update Outsider Vehicle Log's Info")]
                  ),
                  _vm._v(" "),
                  _vm._m(4)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        _vm.editmode ? _vm.updateJVL() : _vm.createJVL()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: {
                          "max-height": "550px",
                          "overflow-y": "auto"
                        }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(5),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLVLDate,
                                        expression: "form.OVLVLDate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      id: "OVLVLDate",
                                      type: "date",
                                      required: ""
                                    },
                                    domProps: { value: _vm.form.OVLVLDate },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLVLDate",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLVLHDRID,
                                        expression: "form.OVLVLHDRID"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "hidden" },
                                    domProps: { value: _vm.form.OVLVLHDRID },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLVLHDRID",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(6),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLNo,
                                        expression: "form.OVLNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "OVLNo" },
                                    domProps: { value: _vm.form.OVLNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLPlateNo,
                                        expression: "form.OVLPlateNo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "OVLPlateNo",
                                      placeholder: "Vehicle Plate Number",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.OVLPlateNo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLPlateNo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.OVLIDLink,
                                        expression: "form.OVLIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "OVLIDLink",
                                      placeholder: "OVLIDLink"
                                    },
                                    domProps: { value: _vm.form.OVLIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "OVLIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchVehicleFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverName,
                                        expression: "form.DriverName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "DriverName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "DriverName",
                                      placeholder: "Driver Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.DriverName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverLastName,
                                        expression: "form.DriverLastName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverLastName",
                                      placeholder: "DriverLastName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverLastName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverLastName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverFirstName,
                                        expression: "form.DriverFirstName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverFirstName",
                                      placeholder: "DriverFirstName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverFirstName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverFirstName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverMiddleName,
                                        expression: "form.DriverMiddleName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverMiddleName",
                                      placeholder: "DriverMiddleName"
                                    },
                                    domProps: {
                                      value: _vm.form.DriverMiddleName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverMiddleName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverExtName,
                                        expression: "form.DriverExtName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverExtName",
                                      placeholder: "DriverExtName"
                                    },
                                    domProps: { value: _vm.form.DriverExtName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverExtName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.DriverIDLink,
                                        expression: "form.DriverIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "DriverIDLink",
                                      placeholder: "DriverIDLink"
                                    },
                                    domProps: { value: _vm.form.DriverIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "DriverIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchDriverFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientName,
                                        expression: "form.ClientName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    class: {
                                      "is-invalid": _vm.form.errors.has(
                                        "DriverName"
                                      )
                                    },
                                    attrs: {
                                      type: "text",
                                      name: "ClientName",
                                      placeholder: "Client Name",
                                      readonly: ""
                                    },
                                    domProps: { value: _vm.form.ClientName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientLastName,
                                        expression: "form.ClientLastName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientLastName",
                                      placeholder: "ClientLastName"
                                    },
                                    domProps: {
                                      value: _vm.form.ClientLastName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientLastName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientFirstName,
                                        expression: "form.ClientFirstName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientFirstName",
                                      placeholder: "ClientFirstName"
                                    },
                                    domProps: {
                                      value: _vm.form.ClientFirstName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientFirstName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientMiddleName,
                                        expression: "form.ClientMiddleName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientMiddleName",
                                      placeholder: "ClientMiddleName"
                                    },
                                    domProps: {
                                      value: _vm.form.ClientMiddleName
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientMiddleName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientExtName,
                                        expression: "form.ClientExtName"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientExtName",
                                      placeholder: "ClientExtName"
                                    },
                                    domProps: { value: _vm.form.ClientExtName },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientExtName",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.ClientIDLink,
                                        expression: "form.ClientIDLink"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "ClientIDLink",
                                      placeholder: "ClientIDLink"
                                    },
                                    domProps: { value: _vm.form.ClientIDLink },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "ClientIDLink",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "outline-primary",
                                            size: "sm"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.searchClientFunction()
                                            }
                                          }
                                        },
                                        [
                                          _c("i", {
                                            staticClass: "fa fa-search",
                                            attrs: { "aria-hidden": "true" }
                                          })
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(7),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.GLCode,
                                        expression: "form.GLCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "GLCode" },
                                    domProps: { value: _vm.form.GLCode },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "GLCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(8),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LocationFrom,
                                        expression: "form.LocationFrom"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "LocationFrom"
                                    },
                                    domProps: { value: _vm.form.LocationFrom },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LocationFrom",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(9),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.LocationTo,
                                        expression: "form.LocationTo"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "LocationTo" },
                                    domProps: { value: _vm.form.LocationTo },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LocationTo",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "input-group mb-3 input-group-sm",
                                  staticStyle: { "text-transform": "uppercase" }
                                },
                                [
                                  _vm._m(10),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.CostCenter,
                                        expression: "form.CostCenter"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "text", name: "CostCenter" },
                                    domProps: { value: _vm.form.CostCenter },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "CostCenter",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(11),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.PerHourRate,
                                        expression: "form.PerHourRate"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "PerHourRate"
                                    },
                                    domProps: { value: _vm.form.PerHourRate },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "PerHourRate",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangestartreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(12),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.NumberOfHours,
                                        expression: "form.NumberOfHours"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "number",
                                      name: "NumberOfHours"
                                    },
                                    domProps: { value: _vm.form.NumberOfHours },
                                    on: {
                                      input: [
                                        function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.form,
                                            "NumberOfHours",
                                            $event.target.value
                                          )
                                        },
                                        function($event) {
                                          return _vm.signalChangestartreading()
                                        }
                                      ]
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(13),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.startreading,
                                        expression: "form.startreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "time",
                                      name: "startreading"
                                    },
                                    domProps: { value: _vm.form.startreading },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "startreading",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(14),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.form.endreading,
                                        expression: "form.endreading"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "time", name: "endreading" },
                                    domProps: { value: _vm.form.endreading },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "endreading",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(15),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.view.ViewBillAmount,
                                        expression: "view.ViewBillAmount"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "text",
                                      name: "ViewBillAmount",
                                      "data-readonly": ""
                                    },
                                    domProps: {
                                      value: _vm.view.ViewBillAmount
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.view,
                                          "ViewBillAmount",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c(
                            "div",
                            { staticClass: "col" },
                            [_c("center", [_c("h3", [_vm._v("EXPENSES")])])],
                            1
                          )
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(16),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.FuelLiters,
                                      expression: "form.FuelLiters"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: { type: "text", name: "FuelLiters" },
                                  domProps: { value: _vm.form.FuelLiters },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "FuelLiters",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(17),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.FuelRate,
                                      expression: "form.FuelRate"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: {
                                    step: "0.01",
                                    type: "number",
                                    name: "FuelRate"
                                  },
                                  domProps: { value: _vm.form.FuelRate },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "FuelRate",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(18),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.LessFuel,
                                      expression: "form.LessFuel"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: {
                                    step: "0.01",
                                    type: "number",
                                    name: "LessFuel"
                                  },
                                  domProps: { value: _vm.form.LessFuel },
                                  on: {
                                    input: [
                                      function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "LessFuel",
                                          $event.target.value
                                        )
                                      },
                                      function($event) {
                                        return _vm.signalChangeLessFuel()
                                      }
                                    ]
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(19),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.view.ViewMaintenanceCost,
                                      expression: "view.ViewMaintenanceCost"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: {
                                    type: "text",
                                    name: "ViewLessAdmin",
                                    "data-readonly": ""
                                  },
                                  domProps: {
                                    value: _vm.view.ViewMaintenanceCost
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.view,
                                        "ViewMaintenanceCost",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(20),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.LessAdmin,
                                      expression: "form.LessAdmin"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: {
                                    type: "text",
                                    name: "ViewLessAdmin",
                                    "data-readonly": ""
                                  },
                                  domProps: { value: _vm.form.LessAdmin },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "LessAdmin",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(21),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.Helper,
                                      expression: "form.Helper"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: {
                                    step: "0.01",
                                    type: "number",
                                    name: "Helper"
                                  },
                                  domProps: { value: _vm.form.Helper },
                                  on: {
                                    input: [
                                      function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Helper",
                                          $event.target.value
                                        )
                                      },
                                      function($event) {
                                        return _vm.signalChangeHelper()
                                      }
                                    ]
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(22),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.Labor,
                                      expression: "form.Labor"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#E985A5" },
                                  attrs: {
                                    step: "0.01",
                                    type: "number",
                                    name: "Labor"
                                  },
                                  domProps: { value: _vm.form.Labor },
                                  on: {
                                    input: [
                                      function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form,
                                          "Labor",
                                          $event.target.value
                                        )
                                      },
                                      function($event) {
                                        return _vm.signalChangeLabor()
                                      }
                                    ]
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c(
                            "div",
                            { staticClass: "col" },
                            [_c("center", [_c("h3", [_vm._v("TOTAL")])])],
                            1
                          )
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(23),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.view.ViewSubTotalExpense,
                                      expression: "view.ViewSubTotalExpense"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#85E9C9" },
                                  attrs: {
                                    type: "text",
                                    name: "TotalExpense",
                                    "data-readonly": ""
                                  },
                                  domProps: {
                                    value: _vm.view.ViewSubTotalExpense
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.view,
                                        "ViewSubTotalExpense",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(24),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.view.ViewTotalExpense,
                                      expression: "view.ViewTotalExpense"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#85E9C9" },
                                  attrs: {
                                    type: "text",
                                    name: "TotalExpense",
                                    "data-readonly": ""
                                  },
                                  domProps: {
                                    value: _vm.view.ViewTotalExpense
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.view,
                                        "ViewTotalExpense",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(25),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.view.ViewNetTrucker,
                                      expression: "view.ViewNetTrucker"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  staticStyle: { "border-color": "#85E9C9" },
                                  attrs: {
                                    type: "text",
                                    name: "ViewNetTrucker",
                                    "data-readonly": ""
                                  },
                                  domProps: { value: _vm.view.ViewNetTrucker },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.view,
                                        "ViewNetTrucker",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addNewMultiple",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-md",
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editPayment,
                          expression: "!editPayment"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add OVL Payment")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editPayment,
                          expression: "editPayment"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update OVL Payment")]
                  ),
                  _vm._v(" "),
                  _vm._m(26)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        !_vm.editPayment
                          ? _vm.createPayment()
                          : _vm.updatePayment()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "modal-body" }, [
                      _c("div", { staticClass: "col-xs-12" }, [
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(27),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.view.ViewBalanceAmount,
                                      expression: "view.ViewBalanceAmount"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "BalanceAmount",
                                    "data-readonly": ""
                                  },
                                  domProps: {
                                    value: _vm.view.ViewBalanceAmount
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.view,
                                        "ViewBalanceAmount",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(28),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.PONo,
                                      expression: "payment.PONo"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "PONo" },
                                  domProps: { value: _vm.payment.PONo },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "PONo",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(29),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.RefNo,
                                      expression: "payment.RefNo"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "ORCRNumber" },
                                  domProps: { value: _vm.payment.RefNo },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "RefNo",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(30),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.ServiceEntrySheet,
                                      expression: "payment.ServiceEntrySheet"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "ServiceEntrySheet"
                                  },
                                  domProps: {
                                    value: _vm.payment.ServiceEntrySheet
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "ServiceEntrySheet",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(31),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.DocHeaderText,
                                      expression: "payment.DocHeaderText"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "DocHeaderText"
                                  },
                                  domProps: {
                                    value: _vm.payment.DocHeaderText
                                  },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "DocHeaderText",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col-7" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(32),
                                _vm._v(" "),
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.payment.ModeOfPayment,
                                        expression: "payment.ModeOfPayment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    on: {
                                      change: function($event) {
                                        var $$selectedVal = Array.prototype.filter
                                          .call($event.target.options, function(
                                            o
                                          ) {
                                            return o.selected
                                          })
                                          .map(function(o) {
                                            var val =
                                              "_value" in o ? o._value : o.value
                                            return val
                                          })
                                        _vm.$set(
                                          _vm.payment,
                                          "ModeOfPayment",
                                          $event.target.multiple
                                            ? $$selectedVal
                                            : $$selectedVal[0]
                                        )
                                      }
                                    }
                                  },
                                  [
                                    _c("option"),
                                    _vm._v(" "),
                                    _vm._l(_vm.paymentModes, function(item) {
                                      return _c("option", { key: item.name }, [
                                        _vm._v(_vm._s(item.name))
                                      ])
                                    })
                                  ],
                                  2
                                )
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-5" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(33),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.Amount,
                                      expression: "payment.Amount"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "CollectedAmount"
                                  },
                                  domProps: { value: _vm.payment.Amount },
                                  on: {
                                    input: [
                                      function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.payment,
                                          "Amount",
                                          $event.target.value
                                        )
                                      },
                                      function($event) {
                                        return _vm.signalChangeCollectedAmount()
                                      }
                                    ]
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col-5" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(34),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.CheckNumber,
                                      expression: "payment.CheckNumber"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "CheckNumber" },
                                  domProps: { value: _vm.payment.CheckNumber },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "CheckNumber",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-7" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(35),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.CheckDate,
                                      expression: "payment.CheckDate"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    id: "date",
                                    type: "date",
                                    name: "CheckDate"
                                  },
                                  domProps: { value: _vm.payment.CheckDate },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "CheckDate",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(36),
                                _vm._v(" "),
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.CheckBank,
                                      expression: "payment.CheckBank"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "CheckBank" },
                                  domProps: { value: _vm.payment.CheckBank },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "CheckBank",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "row" }, [
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              {
                                staticClass: "input-group mb-3 input-group-sm"
                              },
                              [
                                _vm._m(37),
                                _vm._v(" "),
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.payment.Remarks,
                                      expression: "payment.Remarks"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: { type: "text", name: "Remarks" },
                                  domProps: { value: _vm.payment.Remarks },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.payment,
                                        "Remarks",
                                        $event.target.value
                                      )
                                    }
                                  }
                                })
                              ]
                            )
                          ])
                        ])
                      ])
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editPayment,
                              expression: "!editPayment"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editPayment,
                              expression: "editPayment"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "modal fade",
          attrs: {
            id: "addOVLDetails",
            tabindex: "-1",
            role: "dialog",
            "aria-labelledby": "addNewLabel",
            "aria-hidden": "true"
          }
        },
        [
          _c(
            "div",
            {
              staticClass: "modal-dialog modal-xl",
              staticStyle: { "overflow-y": "initial !important" },
              attrs: { role: "document" }
            },
            [
              _c("div", { staticClass: "modal-content" }, [
                _c("div", { staticClass: "modal-header" }, [
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.editmode,
                          expression: "!editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Add OVL Details")]
                  ),
                  _vm._v(" "),
                  _c(
                    "h5",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.editmode,
                          expression: "editmode"
                        }
                      ],
                      staticClass: "modal-title",
                      attrs: { id: "addNewLabel" }
                    },
                    [_vm._v("Update OVL Details")]
                  ),
                  _vm._v(" "),
                  _vm._m(38)
                ]),
                _vm._v(" "),
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        !_vm.editmode ? _vm.updateJVL() : _vm.createOVLDetails()
                      }
                    }
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "modal-body",
                        staticStyle: { height: "450px", "overflow-y": "auto" }
                      },
                      [
                        _c("div", { staticClass: "col-xs-12" }, [
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "pre-scrollable",
                                  staticStyle: { height: "200px" }
                                },
                                [
                                  _c(
                                    "table",
                                    {
                                      directives: [
                                        {
                                          name: "show",
                                          rawName: "v-show",
                                          value: _vm.editmode,
                                          expression: "editmode"
                                        }
                                      ],
                                      staticClass: "table table-hover"
                                    },
                                    [
                                      _c("thead", [
                                        _c("tr", [
                                          _c(
                                            "th",
                                            {
                                              staticStyle: {
                                                "border-color": "#E985A9"
                                              },
                                              attrs: { colspan: "10" }
                                            },
                                            [_c("center", [_vm._v("LOADING")])],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "th",
                                            {
                                              staticStyle: {
                                                "border-color": "#85E9C5"
                                              },
                                              attrs: { colspan: "10" }
                                            },
                                            [
                                              _c("center", [
                                                _vm._v("UNLOADING")
                                              ])
                                            ],
                                            1
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _vm._m(39)
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "tbody",
                                        _vm._l(_vm.OVLDTLDetails, function(
                                          OVLDTL
                                        ) {
                                          return _c(
                                            "tr",
                                            { key: OVLDTL.OVLVLDTLID },
                                            [
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingAssignment
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(OVLDTL.LoadingFLDLOG)
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(OVLDTL.LoadingTimeIn)
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingTimeStart
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingTimeEnd
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingRemarks
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingLoadFill
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingHiredOperatorHour
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingJobCode
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#E985A9"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.LoadingNoOfLoad
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingAssignment
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingFLDLOG
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingTimeIn
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingTimeStart
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingTimeEnd
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingRemarks
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingLoadFill
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingHiredOperatorHour
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingJobCode
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "td",
                                                {
                                                  staticStyle: {
                                                    "border-color": "#85E9C5"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      OVLDTL.UnLoadingNoOfLoad
                                                    )
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c("td", [
                                                _c(
                                                  "a",
                                                  {
                                                    attrs: { href: "#" },
                                                    on: {
                                                      click: function($event) {
                                                        return _vm.deleteModalOVLDTL(
                                                          OVLDTL
                                                        )
                                                      }
                                                    }
                                                  },
                                                  [
                                                    _c("i", {
                                                      staticClass:
                                                        "fa fa-trash",
                                                      staticStyle: {
                                                        color: "red"
                                                      }
                                                    })
                                                  ]
                                                )
                                              ])
                                            ]
                                          )
                                        }),
                                        0
                                      )
                                    ]
                                  )
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(40),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.PHBVLHDRID_Link,
                                        expression: "detail.PHBVLHDRID_Link"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      type: "hidden",
                                      name: "PHBVLHDRID_Link"
                                    },
                                    domProps: {
                                      value: _vm.detail.PHBVLHDRID_Link
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "PHBVLHDRID_Link",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("LOADING")])])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "col" },
                              [_c("center", [_c("h3", [_vm._v("UNLOADING")])])],
                              1
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(41),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingAssignment,
                                        expression: "detail.LoadingAssignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingAssignment"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingAssignment
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingAssignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(42),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingAssignment,
                                        expression: "detail.UnLoadingAssignment"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingAssignment"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingAssignment
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingAssignment",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(43),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingFLDLOG,
                                        expression: "detail.LoadingFLDLOG"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingFLDLOG"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingFLDLOG
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingFLDLOG",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(44),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingFLDLOG,
                                        expression: "detail.UnLoadingFLDLOG"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingFLDLOG"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingFLDLOG
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingFLDLOG",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(45),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeIn,
                                        expression: "detail.LoadingTimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingLocationName"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeIn
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(46),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeIn,
                                        expression: "detail.UnLoadingTimeIn"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeIn"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeIn
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeIn",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(47),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeStart,
                                        expression: "detail.LoadingTimeStart"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingTimeStart"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeStart
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeStart",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(48),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeStart,
                                        expression: "detail.UnLoadingTimeStart"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeStart"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeStart
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeStart",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(49),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingTimeEnd,
                                        expression: "detail.LoadingTimeEnd"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "time",
                                      name: "LoadingTimeEnd"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingTimeEnd
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingTimeEnd",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(50),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingTimeEnd,
                                        expression: "detail.UnLoadingTimeEnd"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "time",
                                      name: "UnLoadingTimeEnd"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingTimeEnd
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingTimeEnd",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(51),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingRemarks,
                                        expression: "detail.LoadingRemarks"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingRemarks"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingRemarks
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingRemarks",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(52),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingRemarks,
                                        expression: "detail.UnLoadingRemarks"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingRemarks"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingRemarks
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingRemarks",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(53),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingLoadFill,
                                        expression: "detail.LoadingLoadFill"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingLoadFill"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingLoadFill
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingLoadFill",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(54),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingLoadFill,
                                        expression: "detail.UnLoadingLoadFill"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingLoadFill"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingLoadFill
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingLoadFill",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(55),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value:
                                          _vm.detail.LoadingHiredOperatorHour,
                                        expression:
                                          "detail.LoadingHiredOperatorHour"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingHiredOperatorHour"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingHiredOperatorHour
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingHiredOperatorHour",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(56),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value:
                                          _vm.detail.UnLoadingHiredOperatorHour,
                                        expression:
                                          "detail.UnLoadingHiredOperatorHour"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingHiredOperatorHour"
                                    },
                                    domProps: {
                                      value:
                                        _vm.detail.UnLoadingHiredOperatorHour
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingHiredOperatorHour",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(57),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingJobCode,
                                        expression: "detail.LoadingJobCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingJobCode"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingJobCode
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingJobCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(58),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingJobCode,
                                        expression: "detail.UnLoadingJobCode"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingJobCode"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingJobCode
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingJobCode",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "row" }, [
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(59),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.LoadingNoOfLoad,
                                        expression: "detail.LoadingNoOfLoad"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#E985A9" },
                                    attrs: {
                                      type: "text",
                                      name: "LoadingNoOfLoad"
                                    },
                                    domProps: {
                                      value: _vm.detail.LoadingNoOfLoad
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "LoadingNoOfLoad",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "input-group mb-3 input-group-sm"
                                },
                                [
                                  _vm._m(60),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.detail.UnLoadingNoOfLoad,
                                        expression: "detail.UnLoadingNoOfLoad"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    staticStyle: { "border-color": "#85E9C5" },
                                    attrs: {
                                      type: "text",
                                      name: "UnLoadingNoOfLoad"
                                    },
                                    domProps: {
                                      value: _vm.detail.UnLoadingNoOfLoad
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.detail,
                                          "UnLoadingNoOfLoad",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "modal-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-secondary",
                          attrs: { type: "button", "data-dismiss": "modal" }
                        },
                        [_vm._v("Close")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.editmode,
                              expression: "editmode"
                            }
                          ],
                          staticClass: "btn btn-primary",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Save")]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_vm.editmode,
                              expression: "!editmode"
                            }
                          ],
                          staticClass: "btn btn-success",
                          attrs: { type: "submit" }
                        },
                        [_vm._v("Update")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("search-driver", {
        on: {
          changeTitle: function($event) {
            return _vm.updateTitle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-operator", {
        on: {
          changeTitleOperator: function($event) {
            return _vm.updateTitleOperator($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-ovlvehicle", {
        on: {
          changeTitleVehicle: function($event) {
            return _vm.updateTitleVehicle($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-client", {
        on: {
          changeTitleClient: function($event) {
            return _vm.updateTitleClient($event)
          }
        }
      })
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("Outsider Vehicle Log Entry")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("VL No")]),
        _vm._v(" "),
        _c("th", [_vm._v("Plate No")]),
        _vm._v(" "),
        _c("th", [_vm._v("Driver")]),
        _vm._v(" "),
        _c("th", [_vm._v("Billable Amt")]),
        _vm._v(" "),
        _c("th", [_vm._v("Less Admin")]),
        _vm._v(" "),
        _c("th", [_vm._v("Less Fuel")]),
        _vm._v(" "),
        _c("th", [_vm._v("Net Amount")]),
        _vm._v(" "),
        _c("th", [_vm._v("Status")]),
        _vm._v(" "),
        _c("th", [_vm._v("Modify")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("VL No")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("GL Code")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Location From")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Location To")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Cost Center")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Per Hour Rate")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("No. of Hours")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time Start")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Time End")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Bill Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Fuel Liters")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Fuel Rate")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Fuel Amount")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Maintenance Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Admin Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Helper")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A5",
            "border-color": "#E985A5"
          }
        },
        [_vm._v("Labor")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C9",
            "border-color": "#85E9C9"
          }
        },
        [_vm._v("Sub-Total Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C9",
            "border-color": "#85E9C9"
          }
        },
        [_vm._v("Total Cost")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C9",
            "border-color": "#85E9C9"
          }
        },
        [_vm._v("Net From Rent")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Balance Amount")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("PO No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Ref No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Service Entry Sheet")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Doc Header Text")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Mode of Payment")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Amount")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check No.")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check Date")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Check Bank")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [_vm._v("Remarks")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Assignment")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("FLD/LOG")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Time In")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Time Start")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Time End")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Remarks")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Load Fill")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Hired Operator Hour")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("Job Code")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#E985A9" } }, [
        _vm._v("No. Of Load")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Assignment")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("FLD/LOG")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Time In")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Time Start")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Time End")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Remarks")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Load Fill")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Hired Operator Hour")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("Job Code")
      ]),
      _vm._v(" "),
      _c("th", { staticStyle: { "border-color": "#85E9C5" } }, [
        _vm._v("No. Of Load")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        { staticClass: "input-group-text", staticStyle: { display: "none" } },
        [_vm._v("Header ID")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Assignment")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Assignment")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading FLD/LOG")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading FLD/LOG")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time In")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time In")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time Start")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time Start")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Time End")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Time End")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Remraks")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Remraks")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Load Fill")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Load Fill")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Hired Operator Hour")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Hired Operator Hour")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading Job Code")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading Job Code")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#E985A9",
            "border-color": "#E985A9"
          }
        },
        [_vm._v("Loading No. Of Load")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c(
        "span",
        {
          staticClass: "input-group-text",
          staticStyle: {
            "background-color": "#85E9C5",
            "border-color": "#85E9C5"
          }
        },
        [_vm._v("Unloading No. Of Load")]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/OVLComponents/OVL.png":
/*!*******************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVL.png ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/OVL.png?70ca35f6f16b7d8ea732077eeaa11d02";

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLMenu.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLMenu.vue ***!
  \***********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _WingVan_PO_Search_vue_vue_type_template_id_0ea3e0ef___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef& */ "./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef&");
/* harmony import */ var _WingVan_PO_Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-PO-Search.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");


=======
/* harmony import */ var _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLMenu.vue?vue&type=template&id=321a0b35& */ "./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

var script = {}


/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_PO_Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_PO_Search_vue_vue_type_template_id_0ea3e0ef___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_PO_Search_vue_vue_type_template_id_0ea3e0ef___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/wingvan/WingVan-PO-Search.vue"
=======
component.options.__file = "resources/js/components/OVLComponents/OVLMenu.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/*! exports provided: default */
=======
/***/ "./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35& ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_PO_Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-PO-Search.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_PO_Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef& ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLMenu.vue?vue&type=template&id=321a0b35& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLMenu.vue?vue&type=template&id=321a0b35&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLMenu_vue_vue_type_template_id_321a0b35___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue ***!
  \**************************************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_PO_Search_vue_vue_type_template_id_0ea3e0ef___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-PO-Search.vue?vue&type=template&id=0ea3e0ef&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_PO_Search_vue_vue_type_template_id_0ea3e0ef___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_PO_Search_vue_vue_type_template_id_0ea3e0ef___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });

=======
/* harmony import */ var _OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& */ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&");
/* harmony import */ var _OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OVLVehicleLogComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

<<<<<<< HEAD
=======
/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/OVLComponents/OVLVehicleLogComponent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./OVLVehicleLogComponent.vue?vue&type=template&id=79633e02& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/OVLComponents/OVLVehicleLogComponent.vue?vue&type=template&id=79633e02&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OVLVehicleLogComponent_vue_vue_type_template_id_79633e02___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ })

}]);