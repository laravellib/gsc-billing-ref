(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[132],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
=======
/* harmony import */ var _search_SearchAllowance_SearchTransmittal_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchAllowance/SearchTransmittal.vue */ "./resources/js/components/search/SearchAllowance/SearchTransmittal.vue");
/* harmony import */ var _allowance_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../allowance/ShowDetailModal.vue */ "./resources/js/components/allowance/ShowDetailModal.vue");
/* harmony import */ var _search_SearchAllowance_SearchSOAAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSOAAllowanceHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchSOAAllowanceHeader.vue");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
<<<<<<< HEAD

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
      datas: {},
      mode: {},
      payment_type: "REQ",
      gridApi: null,
      columnApi: null,
      filter: null,
      form: new Form({
        id: "",
        gclid_link: 0,
        mode: "",
        payment_date: "",
        or_ref_no: "",
        check_card_no: "",
        check_card_bank_name: "",
        amount: 0,
        remarks: "",
        applied_amount: 0,
        filter: null,
        soa_link: 0
      })
    };
  },
  methods: {
    onChange: function onChange(e) {
      var _this = this;

      this.form.applied_amount = 0;
      this.form.filter = [];
      var selectedRows = this.gridApi.getSelectedNodes();
      var selectedData = selectedRows.map(function (node) {
        return node.data;
      });
      var selectedDataStringPresentation = selectedData.map(function (node) {
        return _this.form.applied_amount = _this.form.applied_amount + node.amount;
      });
      var push = selectedData.map(function (node) {
        return _this.form.filter.push(node);
      });
      console.log(this.form.filter);
    },
    clear: function clear() {
      this.filter = null;
      this.soa_no = "";
      this.exact_amount = 0;
      this.form.reset();
    },
    get_soa: function get_soa() {
      var _this2 = this;

      axios.get("wreq_soa/payment/" + this.datefrom + "/" + this.dateto + "/" + this.payment_type).then(function (_ref) {
        var data = _ref.data;
        console.log(data);
        _this2.filter = data.data;
      });
    },
    loadMode: function loadMode() {
      var _this3 = this;

      axios.get("api/mode").then(function (_ref2) {
        var data = _ref2.data;
        _this3.mode = data.data;
      });
    },
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    create_payment: function create_payment() {
      var _this4 = this;

      if (this.form.applied_amount == 0) {
        swal.fire("Select SOA", "warning");
      } else if (this.form.amount != this.form.applied_amount) {
        swal.fire("Check Amount and Rental Amount should be equal", "warning");
      } else {
        this.$Progress.start();
        this.form.post("wingvan/payment_store").then(function (data) {
          toast.fire({
            icon: "success",
            title: "Added Data in successfully"
          });
          console.log(data.data);

          _this4.clear();

          _this4.filter = null;
        })["catch"](function () {
          _this4.$Progress.fail();

          toast.fire({
            icon: "error",
            title: "Error Found"
          });
        });
        this.$Progress.finish();
      }
    }
  },
  created: function created() {
    this.columnDefs = [{
      headerName: "SOA Date",
      field: "soa_date",
      resizable: true,
      width: 170,
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true
    }, {
      headerName: "SOA No",
      field: "series_no",
      resizable: true,
      width: 170
    }, {
      headerName: "Billed To",
      field: "billed_name",
      resizable: true,
      width: 170
    }, {
      headerName: "Charge Invoice No",
      field: "charge_invoice_no",
      resizable: true,
      width: 170
    }, {
      headerName: "Status",
      field: "status",
      resizable: true,
      width: 170
    }, {
      headerName: "Amount",
      field: "amount",
      resizable: true,
      width: 170,
      cellStyle: {
        textAlign: "center"
      },
      valueFormatter: this.$root.currencyFormatter
    }];
    this.filter = [];
    this.loadMode();
    this.datefrom = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
    this.dateto = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
    this.form.payment_date = moment__WEBPACK_IMPORTED_MODULE_0___default()().format("YYYY-MM-DD");
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    "search-transmittal": _search_SearchAllowance_SearchTransmittal_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-allowanceDetail": _allowance_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "search-allowanceSOAHeader": _search_SearchAllowance_SearchSOAAllowanceHeader_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      from: this.$root.formatDate(new Date()),
      to: this.$root.formatDate(new Date()),
      checkTableArrays: [],
      checkHeader: false,
      rows: [],
      search: "",
      transmittal_no: "",
      prepared_by: "",
      SOANo: "",
      SoaTransNo: "",
      invoicedtls: {
        invoice_number: "",
        invoice_date: this.$root.formatDate(new Date()),
        SOANo: "",
        type: "allowance"
      }
    };
  },
  mounted: function mounted() {
    this.generate();
    this.getUser();
    this.getTransmittal();
  },
  methods: {
    checkTableAll: function checkTableAll() {
      if (!this.checkHeader) {
        var arrays = [];
        var index = 0;
        this.rows.forEach(function (item) {
          arrays.push(item);
          document.getElementById(item.AHID).checked = true;
        });
        this.checkTableArrays = arrays;
      } else {
        this.rows.forEach(function (item) {
          document.getElementById(item.AHID).checked = false;
        });
        this.checkTableArrays = [];
      }
    },
    checkTable: function checkTable(row) {
      if (this.checkTableArrays.indexOf(row) < 0) {
        this.checkTableArrays.push(row);
      } else {
        this.checkTableArrays.splice(this.checkTableArrays.indexOf(row), 1);
      }
    },
    generate: function generate() {
      var _this = this;

      this.checkHeader = false;
      this.checkTableArrays = [];
      axios.get("api/allowance", {
        params: {
          SOAHeaderDate: true,
          from: this.from,
          to: this.to
        }
      }).then(function (response) {
        _this.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getUser: function getUser() {
      var _this2 = this;

      axios.get("api/allowance", {
        params: {
          getUser: true
        }
      }).then(function (response) {
        _this2.prepared_by = response.data.name;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getTransmittal: function getTransmittal() {
      var _this3 = this;

      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getTransmittalNo: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          _this3.transmittal_no = response.data;
        } else {
          var dateNow = new Date();
          var month = dateNow.getMonth() + 1;
          _this3.transmittal_no = "TF" + dateNow.getFullYear().toString().substring(2) + month.toString().padStart(2, "0") + "-1";
        }

        _this3.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    clickDetails: function clickDetails(id) {
      Fire.$emit("searchAllowanceDetail", id);
    },
    rowClick: function rowClick(row) {
      console.log(row); // this.invoicedtls = Object.assign({}, row);

      this.invoicedtls.SOANo = row.SOANo;
      this.invoicedtls.invoice_number = row.invoice_number;
      this.invoicedtls.invoice_date = row.invoice_date == '0000-00-00' ? this.$root.formatDate(new Date()) : row.invoice_date;
      console.log(this.invoicedtls);
    },
    createTransmittal: function createTransmittal() {
      var _this4 = this;

      if (this.checkTableArrays.length < 1) {
        return toast.fire({
          icon: "warning",
          title: "No Data Selected."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Create Transmittal!"
      }).then(function (result) {
        if (result.value) {
          _this4.$Progress.start();

          axios.get("api/allowance", {
            params: {
              searchTransmittalExists: true,
              transmittal_no: _this4.transmittal_no
            }
          }).then(function (response) {
            if (response.data.length > 0) {
              swal.fire({
                title: "Transmittal Number Already Exists!",
                text: "Do you want to merge current selected records?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, Merge it!"
              }).then(function (result) {
                if (result.value) {
                  _this4.$Progress.start();

                  var submitArray = [];

                  _this4.checkTableArrays.forEach(function (item) {
                    submitArray.push(item.SOANo);
                  });

                  var data = {
                    transmittal_no: _this4.transmittal_no,
                    prepared_by: _this4.prepared_by,
                    soa_no_list: submitArray,
                    type: "ALLOWANCE",
                    merge: true
                  };

                  _this4.$Progress.start();

                  axios.post("api/allowanceCreateTransmittal", data).then(function (response) {
                    if (response.data.success) {
                      _this4.checkTableArrays = [];
                      _this4.rows = [];
                      _this4.checkHeader = false;
                      _this4.SOANo = "";
                      _this4.prepared_by = "";
                      _this4.SoaTransNo = "";
                      window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this4.transmittal_no + "&type=ALLOWANCE");
                      _this4.transmittal_no = "";

                      _this4.generate();

                      _this4.getUser();

                      _this4.getTransmittal();
                    } else {
                      toast.fire({
                        icon: "warning",
                        title: response.data.message
                      });
                    }

                    _this4.$Progress.finish();
                  })["catch"](function (error) {
                    console.log(error);
                  });
                } else {
                  swal.fire("Information!", "Cancelled.", "warning");
                }
              });
            } else {
              _this4.$Progress.start();

              var submitArray = [];

              _this4.checkTableArrays.forEach(function (item) {
                submitArray.push(item.SOANo);
              });

              var data = {
                transmittal_no: _this4.transmittal_no,
                prepared_by: _this4.prepared_by,
                type: "ALLOWANCE",
                soa_no_list: submitArray
              };

              _this4.$Progress.start();

              axios.post("api/allowanceCreateTransmittal", data).then(function (response) {
                if (response.data.success) {
                  _this4.checkTableArrays = [];
                  _this4.rows = [];
                  _this4.checkHeader = false;
                  _this4.SOANo = "";
                  _this4.prepared_by = "";
                  _this4.SoaTransNo = "";
                  window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this4.transmittal_no + "&type=ALLOWANCE");
                  _this4.transmittal_no = "";

                  _this4.generate();

                  _this4.getUser();

                  _this4.getTransmittal();
                } else {
                  toast.fire({
                    icon: "warning",
                    title: response.data.message
                  });
                }

                _this4.$Progress.finish();
              })["catch"](function (error) {
                console.log(error);
              });
            }

            _this4.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    addInvoice: function addInvoice() {
      var _this5 = this;

      if (!this.invoicedtls.invoice_number) {
        return toast.fire({
          icon: "warning",
          title: "Requirement. Please enter Invoice Number."
        });
      }

      this.$Progress.start();
      axios.post("api/addInvoiceNumber", this.invoicedtls).then(function (response) {
        if (response.data.success) {
          _this5.generate();

          _this5.invoicedtls = {
            invoice_number: "",
            invoice_date: _this5.$root.formatDate(new Date()),
            SOANo: "",
            type: "allowance"
          };
          return toast.fire({
            icon: "success",
            title: response.data.message
          });
        } else {
          return toast.fire({
            icon: "warning",
            title: "Something went wrong."
          });
        }

        _this5.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    removeTransmittal: function removeTransmittal() {
      var _this6 = this;

      if (!this.SOANo) {
        return toast.fire({
          icon: "warning",
          title: "Please select/enter SOA number to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Remove Transmittal #!"
      }).then(function (result) {
        if (result.value) {
          var data = {
            SOANo: _this6.SOANo,
            prepared_by: _this6.prepared_by,
            type: "PPE"
          };

          _this6.$Progress.start();

          axios.post("api/allowanceRemoveTransmittal", data).then(function (response) {
            if (response.data.success) {
              _this6.SOANo = "";
              _this6.SoaTransNo = "";
              toast.fire({
                icon: "success",
                title: response.data.message
              });
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this6.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    searchAllowanceSOAHeaderButton: function searchAllowanceSOAHeaderButton() {
      Fire.$emit("searchSOAAllowanceHeader", "transmittal");
    },
    allowanceSOAHeaderClose: function allowanceSOAHeaderClose(row) {
      this.SoaTransNo = row.SOANo + " ( " + row.transmittal_no + ")";
      this.SOANo = row.SOANo;
    },
    searchTransmittal: function searchTransmittal() {
      Fire.$emit("searchTransmittal", "allowance");
    },
    transmittalClose: function transmittalClose(row) {
      this.transmittal_no = row.transmittal_no;
    },
    printTransmittal: function printTransmittal() {
      var _this7 = this;

      axios.get("api/reportAllowanceTransmittal", {
        params: {
          searchTransmittalExists: true,
          transmittal_no: this.transmittal_no,
          type: "ALLOWANCE"
        }
      }).then(function (response) {
        if (response.data.success) {
          window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this7.transmittal_no + "&type=ALLOWANCE");

          _this7.getTransmittal();
        } else {
          return toast.fire({
            icon: "warning",
            title: "No data found in this transmittal number."
          });
        }

        _this7.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this8 = this;

      return this.rows.filter(function (item) {
        return _this8.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toLowerCase().includes(v);
        });
      });
    }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf& ***!
  \**************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6& ***!
  \************************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
<<<<<<< HEAD
  return _c("div", { staticClass: "container" }, [
    _c("div", { staticClass: "row" }, [
      _c(
        "nav",
        { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
        [
          _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
            _vm._v("WING VAN SECTION")
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNav" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-list"
                        }
                      },
                      [_vm._v("Wing Van List")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-location"
                        }
                      },
                      [_vm._v("Route")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-po"
                        }
                      },
                      [_vm._v("Purchase Order")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-rental"
                        }
                      },
                      [_vm._v("Rental")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-soa"
                        }
                      },
                      [_vm._v("Create SOA")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-payment"
                        }
                      },
                      [_vm._v("Payment Collection")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-ledger"
                        }
                      },
                      [_vm._v("Ledger")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-reports"
                        }
                      },
                      [_vm._v("Reports")]
                    )
                  ],
                  1
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "container" }, [
        _c("div", { staticClass: "row mt-3" }, [
          _vm._v("\n        Search by SOA Date\n        "),
          _c("div", { staticClass: "col-sm" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.datefrom,
                  expression: "datefrom"
                }
              ],
              staticClass: "form-control form-control-sm mb-2",
              attrs: { type: "date", placeholder: "Search Rental..." },
              domProps: { value: _vm.datefrom },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.datefrom = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-sm" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.dateto,
                  expression: "dateto"
                }
              ],
              staticClass: "form-control form-control-sm mb-2",
              attrs: { type: "date", placeholder: "Search Rental..." },
              domProps: { value: _vm.dateto },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.dateto = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                on: {
                  click: function($event) {
                    return _vm.get_soa()
                  }
                }
              },
              [_vm._v("Generate")]
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row mt-2" }, [
          _c(
            "div",
            { staticClass: "col" },
            [
              _c("ag-grid-vue", {
                staticClass: "ag-theme-balham",
                staticStyle: { width: "1050px", height: "200px" },
                attrs: {
                  columnDefs: _vm.columnDefs,
                  rowData: _vm.filter,
                  rowSelection: "multiple"
                },
                on: {
                  "grid-ready": _vm.onGridReady,
                  selectionChanged: _vm.onChange
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row mt-3" }, [
          _c("div", { staticClass: "col" }, [
            _c("h4", [_vm._v("Entry Payments")]),
            _vm._v(" "),
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    return _vm.create_payment()
                  }
                }
              },
              [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-sm" }, [
                    _c("label", { attrs: { for: "refence" } }, [
                      _vm._v("Billed To")
                    ]),
                    _vm._v(" "),
                    _c(
                      "select",
                      {
=======
  return _c(
    "div",
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12" }, [
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.generate()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-3" }, [
                        _c("div", { staticClass: "form-group" }, [
                          _c("label", [_vm._v("SOA Date From")]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.from,
                                expression: "from"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "date",
                              name: "from",
                              placeholder: ""
                            },
                            domProps: { value: _vm.from },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.from = $event.target.value
                              }
                            }
                          })
                        ])
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-3" }, [
                        _c("div", { staticClass: "form-group" }, [
                          _c("label", [_vm._v("SOA Date From")]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.to,
                                expression: "to"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "date",
                              name: "to",
                              placeholder: ""
                            },
                            domProps: { value: _vm.to },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.to = $event.target.value
                              }
                            }
                          })
                        ])
                      ]),
                      _vm._v(" "),
                      _vm._m(1),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4" }, [
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c("label", [_vm._v("Transmittal Number")]),
                            _vm._v(" "),
                            _c(
                              "b-input-group",
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.transmittal_no,
                                      expression: "transmittal_no"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "transmittal_no",
                                    placeholder: "",
                                    disabled: ""
                                  },
                                  domProps: { value: _vm.transmittal_no },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.transmittal_no = $event.target.value
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "b-input-group-append",
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.getTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-sync",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.searchTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-search",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.printTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-print",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ])
                    ])
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-6 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _c("thead", { staticClass: "dave-thead" }, [
                      _c("tr", [
                        _c(
                          "th",
                          {
                            staticStyle: {
                              "text-align": "center",
                              width: "10%"
                            }
                          },
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.checkHeader,
                                  expression: "checkHeader"
                                }
                              ],
                              staticStyle: { height: "10px !important" },
                              attrs: {
                                type: "checkbox",
                                checked: "checked",
                                id: "checkboxAll"
                              },
                              domProps: {
                                checked: Array.isArray(_vm.checkHeader)
                                  ? _vm._i(_vm.checkHeader, null) > -1
                                  : _vm.checkHeader
                              },
                              on: {
                                click: function($event) {
                                  return _vm.checkTableAll()
                                },
                                change: function($event) {
                                  var $$a = _vm.checkHeader,
                                    $$el = $event.target,
                                    $$c = $$el.checked ? true : false
                                  if (Array.isArray($$a)) {
                                    var $$v = null,
                                      $$i = _vm._i($$a, $$v)
                                    if ($$el.checked) {
                                      $$i < 0 &&
                                        (_vm.checkHeader = $$a.concat([$$v]))
                                    } else {
                                      $$i > -1 &&
                                        (_vm.checkHeader = $$a
                                          .slice(0, $$i)
                                          .concat($$a.slice($$i + 1)))
                                    }
                                  } else {
                                    _vm.checkHeader = $$c
                                  }
                                }
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v("SOA")
                        ]),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v(
                            "\n                                        Billed Amount\n                                    "
                          )
                        ]),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v(
                            "\n                                        Invoice No\n                                    "
                          )
                        ]),
                        _vm._v(" "),
                        _c(
                          "th",
                          {
                            staticStyle: {
                              "text-align": "center",
                              width: "20%"
                            }
                          },
                          [
                            _vm._v(
                              "\n                                        Action\n                                    "
                            )
                          ]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody modal-tbody" },
                      _vm._l(_vm.filteredBlogs, function(item) {
                        return _c(
                          "tr",
                          {
                            key: item.id,
                            on: {
                              click: function($event) {
                                return _vm.rowClick(item)
                              }
                            }
                          },
                          [
                            _c(
                              "td",
                              {
                                staticStyle: {
                                  width: "10%",
                                  "text-align": "center"
                                }
                              },
                              [
                                _c("input", {
                                  staticStyle: { height: "10px !important" },
                                  attrs: { id: item.AHID, type: "checkbox" },
                                  on: {
                                    click: function($event) {
                                      return _vm.checkTable(item)
                                    }
                                  }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.SOANo) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatNumber")(item.TotalAmount)
                                  ) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.invoice_number) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                staticStyle: { width: "20%" }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-eye text-primary",
                                  staticStyle: { "font-size": "120%" },
                                  on: {
                                    click: function($event) {
                                      return _vm.clickDetails(item.AHID)
                                    }
                                  }
                                })
                              ]
                            )
                          ]
                        )
                      }),
                      0
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-6" }, [
                _c("div", { staticClass: "row" }, [
                  _vm._m(2),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-7" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Prepared By")]),
                      _vm._v(" "),
                      _c("input", {
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
<<<<<<< HEAD
                            value: _vm.form.mode,
                            expression: "form.mode"
                          }
                        ],
                        staticClass: "form-control form-control-sm",
                        attrs: { required: true },
                        on: {
                          change: function($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function(o) {
                                return o.selected
                              })
                              .map(function(o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.$set(
                              _vm.form,
                              "mode",
                              $event.target.multiple
                                ? $$selectedVal
                                : $$selectedVal[0]
                            )
                          }
                        }
                      },
                      _vm._l(_vm.mode, function(m) {
                        return _c(
                          "option",
                          { key: m.id, domProps: { value: m.name } },
                          [_vm._v(_vm._s(m.name))]
                        )
                      }),
                      0
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-sm" }, [
                    _c("label", { attrs: { for: "date" } }, [
                      _vm._v("Payment Date")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.payment_date,
                          expression: "form.payment_date"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: { type: "date" },
                      domProps: { value: _vm.form.payment_date },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.form,
                            "payment_date",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-sm-6" }, [
                    _c("label", { attrs: { for: "refence" } }, [
                      _vm._v("OR / Ref No")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.or_ref_no,
                          expression: "form.or_ref_no"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: { type: "text" },
                      domProps: { value: _vm.form.or_ref_no },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "or_ref_no", $event.target.value)
                        }
                      }
                    })
=======
                            value: _vm.prepared_by,
                            expression: "prepared_by"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "prepared_by",
                          placeholder: "",
                          disabled: ""
                        },
                        domProps: { value: _vm.prepared_by },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.prepared_by = $event.target.value
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.createTransmittal()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-check-square",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Create Transmittal\n                                    "
                          )
                        ]
                      )
                    ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
<<<<<<< HEAD
                  _c("div", { staticClass: "col" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Check Card No")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.check_card_no,
                          expression: "form.check_card_no"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: { type: "text" },
                      domProps: { value: _vm.form.check_card_no },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.form,
                            "check_card_no",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Check Card / Bank Name")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.check_card_bank_name,
                          expression: "form.check_card_bank_name"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: { type: "text" },
                      domProps: { value: _vm.form.check_card_bank_name },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.form,
                            "check_card_bank_name",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Amount")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.amount,
                          expression: "form.amount"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      staticStyle: { "text-align": "right" },
                      attrs: { type: "text" },
                      domProps: { value: _vm.form.amount },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "amount", $event.target.value)
                        }
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col" }, [
                    _c("label", { attrs: { for: "exampleInputEmail1" } }, [
                      _vm._v("Applied Amount")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.applied_amount,
                          expression: "form.applied_amount"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      staticStyle: { "text-align": "right" },
                      attrs: { type: "text", disabled: "" },
                      domProps: { value: _vm.form.applied_amount },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.form,
                            "applied_amount",
                            $event.target.value
                          )
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row mt-2" }, [
                  _c("div", { staticClass: "col" }, [
                    _c("label", { attrs: { for: "remarks" } }, [
                      _vm._v("Remarks")
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.remarks,
                          expression: "form.remarks"
                        }
                      ],
                      staticClass: "form-control form-control-sm",
                      attrs: { type: "text" },
                      domProps: { value: _vm.form.remarks },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "remarks", $event.target.value)
                        }
                      }
                    })
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row mt-2" }, [
                  _c("div", { staticClass: "col" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-secondary",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            return _vm.clear()
                          }
                        }
                      },
                      [_vm._v("New / Clear")]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-success",
                        attrs: { type: "submit" }
                      },
                      [_vm._v("Save")]
                    )
                  ])
                ])
              ]
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
=======
                  _vm._m(3),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-7" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", [_vm._v("SOA Number")]),
                        _vm._v(" "),
                        _c(
                          "b-input-group",
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.SoaTransNo,
                                  expression: "SoaTransNo"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "SoaTransNo",
                                placeholder: "",
                                disabled: ""
                              },
                              domProps: { value: _vm.SoaTransNo },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.SoaTransNo = $event.target.value
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "b-input-group-append",
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      variant: "outline-primary",
                                      size: "sm"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.searchAllowanceSOAHeaderButton()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-search",
                                      attrs: { "aria-hidden": "true" }
                                    })
                                  ]
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.removeTransmittal()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-times",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Remove Transmittal\n                                    "
                          )
                        ]
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _vm._m(4),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Invoice Number")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.invoicedtls.invoice_number,
                            expression: "invoicedtls.invoice_number"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "invoice_number",
                          placeholder: ""
                        },
                        domProps: { value: _vm.invoicedtls.invoice_number },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.invoicedtls,
                              "invoice_number",
                              $event.target.value
                            )
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Invoice Date")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.invoicedtls.invoice_date,
                            expression: "invoicedtls.invoice_date"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "date",
                          name: "invoice_date",
                          placeholder: ""
                        },
                        domProps: { value: _vm.invoicedtls.invoice_date },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.invoicedtls,
                              "invoice_date",
                              $event.target.value
                            )
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.addInvoice()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-save",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Save\n                                    "
                          )
                        ]
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _vm._m(5)
                ])
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("search-transmittal", {
        on: {
          rowClick: function($event) {
            return _vm.transmittalClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-allowanceSOAHeader", {
        on: {
          rowClick: function($event) {
            return _vm.allowanceSOAHeaderClose($event)
          }
        }
      }),
      _vm._v(" "),
      _c("search-allowanceDetail")
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("Create/Generate Allowance Transmittal")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-2" }, [
      _c("label", [_vm._v(" ")]),
      _vm._v(" "),
      _c("div", { staticClass: "form-group" }, [
        _c(
          "button",
          {
            staticClass: "btn btn-primary",
            attrs: { type: "submit", bold: "" }
          },
          [
            _c("i", {
              staticClass: "fa fa-search",
              attrs: { "aria-hidden": "true" }
            }),
            _vm._v(
              "\n                                            SEARCH\n                                        "
            )
          ]
        )
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-12" }, [
      _c("h6", [_c("b", [_c("i", [_vm._v("Create/Generate Transmittal")])])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-12" }, [
      _c("h6", [_c("b", [_c("i", [_vm._v("Remove Transmittal Number")])])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12 text-center" }, [
        _c("h5", [_c("i", [_vm._v("***ADD INVOICE NUMBER HERE***")])])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-12" }, [
      _c("i", [_c("b", [_vm._v("*Select SOA from list to add invoice*")])])
    ])
  }
]
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-Payment.vue":
/*!*************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Payment.vue ***!
  \*************************************************************/
=======
/***/ "./resources/js/components/allowance/Transmittal.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/allowance/Transmittal.vue ***!
  \***********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Payment.vue?vue&type=template&id=506fa9bf& */ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&");
/* harmony import */ var _WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-Payment.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&");
=======
/* harmony import */ var _Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Transmittal.vue?vue&type=template&id=d1924bc6& */ "./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&");
/* harmony import */ var _Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Transmittal.vue?vue&type=script&lang=js& */ "./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
<<<<<<< HEAD
  _WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
  _Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/wingvan/WingVan-Payment.vue"
=======
component.options.__file = "resources/js/components/allowance/Transmittal.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
=======
/***/ "./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Payment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&":
/*!********************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf& ***!
  \********************************************************************************************/
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Transmittal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6& ***!
  \******************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Payment.vue?vue&type=template&id=506fa9bf& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Payment.vue?vue&type=template&id=506fa9bf&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Payment_vue_vue_type_template_id_506fa9bf___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Transmittal.vue?vue&type=template&id=d1924bc6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/allowance/Transmittal.vue?vue&type=template&id=d1924bc6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_d1924bc6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);