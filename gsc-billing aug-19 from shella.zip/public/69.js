(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[69],{

<<<<<<< HEAD
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/ShowDetailModal.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PPE/ShowDetailModal.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _search_golfcart_transmittal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search/golfcart-transmittal.vue */ "./resources/js/components/search/golfcart-transmittal.vue");
/* harmony import */ var _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchAllowance/SearchSignatories.vue */ "./resources/js/components/search/SearchAllowance/SearchSignatories.vue");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
=======
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      rows: [],
      search: "",
      type: "",
      detailList: [],
      dataInDetail: false
    };
  },
  mounted: function mounted() {
    var _this = this;

    Fire.$on("searchPPEDetail", function (data) {
      _this.getData(data);

      $("#SearchPPEDetail").modal("show");
    });
  },
  methods: {
    getData: function getData(id) {
      var _this2 = this;

      axios.get("api/ppe", {
        params: {
          getDtl: true,
          id: id
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          _this2.dataInDetail = true;
          _this2.detailList = response.data;
        } else {
          _this2.detailList = [];
          _this2.dataInDetail = false;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this3 = this;

      return this.detailList.filter(function (item) {
        return _this3.search.toLowerCase().split(" ").every(function (v) {
          return item.Description.toLowerCase().includes(v);
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/Transmittal.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PPE/Transmittal.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _search_SearchAllowance_SearchTransmittal_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../search/SearchAllowance/SearchTransmittal.vue */ "./resources/js/components/search/SearchAllowance/SearchTransmittal.vue");
/* harmony import */ var _PPE_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../PPE/ShowDetailModal.vue */ "./resources/js/components/PPE/ShowDetailModal.vue");
/* harmony import */ var _search_SearchAllowance_SearchPPEHeader_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../search/SearchAllowance/SearchPPEHeader.vue */ "./resources/js/components/search/SearchAllowance/SearchPPEHeader.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
<<<<<<< HEAD
    'search-transmittal': _search_golfcart_transmittal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    'search-signatory': _search_SearchAllowance_SearchSignatories_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
      DateFrom: '',
      DateTo: '',
      columnDefs: [],
      csoas: [],
      signatories: {
        noted_by: '',
        noted_by_des: '',
        prepared_by: '',
        prepared_by_des: ''
      },
      TransmittalNo: ''
    };
  },
  mounted: function mounted() {
    this.loadCSOA();
    this.getTransmittalNo();
    this.getUser();
  },
  created: function created() {
    var today = new Date().toISOString().slice(0, 10);
    this.DateFrom = today;
    this.DateTo = today;
  },
  methods: {
    onGridReady: function onGridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
    },
    searchSearchSignatoryButton: function searchSearchSignatoryButton(number) {
      Fire.$emit('searchSignatory', number);
    },
    transmittalClose: function transmittalClose(row) {
      this.transmittal_no = row.series_no;
    },
    signatoryClose: function signatoryClose(row) {
      if (row.number == 1) {
        this.signatories.noted_by = row.SignatoryName;
        this.signatories.noted_by_des = row.Designation;
      }
    },
    getTransmittalNo: function getTransmittalNo() {
      var _this = this;

      axios.get('api/jTNo').then(function (_ref) {
        var data = _ref.data;
        _this.TransmittalNo = data;
      });
    },
    printTransmittal: function printTransmittal() {
      var _this2 = this;

      this.$Progress.start();
      axios.get('api/reportJeepTransmittal', {
        params: {
          searchTransmittalExists: true,
          transmittal_no: this.transmittal_no
        }
      }).then(function (response) {
        if (response.data.success) {
          window.open('api/reportJeepTransmittal?report=true&transmittal_no=' + _this2.transmittal_no);

          _this2.getTransmittalNo();

          _this2.loadCSOA();
        } else {
          return toast.fire({
            icon: 'warning',
            title: 'No data found in this transmittal number.'
          });
        }

        _this2.$Progress.finish();
      })["catch"](function (error) {
        return toast.fire({
          icon: 'warning',
          title: 'Something went wrong.'
        });
      });
    },
    searchTransmittal: function searchTransmittal() {
      Fire.$emit('searchTransmittal', 'jeep');
    },
    createTransmittal: function createTransmittal() {
      var _this3 = this;

      var selectedNodes = this.gridApi.getSelectedNodes();
      var selectedData = selectedNodes.map(function (node) {
        return node.data;
      });
      var selectedDataStringPresentation = selectedData.map(function (node) {
        return node.Soa_JeepID;
      }).join(',');

      if (!selectedDataStringPresentation) {
        return swal.fire('Confirmation!', 'Select Transaction to Proceed', 'warning');
      }

      if (!this.TransmittalNo) {
        return swal.fire('Confirmation!', 'No transmittal no to be saved', 'warning');
      }

      if (!this.signatories.noted_by) {
        return swal.fire('Confirmation!', 'Select Noted By to Proceed', 'warning');
      }

      var data = Object.assign({}, this.signatories);
      data.ids = selectedDataStringPresentation;
      axios.post('jeep/create_transmittal/', data).then(function (_ref2) {
        var response = _ref2.response;
        swal.fire('SUCCESS!', 'The transmittal has been created.', 'success');

        _this3.printTransmittal();
      })["catch"](function (error) {
        swal.fire('ERROR!', 'Something went wrong', 'error');
      });
    },
    getUser: function getUser() {
      var _this4 = this;

      axios.get('api/allowance', {
        params: {
          getUser: true
        }
      }).then(function (response) {
        _this4.signatories.prepared_by = response.data.name;
=======
    "search-transmittal": _search_SearchAllowance_SearchTransmittal_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    "search-ppeDetail": _PPE_ShowDetailModal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    "search-ppeHeader": _search_SearchAllowance_SearchPPEHeader_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      from: this.$root.formatDate(new Date()),
      to: this.$root.formatDate(new Date()),
      checkTableArrays: [],
      checkHeader: false,
      rows: [],
      search: "",
      transmittal_no: "",
      prepared_by: "",
      SOANo: "",
      SoaTransNo: "",
      invoicedtls: {
        invoice_number: "",
        invoice_date: this.$root.formatDate(new Date()),
        SOANo: "",
        type: "ppe"
      }
    };
  },
  mounted: function mounted() {
    this.generate();
    this.getUser();
    this.getTransmittal();
  },
  methods: {
    checkTableAll: function checkTableAll() {
      if (!this.checkHeader) {
        var arrays = [];
        var index = 0;
        this.rows.forEach(function (item) {
          arrays.push(item);
          document.getElementById(item.PHID).checked = true;
        });
        this.checkTableArrays = arrays;
      } else {
        this.rows.forEach(function (item) {
          document.getElementById(item.PHID).checked = false;
        });
        this.checkTableArrays = [];
      }
    },
    checkTable: function checkTable(row) {
      if (this.checkTableArrays.indexOf(row) < 0) {
        this.checkTableArrays.push(row);
      } else {
        this.checkTableArrays.splice(this.checkTableArrays.indexOf(row), 1);
      }
    },
    generate: function generate() {
      var _this = this;

      this.checkHeader = false;
      this.checkTableArrays = [];
      axios.get("api/ppe", {
        params: {
          SOAHeaderDate: true,
          from: this.from,
          to: this.to
        }
      }).then(function (response) {
        console.log(response);
        _this.rows = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getUser: function getUser() {
      var _this2 = this;

      axios.get("api/allowance", {
        params: {
          getUser: true
        }
      }).then(function (response) {
        _this2.prepared_by = response.data.name;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getTransmittal: function getTransmittal() {
      var _this3 = this;

      this.$Progress.start();
      axios.get("api/allowance", {
        params: {
          getTransmittalNo: true
        }
      }).then(function (response) {
        if (response.data.length > 0) {
          _this3.transmittal_no = response.data;
        } else {
          var dateNow = new Date();
          var month = dateNow.getMonth() + 1;
          _this3.transmittal_no = "TF" + dateNow.getFullYear().toString().substring(2) + month.toString().padStart(2, "0") + "-1";
        }

        _this3.$Progress.finish();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    clickDetails: function clickDetails(id) {
      Fire.$emit("searchPPEDetail", id);
    },
    rowClick: function rowClick(row) {
      console.log(row);
      this.invoicedtls.SOANo = row.SOANo;
      this.invoicedtls.invoice_number = row.invoice_number;
      this.invoicedtls.invoice_date = row.invoice_date == '0000-00-00' ? this.$root.formatDate(new Date()) : row.invoice_date;
      console.log(this.invoicedtls);
    },
    createTransmittal: function createTransmittal() {
      var _this4 = this;

      if (this.checkTableArrays.length < 1) {
        return toast.fire({
          icon: "warning",
          title: "No Data Selected."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Create Transmittal!"
      }).then(function (result) {
        if (result.value) {
          _this4.$Progress.start();

          axios.get("api/allowance", {
            params: {
              searchTransmittalExists: true,
              transmittal_no: _this4.transmittal_no
            }
          }).then(function (response) {
            if (response.data.length > 0) {
              swal.fire({
                title: "Transmittal Number Already Exists!",
                text: "Do you want to merge current selected records?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, Merge it!"
              }).then(function (result) {
                if (result.value) {
                  _this4.$Progress.start();

                  var submitArray = [];

                  _this4.checkTableArrays.forEach(function (item) {
                    submitArray.push(item.SOANo);
                  });

                  var data = {
                    transmittal_no: _this4.transmittal_no,
                    prepared_by: _this4.prepared_by,
                    soa_no_list: submitArray,
                    type: "PPE",
                    merge: true
                  };

                  _this4.$Progress.start();

                  axios.post("api/allowanceCreateTransmittal", data).then(function (response) {
                    if (response.data.success) {
                      _this4.checkTableArrays = [];
                      _this4.rows = [];
                      _this4.checkHeader = false;
                      _this4.SOANo = "";
                      _this4.prepared_by = "";
                      _this4.SoaTransNo = "";
                      window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this4.transmittal_no + "&type=PPE");
                      _this4.transmittal_no = "";

                      _this4.generate();

                      _this4.getUser();

                      _this4.getTransmittal();
                    } else {
                      toast.fire({
                        icon: "warning",
                        title: response.data.message
                      });
                    }

                    _this4.$Progress.finish();
                  })["catch"](function (error) {
                    console.log(error);
                  });
                } else {
                  swal.fire("Information!", "Cancelled.", "warning");
                }
              });
            } else {
              _this4.$Progress.start();

              var submitArray = [];

              _this4.checkTableArrays.forEach(function (item) {
                submitArray.push(item.SOANo);
              });

              var data = {
                transmittal_no: _this4.transmittal_no,
                prepared_by: _this4.prepared_by,
                type: "PPE",
                soa_no_list: submitArray
              };

              _this4.$Progress.start();

              axios.post("api/allowanceCreateTransmittal", data).then(function (response) {
                if (response.data.success) {
                  _this4.checkTableArrays = [];
                  _this4.rows = [];
                  _this4.checkHeader = false;
                  _this4.SOANo = "";
                  _this4.prepared_by = "";
                  _this4.SoaTransNo = "";
                  window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this4.transmittal_no + "&type=PPE");
                  _this4.transmittal_no = "";

                  _this4.generate();

                  _this4.getUser();

                  _this4.getTransmittal();
                } else {
                  toast.fire({
                    icon: "warning",
                    title: response.data.message
                  });
                }

                _this4.$Progress.finish();
              })["catch"](function (error) {
                console.log(error);
              });
            }

            _this4.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    addInvoice: function addInvoice() {
      var _this5 = this;

      if (!this.invoicedtls.invoice_number) {
        return toast.fire({
          icon: "warning",
          title: "Requirement. Please enter Invoice Number."
        });
      }

      this.$Progress.start();
      axios.post("api/addInvoiceNumber", this.invoicedtls).then(function (response) {
        if (response.data.success) {
          _this5.generate();

          _this5.invoicedtls = {
            invoice_number: "",
            invoice_date: _this5.$root.formatDate(new Date()),
            SOANo: "",
            type: "ppe"
          };
          return toast.fire({
            icon: "success",
            title: response.data.message
          });
        } else {
          return toast.fire({
            icon: "warning",
            title: "Something went wrong."
          });
        }

        _this5.$Progress.finish();
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      })["catch"](function (error) {
        console.log(error);
      });
    },
<<<<<<< HEAD
    loadCSOA: function loadCSOA() {
      var _this5 = this;

      this.columnDefs = [{
        headerName: 'SOA Date',
        field: 'JeepSoaDate',
        width: 200,
        resizable: true
      }, {
        headerName: 'SOA No',
        field: 'GSCSoaSeriesNo',
        width: 200,
        resizable: true
      }, {
        headerName: 'Billed To',
        field: 'BilledName',
        width: 300,
        resizable: true
      }, {
        headerName: 'Charge Invoice No',
        field: 'InvoiceNo',
        width: 200,
        resizable: true
      }, {
        headerName: 'Status',
        field: 'Status',
        resizable: true,
        width: 250
      }];
      axios.get('api/getcsoatransmitted', {
        params: {
          from: this.DateFrom,
          to: this.DateTo
        }
      }).then(function (response) {
        console.log(response.data);
        _this5.csoas = response.data;
=======
    removeTransmittal: function removeTransmittal() {
      var _this6 = this;

      if (!this.SOANo) {
        return toast.fire({
          icon: "warning",
          title: "Please select/enter SOA number to continue."
        });
      }

      swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Remove Transmittal #!"
      }).then(function (result) {
        if (result.value) {
          var data = {
            SOANo: _this6.SOANo,
            prepared_by: _this6.prepared_by,
            type: "PPE"
          };

          _this6.$Progress.start();

          axios.post("api/allowanceRemoveTransmittal", data).then(function (response) {
            if (response.data.success) {
              _this6.SOANo = "";
              _this6.SoaTransNo = "";
              toast.fire({
                icon: "success",
                title: response.data.message
              });
            } else {
              toast.fire({
                icon: "warning",
                title: response.data.message
              });
            }

            _this6.$Progress.finish();
          })["catch"](function (error) {
            console.log(error);
          });
        } else {
          swal.fire("Information!", "Cancelled.", "warning");
        }
      });
    },
    searchPPEHeaderButton: function searchPPEHeaderButton() {
      Fire.$emit("searchPPEHeader", "transmittal");
    },
    PPEHeaderClose: function PPEHeaderClose(row) {
      this.SoaTransNo = row.SOANo + " ( " + row.transmittal_no + ")";
      this.SOANo = row.SOANo;
    },
    searchTransmittal: function searchTransmittal() {
      Fire.$emit("searchTransmittal", "ppe");
    },
    transmittalClose: function transmittalClose(row) {
      this.transmittal_no = row.transmittal_no;
    },
    printTransmittal: function printTransmittal() {
      var _this7 = this;

      axios.get("api/reportAllowanceTransmittal", {
        params: {
          searchTransmittalExists: true,
          transmittal_no: this.transmittal_no,
          type: "PPE"
        }
      }).then(function (response) {
        if (response.data.success) {
          window.open("api/reportAllowanceTransmittal?report=true&transmittal_no=" + _this7.transmittal_no + "&type=PPE");

          _this7.getTransmittal();
        } else {
          return toast.fire({
            icon: "warning",
            title: "No data found in this transmittal number."
          });
        }

        _this7.$Progress.finish();
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      })["catch"](function (error) {
        console.log(error);
      });
    }
<<<<<<< HEAD
=======
  },
  created: function created() {},
  computed: {
    filteredBlogs: function filteredBlogs() {
      var _this8 = this;

      return this.rows.filter(function (item) {
        return _this8.search.toLowerCase().split(" ").every(function (v) {
          return item.SOANo.toLowerCase().includes(v);
        });
      });
    }
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  }
});

/***/ }),

<<<<<<< HEAD
/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\ninput[data-readonly] {\r\n\tpointer-events: none;\n}\n#stringinput {\r\n\tmin-width: 500px;\r\n\tmin-height: 80px;\r\n\tmax-width: 500px;\r\n\tmax-height: 80px;\r\n\ttext-align: left;\r\n\toverflow-y: auto;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./JeepSOATransmittal.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=template&id=160ff670&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=template&id=160ff670& ***!
  \************************************************************************************************************************************************************************************************************************************/
=======
/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/ShowDetailModal.vue?vue&type=template&id=31d49d3a&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PPE/ShowDetailModal.vue?vue&type=template&id=31d49d3a& ***!
  \**********************************************************************************************************************************************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
<<<<<<< HEAD
    { staticClass: "container", attrs: { id: "sweget" } },
    [
      _c(
        "nav",
        {
          staticClass:
            "navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light"
        },
        [
=======
    {
      staticClass: "modal fade dave-template",
      attrs: {
        id: "SearchPPEDetail",
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "addNewLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        {
          staticClass: "modal-dialog modal-dialog-centered modal-lg",
          attrs: { role: "document" }
        },
        [
          _c("div", { staticClass: "modal-content" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("div", { staticClass: "modal-body-cus" }, [
              _c("div", { staticClass: "container-fluid" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12 table-height" }, [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-hover table-striped dave-table"
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          { staticClass: "dave-tbody modal-tbody" },
                          [
                            _c(
                              "tr",
                              {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: !_vm.dataInDetail,
                                    expression: "!dataInDetail"
                                  }
                                ]
                              },
                              [_vm._m(2)]
                            ),
                            _vm._v(" "),
                            _vm._l(_vm.filteredBlogs, function(item) {
                              return _c("tr", { key: item.PEDID }, [
                                _c("td", [
                                  _vm._v(
                                    _vm._s(_vm._f("formatDate")(item.Date))
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.InvoiceNo))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Description))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Qty))]),
                                _vm._v(" "),
                                _c("td", [_vm._v(_vm._s(item.Unit))]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(
                                    _vm._s(_vm._f("formatNumber")(item.Price))
                                  )
                                ]),
                                _vm._v(" "),
                                _c("td", [
                                  _vm._v(
                                    "\n                                        " +
                                      _vm._s(
                                        _vm._f("formatNumber")(item.Amount)
                                      ) +
                                      "\n                                    "
                                  )
                                ])
                              ])
                            })
                          ],
                          2
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "modal-header-cus" }, [
      _c("div", { staticClass: "row container-fluid" }, [
        _c("div", { staticClass: "col-md-11" }, [
          _c("h5", [_c("b", [_vm._v("PPE Detail List")])])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-md-1" }, [
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          _c(
            "button",
            {
              staticClass: "close close-modal",
              attrs: {
                type: "button",
                "data-dismiss": "modal",
                "aria-label": "Close"
              }
            },
<<<<<<< HEAD
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#mlist"
                      }
                    },
                    [
                      _vm._v(
                        "\n                                Master File\n                                "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "mlist"
=======
            [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
          )
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "dave-thead" }, [
      _c("tr", [
        _c("th", [_vm._v("Date")]),
        _vm._v(" "),
        _c("th", [_vm._v("Invoice No.")]),
        _vm._v(" "),
        _c("th", [_vm._v("Description")]),
        _vm._v(" "),
        _c("th", [_vm._v("Qty")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit")]),
        _vm._v(" "),
        _c("th", [_vm._v("Unit Price")]),
        _vm._v(" "),
        _c("th", [_vm._v("Amount")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("td", { staticClass: "text-center", attrs: { colspan: "7" } }, [
      _c("i", [_vm._v("No Data Found...")])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/Transmittal.vue?vue&type=template&id=69f1640a&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/PPE/Transmittal.vue?vue&type=template&id=69f1640a& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container dave-template" },
    [
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "card-body table-responsive" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-12" }, [
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.generate()
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-md-3" }, [
                        _c("div", { staticClass: "form-group" }, [
                          _c("label", [_vm._v("SOA Date From")]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.from,
                                expression: "from"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "date",
                              name: "from",
                              placeholder: ""
                            },
                            domProps: { value: _vm.from },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.from = $event.target.value
                              }
                            }
                          })
                        ])
                      ]),
                      _vm._v(" "),
<<<<<<< HEAD
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/operatorlist" }
                            },
                            [_c("a", [_vm._v("Operator List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehiclelist" }
                            },
                            [_c("a", [_vm._v("JEEP Vehicle List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehicletype" }
                            },
                            [_c("a", [_vm._v("Vehicle Type List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/vehiclerate" }
                            },
                            [_c("a", [_vm._v("JEEP Rate List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/clientlist" }
                            },
                            [_c("a", [_vm._v("Client List")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/ratePercent" }
                            },
                            [_c("a", [_vm._v("Admin Rate Percentage")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#trans"
                      }
                    },
                    [
                      _vm._v(
                        "\n                                Transactions\n                                "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "trans"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/jeepvehiclelogentry" }
                            },
                            [_c("a", [_vm._v("Jeep Vehicle Log Entry")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/createsoa" }
                            },
                            [_c("a", [_vm._v("Create Jeep SOA")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/soatransactions" }
                            },
                            [_c("a", [_vm._v("SOA Transaction")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-item dropdown" }, [
                  _c(
                    "a",
                    {
                      staticClass: "nav-link dropdown-toggle",
                      attrs: {
                        href: "#",
                        id: "navbarDropdownMenuLink",
                        role: "button",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                        "data-target": "#report"
                      }
                    },
                    [
                      _vm._v(
                        "\n                                Jeep Reports\n                                "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "ul",
                    {
                      staticClass: "dropdown-menu",
                      attrs: {
                        "aria-labelledby": "navbarDropdownMenuLink",
                        id: "report"
                      }
                    },
                    [
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistJVL" }
                            },
                            [_c("a", [_vm._v("Standard Jeep Report")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/reportlistJVLPerJeep" }
                            },
                            [
                              _c("a", [
                                _vm._v("Jeepney's Vehicle Log Billing Report")
                              ])
                            ]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass: "dropdown-item",
                              attrs: { to: "/JeepSOATransmittal" }
                            },
                            [_c("a", [_vm._v("Jeepney's SOA Transmittal")])]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ])
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "col-xs-12" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._m(0),
            _vm._v(" "),
            _c("br"),
            _vm._v(" "),
            _c(
              "form",
              {
                staticStyle: {
                  "border-style": "solid",
                  "border-color": "coral"
                },
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    return _vm.loadCSOA($event)
                  }
                }
              },
              [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "form-inline col-md-8" }, [
                    _c(
                      "div",
                      {
                        staticClass: "input-group mb-3 input-group-sm",
                        staticStyle: {
                          "margin-top": "10px",
                          "margin-left": "5px"
                        }
                      },
                      [
                        _vm._m(1),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.DateFrom,
                              expression: "DateFrom"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "date",
                            name: "DateFrom",
                            required: ""
                          },
                          domProps: { value: _vm.DateFrom },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.DateFrom = $event.target.value
                            }
                          }
                        })
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        staticClass: "input-group mb-3 input-group-sm",
                        staticStyle: {
                          "margin-top": "10px",
                          "margin-left": "5px"
                        }
                      },
                      [
                        _vm._m(2),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.DateTo,
                              expression: "DateTo"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: { type: "date", name: "DateTo", required: "" },
                          domProps: { value: _vm.DateTo },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.DateTo = $event.target.value
                            }
                          }
                        }),
                        _vm._v(" "),
                        _vm._m(3)
                      ]
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-3" }, [
                    _c(
                      "div",
                      {
                        staticClass: "input-group mb-3 input-group-sm",
                        staticStyle: {
                          "margin-top": "10px",
                          "margin-left": "5px"
                        }
                      },
                      [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.TransmittalNo,
                              expression: "TransmittalNo"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "TransmittalNo",
                            readonly: ""
                          },
                          domProps: { value: _vm.TransmittalNo },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.TransmittalNo = $event.target.value
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("div", { staticClass: "input-group-append" }, [
                          _c(
                            "button",
                            {
                              staticClass: "btn btn-outline-secondary",
                              attrs: { type: "button" },
                              on: { click: _vm.searchTransmittal }
                            },
                            [_c("i", { staticClass: "fa fa-search" })]
                          ),
                          _vm._v(" "),
                          _c(
                            "button",
                            {
                              staticClass: "btn btn-outline-primary",
                              attrs: { type: "button" },
                              on: { click: _vm.printTransmittal }
                            },
                            [_c("i", { staticClass: "fa fa-print" })]
                          )
                        ])
                      ]
                    )
                  ])
                ])
              ]
            ),
            _vm._v(" "),
            _c("br")
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card-body" }, [
            _c("div", { staticClass: "row" }, [
              _c(
                "div",
                { staticClass: "col-md-12" },
                [
                  _c("ag-grid-vue", {
                    staticClass: "ag-theme-balham",
                    staticStyle: { width: "100%", height: "300px" },
                    attrs: {
                      columnDefs: _vm.columnDefs,
                      rowData: _vm.csoas,
                      rowSelection: "multiple"
                    },
                    on: { "grid-ready": _vm.onGridReady }
                  })
                ],
                1
              )
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-6" }, [
                _c("label", [_vm._v("Prepared By")]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.signatories.prepared_by,
                      expression: "signatories.prepared_by"
                    }
                  ],
                  staticClass: "form-control",
                  attrs: {
                    type: "text",
                    name: "Prepared_by",
                    placeholder: "",
                    required: "",
                    disabled: ""
                  },
                  domProps: { value: _vm.signatories.prepared_by },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(
                        _vm.signatories,
                        "prepared_by",
                        $event.target.value
                      )
                    }
                  }
                })
              ]),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "col-md-6" },
                [
                  _c("label", [_vm._v("Noted By")]),
                  _vm._v(" "),
                  _c(
                    "b-input-group",
                    [
=======
                      _c("div", { staticClass: "col-md-3" }, [
                        _c("div", { staticClass: "form-group" }, [
                          _c("label", [_vm._v("SOA Date From")]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.to,
                                expression: "to"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "date",
                              name: "to",
                              placeholder: ""
                            },
                            domProps: { value: _vm.to },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.to = $event.target.value
                              }
                            }
                          })
                        ])
                      ]),
                      _vm._v(" "),
                      _vm._m(1),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-4" }, [
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c("label", [_vm._v("Transmittal Number")]),
                            _vm._v(" "),
                            _c(
                              "b-input-group",
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.transmittal_no,
                                      expression: "transmittal_no"
                                    }
                                  ],
                                  staticClass: "form-control",
                                  attrs: {
                                    type: "text",
                                    name: "transmittal_no",
                                    placeholder: "",
                                    disabled: ""
                                  },
                                  domProps: { value: _vm.transmittal_no },
                                  on: {
                                    input: function($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.transmittal_no = $event.target.value
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "b-input-group-append",
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.getTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-sync",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.searchTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-search",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        attrs: {
                                          variant: "outline-primary",
                                          size: "sm"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.printTransmittal()
                                          }
                                        }
                                      },
                                      [
                                        _c("i", {
                                          staticClass: "fa fa-print",
                                          attrs: { "aria-hidden": "true" }
                                        })
                                      ]
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ])
                    ])
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-6 table-height" }, [
                _c(
                  "table",
                  { staticClass: "table table-hover table-striped dave-table" },
                  [
                    _c("thead", { staticClass: "dave-thead" }, [
                      _c("tr", [
                        _c(
                          "th",
                          {
                            staticStyle: {
                              "text-align": "center",
                              width: "10%"
                            }
                          },
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.checkHeader,
                                  expression: "checkHeader"
                                }
                              ],
                              staticStyle: { height: "10px !important" },
                              attrs: {
                                type: "checkbox",
                                checked: "checked",
                                id: "checkboxAll"
                              },
                              domProps: {
                                checked: Array.isArray(_vm.checkHeader)
                                  ? _vm._i(_vm.checkHeader, null) > -1
                                  : _vm.checkHeader
                              },
                              on: {
                                click: function($event) {
                                  return _vm.checkTableAll()
                                },
                                change: function($event) {
                                  var $$a = _vm.checkHeader,
                                    $$el = $event.target,
                                    $$c = $$el.checked ? true : false
                                  if (Array.isArray($$a)) {
                                    var $$v = null,
                                      $$i = _vm._i($$a, $$v)
                                    if ($$el.checked) {
                                      $$i < 0 &&
                                        (_vm.checkHeader = $$a.concat([$$v]))
                                    } else {
                                      $$i > -1 &&
                                        (_vm.checkHeader = $$a
                                          .slice(0, $$i)
                                          .concat($$a.slice($$i + 1)))
                                    }
                                  } else {
                                    _vm.checkHeader = $$c
                                  }
                                }
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v("SOA")
                        ]),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v(
                            "\n                                        Billed Amount\n                                    "
                          )
                        ]),
                        _vm._v(" "),
                        _c("th", { staticStyle: { "text-align": "center" } }, [
                          _vm._v(
                            "\n                                        Invoice Number\n                                    "
                          )
                        ]),
                        _vm._v(" "),
                        _c(
                          "th",
                          {
                            staticStyle: {
                              "text-align": "center",
                              width: "20%"
                            }
                          },
                          [
                            _vm._v(
                              "\n                                        Action\n                                    "
                            )
                          ]
                        )
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      { staticClass: "dave-tbody modal-tbody" },
                      _vm._l(_vm.filteredBlogs, function(item) {
                        return _c(
                          "tr",
                          {
                            on: {
                              click: function($event) {
                                return _vm.rowClick(item)
                              }
                            }
                          },
                          [
                            _c(
                              "td",
                              {
                                staticStyle: {
                                  width: "10%",
                                  "text-align": "center"
                                }
                              },
                              [
                                _c("input", {
                                  staticStyle: { height: "10px !important" },
                                  attrs: { id: item.PHID, type: "checkbox" },
                                  on: {
                                    click: function($event) {
                                      return _vm.checkTable(item)
                                    }
                                  }
                                })
                              ]
                            ),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.SOANo) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(
                                    _vm._f("formatNumber")(item.TotalAmount)
                                  ) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-center" }, [
                              _vm._v(
                                "\n                                        " +
                                  _vm._s(item.invoice_number) +
                                  "\n                                    "
                              )
                            ]),
                            _vm._v(" "),
                            _c(
                              "td",
                              {
                                staticClass: "text-center",
                                staticStyle: { width: "20%" }
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-eye text-primary",
                                  staticStyle: { "font-size": "120%" },
                                  on: {
                                    click: function($event) {
                                      return _vm.clickDetails(item.PHID)
                                    }
                                  }
                                })
                              ]
                            )
                          ]
                        )
                      }),
                      0
                    )
                  ]
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-6" }, [
                _c("div", { staticClass: "row" }, [
                  _vm._m(2),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-7" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Prepared By")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.prepared_by,
                            expression: "prepared_by"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "prepared_by",
                          placeholder: "",
                          disabled: ""
                        },
                        domProps: { value: _vm.prepared_by },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.prepared_by = $event.target.value
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.createTransmittal()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-check-square",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Create Transmittal\n                                    "
                          )
                        ]
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _vm._m(3),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-7" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", [_vm._v("SOA Number")]),
                        _vm._v(" "),
                        _c(
                          "b-input-group",
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.SoaTransNo,
                                  expression: "SoaTransNo"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "SoaTransNo",
                                placeholder: "",
                                disabled: ""
                              },
                              domProps: { value: _vm.SoaTransNo },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.SoaTransNo = $event.target.value
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "b-input-group-append",
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      variant: "outline-primary",
                                      size: "sm"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.searchPPEHeaderButton()
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fa fa-search",
                                      attrs: { "aria-hidden": "true" }
                                    })
                                  ]
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.removeTransmittal()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-times",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Remove Transmittal\n                                    "
                          )
                        ]
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _vm._m(4),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Invoice Number")]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.invoicedtls.invoice_number,
                            expression: "invoicedtls.invoice_number"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "invoice_number",
                          placeholder: ""
                        },
                        domProps: { value: _vm.invoicedtls.invoice_number },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.invoicedtls,
                              "invoice_number",
                              $event.target.value
                            )
                          }
                        }
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-5" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", [_vm._v("Invoice Date")]),
                      _vm._v(" "),
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
<<<<<<< HEAD
                            value: _vm.signatories.noted_by,
                            expression: "signatories.noted_by"
=======
                            value: _vm.invoicedtls.invoice_date,
                            expression: "invoicedtls.invoice_date"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
<<<<<<< HEAD
                          type: "text",
                          name: "Prepared_by",
                          placeholder: "",
                          required: "",
                          disabled: ""
                        },
                        domProps: { value: _vm.signatories.noted_by },
=======
                          type: "date",
                          name: "invoice_date",
                          placeholder: ""
                        },
                        domProps: { value: _vm.invoicedtls.invoice_date },
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
<<<<<<< HEAD
                              _vm.signatories,
                              "noted_by",
=======
                              _vm.invoicedtls,
                              "invoice_date",
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
                              $event.target.value
                            )
                          }
                        }
<<<<<<< HEAD
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-primary", size: "sm" },
                              on: {
                                click: function($event) {
                                  return _vm.searchSearchSignatoryButton(1)
                                }
                              }
                            },
                            [
                              _c("i", {
                                staticClass: "fa fa-search",
                                attrs: { "aria-hidden": "true" }
                              })
                            ]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card-footer" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-success",
                    on: { click: _vm.createTransmittal }
                  },
                  [
                    _vm._v(
                      "\n                    Create Transmittal\n                "
                    )
                  ]
                )
=======
                      })
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-2" }, [
                    _c("label", [_vm._v(" ")]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-group" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          attrs: { type: "button", bold: "" },
                          on: {
                            click: function($event) {
                              return _vm.addInvoice()
                            }
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-save",
                            attrs: { "aria-hidden": "true" }
                          }),
                          _vm._v(
                            "\n                                        Save\n                                    "
                          )
                        ]
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _vm._m(5)
                ])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("search-transmittal", {
        on: {
          rowClick: function($event) {
            return _vm.transmittalClose($event)
          }
        }
      }),
      _vm._v(" "),
<<<<<<< HEAD
      _c("search-signatory", {
        on: {
          rowClick: function($event) {
            return _vm.signatoryClose($event)
=======
      _c("search-ppeHeader", {
        on: {
          rowClick: function($event) {
            return _vm.PPEHeaderClose($event)
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
          }
        }
      }),
      _vm._v(" "),
      _c("search-ppeDetail")
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("h3", { staticClass: "card-title" }, [
      _c("b", [_vm._v("For Transmittal Jeep SOA")])
=======
    return _c("div", { staticClass: "card-header" }, [
      _c("h3", { staticClass: "card-title" }, [
        _c("b", [_vm._v("Create/Generate PEE Transmittal")])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-tools" })
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date From")
=======
    return _c("div", { staticClass: "col-md-2" }, [
      _c("label", [_vm._v(" ")]),
      _vm._v(" "),
      _c("div", { staticClass: "form-group" }, [
        _c(
          "button",
          {
            staticClass: "btn btn-primary",
            attrs: { type: "submit", bold: "" }
          },
          [
            _c("i", {
              staticClass: "fa fa-search",
              attrs: { "aria-hidden": "true" }
            }),
            _vm._v(
              "\n                                            SEARCH\n                                        "
            )
          ]
        )
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-prepend" }, [
      _c("span", { staticClass: "input-group-text" }, [
        _vm._v("Search Date To")
      ])
=======
    return _c("div", { staticClass: "col-md-12" }, [
      _c("h6", [_c("b", [_c("i", [_vm._v("Create/Generate Transmittal")])])])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-12" }, [
      _c("h6", [_c("b", [_c("i", [_vm._v("Remove Transmittal Number")])])])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
<<<<<<< HEAD
    return _c("div", { staticClass: "input-group-append" }, [
      _c("button", { staticClass: "btn btn-outline-secondary" }, [
        _vm._v("Search")
      ])
=======
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12 text-center" }, [
        _c("h5", [_c("i", [_vm._v("***ADD INVOICE NUMBER HERE***")])])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-12" }, [
      _c("i", [_c("b", [_vm._v("*Select SOA from list to add invoice*")])])
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
    ])
  }
]
render._withStripped = true



/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/components/JeepComponents/JeepSOATransmittal.vue ***!
  \***********************************************************************/
=======
/***/ "./resources/js/components/PPE/ShowDetailModal.vue":
/*!*********************************************************!*\
  !*** ./resources/js/components/PPE/ShowDetailModal.vue ***!
  \*********************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _JeepSOATransmittal_vue_vue_type_template_id_160ff670___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./JeepSOATransmittal.vue?vue&type=template&id=160ff670& */ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=template&id=160ff670&");
/* harmony import */ var _JeepSOATransmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./JeepSOATransmittal.vue?vue&type=script&lang=js& */ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JeepSOATransmittal.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

=======
/* harmony import */ var _ShowDetailModal_vue_vue_type_template_id_31d49d3a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ShowDetailModal.vue?vue&type=template&id=31d49d3a& */ "./resources/js/components/PPE/ShowDetailModal.vue?vue&type=template&id=31d49d3a&");
/* harmony import */ var _ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ShowDetailModal.vue?vue&type=script&lang=js& */ "./resources/js/components/PPE/ShowDetailModal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc





/* normalize component */

<<<<<<< HEAD
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _JeepSOATransmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _JeepSOATransmittal_vue_vue_type_template_id_160ff670___WEBPACK_IMPORTED_MODULE_0__["render"],
  _JeepSOATransmittal_vue_vue_type_template_id_160ff670___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
=======
var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ShowDetailModal_vue_vue_type_template_id_31d49d3a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ShowDetailModal_vue_vue_type_template_id_31d49d3a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
<<<<<<< HEAD
component.options.__file = "resources/js/components/JeepComponents/JeepSOATransmittal.vue"
=======
component.options.__file = "resources/js/components/PPE/ShowDetailModal.vue"
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

<<<<<<< HEAD
/***/ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
=======
/***/ "./resources/js/components/PPE/ShowDetailModal.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/PPE/ShowDetailModal.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./JeepSOATransmittal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css& ***!
  \********************************************************************************************************/
/*! no static exports found */
=======
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ShowDetailModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/ShowDetailModal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/PPE/ShowDetailModal.vue?vue&type=template&id=31d49d3a&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/PPE/ShowDetailModal.vue?vue&type=template&id=31d49d3a& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_template_id_31d49d3a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./ShowDetailModal.vue?vue&type=template&id=31d49d3a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/ShowDetailModal.vue?vue&type=template&id=31d49d3a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_template_id_31d49d3a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ShowDetailModal_vue_vue_type_template_id_31d49d3a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/PPE/Transmittal.vue":
/*!*****************************************************!*\
  !*** ./resources/js/components/PPE/Transmittal.vue ***!
  \*****************************************************/
/*! exports provided: default */
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./JeepSOATransmittal.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=template&id=160ff670&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=template&id=160ff670& ***!
  \******************************************************************************************************/
=======
/* harmony import */ var _Transmittal_vue_vue_type_template_id_69f1640a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Transmittal.vue?vue&type=template&id=69f1640a& */ "./resources/js/components/PPE/Transmittal.vue?vue&type=template&id=69f1640a&");
/* harmony import */ var _Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Transmittal.vue?vue&type=script&lang=js& */ "./resources/js/components/PPE/Transmittal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Transmittal_vue_vue_type_template_id_69f1640a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Transmittal_vue_vue_type_template_id_69f1640a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/PPE/Transmittal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/PPE/Transmittal.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/PPE/Transmittal.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Transmittal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/Transmittal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/PPE/Transmittal.vue?vue&type=template&id=69f1640a&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/PPE/Transmittal.vue?vue&type=template&id=69f1640a& ***!
  \************************************************************************************/
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
<<<<<<< HEAD
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_template_id_160ff670___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./JeepSOATransmittal.vue?vue&type=template&id=160ff670& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/JeepComponents/JeepSOATransmittal.vue?vue&type=template&id=160ff670&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_template_id_160ff670___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_JeepSOATransmittal_vue_vue_type_template_id_160ff670___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
=======
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_69f1640a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Transmittal.vue?vue&type=template&id=69f1640a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/PPE/Transmittal.vue?vue&type=template&id=69f1640a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_69f1640a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Transmittal_vue_vue_type_template_id_69f1640a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });
>>>>>>> e1abd072882465a997fdfd95314e12a6683697bc



/***/ })

}]);