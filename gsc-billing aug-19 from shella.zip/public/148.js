(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[148],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WingVan_SOA_Search_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-SOA-Search.vue */ "./resources/js/components/wingvan/WingVan-SOA-Search.vue");
/* harmony import */ var _WingVan_Menu_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-Menu.vue */ "./resources/js/components/wingvan/WingVan-Menu.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    'search-soa': _WingVan_SOA_Search_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    'wingvan-menu': _WingVan_Menu_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    AgGridVue: AgGridVue
  },
  data: function data() {
    return {
      soa_no: '',
      balanceAmount: '0.00',
      balance: 0,
      amountPhp: '0.00',
      amount: 0,
      paidAmount: '0.00',
      paid: 0,
      numeral: __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js"),
      filter: []
    };
  },
  methods: {
    searchReference: function searchReference() {
      $('#searchSOA').modal('show');
    },
    get_soa: function get_soa(data) {
      this.soa_no = data.series_no;
      this.amountPhp = this.numeral(data.amount).format('0,0.00');
      this.amount = data.amount;
      this.getBalance(data.id);
    },
    getBalance: function getBalance(id) {
      var _this = this;

      axios.get('wingvan/payments/' + id).then(function (response) {
        var sum = 0;
        response.data.data.forEach(function (item) {
          sum = sum + parseFloat(item.amount);
          item.amountPhp = _this.numeral(item.amount).format('0,0.00');
        });
        _this.filter = response.data.data;
        _this.balance = _this.amount - sum;
        _this.paid = sum;
        _this.paidAmount = _this.numeral(sum).format('0,0.00');
        _this.balanceAmount = _this.numeral(_this.balance).format('0,0.00');
      });
    }
  },
  created: function created() {
    this.columnDefs = [{
      headerName: 'Date',
      field: 'payment_date',
      resizable: true,
      width: 170
    }, {
      headerName: 'Mode',
      field: 'mode',
      resizable: true,
      width: 170
    }, {
      headerName: 'OR/Ref. No',
      field: 'or_ref_no',
      resizable: true,
      width: 170
    }, {
      headerName: 'Check No',
      field: 'check_card_no',
      resizable: true,
      width: 170
    }, {
      headerName: 'Bank Name',
      field: 'check_card_bank_name',
      resizable: true,
      width: 270
    }, {
      headerName: 'Amount',
      field: 'amountPhp',
      resizable: true,
      width: 170,
      cellClass: 'text-right'
    }];
    this.filter = [];
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340& ***!
  \*************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c("div", { staticClass: "row" }, [
      _c("img", { attrs: { src: __webpack_require__(/*! ./WingVan.png */ "./resources/js/components/wingvan/WingVan.png") } }),
      _vm._v(" "),
      _c(
        "nav",
        { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
        [
          _c("span", { staticClass: "navbar-brand mb-0 h3" }, [
            _vm._v("WING VAN SECTION")
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "collapse navbar-collapse",
              attrs: { id: "navbarNav" }
            },
            [
              _c("ul", { staticClass: "navbar-nav" }, [
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-list"
                        }
                      },
                      [_vm._v("Wing Van List")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-location"
                        }
                      },
                      [_vm._v("Route")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-po"
                        }
                      },
                      [_vm._v("Purchase Order")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-rental"
                        }
                      },
                      [_vm._v("Rental")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-soa"
                        }
                      },
                      [_vm._v("Create SOA")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-payment"
                        }
                      },
                      [_vm._v("Payment Collection")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-ledger"
                        }
                      },
                      [_vm._v("Ledger")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "li",
                  { staticClass: "nav-item" },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "nav-link",
                        attrs: {
                          tag: "a",
                          "active-class": "active",
                          exact: "",
                          to: "/wingvan-reports"
                        }
                      },
                      [_vm._v("Reports")]
                    )
                  ],
                  1
                )
              ])
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "container" },
        [
          _vm._m(0),
          _vm._v(" "),
          _c("div", { staticClass: "row mt-6 mb-3" }, [
            _c("div", { staticClass: "col-4" }, [
              _c("div", { staticClass: "input-group" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.soa_no,
                      expression: "soa_no"
                    }
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { type: "text", name: "soa_no", disabled: "" },
                  domProps: { value: _vm.soa_no },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.soa_no = $event.target.value
                    }
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "input-group-btn" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-outline-primary btn-sm",
                      attrs: { type: "button" },
                      on: {
                        click: function($event) {
                          return _vm.searchReference()
                        }
                      }
                    },
                    [_vm._v("Search")]
                  )
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-8" }, [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col" }, [
                  _c("div", { staticClass: "mb-2" }, [
                    _c("span", { staticStyle: { "font-size": "16px" } }, [
                      _vm._v("Amount: Php " + _vm._s(this.amountPhp))
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col" }, [
                  _c("div", { staticClass: "mb-2" }, [
                    _c("span", { staticStyle: { "font-size": "16px" } }, [
                      _vm._v("Total Paid: Php " + _vm._s(this.paidAmount))
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col" }, [
                  _c("div", { staticClass: "mb-2" }, [
                    _c("span", { staticStyle: { "font-size": "16px" } }, [
                      _vm._v("Balance: Php " + _vm._s(this.balanceAmount))
                    ])
                  ])
                ])
              ])
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c(
              "div",
              { staticClass: "col" },
              [
                _c("ag-grid-vue", {
                  staticClass: "ag-theme-balham",
                  staticStyle: { height: "200px" },
                  attrs: { columnDefs: _vm.columnDefs, rowData: _vm.filter }
                })
              ],
              1
            )
          ]),
          _vm._v(" "),
          _c("search-soa", { on: { search: _vm.get_soa } })
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row mt-3" }, [
      _c("div", { staticClass: "col-sm-6" }, [
        _c("label", { attrs: { for: "refence" } }, [_vm._v("SOA #")])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Ledger.vue":
/*!************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Ledger.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WingVan-Ledger.vue?vue&type=template&id=01d04340& */ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&");
/* harmony import */ var _WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WingVan-Ledger.vue?vue&type=script&lang=js& */ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["render"],
  _WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/wingvan/WingVan-Ledger.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Ledger.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./WingVan-Ledger.vue?vue&type=template&id=01d04340& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/wingvan/WingVan-Ledger.vue?vue&type=template&id=01d04340&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WingVan_Ledger_vue_vue_type_template_id_01d04340___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);