<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class DmpiDar extends Model
{
    public function get_soa_dar($refid){

        $query = collect(DB::connection('mysql')->select("SELECT * FROM dmpi_dar_dtls dtl LEFT JOIN dmpi_dar_hdrs hdr ON hdr.id= dtl.hdr_id LEFT JOIN rate_masters rate ON dtl.rate_id= rate.id WHERE hdr.id = $refid"));
        return $query;
    }
}
