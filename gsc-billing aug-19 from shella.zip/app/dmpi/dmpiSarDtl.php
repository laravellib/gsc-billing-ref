<?php

namespace App\dmpi;

use Illuminate\Database\Eloquent\Model;

class dmpiSarDtl extends Model
{
    protected $guarded = [];
}
