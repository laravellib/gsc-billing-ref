<?php

namespace App\dmpi;

use Illuminate\Database\Eloquent\Model;

class dmpiSar extends Model
{
    protected $guarded = [];
}
