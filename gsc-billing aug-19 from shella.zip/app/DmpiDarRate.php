<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DmpiDarRate extends Model
{
    protected $guarded = [];
}
