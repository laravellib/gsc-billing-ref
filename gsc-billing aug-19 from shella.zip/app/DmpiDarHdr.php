<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DmpiDarHdr extends Model
{
    protected $guarded = [];
}
