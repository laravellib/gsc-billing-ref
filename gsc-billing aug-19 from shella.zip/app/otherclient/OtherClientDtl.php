<?php

namespace App\otherclient;

use Illuminate\Database\Eloquent\Model;

class OtherClientDtl extends Model
{
    //
}
