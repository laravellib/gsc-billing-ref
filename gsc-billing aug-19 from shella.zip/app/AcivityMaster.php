
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcivityMaster extends Model
{
    protected $guarded = [];
}
