<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GlMaster extends Model
{
    protected $guarded = [];
}
