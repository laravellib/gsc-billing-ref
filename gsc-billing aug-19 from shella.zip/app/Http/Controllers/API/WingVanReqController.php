<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use App\Model\WingVanModel\WingVanReq;
use Illuminate\Support\Facades\Auth;
Use App\Model\WingVanModel\WingVanLedger;
use DB;
class WingVanReqController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct() 
    {
        $this->middleware('auth:api')->only(['store']);
        // $this->middleware('auth');
        // $this->user =  \Auth::user();
    }

    public function index()
    {
        return WingVanReq::latest()->paginate(10);
    }

    public function store_client(Request $request)
    {
        if ($request['id'] == 0){
            $req = new WingVanReq;
            $req->req_id = $request['req_id'];
            $req->date = $request['req_date'];
            $req->type = "CLIENT DMPI";
            $req->po_no = $request['doc_no'];
            $req->po_date = $request['date'];
            $req->po_route = $request['route'];
            $req->po_activity = $request['activity'];
            $req->client = "";
            $req->vehicle_name ="";
            $req->serial_no = "";
            $req->gross_amount = $request['rate'];
            $req->no_trips = $request['qty'];
            $req->po_detail_id = $request['po_detail_id'];
            $req->amount = $request['amount'];
            $req->encoded_by = Auth::user()->name;
            $req->encoded_id = Auth::user()->id;
            $req->status = "ACTIVE";
            $req->FuelLiters = $request['FuelLiters'] ? $request['FuelLiters'] : 0;
            $req->FuelRate = $request['FuelRate'] ? $request['FuelRate'] : 0;
            $req->LessFuel = $request['LessFuel'] ? $request['LessFuel'] : 0;
            $req->MaintenanceCost = $request['MaintenanceCost'] ? $request['MaintenanceCost'] : 0;
            $req->LessAdmin = $request['LessAdmin'] ? $request['LessAdmin'] : 0;
            $req->Helper = $request['Helper'] ? $request['Helper'] : 0;
            $req->Labor = $request['Labor'] ? $request['Labor'] : 0;
            $req->DriverID = $request['DriverID'] ? $request['DriverID'] : 0;
            $req->DriverName = $request['DriverName'] ? $request['DriverName'] : '';
            $req->save();
         }else {
            $req['req_id'] = $request['req_id'];
            $req['date'] = $request['req_date'];
            $req['po_no'] = $request['doc_no'];
            $req['po_date'] = $request['date'];
            $req['po_route'] = $request['route'];
            $req['po_activity'] = $request['activity'];
            $req['po_detail_id'] = $request['po_detail_id'];
            $req['gross_amount'] = $request['rate'];
            $req['no_trips'] = $request['qty'];
            $req['amount'] = $request['amount'] ? $request['amount'] : 0;
            $req['FuelLiters'] = $request['FuelLiters'] ? $request['FuelLiters'] : 0;
            $req['FuelRate'] = $request['FuelRate'] ? $request['FuelRate'] : 0;
            $req['LessFuel'] = $request['LessFuel'] ? $request['LessFuel'] : 0;
            $req['MaintenanceCost'] = $request['MaintenanceCost'] ? $request['MaintenanceCost'] : 0;
            $req['LessAdmin'] = $request['LessAdmin'] ? $request['LessAdmin'] : 0;
            $req['Helper'] = $request['Helper'] ? $request['Helper'] : 0;
            $req['Labor'] = $request['Labor'] ? $request['Labor'] : 0;
            $req['DriverID'] = $request['DriverID'] ? $request['DriverID'] : 0;
            $req['DriverName'] = $request['DriverName'] ? $request['DriverName'] : '';
            WingVanReq::FindOrFail($request['id'])->update($req);
        }
         return $req;
    }

    public function store_outsider(Request $request)
    {
        
        if ($request['id'] == 0){
            $req = new WingVanReq;
            $req->req_id = $request['req_id'];
            $req->date = $request['req_date'];
            $req->type = "CLIENT OUTSIDER";
            $req->po_no = "";
            $req->po_date = "";
            $req->po_route = "";
            $req->po_activity = $request['activity'];
            $req->client = $request['client'];
            $req->vehicle_name = $request['vehicle_name'];
            $req->serial_no = $request['serial_no'];
            $req->gross_amount = $request['rate'];
            $req->no_trips = $request['qty'];
            $req->amount = $request['amount'];
            $req->encoded_by = Auth::user()->name;
            $req->encoded_id = Auth::user()->id;
            $req->status = "ACTIVE";
            $req->save();

        }else {

            $req['req_id'] = $request['req_id'];
            $req['date'] = $request['req_date'];
            $req['client'] = $request['client'];
            $req['vehicle_name'] = $request['vehicle_name'];
            $req['serial_no'] = $request['serial_no'];
            $req['po_activity'] = $request['activity'];
            $req['gross_amount'] = $request['rate'];
            $req['no_trips'] = $request['qty'];
            $req['amount'] = $request['amount'];
            WingVanReq::FindOrFail($request['id'])->update($req);
        }

         return $req;
    }

    public function get_requisition_dmpi(){
        return ['data'=>WingVanReq::where('type','CLIENT DMPI')->get()];
    }

    public function get_requisition_outsider(){
        

        return ['data'=>WingVanReq::where('type','CLIENT OUTSIDER')->get()];
    }

    public function req_post($id)
    {
        $detail =  WingVanReq::where('id',$id)->first();
        WingVanLedger::insert(['po_detail_id'=>$detail->po_detail_id,'qty'=>$detail->no_trips,'type'=>'RENTAL']);
        return ['data'=> WingVanReq::FindOrFail($id)->update(['status'=>'POSTED'])];
    }

    public function req_post_outsider($id)
    {
        return ['data'=> WingVanReq::FindOrFail($id)->update(['status'=>'POSTED'])];
    }

    public function report($from, $to){
        $Collected = "SELECT SUM(b.amount) FROM wingvan_payment b WHERE b.soa_link = a.soaid_link";
        $CheckNo = "SELECT b.check_card_no FROM wingvan_payment b WHERE b.soa_link = a.soaid_link AND mode = 'CHECK' LIMIT 1";
        $CheckDate = "SELECT b.payment_date FROM wingvan_payment b WHERE b.soa_link = a.soaid_link AND mode = 'CHECK' LIMIT 1";
        return ['data'=> DB::connection('mysql')->select("SELECT a.*, (". $Collected .") AS Collected, (". $CheckNo .") AS CheckNumber, (". $CheckDate .") AS CheckDate FROM wingvan_requisition a WHERE a.date BETWEEN '".$from."' AND '".$to."'")];
    }

    public function search($from,$to)
    {
        return ['data'=>WingVanReq::where('soaid_link',0)->whereBetween('date',[$from,$to])->get()];
    }


  
}
