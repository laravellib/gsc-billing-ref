<?php

namespace App\Exports;

use App\DmpiDar;
use App\Payroll;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class SoaDARExport implements ShouldAutoSize,FromView
{
    /**
    * @return \Illuminate\Support\Collection
    */
    function __construct($refid) {
            $this->id = $refid;

    }

    public function view(): View
    {
        $DmpiDarModel = new DmpiDar();
        $data = $DmpiDarModel->get_soa_dar($this->id);
        $payroll = new Payroll();
        $companyInfo= $payroll->getCompanyInfo();

        return view('exports.SoaDar_view', [
            'records' => $data,
            'company' => $companyInfo
        ]);
    }

   
}
