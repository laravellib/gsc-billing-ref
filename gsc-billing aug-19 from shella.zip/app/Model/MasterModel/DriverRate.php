<?php

namespace App\Model\MasterModel;

use Illuminate\Database\Eloquent\Model;

class DriverRate extends Model
{
    //
    protected $table = 'tbldriverrate';
      protected $fillable = [
        'type', 'rate'
    ];
}
