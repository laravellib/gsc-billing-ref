<?php

namespace App\Model\MasterModel;

use Illuminate\Database\Eloquent\Model;

class MotorVehicleRentalRate extends Model
{
    //
    protected $table = 'motor_vehicle_rental_rate';
    protected $guarded = [];
}
