<?php

namespace App\PHBModel;

use Illuminate\Database\Eloquent\Model;
use DB;
class PHBVehicleLogHDR extends Model
{
    public function getFilterFilter($idsajvcpfilter){

        $jvcpfilter = DB::select("SELECT BillAmount,CollectedAmount,BalanceAmount FROM tblphbvehicleloghdr WHERE PHBVLHDRID in (''+$idsajvcpfilter+'') ");
        return $jvcpfilter;
    }

    public function getbalamt($idsajvcpbalamt){

        $jvcpfilter = DB::select("SELECT BalanceAmount FROM tblphbvehicleloghdr WHERE PHBVLHDRID = $idsajvcpbalamt ");
        return $jvcpfilter;
    }

    public function getDateFromTo($datefrom,$dateto){

        $jvcpfilter = DB::select("SELECT * FROM tblphbvehicleloghdr WHERE PHBVLDate between '$datefrom' AND '$dateto' ");
        return $jvcpfilter;
    }

    public function kuhaalldata(){

        $jvcpfilter = DB::select("SELECT * FROM tblphbvehicleloghdr");
        return $jvcpfilter;
    }
    
    protected $table = 'tblphbvehicleloghdr';
    protected $primaryKey = 'PHBVLHDRID';
    protected $fillable = [
        'PHBVLDate', 
        'OVLNo',
        'OVLType',
        'PHBIDLink',
        'PHBPlateNo',
        'DriverIDLink',
        'DriverName',
        'DriverLastName',
        'DriverFirstName',
        'DriverMiddleName',
        'DriverExtName',
        'GLCode',
        'CostCenter',
        'PerKilometerRate',
        'startreading',
        'endreading',
        'totalrun',
        'totalactualrun',
        'BillAmount',
        'LessAdmin',
        'FuelAmount',
        'FuelLiters',
        'FuelRate',
        'NetTrucker',
        'Status',
        'CollectedAmount',
        'ORCRNumber',
        'ORCRDate',
        'TimeIn',
        'TimeOut',
        'Assignment',
        'LocationName',
        'Helper',
        'MaintenanceCost',
        'Labor',
        'CheckNumber',
        'CheckDate',
        'ModeOfPayment',
        'PaymentRemarks',
        'DocHeaderText',
        'ServiceEntrySheet',
        'RefNo',
        'PONo',
        'ExtraRunAmount',
        'ExtraRun',
        'CheckBank',
        'PaymentRemarks',
    ];
   
}
