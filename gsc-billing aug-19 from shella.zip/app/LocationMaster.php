<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LocationMaster extends Model
{
    protected $guarded = [];
}
